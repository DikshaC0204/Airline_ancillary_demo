import React, { useEffect, useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { api } from '../api/client';

const Header = () => {
  const [probe, setProbe] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api
      .probeScorer()
      .then((data) => {
        if (!cancelled) setProbe(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setProbe({ ok: false, endpoint: 'unconfigured', error: err.message });
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const liveCount = Number(probe?.live_count || 0);
  const totalCount = Number(probe?.total_count || 0);
  const live = Boolean(probe?.ok);
  const statusWord = probe?.source === 'serving-status' ? 'ready' : 'live';
  const label = !probe
    ? 'Checking Databricks…'
    : totalCount
      ? `Databricks ${liveCount}/${totalCount} ${statusWord}${
          probe.final_score != null ? ` · final ${Number(probe.final_score).toFixed(3)}` : ''
        }`
      : live
        ? `Databricks live · ${probe.endpoint || 'serving'}`
        : `Databricks down · ${probe.endpoint || 'serving'}`;

  return (
    <header className="bg-brand-navy text-white px-4 md:px-6 py-3 flex justify-between items-center shadow-md">
      <Link to="/" className="text-2xl md:text-3xl font-black tracking-tight text-brand-coral">
        TredAir
      </Link>
      <div className="flex items-center gap-2 sm:gap-3">
        {probe !== undefined && (
          <span
            title={probe?.error || probe?.url || ''}
            className={`hidden lg:inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold ${
              live ? 'bg-emerald-500/20 text-emerald-200' : 'bg-white/10 text-white/70'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${live ? 'bg-emerald-400' : 'bg-amber-400'}`} />
            {label}
          </span>
        )}
        <NavLink
          to="/demo/scenarios"
          className={({ isActive }) =>
            `hidden md:inline-flex items-center justify-center rounded-md px-3 py-1.5 text-sm font-bold transition-colors ${
              isActive ? 'bg-white/15 text-white' : 'text-white/80 hover:text-white'
            }`
          }
        >
          Scenarios
        </NavLink>
        <NavLink
          to="/demo/commercial-dial"
          className={({ isActive }) =>
            `hidden md:inline-flex items-center justify-center rounded-md px-3 py-1.5 text-sm font-bold transition-colors ${
              isActive ? 'bg-white/15 text-white' : 'text-white/80 hover:text-white'
            }`
          }
        >
          Commercial dial
        </NavLink>
        <NavLink
          to="/manage"
          className={({ isActive }) =>
            `inline-flex items-center justify-center rounded-md px-3 sm:px-4 py-1.5 text-sm font-bold transition-colors border-2 ${
              isActive
                ? 'bg-brand-coral border-brand-coral text-white'
                : 'border-brand-coral text-brand-coral hover:bg-brand-coral hover:text-white'
            }`
          }
        >
          Manage booking
        </NavLink>
        <button
          type="button"
          className="border-2 border-white rounded-md px-3 sm:px-4 py-1.5 text-sm font-bold hover:bg-white hover:text-brand-navy transition-colors"
        >
          Sign in
        </button>
      </div>
    </header>
  );
};

export default Header;
