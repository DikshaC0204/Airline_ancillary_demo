# TredFlight

Reusable **flight scheduling** web app with an explainable **ancillary curation** engine. Built as a generic framework for upcoming airline projects — product codes and fare names are carrier-agnostic; the site brand is **TredFlight**.

Full technical design, diagrams, and DB migration notes: [`architecture.md`](./architecture.md)

## What’s included

- Booking flow: search → flights / fares → passengers & bags → seats → payment → confirmation → manage booking
- Single curation API (`POST /api/v1/curate`) with ranked offers, suppressed products, and reasons
- Tiny transformer ancillary ranker (bundled weights; optional Databricks Model Serving / Docker scorer — see [`ml/README.md`](./ml/README.md))
- Optional **Airline ACE V6** embed: point `ACE_ROOT` at the ACE repo and set `CURATION_SCORER=ace` — see [`ml/ACE_EMBED.md`](./ml/ACE_EMBED.md)
- Local data via **SQLAlchemy + SQLite** (swap `DATABASE_URL` for PostgreSQL when provisioned)
- Demo catalogue: Basic / Smart / Go / Plus, Priority, Fast Track, seats, bags, Flex, partners, etc.
- Any origin/destination search returns bookable demo flights (auto-seeded if the route is missing)

## Repository layout

| Path | Purpose |
|------|---------|
| `frontend/` | React + Vite + Tailwind booking UI |
| `backend/` | FastAPI API, curation engine, SQLite DB |
| `architecture.md` | System architecture and migration guide |
| `requirements.txt` | Python dependencies |

Scenario workbooks and product notes belong in a local `requirement/` folder (gitignored — not committed).

## Quick start

### 1. Backend (port 8000)

```bash
cd backend
# Activate venv (Windows)
.\venv\Scripts\activate
# Or create: python -m venv venv && pip install -r ../requirements.txt

uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

- API: http://127.0.0.1:8000  
- Docs: http://127.0.0.1:8000/docs  
- Health: http://127.0.0.1:8000/api/v1/health  

Run the API on **8000** only; the frontend defaults to that origin.

### 2. Frontend (port 5173)

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173  

Optional: copy `frontend/.env.example` → `.env.local` and set `VITE_API_BASE` if the API is not on `:8000`.

## Storage (local → production DB)

Default: SQLite file at `backend/data/tredflight.db` (created on first run).

When a real database is approved:

```env
DATABASE_URL=postgresql+psycopg://user:pass@host:5432/tredflight
```

ORM models stay the same — see `architecture.md` §4 and §11.

## Requirements source

Demo scenarios and the `/curate` API shape come from the Ancillary Curation Engine workbook (kept locally under `requirement/`, which is gitignored). Implementation lives in `backend/app/services/curation_engine.py` and the booking UI.

## License / demo note

Demo data and mocked inventory / ops feeds. Payment is non-PCI demo UI only.
