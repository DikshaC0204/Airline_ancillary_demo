"""REST routers for TredFlight — backed by Lakebase Postgres via text() SQL."""

from __future__ import annotations

import random
import string
from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app import repositories as repo
from app.config import get_settings
from app.data.major_airports import airport_record, list_major_airports
from app.database import get_db
from app.schemas import (
    AirportOut,
    BookingCreate,
    BookingOut,
    BookingUpdate,
    CurationRequest,
    CurationResponse,
    DeclineOfferRequest,
    FlightOut,
    FlightSearchResult,
    ScorerProbeOut,
    HealthOut,
    InventoryOut,
    ProductOut,
)
from app.services.ancillary_model import probe_serving, scorer_status
from app.services.databricks_ensemble import list_serving_status
from app.services.curation_engine import curate

router = APIRouter()
settings = get_settings()


def _parse_day(day: Optional[str], fallback_days: int = 7) -> datetime:
    base = datetime.utcnow().replace(hour=12, minute=0, second=0, microsecond=0)
    if not day or not str(day).strip():
        return base + timedelta(days=fallback_days)
    try:
        d = datetime.fromisoformat(str(day).strip()[:10])
        return d.replace(hour=12, minute=0, second=0, microsecond=0)
    except ValueError:
        return base + timedelta(days=fallback_days)


_DEFAULT_INVENTORY = {
    "PRIORITY": 30,
    "EXTRA_LEGROOM": 6,
    "BAG_20KG": -1,
    "SECURITY_FAST_TRACK": 15,
}


def _create_day_flights(
    db: Session,
    origin: str,
    destination: str,
    base: datetime,
    count: int = 2,
) -> None:
    """Insert synthetic same-day departures for a route (demo inventory).

    Skips slots whose flight_number already exists so concurrent searches
    do not create duplicate rows.
    """
    day_key = base.strftime("%y%m%d")
    for i in range(count):
        flight_number = f"TF{origin[:1]}{destination[:1]}{day_key}{i}"
        if repo.flight_number_exists(db, flight_number):
            continue
        depart_at = base.replace(hour=7 + i * 5, minute=(i * 17) % 60, second=0, microsecond=0)
        arrive_at = depart_at + timedelta(hours=3, minutes=15)
        repo.create_flight(
            db,
            flight_number=flight_number,
            origin=origin,
            destination=destination,
            depart_at=depart_at,
            arrive_at=arrive_at,
            base_price=round(49.99 + i * 25.0 + (base.toordinal() % 17), 2),
            currency="USD",
            load_factor=round(0.55 + i * 0.1, 2),
            inventory=dict(_DEFAULT_INVENTORY),
        )


def _dedupe_flights(flights: list[dict], limit: int = 8) -> list[dict]:
    """Collapse duplicate synthetic rows (same number or same departure slot)."""
    seen_numbers: set[str] = set()
    seen_slots: set[str] = set()
    out: list[dict] = []
    for flight in flights:
        number = str(flight.get("flight_number") or "")
        depart = flight.get("depart_at")
        if isinstance(depart, datetime):
            slot = depart.strftime("%Y-%m-%dT%H")
        else:
            slot = str(depart)[:13]
        if number and number in seen_numbers:
            continue
        if slot in seen_slots:
            continue
        if number:
            seen_numbers.add(number)
        seen_slots.add(slot)
        out.append(flight)
        if len(out) >= limit:
            break
    return out


def _ensure_route_flights(
    db: Session,
    origin: str,
    destination: str,
    depart_day: Optional[str],
    count: int = 2,
) -> list[dict]:
    """Guarantee bookable flights on the requested calendar day (demo).

    Fast path: return existing same-day flights. If none, create only that day
    (no multi-month backfill on search — use seed_network.py for bulk seed).
    """
    requested = _parse_day(depart_day, fallback_days=7)
    requested_key = requested.date().isoformat()

    existing = _dedupe_flights(
        repo.list_flights_by_route(db, origin, destination, day=requested_key, limit=24),
        limit=count,
    )
    if len(existing) >= count:
        return existing

    origin_meta = airport_record(origin)
    dest_meta = airport_record(destination)
    repo.ensure_airport(
        db,
        origin,
        name=origin_meta["name"],
        city=origin_meta["city"],
        country=origin_meta["country"],
    )
    repo.ensure_airport(
        db,
        destination,
        name=dest_meta["name"],
        city=dest_meta["city"],
        country=dest_meta["country"],
    )

    _create_day_flights(db, origin, destination, requested, count=count)
    db.commit()
    return _dedupe_flights(
        repo.list_flights_by_route(db, origin, destination, day=requested_key, limit=24),
        limit=count,
    )


def _flight_out(flight: dict) -> FlightOut:
    return FlightOut(
        id=flight["id"],
        flight_number=flight["flight_number"],
        origin=flight["origin"],
        destination=flight["destination"],
        depart_at=flight["depart_at"],
        arrive_at=flight["arrive_at"],
        base_price=float(flight["base_price"]),
        currency=flight.get("currency") or "USD",
        load_factor=float(flight.get("load_factor") or 0.65),
        delay_minutes=int(flight.get("delay_minutes") or 0),
        schedule_changed=bool(flight.get("schedule_changed") or False),
        inventory=[
            InventoryOut(
                product_code=i["product_code"],
                remaining=int(i["remaining"]),
                status=i["status"],
            )
            for i in (flight.get("inventory") or [])
        ],
    )


def _product_out(product: dict) -> ProductOut:
    return ProductOut(
        code=product["code"],
        name=product["name"],
        category=product["category"],
        description=product.get("description") or "",
        base_price=float(product.get("base_price") or 0),
        includes=list(product.get("includes") or []),
        metadata_json=dict(product.get("metadata_json") or {}),
    )


def _pnr() -> str:
    return "".join(random.choices(string.ascii_uppercase + string.digits, k=6))


def _calc_total(
    db: Session,
    outbound_id: int,
    return_id: Optional[int],
    fare_code: str,
    selected_products: list[str],
    party: dict,
) -> float:
    total = 0.0
    out_f = repo.get_flight_base(db, outbound_id)
    if out_f:
        total += float(out_f["base_price"])
    if return_id:
        ret_f = repo.get_flight_base(db, return_id)
        if ret_f:
            total += float(ret_f["base_price"])
    fare = repo.get_product(db, fare_code.upper())
    pax = max(1, int(party.get("adults", 1)) + int(party.get("children", 0)))
    if fare:
        total += float(fare["base_price"]) * pax
    for code in selected_products:
        prod = repo.get_product(db, code)
        if prod and prod["category"] != "FARE":
            total += float(prod["base_price"])
    return round(total, 2)


def _booking_out(booking: dict) -> BookingOut:
    return BookingOut(
        id=booking["id"],
        pnr=booking["pnr"],
        passenger_ref=booking["passenger_ref"],
        status=booking["status"],
        trip_type=booking["trip_type"],
        origin=booking["origin"],
        destination=booking["destination"],
        outbound_flight_id=booking.get("outbound_flight_id"),
        return_flight_id=booking.get("return_flight_id"),
        fare_code=booking["fare_code"],
        party=booking.get("party") or {},
        passengers=booking.get("passengers") or [],
        selected_products=booking.get("selected_products") or [],
        extras=booking.get("extras") or {},
        total_amount=float(booking.get("total_amount") or 0),
        currency=booking.get("currency") or "USD",
        promo_code=booking.get("promo_code"),
        created_at=booking["created_at"],
        confirmed_at=booking.get("confirmed_at"),
        outbound_flight=_flight_out(booking["outbound_flight"]) if booking.get("outbound_flight") else None,
        return_flight=_flight_out(booking["return_flight"]) if booking.get("return_flight") else None,
    )


@router.get("/health", response_model=HealthOut)
def health():
    scorer = scorer_status()
    return HealthOut(
        status="ok",
        app=settings.app_name,
        storage="postgresql",
        ancillary_scorer=str(scorer.get("active") or "unknown"),
        serving_endpoint=str(scorer.get("serving_endpoint") or ""),
        serving_configured=bool(scorer.get("serving_configured")),
    )


@router.get("/scorer/probe", response_model=ScorerProbeOut)
def scorer_probe(light: bool = Query(False)):
    """Databricks serving status. `light=true` lists Ready endpoints without invoking them."""
    out = list_serving_status() if light else probe_serving()
    return ScorerProbeOut(**out)


@router.get("/airports", response_model=list[AirportOut])
def list_airports():
    rows = sorted(list_major_airports(), key=lambda a: (a["city"], a["code"]))
    return [AirportOut(**a) for a in rows]


@router.get("/products", response_model=list[ProductOut])
def list_products(
    category: Optional[str] = None,
    db: Session = Depends(get_db),
):
    return [_product_out(p) for p in repo.list_products(db, category)]


@router.get("/flights/search", response_model=FlightSearchResult)
def search_flights(
    origin: str = Query(...),
    destination: str = Query(...),
    depart_date: Optional[str] = None,
    return_date: Optional[str] = None,
    trip_type: str = "return",
    db: Session = Depends(get_db),
):
    origin = (origin or "").strip().upper()
    destination = (destination or "").strip().upper()
    if not origin or not destination:
        raise HTTPException(400, "origin and destination are required")
    if origin == destination:
        raise HTTPException(400, "origin and destination must differ")

    depart_date = depart_date.strip() if depart_date else None
    return_date = return_date.strip() if return_date else None

    outbound = _ensure_route_flights(db, origin, destination, depart_date)
    inbound: list[dict] = []
    if trip_type != "oneway":
        inbound = _ensure_route_flights(db, destination, origin, return_date or depart_date)

    fares = repo.list_fare_bundles(db)

    return FlightSearchResult(
        outbound=[_flight_out(f) for f in outbound],
        inbound=[_flight_out(f) for f in inbound],
        fare_bundles=[_product_out(p) for p in fares],
        message=None if outbound else "No flights found for this route.",
    )


@router.get("/flights/{flight_id}", response_model=FlightOut)
def get_flight(flight_id: int, db: Session = Depends(get_db)):
    flight = repo.get_flight(db, flight_id)
    if not flight:
        raise HTTPException(404, "Flight not found")
    return _flight_out(flight)


_POST_BOOKING_MOMENTS = {
    "PRE_TRIP_REMINDER",
    "PRE_TRIP",
    "MANAGE_BOOKING",
    "MMB",
    "OPS",
    "CHECK_IN",
    "CHECKIN",
    "AIRPORT_ENTRY",
    "SECURITY",
    "AIRPORT",
}


@router.post("/curate", response_model=CurationResponse)
def curate_offers(body: CurationRequest, db: Session = Depends(get_db)):
    profile = repo.get_passenger(db, body.passenger_ref)
    event_stream = list(profile["event_stream"]) if profile else []
    declined = list(profile["declined_products"]) if profile else []

    if profile:
        # Shared demo passenger accumulates declines; only apply them after booking
        # so search/payment still receive model offers.
        if body.moment.upper() in _POST_BOOKING_MOMENTS:
            body.declined_products = list(set(declined + (body.declined_products or [])))
        if body.event_stream:
            event_stream.extend([e.model_dump() for e in body.event_stream])
            event_stream = event_stream[-50:]

    result = curate(body, revenue_fit_dial=settings.revenue_fit_dial)

    if profile:
        impressions = int(profile.get("fatigue_impressions") or 0) + 1
        repo.update_passenger_curation(
            db,
            body.passenger_ref,
            declined_products=list(set(declined + (body.declined_products or []))),
            event_stream=event_stream,
            fatigue_impressions=impressions,
        )
        result.fatigue_state = {
            "impressions": impressions,
            "declines": int(profile.get("fatigue_declines") or 0),
        }

    repo.insert_curation_log(
        db,
        passenger_ref=body.passenger_ref,
        moment=body.moment,
        channel=body.channel,
        request_json=body.model_dump(),
        response_json=result.model_dump(),
    )
    db.commit()
    return result


@router.post("/curate/decline")
def decline_offer(body: DeclineOfferRequest, db: Session = Depends(get_db)):
    profile = repo.ensure_passenger(db, body.passenger_ref)
    declined = list(profile.get("declined_products") or [])
    if body.product not in declined:
        declined.append(body.product)
    fatigue_declines = int(profile.get("fatigue_declines") or 0) + 1
    repo.update_passenger_decline(
        db,
        body.passenger_ref,
        declined_products=declined,
        fatigue_declines=fatigue_declines,
    )
    db.commit()
    return {"ok": True, "declined_products": declined}


@router.post("/bookings", response_model=BookingOut)
def create_booking(body: BookingCreate, db: Session = Depends(get_db)):
    pref = body.passenger_ref or f"SYN-{_pnr()}"
    repo.ensure_passenger(db, pref, display_name="Guest")

    passengers = [p.model_dump() for p in body.passengers] or [
        {"first_name": "", "last_name": "", "type": "adult"}
    ]
    total = _calc_total(
        db,
        body.outbound_flight_id,
        body.return_flight_id,
        body.fare_code,
        body.selected_products,
        body.party,
    )
    booking = repo.create_booking(
        db,
        {
            "pnr": _pnr(),
            "passenger_ref": pref,
            "status": "DRAFT",
            "trip_type": body.trip_type,
            "origin": body.origin.upper(),
            "destination": body.destination.upper(),
            "outbound_flight_id": body.outbound_flight_id,
            "return_flight_id": body.return_flight_id,
            "fare_code": body.fare_code.upper(),
            "party": body.party,
            "passengers": passengers,
            "selected_products": body.selected_products,
            "extras": body.extras,
            "total_amount": total,
            "promo_code": body.promo_code,
        },
    )
    db.commit()
    refreshed = repo.get_booking_by_id(db, booking["id"])
    assert refreshed is not None
    return _booking_out(refreshed)


@router.get("/bookings/{pnr}", response_model=BookingOut)
def get_booking(pnr: str, db: Session = Depends(get_db)):
    booking = repo.get_booking_by_pnr(db, pnr)
    if not booking:
        raise HTTPException(404, "Booking not found")
    return _booking_out(booking)


@router.patch("/bookings/{pnr}", response_model=BookingOut)
def update_booking(pnr: str, body: BookingUpdate, db: Session = Depends(get_db)):
    booking = repo.get_booking_by_pnr(db, pnr)
    if not booking:
        raise HTTPException(404, "Booking not found")

    passengers = booking.get("passengers") or []
    fare_code = booking["fare_code"]
    selected_products = booking.get("selected_products") or []
    extras = booking.get("extras") or {}
    status = booking["status"]
    confirmed_at = booking.get("confirmed_at")

    if body.passengers is not None:
        passengers = [p.model_dump() for p in body.passengers]
    if body.fare_code is not None:
        fare_code = body.fare_code.upper()
    if body.selected_products is not None:
        selected_products = body.selected_products
    if body.extras is not None:
        extras = body.extras
    if body.status is not None:
        status = body.status.upper()
        if status == "CONFIRMED" and not confirmed_at:
            confirmed_at = datetime.utcnow()
            profile = repo.get_passenger(db, booking["passenger_ref"])
            if profile:
                held = set(profile.get("held_products") or [])
                held.add(fare_code)
                held.update(selected_products or [])
                fare = repo.get_product(db, fare_code)
                if fare and fare.get("includes"):
                    held.update(fare["includes"])
                repo.update_passenger_held(db, booking["passenger_ref"], list(held))

    total = _calc_total(
        db,
        booking.get("outbound_flight_id") or 0,
        booking.get("return_flight_id"),
        fare_code,
        selected_products,
        booking.get("party") or {},
    )
    if isinstance(extras.get("baggage"), dict) and extras["baggage"].get("price"):
        total = round(total + float(extras["baggage"]["price"]), 2)
    if extras.get("seat_price"):
        total = round(total + float(extras["seat_price"]), 2)

    updated = repo.update_booking(
        db,
        pnr,
        {
            "passengers": passengers,
            "fare_code": fare_code,
            "selected_products": selected_products,
            "extras": extras,
            "status": status,
            "confirmed_at": confirmed_at,
            "total_amount": total,
        },
    )
    db.commit()
    assert updated is not None
    return _booking_out(updated)


@router.post("/bookings/{pnr}/confirm", response_model=BookingOut)
def confirm_booking(pnr: str, db: Session = Depends(get_db)):
    return update_booking(pnr, BookingUpdate(status="CONFIRMED"), db)


@router.post("/bookings/{pnr}/check-in", response_model=BookingOut)
def check_in(pnr: str, db: Session = Depends(get_db)):
    booking = repo.get_booking_by_pnr(db, pnr)
    if not booking:
        raise HTTPException(404, "Booking not found")
    if booking["status"] != "CONFIRMED":
        raise HTTPException(400, "Booking must be confirmed before check-in")

    has_seat = any(
        s.startswith("SEAT") or s == "EXTRA_LEGROOM"
        for s in (booking.get("selected_products") or [])
    ) or booking["fare_code"] in {"SMART", "GO", "PLUS", "FAMILY_GO", "FAMILY_PLUS"}

    extras = {**(booking.get("extras") or {}), "check_in_rule": "T-30d" if has_seat else "T-24h"}
    updated = repo.update_booking(
        db,
        pnr,
        {
            "passengers": booking.get("passengers") or [],
            "fare_code": booking["fare_code"],
            "selected_products": booking.get("selected_products") or [],
            "extras": extras,
            "status": "CHECKED_IN",
            "confirmed_at": booking.get("confirmed_at"),
            "total_amount": float(booking.get("total_amount") or 0),
        },
    )
    db.commit()
    assert updated is not None
    return _booking_out(updated)
