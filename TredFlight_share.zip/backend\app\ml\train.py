"""Train the ancillary transformer by distilling the rule engine + domain labels.

From the backend directory (venv active):

    python -m app.ml.train
"""

from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

import numpy as np

# Allow `python ml/train_local.py` from repo root as well.
_BACKEND = Path(__file__).resolve().parents[2]
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from app.ml.features import (  # noqa: E402
    AIRPORTS,
    CHANNELS,
    FARES,
    MOMENTS,
    N_NUMERIC,
    PRICE_SENS,
    PRODUCT_CODES,
    SEQ_LEN,
    encode_context,
)
from app.ml.transformer import default_artifact_path, export_torch_state  # noqa: E402
from app.schemas import CurationRequest, EventItem, JourneyContext  # noqa: E402
from app.services.curation_engine import (  # noqa: E402
    EngineState,
    _expand_held,
    _filter_and_rank,
    _generate_candidates,
    _normalize_inventory,
)


def _teacher_scores(req: CurationRequest, dial: float) -> np.ndarray:
    held = _expand_held(req.held_products, req.journey.fare)
    state = EngineState(
        held=held,
        declined=set(req.declined_products or []),
        events=[e.e for e in req.event_stream],
        inventory=_normalize_inventory(req.inventory),
        dial=dial,
    )
    ranked, suppressed = _filter_and_rank(_generate_candidates(req, state), state)
    scores = {code: 0.06 for code in PRODUCT_CODES}
    for c in ranked:
        if c.code in scores:
            scores[c.code] = float(min(0.95, max(0.08, c.score)))
    for c in suppressed:
        if c.code in scores:
            scores[c.code] = min(scores[c.code], 0.07)
    return np.array([scores[c] for c in PRODUCT_CODES], dtype=np.float32)


def _sample_request(rng: random.Random) -> tuple[CurationRequest, list[str], float]:
    moment = rng.choice(MOMENTS)
    fare = rng.choice(FARES)
    children = rng.choice([0, 0, 0, 1, 2])
    adults = rng.choice([1, 1, 2, 2, 3])
    pax = adults + children
    origin, dest = rng.sample(AIRPORTS, 2)
    delay = rng.choice([0, 0, 0, 20, 75, 200])
    dtd = rng.choice([1, 2, 3, 7, 14, 21, 42, 60])
    nights = rng.choice([1, 2, 3, 5, 7, 10])
    dial = rng.choice([0.15, 0.35, 0.45, 0.7, 0.85])
    opens = 2 if moment == "SEAT_MAP" and rng.random() < 0.6 else rng.choice([0, 0, 1, 2])
    events = [EventItem(t="2026-01-01T10:00:00", e="SEAT_MAP_OPEN") for _ in range(opens)]
    held = [fare] if rng.random() < 0.5 else []
    if fare in {"SMART", "PLUS", "FAMILY_PLUS"} and rng.random() < 0.7:
        held.append("PRIORITY")
    declined = ["SEAT_STANDARD"] if moment == "PRE_TRIP_REMINDER" and rng.random() < 0.5 else []
    journey = JourneyContext(
        origin=origin,
        destination=dest,
        pax=pax,
        adults=adults,
        children=children,
        fare=fare,
        days_to_departure=dtd,
        trip_nights=nights,
        return_trip=rng.random() > 0.2,
        price_sensitivity=rng.choice(PRICE_SENS),
        load_factor=rng.choice([0.55, 0.72, 0.88, 0.97]),
        delay_minutes=delay,
        schedule_changed=delay >= 60 and rng.random() < 0.5,
        queue_long=moment == "AIRPORT_ENTRY" and rng.random() < 0.6,
    )
    req = CurationRequest(
        moment=moment,
        channel=rng.choice(CHANNELS),
        passenger_ref="SYN-TRAIN",
        journey=journey,
        event_stream=events,
        held_products=held,
        declined_products=declined,
        revenue_fit_dial=dial,
    )
    event_names = [e.e for e in events]
    return req, event_names, dial


def build_dataset(n: int, seed: int = 7) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = random.Random(seed)
    tokens = np.zeros((n, SEQ_LEN), dtype=np.int64)
    numeric = np.zeros((n, N_NUMERIC), dtype=np.float32)
    labels = np.zeros((n, len(PRODUCT_CODES)), dtype=np.float32)
    for i in range(n):
        req, event_names, dial = _sample_request(rng)
        j = req.journey
        tok, num = encode_context(
            moment=req.moment,
            channel=req.channel,
            origin=j.origin,
            destination=j.destination,
            fare=j.fare,
            pax=j.pax,
            adults=j.adults,
            children=j.children,
            infants=j.infants,
            days_to_departure=j.days_to_departure,
            trip_nights=j.trip_nights,
            return_trip=j.return_trip,
            price_sensitivity=j.price_sensitivity,
            load_factor=j.load_factor,
            delay_minutes=j.delay_minutes,
            schedule_changed=j.schedule_changed,
            queue_long=j.queue_long,
            events=event_names,
            held_count=len(req.held_products),
            declined_count=len(req.declined_products),
            dial=dial,
        )
        tokens[i] = tok
        numeric[i] = num
        labels[i] = _teacher_scores(req, dial)
    return tokens, numeric, labels


def train_from_arrays(
    tokens: np.ndarray,
    numeric: np.ndarray,
    labels: np.ndarray,
    epochs: int = 12,
    batch_size: int = 64,
    lr: float = 1e-3,
    seed: int = 7,
    out: Path | None = None,
) -> Path:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset

    from app.ml.transformer import build_torch_module

    torch.manual_seed(seed)
    np.random.seed(seed)

    dataset = TensorDataset(
        torch.from_numpy(tokens),
        torch.from_numpy(numeric),
        torch.from_numpy(labels),
    )
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    model = build_torch_module()
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    loss_fn = nn.BCEWithLogitsLoss()
    model.train()
    for epoch in range(epochs):
        total = 0.0
        n_batches = 0
        for tok, num, y in loader:
            opt.zero_grad()
            logits = model(tok, num)
            loss = loss_fn(logits, y)
            loss.backward()
            opt.step()
            total += float(loss.item())
            n_batches += 1
        print(f"epoch {epoch + 1:02d}/{epochs}  loss={total / max(n_batches, 1):.4f}")

    model.eval()
    out_path = out or default_artifact_path()
    export_torch_state(model, out_path)
    print(f"wrote {out_path}")
    return out_path


def train(
    n_samples: int = 4000,
    epochs: int = 12,
    batch_size: int = 64,
    lr: float = 1e-3,
    seed: int = 7,
    out: Path | None = None,
) -> Path:
    tokens, numeric, labels = build_dataset(n_samples, seed=seed)
    return train_from_arrays(
        tokens,
        numeric,
        labels,
        epochs=epochs,
        batch_size=batch_size,
        lr=lr,
        seed=seed,
        out=out,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Train TredFlight ancillary transformer")
    parser.add_argument("--samples", type=int, default=4000)
    parser.add_argument("--epochs", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--out", type=str, default="")
    args = parser.parse_args()
    train(
        n_samples=args.samples,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        seed=args.seed,
        out=Path(args.out) if args.out else None,
    )


if __name__ == "__main__":
    main()
