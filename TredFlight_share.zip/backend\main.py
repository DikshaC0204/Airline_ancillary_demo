"""Compatibility shim — run with: uvicorn app.main:app --reload --app-dir backend"""

from app.main import app

__all__ = ["app"]
