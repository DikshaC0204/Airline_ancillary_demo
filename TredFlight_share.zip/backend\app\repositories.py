"""Repository helpers — execute text() SQL against Lakebase tables."""

from __future__ import annotations

import json
from datetime import date, datetime, timedelta
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.data.major_airports import airport_record, list_major_airports
from app.sql import airports as airports_sql
from app.sql import bookings as bookings_sql
from app.sql import curation as curation_sql
from app.sql import flights as flights_sql
from app.sql import passengers as passengers_sql
from app.sql import products as products_sql

_FARE_BUNDLE_CACHE: list[dict[str, Any]] | None = None


def _json_dump(value: Any) -> str:
    return json.dumps(value if value is not None else {})


def _json_list_dump(value: Any) -> str:
    return json.dumps(value if value is not None else [])


def _as_list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, str):
        return json.loads(value)
    return list(value)


def _as_dict(value: Any) -> dict:
    if value is None:
        return {}
    if isinstance(value, str):
        return json.loads(value)
    return dict(value)


def _row(mapping) -> dict[str, Any]:
    return dict(mapping) if mapping is not None else {}


def _normalize_flight(row: dict[str, Any]) -> dict[str, Any]:
    inv = row.get("inventory")
    if isinstance(inv, str):
        inv = json.loads(inv)
    row["inventory"] = inv or []
    return row


# --- Airports -----------------------------------------------------------------


def list_airports(db: Session) -> list[dict[str, Any]]:
    """Major airports only, with real city/country names (not IATA stubs)."""
    _ = db
    rows = list_major_airports()
    rows.sort(key=lambda a: (a["city"], a["code"]))
    return rows


def ensure_airport(
    db: Session,
    code: str,
    name: str | None = None,
    city: str | None = None,
    country: str = "",
) -> None:
    meta = airport_record(code)
    db.execute(
        airports_sql.ENSURE_AIRPORT,
        {
            "code": meta["code"],
            "name": name or meta["name"],
            "city": city or meta["city"],
            "country": country or meta["country"],
        },
    )


# --- Products -----------------------------------------------------------------


def _normalize_product(row: dict[str, Any]) -> dict[str, Any]:
    row["includes"] = _as_list(row.get("includes"))
    row["metadata_json"] = _as_dict(row.get("metadata_json"))
    return row


def list_products(db: Session, category: Optional[str] = None) -> list[dict[str, Any]]:
    if category:
        rows = db.execute(
            products_sql.LIST_PRODUCTS_BY_CATEGORY, {"category": category.upper()}
        ).mappings().all()
    else:
        rows = db.execute(products_sql.LIST_PRODUCTS).mappings().all()
    return [_normalize_product(_row(r)) for r in rows]


def get_product(db: Session, code: str) -> Optional[dict[str, Any]]:
    row = db.execute(products_sql.GET_PRODUCT, {"code": code.upper()}).mappings().first()
    return _normalize_product(_row(row)) if row else None


def list_fare_bundles(db: Session) -> list[dict[str, Any]]:
    global _FARE_BUNDLE_CACHE
    if _FARE_BUNDLE_CACHE is not None:
        return _FARE_BUNDLE_CACHE
    rows = db.execute(products_sql.LIST_FARE_BUNDLES).mappings().all()
    _FARE_BUNDLE_CACHE = [_normalize_product(_row(r)) for r in rows]
    return _FARE_BUNDLE_CACHE


# --- Flights ------------------------------------------------------------------


def _day_bounds_iso(day: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    """Return [day_from, day_to) ISO timestamps for a calendar day, or (None, None)."""
    if not day or not str(day).strip():
        return None, None
    try:
        d = datetime.fromisoformat(str(day).strip()[:10]).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        return d.isoformat(sep=" "), (d + timedelta(days=1)).isoformat(sep=" ")
    except ValueError:
        return None, None


def list_flights_by_route(
    db: Session,
    origin: str,
    destination: str,
    day: Optional[str] = None,
    limit: int = 8,
) -> list[dict[str, Any]]:
    day_from, day_to = _day_bounds_iso(day)
    rows = db.execute(
        flights_sql.LIST_FLIGHTS_BY_ROUTE,
        {
            "origin": origin,
            "destination": destination,
            "day_from": day_from,
            "day_to": day_to,
            "lim": max(1, min(int(limit), 24)),
        },
    ).mappings().all()
    return [_normalize_flight(_row(r)) for r in rows]


def route_has_flights(db: Session, origin: str, destination: str) -> bool:
    row = db.execute(
        flights_sql.ROUTE_HAS_FLIGHTS,
        {"origin": origin, "destination": destination},
    ).first()
    return row is not None


def flight_number_exists(db: Session, flight_number: str) -> bool:
    row = db.execute(
        flights_sql.FLIGHT_NUMBER_EXISTS,
        {"flight_number": flight_number},
    ).first()
    return row is not None


def get_flight(db: Session, flight_id: int) -> Optional[dict[str, Any]]:
    row = db.execute(flights_sql.GET_FLIGHT, {"flight_id": flight_id}).mappings().first()
    return _normalize_flight(_row(row)) if row else None


def get_flight_base(db: Session, flight_id: int) -> Optional[dict[str, Any]]:
    row = db.execute(flights_sql.GET_FLIGHT_BASE, {"flight_id": flight_id}).mappings().first()
    return _row(row) if row else None


def create_flight(
    db: Session,
    *,
    flight_number: str,
    origin: str,
    destination: str,
    depart_at: datetime,
    arrive_at: datetime,
    base_price: float,
    currency: str = "USD",
    load_factor: float = 0.65,
    delay_minutes: int = 0,
    schedule_changed: bool = False,
    inventory: Optional[dict[str, int]] = None,
) -> dict[str, Any]:
    ensure_airport(db, origin)
    ensure_airport(db, destination)
    flight_id = db.execute(
        flights_sql.INSERT_FLIGHT,
        {
            "flight_number": flight_number,
            "origin": origin,
            "destination": destination,
            "depart_at": depart_at,
            "arrive_at": arrive_at,
            "base_price": base_price,
            "currency": currency,
            "load_factor": load_factor,
            "delay_minutes": delay_minutes,
            "schedule_changed": schedule_changed,
        },
    ).scalar_one()

    for product_code, remaining in (inventory or {}).items():
        status = "SOLD_OUT" if remaining == 0 else ("OPEN" if remaining < 0 or remaining > 5 else "CAPPED")
        db.execute(
            flights_sql.INSERT_INVENTORY,
            {
                "flight_id": flight_id,
                "product_code": product_code,
                "remaining": remaining,
                "status": status,
            },
        )
    db.flush()
    flight = get_flight(db, flight_id)
    assert flight is not None
    return flight


def filter_flights_on_day(flights: list[dict[str, Any]], day: Optional[str]) -> list[dict[str, Any]]:
    """Keep only flights departing on the requested calendar day (no date fallback)."""
    if not day or not str(day).strip():
        return flights
    try:
        d = datetime.fromisoformat(str(day).strip()[:10]).date()
    except ValueError:
        return flights

    def _depart_date(f: dict[str, Any]) -> date:
        val = f["depart_at"]
        if isinstance(val, datetime):
            return val.date()
        return datetime.fromisoformat(str(val)).date()

    return [f for f in flights if _depart_date(f) == d]


# --- Passengers ---------------------------------------------------------------


def get_passenger(db: Session, passenger_ref: str) -> Optional[dict[str, Any]]:
    row = db.execute(
        passengers_sql.GET_PASSENGER, {"passenger_ref": passenger_ref}
    ).mappings().first()
    if not row:
        return None
    data = _row(row)
    data["declined_products"] = _as_list(data.get("declined_products"))
    data["event_stream"] = _as_list(data.get("event_stream"))
    data["held_products"] = _as_list(data.get("held_products"))
    return data


def ensure_passenger(
    db: Session,
    passenger_ref: str,
    display_name: str = "Guest",
    cohort: str = "leisure_cold_start",
    held_products: Optional[list[str]] = None,
) -> dict[str, Any]:
    existing = get_passenger(db, passenger_ref)
    if existing:
        return existing
    db.execute(
        passengers_sql.INSERT_PASSENGER,
        {
            "passenger_ref": passenger_ref,
            "display_name": display_name,
            "cohort": cohort,
            "held_products": _json_list_dump(held_products or ["BASIC_FARE"]),
        },
    )
    db.flush()
    profile = get_passenger(db, passenger_ref)
    assert profile is not None
    return profile


def update_passenger_curation(
    db: Session,
    passenger_ref: str,
    *,
    declined_products: list[str],
    event_stream: list[Any],
    fatigue_impressions: int,
) -> None:
    db.execute(
        passengers_sql.UPDATE_PASSENGER_CURATION,
        {
            "passenger_ref": passenger_ref,
            "declined_products": _json_list_dump(declined_products),
            "event_stream": _json_list_dump(event_stream),
            "fatigue_impressions": fatigue_impressions,
        },
    )


def update_passenger_decline(
    db: Session,
    passenger_ref: str,
    *,
    declined_products: list[str],
    fatigue_declines: int,
) -> None:
    db.execute(
        passengers_sql.UPDATE_PASSENGER_DECLINE,
        {
            "passenger_ref": passenger_ref,
            "declined_products": _json_list_dump(declined_products),
            "fatigue_declines": fatigue_declines,
        },
    )


def update_passenger_held(db: Session, passenger_ref: str, held_products: list[str]) -> None:
    db.execute(
        passengers_sql.UPDATE_PASSENGER_HELD,
        {
            "passenger_ref": passenger_ref,
            "held_products": _json_list_dump(held_products),
        },
    )


# --- Bookings -----------------------------------------------------------------


def create_booking(db: Session, payload: dict[str, Any]) -> dict[str, Any]:
    booking_id = db.execute(
        bookings_sql.INSERT_BOOKING,
        {
            "pnr": payload["pnr"],
            "passenger_ref": payload["passenger_ref"],
            "status": payload.get("status", "DRAFT"),
            "trip_type": payload.get("trip_type", "return"),
            "origin": payload["origin"],
            "destination": payload["destination"],
            "outbound_flight_id": payload["outbound_flight_id"],
            "return_flight_id": payload.get("return_flight_id"),
            "fare_code": payload.get("fare_code", "BASIC"),
            "party": _json_dump(payload.get("party") or {}),
            "passengers": _json_list_dump(payload.get("passengers") or []),
            "selected_products": _json_list_dump(payload.get("selected_products") or []),
            "extras": _json_dump(payload.get("extras") or {}),
            "total_amount": payload.get("total_amount", 0.0),
            "currency": payload.get("currency", "USD"),
            "promo_code": payload.get("promo_code"),
        },
    ).scalar_one()
    db.flush()
    booking = get_booking_by_id(db, booking_id)
    assert booking is not None
    return booking


def _hydrate_booking(db: Session, data: dict[str, Any]) -> dict[str, Any]:
    data["party"] = _as_dict(data.get("party"))
    data["passengers"] = _as_list(data.get("passengers"))
    data["selected_products"] = _as_list(data.get("selected_products"))
    data["extras"] = _as_dict(data.get("extras"))
    out_id = data.get("outbound_flight_id")
    ret_id = data.get("return_flight_id")
    data["outbound_flight"] = get_flight(db, out_id) if out_id else None
    data["return_flight"] = get_flight(db, ret_id) if ret_id else None
    return data


def get_booking_by_pnr(db: Session, pnr: str) -> Optional[dict[str, Any]]:
    row = db.execute(bookings_sql.GET_BOOKING_BY_PNR, {"pnr": pnr.upper()}).mappings().first()
    if not row:
        return None
    return _hydrate_booking(db, _row(row))


def get_booking_by_id(db: Session, booking_id: int) -> Optional[dict[str, Any]]:
    row = db.execute(
        bookings_sql.GET_BOOKING_BY_ID, {"booking_id": booking_id}
    ).mappings().first()
    if not row:
        return None
    return _hydrate_booking(db, _row(row))


def update_booking(db: Session, pnr: str, fields: dict[str, Any]) -> Optional[dict[str, Any]]:
    db.execute(
        bookings_sql.UPDATE_BOOKING,
        {
            "pnr": pnr.upper(),
            "passengers": _json_list_dump(fields["passengers"]),
            "fare_code": fields["fare_code"],
            "selected_products": _json_list_dump(fields["selected_products"]),
            "extras": _json_dump(fields["extras"]),
            "status": fields["status"],
            "confirmed_at": fields.get("confirmed_at"),
            "total_amount": fields["total_amount"],
        },
    )
    db.flush()
    return get_booking_by_pnr(db, pnr)


# --- Curation logs ------------------------------------------------------------


def insert_curation_log(
    db: Session,
    *,
    passenger_ref: str,
    moment: str,
    channel: str,
    request_json: dict[str, Any],
    response_json: dict[str, Any],
) -> int:
    return db.execute(
        curation_sql.INSERT_CURATION_LOG,
        {
            "passenger_ref": passenger_ref,
            "moment": moment,
            "channel": channel,
            "request_json": _json_dump(request_json),
            "response_json": _json_dump(response_json),
        },
    ).scalar_one()
