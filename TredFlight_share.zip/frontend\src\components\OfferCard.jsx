import React, { useState } from 'react';
import { api } from '../api/client';

/** Legacy ML offer card — now calls /curate for a SEARCH_RESULTS moment. */
const OfferCard = ({ basePrice, onAcceptOffer, journey, passengerRef = 'SYN-000431' }) => {
  const [offer, setOffer] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchOffer = async () => {
    setLoading(true);
    try {
      const data = await api.curate({
        moment: 'SEARCH_RESULTS',
        channel: 'WEB',
        passenger_ref: passengerRef,
        journey: journey || {
          origin: 'LTN',
          destination: 'BUD',
          pax: 1,
          fare: 'BASIC',
          days_to_departure: 3,
          trip_nights: 2,
          return_trip: true,
        },
        held_products: ['BASIC_FARE'],
        event_stream: [],
        inventory: {},
      });
      const top = data.ranked?.[0];
      if (top) {
        setOffer({
          offerId: top.product,
          bundleType: top.name,
          discountPercentage: 0,
          includedServices: [top.reason],
          finalPrice: (basePrice || 0) + (top.price || 0),
          description: data.explainability_note,
          raw: top,
        });
      } else {
        setOffer({
          offerId: 'NO_OFFER',
          bundleType: 'No offer',
          discountPercentage: 0,
          includedServices: ['Engine returned NO_OFFER'],
          finalPrice: basePrice || 0,
          description: data.explainability_note,
        });
      }
    } catch {
      setOffer({
        offerId: 'FALLBACK',
        bundleType: 'Go Upgrade',
        discountPercentage: 0,
        includedServices: ['20kg bag', 'Priority boarding', 'Travel Flex'],
        finalPrice: (basePrice || 0) + 19.99,
        description: 'Backend offline — fallback demo offer.',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-brand-navy via-slate-800 to-brand-navy text-white rounded-lg shadow-xl p-6 border-2 border-brand-coral mb-6">
      <span className="bg-brand-coral text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
        Curated deal
      </span>
      <h4 className="text-2xl font-black mt-2">Personalized ancillary offer</h4>
      <p className="text-slate-200 mt-1">Ranked by the curation engine for this booking moment.</p>

      {!offer ? (
        <button
          type="button"
          onClick={fetchOffer}
          disabled={loading}
          className="mt-4 bg-brand-coral text-white hover:bg-pink-600 px-6 py-3 rounded-md font-bold w-full transition uppercase tracking-wider text-sm shadow-lg"
        >
          {loading ? 'Ranking…' : 'Reveal my deal'}
        </button>
      ) : (
        <div className="mt-4 pt-4 border-t border-slate-600">
          <h5 className="text-xl font-bold text-brand-coral">{offer.bundleType}</h5>
          <p className="text-sm text-slate-300 mt-1">{offer.description}</p>
          <ul className="mt-4 space-y-2 text-sm text-slate-100">
            {offer.includedServices.map((service, idx) => (
              <li key={idx} className="flex items-center font-medium">
                <span className="text-green-400 mr-2.5">✔</span> {service}
              </li>
            ))}
          </ul>
          <div className="mt-5 flex justify-between items-center">
            <div>
              <span className="text-xs text-slate-300 block">Fare with add-on</span>
              <span className="text-3xl font-black text-white">${offer.finalPrice.toFixed(2)}</span>
            </div>
            {offer.offerId !== 'NO_OFFER' && (
              <button
                type="button"
                onClick={() => onAcceptOffer?.(offer)}
                className="bg-green-500 hover:bg-green-600 text-white font-extrabold px-6 py-3 rounded-lg transition shadow-md"
              >
                Add this upgrade
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default OfferCard;
