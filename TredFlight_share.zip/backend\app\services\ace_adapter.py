"""Embed Airline ACE V6 decisioning behind TredFlight's /curate contract.

ACE lives in a separate repo. Set ACE_ROOT to that path (or install airline_demo
on PYTHONPATH). This adapter creates a shopping session, calls V6DecisionService,
and maps ACE product IDs / ranked offers into TredFlight scoring shapes.
"""

from __future__ import annotations

import sys
from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path
from typing import Any

from app.config import get_settings
from app.ml.features import PRODUCT_CODES, explain_product, normalize_moment
from app.schemas import CurationRequest

# ACE offer_id → TredFlight product code used by the booking UI / catalogue.
ACE_TO_TRED: dict[str, str] = {
    "PRIORITY": "PRIORITY",
    "FAST_TRACK": "SECURITY_FAST_TRACK",
    "BAG": "BAG_20KG",
    "SEAT_STD": "SEAT_STANDARD",
    "SEAT_LEG": "EXTRA_LEGROOM",
    "WIZZ_FLEX": "FLEX",
    "AUTO_CHECKIN": "AUTO_CHECKIN",
    "LOUNGE": "LOUNGE",
    "FAMILY_BASKET": "FAMILY_BAG_BUNDLE",
    "SITTING_TOGETHER": "SITTING_TOGETHER",
    "BUNDLE_WIZZ_FLEX_BAG": "FLEX",
    "BUNDLE_WIZZ_FLEX_SEAT_LEG": "EXTRA_LEGROOM",
}

# TredFlight held / declined codes → ACE catalogue IDs for entitlement checks.
TRED_TO_ACE: dict[str, str] = {
    "PRIORITY": "PRIORITY",
    "SECURITY_FAST_TRACK": "FAST_TRACK",
    "BAG_10KG": "BAG",
    "BAG_20KG": "BAG",
    "BAG_26KG": "BAG",
    "BAG_32KG": "BAG",
    "SEAT_STANDARD": "SEAT_STD",
    "SEAT_FRONT": "SEAT_LEG",
    "EXTRA_LEGROOM": "SEAT_LEG",
    "SEAT_PREMIUM": "SEAT_LEG",
    "FLEX": "WIZZ_FLEX",
    "AUTO_CHECKIN": "AUTO_CHECKIN",
    "LOUNGE": "LOUNGE",
    "FAMILY_BAG_BUNDLE": "FAMILY_BASKET",
    "SITTING_TOGETHER": "SITTING_TOGETHER",
}

FARE_TO_ACE_BUNDLE: dict[str, str] = {
    "BASIC": "BASIC",
    "SMART": "WIZZ_SMART",
    "GO": "WIZZ_GO",
    "PLUS": "WIZZ_PLUS",
    "FAMILY_GO": "FAMILY_GO",
    "FAMILY_PLUS": "FAMILY_PLUS",
}

PREBOOKING_MOMENTS = {
    "SEARCH_RESULTS",
    "FARE_COMPARISON",
    "SEAT_MAP",
    "PAYMENT",
    "BOOKING_CONFIRMATION",
}

MOMENT_EVENT: dict[str, str] = {
    "SEARCH_RESULTS": "flight_selected",
    "FARE_COMPARISON": "fare_family_compared",
    "SEAT_MAP": "seat_map_opened",
    "PAYMENT": "payment_started",
    "BOOKING_CONFIRMATION": "confirmation_viewed",
}


def _ensure_ace_on_path(ace_root: Path) -> None:
    root = str(ace_root.resolve())
    if root not in sys.path:
        sys.path.insert(0, root)


@lru_cache(maxsize=1)
def _ace_service(ace_root: str):
    root = Path(ace_root)
    if not root.is_dir():
        raise FileNotFoundError(f"ACE_ROOT does not exist: {root}")
    _ensure_ace_on_path(root)
    from airline_demo.v6.contracts import (  # noqa: WPS433
        BackendContext,
        DecisionRequest,
        EventContext,
        JourneyContext,
        SessionCreateRequest,
        StrategyContext,
    )
    from airline_demo.v6.service import V6DecisionService  # noqa: WPS433

    return V6DecisionService(), {
        "BackendContext": BackendContext,
        "DecisionRequest": DecisionRequest,
        "EventContext": EventContext,
        "JourneyContext": JourneyContext,
        "SessionCreateRequest": SessionCreateRequest,
        "StrategyContext": StrategyContext,
    }


def ace_available() -> bool:
    settings = get_settings()
    root = settings.ace_root
    if not root:
        return False
    try:
        _ace_service(root)
        return True
    except Exception:  # noqa: BLE001
        return False


def _map_held(codes: list[str]) -> list[str]:
    out: list[str] = []
    for code in codes or []:
        mapped = TRED_TO_ACE.get(str(code).upper())
        if mapped and mapped not in out:
            out.append(mapped)
        elif not mapped and code:
            out.append(str(code).upper())
    return out


def _departure_date(journey: Any) -> str:
    days = max(0, int(getattr(journey, "days_to_departure", 7) or 7))
    return (date.today() + timedelta(days=days)).isoformat()


def _return_date(journey: Any, departure: str) -> str | None:
    if not getattr(journey, "return_trip", True):
        return None
    nights = max(0, int(getattr(journey, "trip_nights", 2) or 2))
    return (date.fromisoformat(departure) + timedelta(days=nights)).isoformat()


def _inventory_remaining(inventory: dict[str, Any], key: str) -> int | None:
    if not inventory:
        return None
    raw = inventory.get(key)
    if raw is None:
        return None
    if isinstance(raw, str) and raw.upper() in {"SOLD_OUT", "CLOSED"}:
        return 0
    try:
        remaining = int(raw)
    except (TypeError, ValueError):
        return None
    # -1 means unlimited in TredFlight inventory; do not treat as sold out.
    if remaining < 0:
        return None
    return remaining


def _strategy_from_dial(dial: float):
    # Higher dial → more revenue weight; lower dial → more fit/experience restraint.
    dial = max(0.0, min(1.0, float(dial)))
    fit = 0.70 - 0.30 * dial
    revenue = 0.10 + 0.40 * dial
    experience = max(0.05, 1.0 - fit - revenue)
    return fit, revenue, experience, 0.0


def _sigmoid_norm(score: float) -> float:
    # ACE objective scores can be large negatives for ineligible rows (-999).
    import math

    clipped = max(-20.0, min(20.0, float(score)))
    return 1.0 / (1.0 + math.exp(-clipped))


def score_with_ace(req: CurationRequest, dial: float, events: list[str]) -> dict[str, Any]:
    settings = get_settings()
    if not settings.ace_root:
        raise RuntimeError("ACE_ROOT is not set")

    moment = normalize_moment(req.moment)
    if moment not in PREBOOKING_MOMENTS:
        raise RuntimeError(
            f"ACE embed adapter currently supports pre-booking moments only; got {moment}"
        )

    svc, models = _ace_service(settings.ace_root)
    SessionCreateRequest = models["SessionCreateRequest"]
    DecisionRequest = models["DecisionRequest"]
    JourneyContext = models["JourneyContext"]
    EventContext = models["EventContext"]
    BackendContext = models["BackendContext"]
    StrategyContext = models["StrategyContext"]

    j = req.journey
    departure = _departure_date(j)
    ret = _return_date(j, departure)
    trip_type = "round_trip" if getattr(j, "return_trip", True) else "one_way"

    session = svc.create_session(
        SessionCreateRequest(
            origin=str(j.origin).upper(),
            destination=str(j.destination).upper(),
            departure_date=departure,
            return_date=ret,
            trip_type=trip_type,
            adults=max(1, int(getattr(j, "adults", None) or getattr(j, "pax", 1) or 1)),
            children=max(0, int(getattr(j, "children", 0) or 0)),
            cabin="Economy",
            channel=(req.channel or "WEB").upper(),
        )
    )
    session_id = session["session_id"]

    fare = str(getattr(j, "fare", "BASIC") or "BASIC").upper()
    fit_w, rev_w, exp_w, explore_w = _strategy_from_dial(dial)

    inv = req.inventory or {}
    backend = BackendContext(
        load_factor=getattr(j, "load_factor", None),
        delay_minutes=float(getattr(j, "delay_minutes", 0) or 0),
        schedule_changed=bool(getattr(j, "schedule_changed", False)),
        extra_legroom_remaining=_inventory_remaining(inv, "EXTRA_LEGROOM"),
        priority_remaining=_inventory_remaining(inv, "PRIORITY"),
        fast_track_remaining=_inventory_remaining(inv, "SECURITY_FAST_TRACK"),
        security_wait_minutes=25.0 if getattr(j, "queue_long", False) else 8.0,
        airport_congestion_score=0.7 if getattr(j, "queue_long", False) else 0.2,
    )

    event_type = MOMENT_EVENT.get(moment, "flight_selected")
    # Prefer the last website event stream token when present.
    if events:
        last = str(events[-1]).lower()
        if "seat" in last:
            event_type = "seat_map_opened"
        elif "fare" in last:
            event_type = "fare_family_compared"
        elif "pay" in last or "checkout" in last:
            event_type = "payment_started"

    decision_req = DecisionRequest(
        session_id=session_id,
        passenger_ref=req.passenger_ref,
        moment=moment,
        channel=(req.channel or "WEB").upper(),
        journey=JourneyContext(
            origin=str(j.origin).upper(),
            destination=str(j.destination).upper(),
            departure_date=departure,
            return_date=ret,
            trip_type=trip_type,
            adults=max(1, int(getattr(j, "adults", None) or getattr(j, "pax", 1) or 1)),
            children=max(0, int(getattr(j, "children", 0) or 0)),
            cabin="Economy",
            fare_family=fare,
            selected_flight_id=f"TF_{j.origin}_{j.destination}",
            fare_rank_selected={"BASIC": 1, "SMART": 2, "GO": 2, "PLUS": 3}.get(fare, 2),
        ),
        event=EventContext(
            event_type=event_type,
            payload={
                "selected_fare_family": fare,
                "website_events": list(events or [])[:12],
                "price_sensitivity": getattr(j, "price_sensitivity", "medium"),
            },
        ),
        held_products=_map_held(req.held_products),
        rejected_products=_map_held(req.declined_products),
        backend_context=backend,
        strategy=StrategyContext(
            fit_weight=fit_w,
            revenue_weight=rev_w,
            experience_weight=exp_w,
            exploration_weight=explore_w,
        ),
        fare_bundle=FARE_TO_ACE_BUNDLE.get(fare, fare),
        include_trace=True,
    )

    raw = svc.decide(decision_req)

    scores: dict[str, float] = {code: 0.0 for code in PRODUCT_CODES}
    reasons: dict[str, str] = {}
    ranked_out: list[dict[str, Any]] = []

    for row in raw.get("ranked") or []:
        ace_id = str(row.get("product_id") or "")
        if ace_id in {"", "NO_OFFER", "INSURANCE", "CARBON_OFFSET"}:
            continue
        tred = ACE_TO_TRED.get(ace_id)
        if not tred:
            continue
        score = _sigmoid_norm(float(row.get("score") or 0.0))
        if not bool(row.get("eligible", True)):
            reason = str(row.get("reason_code") or "INELIGIBLE")
            reasons[tred] = reason
            continue
        scores[tred] = max(scores.get(tred, 0.0), score)
        reason = str(row.get("reason_code") or "ACE_V6_RANKED")
        reasons[tred] = reason
        ranked_out.append(
            {
                "product": tred,
                "ace_product_id": ace_id,
                "name": str(row.get("name") or tred),
                "score": score,
                "reason": reason,
                "eligible": True,
            }
        )

    selected = raw.get("selected_offer") or {}
    selected_ace = str(selected.get("product_id") or "")
    selected_tred = ACE_TO_TRED.get(selected_ace)
    if selected_tred and selected_tred not in {r["product"] for r in ranked_out}:
        sel_score = _sigmoid_norm(float(selected.get("score") or 1.0))
        scores[selected_tred] = max(scores.get(selected_tred, 0.0), sel_score)
        reasons[selected_tred] = str(raw.get("reason_code") or "ACE_V6_SELECTED")
        ranked_out.insert(
            0,
            {
                "product": selected_tred,
                "ace_product_id": selected_ace,
                "name": str(selected.get("name") or selected_tred),
                "score": sel_score,
                "reason": reasons[selected_tred],
                "eligible": True,
            },
        )

    for code, value in list(scores.items()):
        if code not in reasons:
            reasons[code] = explain_product(code, value, moment)

    suppressed = []
    for row in raw.get("suppressed") or []:
        ace_id = str(row.get("product_id") or "")
        tred = ACE_TO_TRED.get(ace_id, ace_id)
        suppressed.append(
            {
                "product": tred,
                "ace_product_id": ace_id,
                "reason": str(row.get("reason_code") or "SUPPRESSED"),
            }
        )

    return {
        "scores": scores,
        "reasons": reasons,
        "source": "ace-v6-local",
        "extras": {
            "action": raw.get("action"),
            "decision_id": raw.get("decision_id"),
            "request_id": raw.get("request_id"),
            "session_id": session_id,
            "passenger_payload": raw.get("passenger_payload"),
            "selected_offer": raw.get("selected_offer"),
            "ranked": ranked_out,
            "suppressed": suppressed,
            "reason_code": raw.get("reason_code"),
            "channel_decision": raw.get("channel_decision"),
        },
    }
