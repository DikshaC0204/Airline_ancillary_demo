import React, { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import BookingSummarySidebar from '../components/BookingSummarySidebar';
import CurationPanel from '../components/CurationPanel';
import { useBooking } from '../context/BookingContext';
import { daysUntil, tripNights } from '../api/client';

const ConfirmationPage = () => {
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();

  const journey = useMemo(
    () => ({
      origin: booking.origin,
      destination: booking.destination,
      pax: (booking.party?.adults || 1) + (booking.party?.children || 0),
      adults: booking.party?.adults || 1,
      children: booking.party?.children || 0,
      fare: booking.fareCode || 'BASIC',
      days_to_departure: daysUntil(booking.outboundFlight?.depart_at || booking.departDate),
      trip_nights: tripNights(
        booking.outboundFlight?.depart_at || booking.departDate,
        booking.returnFlight?.depart_at || booking.returnDate,
        booking.tripType
      ),
      return_trip: booking.tripType !== 'oneway',
    }),
    [booking]
  );

  const addOfferAndPay = (item) => {
    setBooking((prev) => ({
      ...prev,
      selectedProducts: [...new Set([...(prev.selectedProducts || []), item.product])],
      heldProducts: [...new Set([...(prev.heldProducts || []), item.product])],
      productPrices: { ...(prev.productPrices || {}), [item.product]: item.price },
      postBookingPayment: true,
    }));
    navigate('/payment');
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-screen-xl mx-auto p-4 lg:p-8 flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-[280px] flex-shrink-0">
          <BookingSummarySidebar booking={booking} currentStep="confirmation" />
        </aside>
        <main className="flex-grow space-y-6">
          <div className="bg-white p-8 rounded-lg shadow-md text-center">
            <div className="text-brand-coral text-5xl font-black mb-2">✓</div>
            <h2 className="text-3xl font-black text-brand-navy">Booking confirmed</h2>
            <p className="text-gray-600 mt-2">Your trip is confirmed. Keep this PNR for manage booking.</p>
            <p className="text-4xl font-mono font-black text-brand-navy mt-6 tracking-widest">
              {booking.pnr || '———'}
            </p>
            <p className="text-sm text-gray-500 mt-2">Passenger ref: {booking.passenger_ref}</p>
            <div className="flex flex-wrap justify-center gap-3 mt-8">
              <Link
                to="/manage"
                className="bg-brand-navy text-white font-bold px-5 py-2 rounded-md"
              >
                Manage booking
              </Link>
              <Link to="/" className="border border-brand-navy text-brand-navy font-bold px-5 py-2 rounded-md">
                New search
              </Link>
            </div>
          </div>

          <CurationPanel
            moment="BOOKING_CONFIRMATION"
            heading="Get Offers"
            title="Lounge & post-booking extras"
            journey={journey}
            heldProducts={booking.heldProducts}
            eventStream={booking.eventStream}
            declinedProducts={booking.declinedProducts}
            passengerRef={
              booking.fareCode === 'PLUS' ? 'SYN-PLUS-01' : booking.passenger_ref
            }
            onAccept={addOfferAndPay}
            onDecline={(item) =>
              setBooking((prev) => ({
                ...prev,
                declinedProducts: [...new Set([...(prev.declinedProducts || []), item.product])],
              }))
            }
          />
        </main>
      </div>
    </div>
  );
};

export default ConfirmationPage;
