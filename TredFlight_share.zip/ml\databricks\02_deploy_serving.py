"""Create or update a Databricks custom-container serving endpoint.

Requires:
  DATABRICKS_HOST   e.g. https://adb-xxxx.azuredatabricks.net
  DATABRICKS_TOKEN  personal access token
  ANCILLARY_IMAGE   e.g. myregistry.azurecr.io/tredflight-ancillary:latest

Optional:
  DATABRICKS_SERVING_ENDPOINT  default tredflight-ancillary
  ACR_USERNAME / ACR_PASSWORD  if the image is on a private registry
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request


def _env(name: str, default: str | None = None) -> str:
    val = os.getenv(name, default or "").strip()
    if not val:
        raise SystemExit(f"Missing required env var {name}")
    return val


def _request(method: str, url: str, token: str, body: dict | None = None) -> dict:
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"{method} {url} -> {exc.code}: {detail}") from exc


def main() -> None:
    host = _env("DATABRICKS_HOST").rstrip("/")
    token = _env("DATABRICKS_TOKEN")
    image = _env("ANCILLARY_IMAGE")
    name = os.getenv("DATABRICKS_SERVING_ENDPOINT", "tredflight-ancillary").strip()
    entity = {
        "name": "ancillary-transformer",
        "workload_size": os.getenv("SERVING_WORKLOAD_SIZE", "Small"),
        "scale_to_zero_enabled": True,
        "container": {
            "image": image,
            "port": int(os.getenv("ANCILLARY_PORT", "8080")),
        },
    }
    acr_user = os.getenv("ACR_USERNAME", "").strip()
    acr_pass = os.getenv("ACR_PASSWORD", "").strip()
    if acr_user and acr_pass:
        entity["container"]["image_registry_username"] = acr_user
        entity["container"]["image_registry_password"] = acr_pass

    payload = {"name": name, "config": {"served_entities": [entity]}}
    existing = None
    try:
        existing = _request("GET", f"{host}/api/2.0/serving-endpoints/{name}", token)
    except SystemExit:
        existing = None

    if existing:
        print(f"Updating endpoint {name}")
        result = _request(
            "PUT",
            f"{host}/api/2.0/serving-endpoints/{name}/config",
            token,
            {"served_entities": [entity]},
        )
    else:
        print(f"Creating endpoint {name}")
        result = _request("POST", f"{host}/api/2.0/serving-endpoints", token, payload)

    invocations = f"{host}/serving-endpoints/{name}/invocations"
    print(json.dumps({"endpoint": name, "invocations": invocations, "response": result}, indent=2))
    print("\nSet in TredFlight .env:")
    print(f"CURATION_SCORER=databricks")
    print(f"DATABRICKS_HOST={host}")
    print(f"DATABRICKS_SERVING_ENDPOINT={name}")
    print("DATABRICKS_TOKEN=<same PAT>")


if __name__ == "__main__":
    main()
