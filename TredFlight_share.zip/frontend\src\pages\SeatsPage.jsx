import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import BookingSummarySidebar from '../components/BookingSummarySidebar';
import CurationPanel from '../components/CurationPanel';
import { useBooking } from '../context/BookingContext';
import { daysUntil, tripNights } from '../api/client';

const ROWS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
const COLS = ['A', 'B', 'C', 'D', 'E', 'F'];

const seatPrice = (row) => {
  if (row <= 4) return { code: 'SEAT_FRONT', label: `${row}`, price: 18, type: 'front' };
  if (row === 6 || row === 12) return { code: 'EXTRA_LEGROOM', label: `${row}`, price: 28, type: 'xl' };
  return { code: 'SEAT_STANDARD', label: `${row}`, price: 8, type: 'standard' };
};

const SeatsPage = () => {
  const navigate = useNavigate();
  const { booking, setBooking, pushEvent } = useBooking();
  const [selected, setSelected] = useState(booking.extras?.seat || null);
  const [mapOpens, setMapOpens] = useState(0);
  const [showMap, setShowMap] = useState(true);

  const openMap = () => {
    setShowMap(true);
    setMapOpens((n) => n + 1);
    pushEvent('SEAT_MAP_OPEN');
  };

  const pickSeat = (row, col) => {
    const meta = seatPrice(row);
    const seat = { row, col, ...meta, seatId: `${row}${col}` };
    setSelected(seat);
    setBooking((prev) => ({
      ...prev,
      extras: {
        ...prev.extras,
        seat,
        seat_price: meta.price,
        seat_label: `${row}${col}`,
      },
      selectedProducts: [
        ...new Set([
          ...(prev.selectedProducts || []).filter(
            (p) => !['SEAT_STANDARD', 'SEAT_FRONT', 'EXTRA_LEGROOM'].includes(p)
          ),
          meta.code,
        ]),
      ],
      productPrices: { ...(prev.productPrices || {}), [meta.code]: meta.price },
    }));
  };

  const journey = useMemo(
    () => ({
      origin: booking.origin,
      destination: booking.destination,
      pax: (booking.party?.adults || 1) + (booking.party?.children || 0),
      adults: booking.party?.adults || 1,
      children: booking.party?.children || 0,
      fare: booking.fareCode || 'BASIC',
      days_to_departure: daysUntil(booking.outboundFlight?.depart_at || booking.departDate),
      trip_nights: tripNights(
        booking.outboundFlight?.depart_at || booking.departDate,
        booking.returnFlight?.depart_at || booking.returnDate,
        booking.tripType
      ),
      return_trip: booking.tripType !== 'oneway',
      price_sensitivity: booking.fareCode === 'BASIC' ? 'high' : 'medium',
      load_factor: booking.outboundFlight?.load_factor,
    }),
    [booking]
  );

  const inventory = useMemo(() => {
    const inv = {};
    (booking.outboundFlight?.inventory || []).forEach((i) => {
      inv[i.product_code] = i.remaining;
    });
    return inv;
  }, [booking.outboundFlight]);

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-screen-xl mx-auto p-4 lg:p-8 flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-[280px] flex-shrink-0">
          <div className="sticky top-6">
            <BookingSummarySidebar booking={booking} currentStep="seats" />
          </div>
        </aside>

        <main className="flex-grow space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-xl font-black text-brand-navy">SEAT MAP</h3>
                <p className="text-sm text-gray-500">
                  Opens tracked for live intent ({mapOpens} open{mapOpens === 1 ? '' : 's'}).
                </p>
              </div>
              <button
                type="button"
                onClick={() => (showMap ? setShowMap(false) : openMap())}
                className="text-sm font-bold text-brand-coral border border-brand-coral px-3 py-1.5 rounded"
              >
                {showMap ? 'Close map' : 'Open map'}
              </button>
            </div>

            {showMap && (
              <div className="overflow-x-auto">
                <div className="inline-block min-w-full">
                  <div className="flex gap-2 mb-2 justify-center text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-brand-navy rounded-sm" /> Front
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-amber-500 rounded-sm" /> Extra legroom
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-3 h-3 bg-gray-300 rounded-sm" /> Standard
                    </span>
                  </div>
                  {ROWS.map((row) => (
                    <div key={row} className="flex items-center justify-center gap-1 mb-1">
                      <span className="w-6 text-xs text-gray-500 text-right mr-1">{row}</span>
                      {COLS.map((col, idx) => {
                        const meta = seatPrice(row);
                        const id = `${row}${col}`;
                        const isSel = selected?.seatId === id;
                        const color =
                          meta.type === 'front'
                            ? 'bg-brand-navy text-white'
                            : meta.type === 'xl'
                              ? 'bg-amber-500 text-white'
                              : 'bg-gray-200';
                        return (
                          <React.Fragment key={id}>
                            {idx === 3 && <span className="w-4" />}
                            <button
                              type="button"
                              onClick={() => pickSeat(row, col)}
                              className={`w-8 h-8 text-[10px] font-bold rounded ${color} ${
                                isSel ? 'ring-2 ring-brand-coral scale-110' : ''
                              }`}
                            >
                              {col}
                            </button>
                          </React.Fragment>
                        );
                      })}
                    </div>
                  ))}
                </div>
                {selected && (
                  <p className="mt-4 text-sm font-semibold text-brand-navy">
                    Selected {selected.seatId} — {selected.code.replace(/_/g, ' ')} ($
                    {selected.price.toFixed(2)})
                  </p>
                )}
                <button
                  type="button"
                  className="mt-3 text-sm text-gray-600 underline"
                  onClick={() => {
                    setSelected(null);
                    setBooking((prev) => ({
                      ...prev,
                      extras: { ...prev.extras, seat: null, seat_price: 0, seat_label: '' },
                    }));
                  }}
                >
                  Continue without selecting
                </button>
              </div>
            )}
          </div>

          <CurationPanel
            moment="SEAT_MAP"
            heading="Get Offers"
            title="Seat upgrades for this flight"
            journey={journey}
            heldProducts={booking.heldProducts}
            eventStream={booking.eventStream}
            declinedProducts={booking.declinedProducts}
            inventory={inventory}
            passengerRef={booking.passenger_ref}
            onAccept={(item) =>
              setBooking((prev) => ({
                ...prev,
                selectedProducts: [...new Set([...(prev.selectedProducts || []), item.product])],
                heldProducts: [...new Set([...(prev.heldProducts || []), item.product])],
                productPrices: { ...(prev.productPrices || {}), [item.product]: item.price },
              }))
            }
            onDecline={(item) =>
              setBooking((prev) => ({
                ...prev,
                declinedProducts: [...new Set([...(prev.declinedProducts || []), item.product])],
              }))
            }
          />

          <button
            type="button"
            onClick={() => navigate('/payment')}
            className="w-full bg-brand-coral text-white font-bold text-lg py-3 rounded-md"
          >
            Continue to Payment
          </button>
        </main>
      </div>
    </div>
  );
};

export default SeatsPage;
