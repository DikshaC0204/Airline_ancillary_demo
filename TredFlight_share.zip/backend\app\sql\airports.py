"""SQLAlchemy text() statements for airports."""

from sqlalchemy import text

LIST_AIRPORTS = text(
    """
    SELECT code, name, city, country
    FROM airports
    ORDER BY city
    """
)

GET_AIRPORT = text(
    """
    SELECT code, name, city, country
    FROM airports
    WHERE code = :code
    """
)

# Insert if missing. Never overwrite a real city/country with IATA stubs.
ENSURE_AIRPORT = text(
    """
    INSERT INTO airports (code, name, city, country)
    VALUES (:code, :name, :city, :country)
    ON CONFLICT (code) DO UPDATE SET
        name = CASE
            WHEN airports.name IS NULL OR btrim(airports.name) = '' OR airports.name = airports.code
            THEN EXCLUDED.name
            ELSE airports.name
        END,
        city = CASE
            WHEN airports.city IS NULL OR btrim(airports.city) = '' OR airports.city = airports.code
            THEN EXCLUDED.city
            ELSE airports.city
        END,
        country = CASE
            WHEN airports.country IS NULL OR btrim(airports.country) = ''
                 OR airports.country IN ('Unknown', 'UK')
            THEN EXCLUDED.country
            ELSE airports.country
        END
    """
)
