"""TredFlight API entrypoint — Databricks Lakebase PostgreSQL."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.config import get_settings
from app.database import check_db

settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    description="Reusable flight scheduling + ancillary curation framework (Lakebase Postgres)",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix=settings.api_prefix)


@app.on_event("startup")
def on_startup() -> None:
    info = check_db()
    print(f"DB connected schema={info.get('schema')} target={settings.safe_database_target}")
    from app.services.databricks_ensemble import start_serving_keepalive

    start_serving_keepalive()


@app.get("/")
def root():
    return {
        "app": settings.app_name,
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
        "storage": "postgresql",
        "schema": settings.db_schema,
    }
