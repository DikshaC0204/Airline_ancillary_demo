"""Exact Databricks serving rows (column schemas from the ML Payload samples).

Each endpoint was registered with its own one-hot dummy set. Sending a generic
numeric row fails MLflow schema enforcement. These templates keep the signed
columns; live journey fields are overlaid where the name exists.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

_DIR = Path(__file__).resolve().parent.parent / "data" / "serving_payloads"

_ENDPOINT_FILES = {
    "propensity_bag": "propensity_bag.json",
    "propensity_lounge": "propensity_lounge.json",
    "propensity_meal": "propensity_meal.json",
    "propensity_insurance": "propensity_insurance.json",
    "propensity_wifi": "propensity_wifi.json",
    "propensity_upgrade": "propensity_upgrade.json",
    "propensity_seat_std": "propensity_seat_std.json",
    "propensity_seat_leg": "propensity_seat_leg.json",
    "propensity_priority": "propensity_priority.json",
    "lambdamart_ranker": "lambdamart_ranker.json",
    "linucb_policy": "linucb_policy.json",
}

_FARE_TO_FAMILY = {
    "BASIC": "Basic Economy",
    "SMART": "Economy",
    "GO": "Economy",
    "PLUS": "Economy Flex",
    "FAMILY_GO": "Economy",
    "FAMILY_PLUS": "Premium Economy",
}

_MOMENT_STAGE = {
    "SEARCH_RESULTS": "confirmation",
    "SEARCH": "confirmation",
    "FARE_COMPARISON": "payment",
    "FARE": "payment",
    "SEAT_MAP": "seat_selection",
    "SEATS": "seat_selection",
    "PAYMENT": "payment",
    "CHECKOUT": "payment",
    "BOOKING_CONFIRMATION": "confirmation",
    "CONFIRMATION": "confirmation",
    "CHECK_IN": "checkin",
    "CHECKIN": "checkin",
    "AIRPORT_ENTRY": "airport",
    "SECURITY": "airport",
    "AIRPORT": "airport",
    "MANAGE_BOOKING": "confirmation",
    "MMB": "confirmation",
}


@lru_cache(maxsize=24)
def _template_items(endpoint: str) -> tuple[tuple[str, Any], ...]:
    filename = _ENDPOINT_FILES.get(endpoint)
    if not filename:
        return ()
    path = _DIR / filename
    if not path.is_file():
        return ()
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return ()
    return tuple(data.items())


def load_template(endpoint: str) -> dict[str, Any]:
    return dict(_template_items(endpoint))


def _set_onehot(row: dict[str, Any], prefix: str, value: str | None) -> None:
    keys = [k for k in row if k.startswith(prefix)]
    if not keys:
        return
    for key in keys:
        if isinstance(row[key], (int, float)) and not isinstance(row[key], bool):
            row[key] = 0.0
    if not value:
        nan = f"{prefix}nan"
        if nan in row:
            row[nan] = 1.0
        return
    target = f"{prefix}{value}"
    if target in row:
        row[target] = 1.0
        return
    nan = f"{prefix}nan"
    if nan in row:
        row[nan] = 1.0


def pin_record(endpoint: str, record: dict[str, Any]) -> dict[str, Any]:
    """Keep only the signed columns for this endpoint; fill missing numerics with 0."""
    template = load_template(endpoint)
    if not template:
        return dict(record)
    pinned: dict[str, Any] = {}
    for key, default in template.items():
        if key in record:
            pinned[key] = record[key]
        elif isinstance(default, (int, float)) and not isinstance(default, bool):
            pinned[key] = 0.0
        else:
            pinned[key] = default
    return pinned


def overlay_record(
    endpoint: str,
    *,
    numeric: dict[str, Any] | None = None,
    origin: str | None = None,
    destination: str | None = None,
    fare: str | None = None,
    moment: str | None = None,
) -> dict[str, Any]:
    """Return a full signature row for `endpoint`, with live numerics filled in."""
    row = load_template(endpoint)
    if not row:
        return dict(numeric or {})
    for key, value in (numeric or {}).items():
        if key not in row:
            continue
        current = row[key]
        if isinstance(current, bool) or isinstance(value, bool):
            continue
        if isinstance(current, (int, float)) and isinstance(value, (int, float)):
            row[key] = float(value) if isinstance(current, float) else type(current)(value)
        elif isinstance(current, str) and value is not None:
            row[key] = str(value)
    origin_code = (origin or "").strip().upper() or None
    dest_code = (destination or "").strip().upper() or None
    _set_onehot(row, "origin_", origin_code)
    _set_onehot(row, "destination_", dest_code)
    _set_onehot(row, "home_airport_", origin_code)
    fare_key = _FARE_TO_FAMILY.get(str(fare or "").upper())
    if fare_key:
        _set_onehot(row, "fare_family_", fare_key)
        if str(fare or "").upper() in {"PLUS", "FAMILY_PLUS"}:
            _set_onehot(row, "cabin_", "Premium Economy")
        else:
            _set_onehot(row, "cabin_", "Economy")
    stage = _MOMENT_STAGE.get(str(moment or "").upper())
    if stage:
        _set_onehot(row, "journey_stage_", stage)
        _set_onehot(row, "journey_phase_", stage)
    moment_u = str(moment or "").upper()
    if moment_u in {"CHECK_IN", "CHECKIN", "AIRPORT_ENTRY", "SECURITY", "AIRPORT"}:
        _set_onehot(row, "journey_stage_", "boarding")
        _set_onehot(row, "journey_phase_", "boarding")
    return pin_record(endpoint, row)
