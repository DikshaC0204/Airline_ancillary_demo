"""Tiny transformer ranker for ancillary propensity scoring."""
