import React, { useEffect, useMemo, useRef, useState } from 'react';
import { api } from '../api/client';
import { useBooking } from '../context/BookingContext';

const INCLUDED_NAMES = {
  PRIORITY: 'Priority boarding',
  SECURITY_FAST_TRACK: 'Security Fast Track',
  LOUNGE: 'Lounge access',
  SEAT_STANDARD: 'Standard seat',
  SEAT_FRONT: 'Front row seat',
  EXTRA_LEGROOM: 'Extra legroom seat',
  SEAT_PREMIUM: 'Premium seat',
  BAG_10KG: 'Checked bag 10 kg',
  BAG_20KG: 'Checked bag 20 kg',
  BAG_26KG: 'Checked bag 26 kg',
  BAG_32KG: 'Checked bag 32 kg',
  FLEX: 'Travel Flex',
  AUTO_CHECKIN: 'Online check-in',
  SITTING_TOGETHER: 'Sitting together',
  FAMILY_BAG_BUNDLE: 'Family bag + seats bundle',
  FARE_LOCK: 'Fare lock',
  CAFE_VOUCHER: 'Café voucher',
  HOTEL: 'Hotel offer',
  CAR_RENTAL: 'Car rental',
  AIRPORT_PARKING: 'Airport parking',
  ESIM: 'Travel eSIM',
};

const includedLabel = (code) =>
  INCLUDED_NAMES[code] || String(code).replace(/_/g, ' ').toLowerCase();

const uniqueCodes = (...lists) => [
  ...new Set(lists.flat().filter((c) => typeof c === 'string' && c.trim())),
];

/**
 * Offer panel for booking moments — Get Offers.
 */
const CurationPanel = ({
  moment,
  journey,
  heldProducts = [],
  eventStream = [],
  declinedProducts = [],
  inventory = {},
  passengerRef = 'SYN-000431',
  email,
  emails,
  revenueFitDial,
  onAccept,
  onDecline,
  title = 'Recommended for your trip',
  heading = 'Get Offers',
  /** When false, wait for the user to click Get offers before calling /curate. */
  autoFetch = true,
}) => {
  const { booking, setBooking } = useBooking();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [busyProduct, setBusyProduct] = useState(null);
  const [sessionAccepted, setSessionAccepted] = useState([]);
  const [sessionDeclined, setSessionDeclined] = useState([]);
  const mounted = useRef(true);
  const requestSeq = useRef(0);
  const warmRetries = useRef(0);
  const dial = revenueFitDial ?? booking.revenueFitDial ?? 0.45;

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const resolvedEmails = useMemo(() => {
    const fromProp = Array.isArray(emails) ? emails : [];
    const fromBooking = (booking.passengers || [])
      .map((p) => String(p.email || '').trim())
      .filter(Boolean);
    const primary = String(email || '').trim();
    return [...new Set([primary, ...fromProp, ...fromBooking].filter(Boolean))];
  }, [email, emails, booking.passengers]);

  const primaryEmail = resolvedEmails[0] || '';

  const mergedHeld = useMemo(
    () =>
      uniqueCodes(
        heldProducts,
        booking.selectedProducts,
        booking.heldProducts,
        sessionAccepted
      ),
    [heldProducts, booking.selectedProducts, booking.heldProducts, sessionAccepted]
  );
  const mergedDeclined = useMemo(
    () => uniqueCodes(declinedProducts, booking.declinedProducts, sessionDeclined),
    [declinedProducts, booking.declinedProducts, sessionDeclined]
  );

  const runCurate = async (heldOverride, declinedOverride, silent = false) => {
    const seq = ++requestSeq.current;
    if (!silent) setLoading(true);
    setError(null);
    try {
      const data = await api.curate({
        moment,
        channel: 'WEB',
        passenger_ref: passengerRef,
        email: primaryEmail || null,
        emails: resolvedEmails,
        journey,
        event_stream: eventStream,
        held_products: heldOverride || mergedHeld,
        inventory,
        declined_products: declinedOverride || mergedDeclined,
        revenue_fit_dial: dial,
      });
      if (!mounted.current || seq !== requestSeq.current) return data;
      setResult(data);
      return data;
    } catch (err) {
      if (mounted.current && seq === requestSeq.current) setError(err.message);
      return null;
    } finally {
      if (mounted.current && seq === requestSeq.current && !silent) setLoading(false);
    }
  };

  useEffect(() => {
    if (!autoFetch) return undefined;
    warmRetries.current = 0;
    runCurate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    autoFetch,
    moment,
    passengerRef,
    primaryEmail,
    dial,
    JSON.stringify(journey),
    JSON.stringify(mergedHeld),
    JSON.stringify(eventStream),
    JSON.stringify(mergedDeclined),
    JSON.stringify(inventory),
    JSON.stringify(resolvedEmails),
  ]);

  useEffect(() => {
    if (!autoFetch && !result) return undefined;
    const warming = (result?.serving_endpoints || []).some((ep) => ep?.source === 'warming');
    if (!warming || loading || warmRetries.current >= 4) return undefined;
    const timer = setTimeout(() => {
      warmRetries.current += 1;
      runCurate(undefined, undefined, true);
    }, 8000);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [result, loading, autoFetch]);

  const visibleRanked = (result?.ranked || []).filter(
    (item) => !mergedHeld.includes(item.product) && !mergedDeclined.includes(item.product)
  );
  const includedCodes = uniqueCodes(
    (result?.suppressed || []).map((s) => s.product),
    sessionAccepted.filter((code) => !mergedDeclined.includes(code)),
    mergedHeld.filter(
      (code) =>
        INCLUDED_NAMES[code] &&
        !['BASIC_FARE', 'UNDERSEAT_BAG', 'BASIC', 'SMART', 'GO', 'PLUS', 'FAMILY_GO', 'FAMILY_PLUS'].includes(
          code
        )
    )
  );

  const handleAccept = async (item) => {
    if (!item?.product || busyProduct) return;
    const code = item.product;
    const nextHeld = uniqueCodes(mergedHeld, [code]);
    setBusyProduct(code);
    setSessionAccepted((prev) => uniqueCodes(prev, [code]));
    setResult((prev) =>
      prev
        ? {
            ...prev,
            ranked: (prev.ranked || []).filter((row) => row.product !== code),
            suppressed: [
              ...(prev.suppressed || []).filter((row) => row.product !== code),
              { product: code, reason: 'added' },
            ],
          }
        : prev
    );
    setBooking((prev) => ({
      ...prev,
      selectedProducts: uniqueCodes(prev.selectedProducts, [code]),
      heldProducts: uniqueCodes(prev.heldProducts, [code]),
      productPrices: { ...(prev.productPrices || {}), [code]: item.price },
    }));
    try {
      onAccept?.(item);
    } catch {
      /* parent may navigate */
    }
    await runCurate(nextHeld, mergedDeclined);
    if (mounted.current) setBusyProduct(null);
  };

  const handleDecline = async (item) => {
    if (!item?.product || busyProduct) return;
    const code = item.product;
    const nextDeclined = uniqueCodes(mergedDeclined, [code]);
    setBusyProduct(code);
    setSessionDeclined((prev) => uniqueCodes(prev, [code]));
    setResult((prev) =>
      prev
        ? {
            ...prev,
            ranked: (prev.ranked || []).filter((row) => row.product !== code),
          }
        : prev
    );
    setBooking((prev) => ({
      ...prev,
      declinedProducts: uniqueCodes(prev.declinedProducts, [code]),
    }));
    try {
      await api.declineOffer({
        passenger_ref: passengerRef,
        product: code,
        moment,
      });
    } catch {
      /* keep the local decline even if the log write fails */
    }
    try {
      onDecline?.(item);
    } catch {
      /* ignore */
    }
    await runCurate(mergedHeld, nextDeclined);
    if (mounted.current) setBusyProduct(null);
  };

  return (
    <div className="bg-white border border-brand-navy/10 rounded-lg shadow-md overflow-hidden">
      <div className="bg-brand-navy text-white px-4 py-3 flex justify-between items-center gap-3">
        <div>
          <div className="text-xs uppercase tracking-wider text-brand-coral font-bold">{heading}</div>
          <h4 className="font-bold">{title}</h4>
        </div>
        <button
          type="button"
          onClick={() => {
            warmRetries.current = 0;
            runCurate();
          }}
          disabled={loading}
          className="bg-brand-coral hover:bg-pink-700 text-white text-sm font-bold px-4 py-2 rounded-md shrink-0"
        >
          {loading ? 'Loading…' : result ? 'Refresh offers' : 'Get offers'}
        </button>
      </div>

      {error && <p className="p-4 text-sm text-red-600">{error}</p>}

      {loading && !result && (
        <p className="p-4 text-sm text-gray-600">Loading offers… waking Databricks serving in parallel.</p>
      )}

      {!loading && !result && !error && !autoFetch && (
        <p className="p-4 text-sm text-gray-600">
          Enter passenger details, then click Get offers to load recommendations.
        </p>
      )}

      {result && (
        <div className="p-4 space-y-4">
          <div
            className={`text-xs font-semibold rounded-md px-3 py-2 ${
              result.serving_live
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : (result.serving_endpoints || []).some((ep) => ep.source === 'warming')
                  ? 'bg-sky-50 text-sky-800 border border-sky-200'
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
            }`}
          >
            {result.serving_live
              ? `Databricks ensemble ${result.serving_live_count || 0}/${result.serving_total_count || 0} live · final ${
                  result.serving_final_score != null ? Number(result.serving_final_score).toFixed(4) : '—'
                } · LambdaMART ${
                  result.serving_rank_score != null ? Number(result.serving_rank_score).toFixed(4) : '—'
                }`
              : `Databricks serving not live${result.serving_error ? `: ${result.serving_error}` : ''}. Catalogue source: ${result.model_source || 'local'}`}
          </div>
          {Array.isArray(result.serving_endpoints) && result.serving_endpoints.length > 0 && (
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {result.serving_endpoints.map((ep) => (
                <li
                  key={ep.name}
                  className={`text-[11px] rounded-md border px-2 py-1.5 ${
                    ep.live
                      ? 'border-emerald-200 bg-emerald-50/60'
                      : ep.source === 'warming'
                        ? 'border-sky-200 bg-sky-50/70'
                        : 'border-amber-200 bg-amber-50/70'
                  }`}
                >
                  <div className="font-bold text-brand-navy">
                    {ep.name} · {ep.live ? 'Databricks' : ep.source === 'warming' ? 'warming…' : 'local fallback'}
                  </div>
                  <div className="text-gray-600">
                    {ep.role}
                    {ep.value != null ? ` · ${Number(ep.value).toFixed(3)}` : ''}
                    {ep.latency_ms != null ? ` · ${ep.latency_ms} ms` : ''}
                  </div>
                  {!ep.live && ep.error ? (
                    <div className="text-amber-800/80 mt-0.5 break-words">{String(ep.error).slice(0, 160)}</div>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
          {visibleRanked.length > 0 ? (
            <div className="space-y-3">
              {visibleRanked.map((item) => (
                <div
                  key={item.product}
                  className="border rounded-md p-3 flex justify-between gap-4 items-start"
                >
                  <div>
                    <div className="font-bold text-brand-navy">{item.name}</div>
                    {item.price > 0 && (
                      <div className="text-sm font-semibold mt-1 text-brand-navy">
                        ${Number(item.price).toFixed(2)}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col gap-2 shrink-0">
                    <button
                      type="button"
                      disabled={Boolean(busyProduct) || loading}
                      className="bg-brand-coral text-white text-xs font-bold px-3 py-1.5 rounded disabled:opacity-60"
                      onClick={() => handleAccept(item)}
                    >
                      {busyProduct === item.product ? 'Adding…' : 'Add'}
                    </button>
                    <button
                      type="button"
                      disabled={Boolean(busyProduct) || loading}
                      className="border text-xs font-semibold px-3 py-1.5 rounded text-gray-600 disabled:opacity-60"
                      onClick={() => handleDecline(item)}
                    >
                      {busyProduct === item.product ? 'Updating…' : 'Decline'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-700">
              {loading ? 'Refreshing offers…' : 'No offers for this moment.'}
            </p>
          )}

          {includedCodes.length > 0 && (
            <div>
              <h5 className="text-sm font-bold text-gray-700 uppercase mb-2">Already included</h5>
              <ul className="space-y-1 text-sm text-gray-700">
                {includedCodes.map((code) => (
                  <li key={code}>{includedLabel(code)}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CurationPanel;
