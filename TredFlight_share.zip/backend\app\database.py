"""SQLAlchemy engine / session — Databricks Lakebase Postgres (schema: tredflights)."""

from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings

settings = get_settings()

_schema = settings.db_schema.replace('"', "")

engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=10,
    pool_recycle=300,
    future=True,
    connect_args={
        "connect_timeout": 8,
        "options": f"-csearch_path={_schema}",
    },
)


def _schema_sql() -> str:
    return f'SET search_path TO "{_schema}"'


@event.listens_for(engine, "connect")
def _set_search_path_on_connect(dbapi_connection, _connection_record) -> None:  # noqa: ANN001
    cursor = dbapi_connection.cursor()
    cursor.execute(_schema_sql())
    cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def check_db() -> dict:
    """Lightweight connectivity probe used at startup / health."""
    with engine.connect() as conn:
        conn.execute(text(_schema_sql()))
        schema = conn.execute(text("SELECT current_schema()")).scalar()
        return {"ok": True, "schema": schema}
