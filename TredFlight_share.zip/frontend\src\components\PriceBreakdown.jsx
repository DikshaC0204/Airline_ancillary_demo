import React from 'react';
import { computeTotal } from '../context/BookingContext';

const PriceBreakdown = ({ booking, onNext, nextButtonText = 'Continue' }) => {
  const total = computeTotal(booking);

  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-md p-6 sticky top-6">
      <h3 className="text-lg font-bold text-brand-navy border-b pb-3 mb-4 uppercase">Price Breakdown</h3>
      <div className="space-y-3 text-sm text-gray-700">
        {booking.outboundFlight && (
          <div className="flex justify-between">
            <span className="font-semibold">Outbound Flight</span>
            <span>
              $
              {Number(
                booking.outboundFlight.base_price ?? booking.outboundFlight.price ?? 0
              ).toFixed(2)}
            </span>
          </div>
        )}
        {booking.returnFlight && (
          <div className="flex justify-between">
            <span className="font-semibold">Return Flight</span>
            <span>
              $
              {Number(booking.returnFlight.base_price ?? booking.returnFlight.price ?? 0).toFixed(2)}
            </span>
          </div>
        )}
        {booking.extras?.baggage && (
          <div className="flex justify-between text-green-700 font-medium">
            <span>Bag {booking.extras.baggage.weight}</span>
            <span>${Number(booking.extras.baggage.price).toFixed(2)}</span>
          </div>
        )}
        {booking.extras?.seat_price > 0 && (
          <div className="flex justify-between text-green-700 font-medium">
            <span>Seat {booking.extras.seat_label}</span>
            <span>${Number(booking.extras.seat_price).toFixed(2)}</span>
          </div>
        )}
      </div>
      <div className="border-t border-dashed my-4 pt-4 flex justify-between items-center">
        <span className="text-base font-bold text-gray-800">Total Price</span>
        <span className="text-2xl font-black text-brand-navy">${total.toFixed(2)}</span>
      </div>
      <button
        type="button"
        onClick={onNext}
        disabled={!booking.outboundFlight}
        className={`w-full text-white font-bold py-3 px-4 rounded transition mt-4 ${
          booking.outboundFlight
            ? 'bg-brand-coral hover:bg-pink-700 cursor-pointer'
            : 'bg-gray-300 cursor-not-allowed'
        }`}
      >
        {nextButtonText}
      </button>
    </div>
  );
};

export default PriceBreakdown;
