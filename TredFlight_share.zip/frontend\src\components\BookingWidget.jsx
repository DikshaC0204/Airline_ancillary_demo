import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PromoCodeModal from './PromoCodeModal';
import PassengerSelector from './PassengerSelector';
import DatePicker from './DatePicker';
import { FieldError, FormErrorBanner } from './FieldError';
import { useBooking } from '../context/BookingContext';
import { api } from '../api/client';

const FIELD =
  'booking-field border rounded-md px-3 py-1.5 w-full text-left focus:outline-none transition';

const LocationInput = ({ placeholder, value, onChange, locations, error, required }) => {
  const rootRef = useRef(null);
  const inputRef = useRef(null);
  const [isOpen, setIsOpen] = useState(false);
  const [text, setText] = useState(value || '');
  const [committed, setCommitted] = useState(value || '');

  useEffect(() => {
    setText(value || '');
    setCommitted(value || '');
  }, [value]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const onDocClick = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) {
        setIsOpen(false);
        setText(committed);
      }
    };
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
        setText(committed);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [isOpen, committed]);

  const query = text.trim().toLowerCase();
  const lookingLikeSelection = /\([A-Z]{3}\)$/.test(text.trim());
  const filtered = (locations || []).filter((loc) => {
    if (!query || lookingLikeSelection) return true;
    return (
      loc.city?.toLowerCase().includes(query) ||
      loc.name?.toLowerCase().includes(query) ||
      loc.country?.toLowerCase().includes(query) ||
      loc.code?.toLowerCase().includes(query)
    );
  });

  const pick = (loc) => {
    const label = loc.country ? `${loc.country} (${loc.code})` : loc.code;
    setText(label);
    setCommitted(label);
    onChange?.(loc.code, loc);
    setIsOpen(false);
  };

  return (
    <div className="relative col-span-1 min-w-0" ref={rootRef}>
      <div
        className={`${FIELD} flex flex-col justify-center cursor-text ${
          error
            ? 'border-red-500 ring-1 ring-red-500'
            : isOpen
              ? 'border-brand-coral ring-1 ring-brand-coral'
              : 'border-gray-300 focus-within:border-brand-coral'
        }`}
        onClick={() => {
          setIsOpen(true);
          inputRef.current?.focus();
        }}
      >
        <span className="block text-[10px] uppercase tracking-wide text-gray-500 font-bold leading-none mb-0.5">
          {placeholder}
          {required ? ' *' : ''}
        </span>
        <input
          ref={inputRef}
          type="text"
          value={text}
          placeholder={`Select ${placeholder.toLowerCase()}`}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setText(e.target.value);
            setIsOpen(true);
          }}
          className="w-full bg-transparent font-semibold text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none truncate"
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          aria-invalid={error || undefined}
          aria-required={required || undefined}
        />
      </div>
      <FieldError message={error} />

      {isOpen && (
        <div className="absolute top-full left-0 mt-1 w-full min-w-[220px] bg-white border border-gray-200 rounded-lg shadow-2xl z-30 overflow-hidden animate-fadeIn">
          <div className="max-h-56 overflow-y-auto" role="listbox">
            {filtered.length === 0 && (
              <div className="p-3 text-sm text-gray-500">No airports match</div>
            )}
            {filtered.map((loc) => (
              <button
                key={loc.code}
                type="button"
                role="option"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => pick(loc)}
                className="w-full px-3 py-2.5 hover:bg-brand-navy/5 cursor-pointer flex justify-between gap-2 text-left border-b border-gray-50 last:border-0"
              >
                <span className="text-sm truncate">
                  <span className="font-semibold text-gray-900">{loc.country || loc.city}</span>
                </span>
                <span className="font-mono text-xs text-brand-navy font-bold shrink-0">{loc.code}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const BookingWidget = () => {
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();
  const [tripType, setTripType] = useState(booking.tripType || 'return');
  const [isPromoModalOpen, setPromoModalOpen] = useState(false);
  const [airports, setAirports] = useState([]);
  const [origin, setOrigin] = useState(booking.origin || '');
  const [destination, setDestination] = useState(booking.destination || '');
  const [departDate, setDepartDate] = useState(booking.departDate || '');
  const [returnDate, setReturnDate] = useState(booking.returnDate || '');
  const [party, setParty] = useState(booking.party || { adults: 1, children: 0, infants: 0 });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    api.airports().then(setAirports).catch(() => {
      setAirports([
        { code: 'GYD', city: 'Baku', name: 'Heydar Aliyev', country: 'Azerbaijan' },
        { code: 'BUD', city: 'Budapest', name: 'Ferenc Liszt', country: 'Hungary' },
        { code: 'LTN', city: 'London', name: 'Luton', country: 'United Kingdom' },
        { code: 'ALC', city: 'Alicante', name: 'Alicante–Elche', country: 'Spain' },
      ]);
    });
  }, []);

  const clearError = (key) => {
    setErrors((prev) => {
      if (!prev[key]) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const validate = () => {
    const next = {};
    if (!origin) next.origin = 'Origin is required';
    else if (!airports.some((a) => a.code === origin) && origin.length !== 3) {
      next.origin = 'Please select an origin from the list';
    }
    if (!destination) next.destination = 'Destination is required';
    if (origin && destination && origin === destination) {
      next.destination = 'Destination must be different from origin';
    }
    if (!departDate) next.departDate = 'Departure date is required';
    if (tripType === 'return' && !returnDate) next.returnDate = 'Return date is required';
    if (departDate && returnDate && returnDate < departDate) {
      next.returnDate = 'Return date must be on or after departure';
    }
    if (!party?.adults || party.adults < 1) next.passengers = 'At least one adult is required';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const passengers = [];
    for (let i = 0; i < (party.adults || 1); i++) {
      passengers.push({ first_name: '', last_name: '', email: '', age: '', type: 'adult' });
    }
    for (let i = 0; i < (party.children || 0); i++) {
      passengers.push({ first_name: '', last_name: '', email: '', age: '', type: 'child' });
    }
    setBooking((prev) => ({
      ...prev,
      tripType,
      origin,
      destination,
      departDate,
      returnDate: tripType === 'oneway' ? '' : returnDate,
      party,
      passengers,
      passenger_ref: party.children > 0 ? 'SYN-FAMILY-01' : 'SYN-000431',
      // reset previous flight picks for a fresh search
      outboundFlight: null,
      returnFlight: null,
      heldProducts: ['BASIC_FARE'],
      selectedProducts: [],
      declinedProducts: [],
      productPrices: {},
      extras: {},
      fareCode: 'BASIC',
      pnr: null,
    }));
    navigate('/flights', {
      state: {
        origin,
        destination,
        departDate,
        returnDate: tripType === 'oneway' ? '' : returnDate,
        tripType,
        party,
      },
    });
  };

  const originLabel = airports.find((a) => a.code === origin);
  const destLabel = airports.find((a) => a.code === destination);
  const locationValue = (loc, fallback) => {
    if (!loc) return fallback;
    return loc.country ? `${loc.country} (${loc.code})` : loc.code;
  };
  const formError =
    errors.origin ||
    errors.destination ||
    errors.departDate ||
    errors.returnDate ||
    errors.passengers
      ? 'Please enter the highlighted fields to continue.'
      : '';

  return (
    <>
      <div className="bg-white rounded-lg shadow-2xl p-1 max-w-5xl mx-auto relative z-20 overflow-visible">
        <div className="flex border-b border-gray-200">
          {['Flights', 'Holidays', 'Hotels', 'Cars'].map((tab, idx) => (
            <button
              key={tab}
              type="button"
              className={`px-6 py-4 font-bold text-sm ${
                idx === 0
                  ? 'text-brand-navy border-b-4 border-brand-navy'
                  : 'text-gray-500 hover:text-brand-navy'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="p-6 overflow-visible">
          <div className="flex space-x-6 mb-4 font-semibold text-gray-700">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="trip"
                className="accent-brand-coral mr-2 w-4 h-4"
                checked={tripType === 'return'}
                onChange={() => {
                  setTripType('return');
                  clearError('returnDate');
                }}
              />{' '}
              Return
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="trip"
                className="accent-brand-coral mr-2 w-4 h-4"
                checked={tripType === 'oneway'}
                onChange={() => {
                  setTripType('oneway');
                  clearError('returnDate');
                }}
              />{' '}
              One way
            </label>
          </div>

          <form onSubmit={handleSearch} noValidate>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-2 items-start">
              <LocationInput
                placeholder="Origin"
                required
                error={errors.origin}
                value={locationValue(originLabel, origin)}
                locations={airports}
                onChange={(code) => {
                  if (typeof code === 'string' && code.length <= 8) {
                    setOrigin(code);
                    clearError('origin');
                    if (destination && code === destination) {
                      setErrors((prev) => ({
                        ...prev,
                        destination: 'Destination must be different from origin',
                      }));
                    } else clearError('destination');
                  }
                }}
              />
              <LocationInput
                placeholder="Destination"
                required
                error={errors.destination}
                value={locationValue(destLabel, destination)}
                locations={airports}
                onChange={(code) => {
                  if (typeof code === 'string' && code.length <= 8) {
                    setDestination(code);
                    clearError('destination');
                  }
                }}
              />
              <div className="min-w-0">
                <DatePicker
                  label="Departure"
                  placeholder="Pick date"
                  required
                  error={Boolean(errors.departDate)}
                  value={departDate}
                  onChange={(iso) => {
                    setDepartDate(iso);
                    clearError('departDate');
                    if (returnDate && iso && returnDate < iso) setReturnDate('');
                  }}
                />
                <FieldError message={errors.departDate} />
              </div>
              <div className={`min-w-0 ${tripType === 'oneway' ? 'invisible pointer-events-none' : ''}`}>
                <DatePicker
                  label="Return"
                  placeholder="Pick date"
                  required={tripType === 'return'}
                  error={Boolean(errors.returnDate)}
                  value={returnDate}
                  minDate={departDate || undefined}
                  onChange={(iso) => {
                    setReturnDate(iso);
                    clearError('returnDate');
                  }}
                  hidden={false}
                  keepSpace
                />
                <FieldError message={tripType === 'return' ? errors.returnDate : ''} />
              </div>
              <div className="min-w-0">
                <PassengerSelector onPassengerChange={setParty} />
                <FieldError message={errors.passengers} />
              </div>
              <button
                type="submit"
                className="bg-brand-coral text-white font-bold rounded-md px-3 hover:brightness-95 transition w-full text-base booking-field self-start"
              >
                Start booking
              </button>
            </div>
            <FormErrorBanner message={formError} />
          </form>

          <div className="flex justify-between items-center mt-4">
            <label className="flex items-center">
              <input type="checkbox" className="form-checkbox rounded-md" />
              <span className="ml-2 text-sm text-gray-600">Include self-transfer flights</span>
            </label>
            <button
              type="button"
              onClick={() => setPromoModalOpen(true)}
              className="text-sm text-brand-coral font-semibold hover:underline"
            >
              Apply promo code
            </button>
          </div>
        </div>
      </div>

      <PromoCodeModal isOpen={isPromoModalOpen} onClose={() => setPromoModalOpen(false)} />
    </>
  );
};

export default BookingWidget;
