import React from 'react';

/** Inline field error under a control */
export const FieldError = ({ message }) => {
  if (!message) return null;
  return (
    <p className="text-xs text-red-600 mt-1 font-medium" role="alert">
      {message}
    </p>
  );
};

export const FormErrorBanner = ({ message }) => {
  if (!message) return null;
  return (
    <div
      className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-md px-3 py-2 mt-3"
      role="alert"
    >
      {message}
    </div>
  );
};

export default FieldError;
