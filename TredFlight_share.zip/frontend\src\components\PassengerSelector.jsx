import React, { useState, useEffect, useRef } from 'react';

const Counter = ({ label, description, count, onIncrement, onDecrement }) => (
  <div className="flex justify-between items-center py-2">
    <div>
      <div className="font-semibold">{label}</div>
      <div className="text-xs text-gray-500">{description}</div>
    </div>
    <div className="flex items-center space-x-2">
      <button
        type="button"
        onClick={onDecrement}
        className="w-8 h-8 rounded-full border bg-gray-100 text-lg font-bold text-gray-600"
      >
        -
      </button>
      <span className="w-8 text-center font-bold">{count}</span>
      <button
        type="button"
        onClick={onIncrement}
        className="w-8 h-8 rounded-full border bg-brand-coral text-lg font-bold text-white"
      >
        +
      </button>
    </div>
  </div>
);

const PassengerSelector = ({ onPassengerChange }) => {
  const rootRef = useRef(null);
  const onChangeRef = useRef(onPassengerChange);
  const [isOpen, setIsOpen] = useState(false);
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);

  const totalPassengers = adults + children;

  useEffect(() => {
    onChangeRef.current = onPassengerChange;
  }, [onPassengerChange]);

  useEffect(() => {
    onChangeRef.current?.({ adults, children, infants });
  }, [adults, children, infants]);

  useEffect(() => {
    if (!isOpen) return undefined;
    const onDocClick = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setIsOpen(false);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [isOpen]);

  let summary = `${totalPassengers} passenger${totalPassengers > 1 ? 's' : ''}`;
  if (children > 0) summary += `, ${children} child`;
  if (infants > 0) summary += `, ${infants} infant`;

  return (
    <div className="relative col-span-1 min-w-0" ref={rootRef}>
      <button
        type="button"
        onClick={() => setIsOpen((o) => !o)}
        className={`booking-field border rounded-md px-3 py-1.5 font-semibold w-full text-left focus:outline-none transition flex flex-col justify-center ${
          isOpen ? 'border-brand-coral ring-1 ring-brand-coral' : 'border-gray-300 focus:border-brand-coral'
        }`}
        aria-expanded={isOpen}
      >
        <span className="block text-[10px] uppercase tracking-wide text-gray-500 font-bold leading-none mb-0.5">
          Passengers
        </span>
        <span className="text-sm text-gray-900 truncate">{summary}</span>
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-1 w-80 bg-white border border-gray-200 rounded-lg shadow-2xl z-30 p-4 animate-fadeIn">
          <Counter
            label="Adults"
            description="14+"
            count={adults}
            onIncrement={() => setAdults((a) => a + 1)}
            onDecrement={() => setAdults((a) => Math.max(1, a - 1))}
          />
          <Counter
            label="Children"
            description="2-14"
            count={children}
            onIncrement={() => setChildren((c) => c + 1)}
            onDecrement={() => setChildren((c) => Math.max(0, c - 1))}
          />
          <Counter
            label="Infants"
            description="0-2"
            count={infants}
            onIncrement={() => setInfants((i) => i + 1)}
            onDecrement={() => setInfants((i) => Math.max(0, i - 1))}
          />
          <button
            type="button"
            onClick={() => setIsOpen(false)}
            className="mt-4 w-full bg-gray-200 p-2 rounded-md font-bold text-gray-700"
          >
            Done
          </button>
        </div>
      )}
    </div>
  );
};

export default PassengerSelector;
