"""
Legacy local SQLite seeder — unused when connected to Lakebase.

Schema + sample data live in repo-root init.sql (applied via apply_init_sql.py).
Runtime APIs read/write through app/sql text() statements + app/repositories.py.
"""

from __future__ import annotations

from sqlalchemy.orm import Session


def seed_database(db: Session) -> None:  # noqa: ARG001
    """No-op: Lakebase is seeded by init.sql."""
    return
