"""Major origin/destination airports shown in the booking widget.

The full Wizz-style dump in data/origin_dest_airports.txt includes many
secondary fields. The website only lists these hub and high-volume cities,
each with a real country name.
"""

from __future__ import annotations

MAJOR_AIRPORTS: list[dict[str, str]] = [
    {"code": "LTN", "name": "London Luton", "city": "London", "country": "United Kingdom"},
    {"code": "LGW", "name": "London Gatwick", "city": "London", "country": "United Kingdom"},
    {"code": "BUD", "name": "Budapest Ferenc Liszt", "city": "Budapest", "country": "Hungary"},
    {"code": "GYD", "name": "Heydar Aliyev", "city": "Baku", "country": "Azerbaijan"},
    {"code": "ALC", "name": "Alicante–Elche", "city": "Alicante", "country": "Spain"},
    {"code": "BCN", "name": "Barcelona El Prat", "city": "Barcelona", "country": "Spain"},
    {"code": "MAD", "name": "Adolfo Suárez Madrid–Barajas", "city": "Madrid", "country": "Spain"},
    {"code": "AGP", "name": "Málaga–Costa del Sol", "city": "Malaga", "country": "Spain"},
    {"code": "PMI", "name": "Palma de Mallorca", "city": "Palma de Mallorca", "country": "Spain"},
    {"code": "FCO", "name": "Rome Fiumicino", "city": "Rome", "country": "Italy"},
    {"code": "BGY", "name": "Milan Bergamo", "city": "Milan", "country": "Italy"},
    {"code": "NAP", "name": "Naples International", "city": "Naples", "country": "Italy"},
    {"code": "WAW", "name": "Warsaw Chopin", "city": "Warsaw", "country": "Poland"},
    {"code": "KRK", "name": "Kraków John Paul II", "city": "Kraków", "country": "Poland"},
    {"code": "GDN", "name": "Gdańsk Lech Wałęsa", "city": "Gdańsk", "country": "Poland"},
    {"code": "OTP", "name": "Bucharest Otopeni", "city": "Bucharest", "country": "Romania"},
    {"code": "ATH", "name": "Athens International", "city": "Athens", "country": "Greece"},
    {"code": "LIS", "name": "Lisbon Humberto Delgado", "city": "Lisbon", "country": "Portugal"},
    {"code": "SOF", "name": "Sofia Airport", "city": "Sofia", "country": "Bulgaria"},
    {"code": "TIA", "name": "Tirana International", "city": "Tirana", "country": "Albania"},
    {"code": "CRL", "name": "Brussels South Charleroi", "city": "Brussels", "country": "Belgium"},
    {"code": "EVN", "name": "Zvartnots International", "city": "Yerevan", "country": "Armenia"},
]

MAJOR_CODES: frozenset[str] = frozenset(a["code"] for a in MAJOR_AIRPORTS)

# Hubs used to generate demo flights; spokes are the remaining major airports.
HUBS: tuple[str, ...] = ("LTN", "BUD", "GYD", "ALC", "BCN", "FCO", "WAW", "ATH")
POPULAR: tuple[str, ...] = tuple(a["code"] for a in MAJOR_AIRPORTS)

_BY_CODE: dict[str, dict[str, str]] = {a["code"]: a for a in MAJOR_AIRPORTS}

# Approx WGS84 coords for OD distance features (models unchanged; inputs only).
AIRPORT_COORDS: dict[str, tuple[float, float]] = {
    "LTN": (51.8747, -0.3683),
    "LGW": (51.1537, -0.1821),
    "BUD": (47.4394, 19.2618),
    "GYD": (40.4675, 50.0467),
    "ALC": (38.2822, -0.5582),
    "BCN": (41.2971, 2.0785),
    "MAD": (40.4983, -3.5676),
    "AGP": (36.6749, -4.4991),
    "PMI": (39.5517, 2.7388),
    "FCO": (41.8003, 12.2389),
    "BGY": (45.6739, 9.7042),
    "NAP": (40.8860, 14.2908),
    "WAW": (52.1657, 20.9671),
    "KRK": (50.0777, 19.7848),
    "GDN": (54.3776, 18.4662),
    "OTP": (44.5711, 26.0850),
    "ATH": (37.9364, 23.9445),
    "LIS": (38.7742, -9.1342),
    "SOF": (42.6952, 23.4062),
    "TIA": (41.4147, 19.7206),
    "CRL": (50.4592, 4.4538),
    "EVN": (40.1473, 44.3959),
}


def list_major_airports() -> list[dict[str, str]]:
    return [dict(row) for row in MAJOR_AIRPORTS]


def airport_record(code: str) -> dict[str, str]:
    key = (code or "").strip().upper()
    if key in _BY_CODE:
        return dict(_BY_CODE[key])
    return {"code": key, "name": key, "city": key, "country": ""}


def distance_miles(origin: str, destination: str) -> float | None:
    """Great-circle miles between two major airports, or None if unknown."""
    import math

    o = AIRPORT_COORDS.get((origin or "").strip().upper())
    d = AIRPORT_COORDS.get((destination or "").strip().upper())
    if not o or not d:
        return None
    lat1, lon1 = map(math.radians, o)
    lat2, lon2 = map(math.radians, d)
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return round(3958.8 * 2 * math.asin(min(1.0, math.sqrt(a))), 1)