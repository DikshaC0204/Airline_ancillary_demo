# Databricks notebook source
# TredFlight — train ancillary transformer and register for Model Serving
#
# Import: Workspace → Import → this file (Databricks .py source format)
# Cluster: ML runtime 14.x+ (CPU is enough). Attach the TredFlight Git repo
#          or upload backend/app/ml onto the workspace.
#
# This notebook cannot be executed from the laptop IDE. Run it in Databricks.

# COMMAND ----------

# MAGIC %pip install numpy psycopg[binary] python-dotenv fastapi pydantic requests

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

from __future__ import annotations

import json
import os
import random
import sys
from pathlib import Path

import numpy as np

# --- Point this at the cloned TredFlight repo on Databricks Repos ---
REPO_CANDIDATES = [
    Path("/Workspace/Repos") / os.getenv("DATABRICKS_USERNAME", "") / "TredFlight" / "backend",
    Path("/Workspace/Users") / os.getenv("DATABRICKS_USERNAME", "") / "TredFlight" / "backend",
    Path("/Workspace/TredFlight/backend"),
]
for candidate in REPO_CANDIDATES:
    if (candidate / "app" / "ml").exists():
        sys.path.insert(0, str(candidate))
        REPO_BACKEND = candidate
        break
else:
    raise FileNotFoundError(
        "Could not find backend/app/ml. Add the TredFlight Git repo to Databricks Repos "
        "or set REPO_BACKEND manually in this cell."
    )

print("using", REPO_BACKEND)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Lakebase connection
# MAGIC Store secrets once:
# MAGIC ```
# MAGIC databricks secrets create-scope tredflight
# MAGIC databricks secrets put --scope tredflight --key db-user
# MAGIC databricks secrets put --scope tredflight --key db-password
# MAGIC databricks secrets put --scope tredflight --key db-host
# MAGIC ```
# MAGIC Host default is the TredFlight Lakebase hostname.

# COMMAND ----------

def _secret(key: str, default: str = "") -> str:
    try:
        return dbutils.secrets.get(scope="tredflight", key=key)
    except Exception:
        return os.getenv(key.upper().replace("-", "_"), default)


DB_USER = _secret("db-user")
DB_PASSWORD = _secret("db-password")
DB_HOST = _secret("db-host", "ep-late-art-e3d9qikt.database.westus.azuredatabricks.net")
DB_NAME = _secret("db-name", "databricks_postgres")
DB_SCHEMA = _secret("db-schema", "tredflights")

# COMMAND ----------

import psycopg
from psycopg.rows import dict_row

def fetch_booking_labels(limit: int = 5000) -> list[dict]:
    if not DB_USER or not DB_PASSWORD:
        print("No Lakebase secrets — training will use synthetic distillation labels only.")
        return []
    conninfo = (
        f"host={DB_HOST} dbname={DB_NAME} user={DB_USER} password={DB_PASSWORD} "
        "sslmode=require"
    )
    sql = f"""
        SELECT origin, destination, fare_code, party, selected_products,
               extras, trip_type
        FROM {DB_SCHEMA}.bookings
        ORDER BY created_at DESC
        LIMIT %s
    """
    with psycopg.connect(conninfo, row_factory=dict_row) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (limit,))
            return list(cur.fetchall())


bookings = fetch_booking_labels()
print(f"loaded {len(bookings)} bookings from Lakebase")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Train (distill rules + booking positives)

# COMMAND ----------

from app.ml.features import PRODUCT_CODES, encode_context
from app.ml.train import build_dataset, train_from_arrays

tokens, numeric, labels = build_dataset(n=4000, seed=7)

if bookings:
    extra_tok, extra_num, extra_y = [], [], []
    rng = random.Random(11)
    for row in bookings:
        party = row.get("party") or {}
        if isinstance(party, str):
            party = json.loads(party)
        selected = row.get("selected_products") or []
        if isinstance(selected, str):
            selected = json.loads(selected)
        y = np.full((len(PRODUCT_CODES),), 0.05, dtype=np.float32)
        for code in selected:
            if code in PRODUCT_CODES:
                y[PRODUCT_CODES.index(code)] = 0.9
        tok, num = encode_context(
            moment=rng.choice(
                ["SEARCH_RESULTS", "PAYMENT", "SEAT_MAP", "BOOKING_CONFIRMATION"]
            ),
            origin=row.get("origin") or "LTN",
            destination=row.get("destination") or "BUD",
            fare=row.get("fare_code") or "BASIC",
            pax=int(party.get("adults") or 1) + int(party.get("children") or 0),
            adults=int(party.get("adults") or 1),
            children=int(party.get("children") or 0),
            infants=int(party.get("infants") or 0),
            return_trip=(row.get("trip_type") or "return") == "return",
        )
        extra_tok.append(tok)
        extra_num.append(num)
        extra_y.append(y)
    tokens = np.concatenate([tokens, np.stack(extra_tok)], axis=0)
    numeric = np.concatenate([numeric, np.stack(extra_num)], axis=0)
    labels = np.concatenate([labels, np.stack(extra_y)], axis=0)
    print("mixed booking positives into training set:", tokens.shape)

# COMMAND ----------

out_path = Path("/tmp/ancillary_transformer.npz")
artifact = train_from_arrays(tokens, numeric, labels, epochs=12, out=out_path)
print("artifact", artifact, "size", artifact.stat().st_size)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Log to MLflow (optional Unity Catalog model)
# MAGIC After this cell, Serving → Create endpoint → select the registered model
# MAGIC **or** skip MLflow and deploy the Docker image in `ml/serving`.

# COMMAND ----------

import mlflow
from mlflow.models.signature import infer_signature
import pandas as pd

from app.ml.infer import score_payload

class AncillaryPyFunc(mlflow.pyfunc.PythonModel):
    def load_context(self, context):
        from app.ml.transformer import NumpyAncillaryTransformer
        self.model = NumpyAncillaryTransformer.load(context.artifacts["weights"])

    def predict(self, context, model_input):
        if hasattr(model_input, "to_dict"):
            records = model_input.to_dict(orient="records")
        else:
            records = list(model_input)
        out = []
        for rec in records:
            payload = rec.get("payload") if isinstance(rec.get("payload"), dict) else rec
            # journey columns may have been flattened
            if "journey" not in payload and "origin" in payload:
                payload = {
                    "moment": payload.get("moment", "SEARCH_RESULTS"),
                    "channel": payload.get("channel", "WEB"),
                    "journey": payload,
                    "event_stream": [],
                    "held_products": [],
                    "declined_products": [],
                    "revenue_fit_dial": float(payload.get("revenue_fit_dial") or 0.45),
                }
            from app.ml.features import encode_from_mapping
            tok, num = encode_from_mapping(payload)
            out.append(self.model.score_map(tok, num))
        return out


sample = {
    "moment": "SEARCH_RESULTS",
    "channel": "WEB",
    "origin": "LTN",
    "destination": "BUD",
    "fare": "BASIC",
    "pax": 1,
    "adults": 1,
    "children": 0,
    "days_to_departure": 3,
    "trip_nights": 2,
    "return_trip": True,
    "price_sensitivity": "medium",
    "revenue_fit_dial": 0.45,
}
pred = score_payload({"moment": "SEARCH_RESULTS", "journey": sample})
print("smoke scores", {k: round(v, 3) for k, v in list(pred["scores"].items())[:5]})

try:
    dbutils.fs.mkdirs("dbfs:/FileStore/tredflight")
    dbutils.fs.cp(f"file:{artifact.as_posix()}", "dbfs:/FileStore/tredflight/ancillary_transformer.npz")
    print("copied weights to dbfs:/FileStore/tredflight/ancillary_transformer.npz")
except Exception as exc:
    print("DBFS copy skipped:", exc)

try:
    mlflow.set_registry_uri("databricks-uc")
except Exception as exc:
    print("Unity Catalog registry not available:", exc)

register_name = os.getenv("ANCILLARY_UC_MODEL", "").strip()
with mlflow.start_run(run_name="tredflight-ancillary-transformer") as run:
    log_kwargs = {}
    if register_name:
        log_kwargs["registered_model_name"] = register_name
    try:
        mlflow.pyfunc.log_model(
            artifact_path="model",
            python_model=AncillaryPyFunc(),
            artifacts={"weights": str(artifact)},
            pip_requirements=["numpy"],
            **log_kwargs,
        )
        print("run_id", run.info.run_id)
    except Exception as exc:
        print("MLflow pyfunc log skipped:", exc)
        print("Prefer the Docker image in ml/serving for Model Serving.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Create a Model Serving endpoint (pyfunc)
# MAGIC Serving → Create serving endpoint
# MAGIC - Name: `tredflight-ancillary`
# MAGIC - Entity: the registered model from the previous cell
# MAGIC - Compute: CPU Small, scale-to-zero OK
# MAGIC
# MAGIC Invoke:
# MAGIC ```
# MAGIC POST {DATABRICKS_HOST}/serving-endpoints/tredflight-ancillary/invocations
# MAGIC Authorization: Bearer <PAT>
# MAGIC {
# MAGIC   "dataframe_records": [{ "moment": "SEARCH_RESULTS", "origin": "LTN", ... }]
# MAGIC }
# MAGIC ```
# MAGIC
# MAGIC Then in TredFlight `.env`:
# MAGIC ```
# MAGIC CURATION_SCORER=databricks
# MAGIC DATABRICKS_HOST=https://<workspace>.azuredatabricks.net
# MAGIC DATABRICKS_TOKEN=<PAT>
# MAGIC DATABRICKS_SERVING_ENDPOINT=tredflight-ancillary
# MAGIC ```
# MAGIC
# MAGIC Custom container alternative: see `ml/README.md` (build `ml/serving/Dockerfile`,
# MAGIC push to ACR, create a custom-model serving endpoint on port 8080).
