import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white border-t py-8 px-4 mt-12">
      <div className="max-w-7xl mx-auto text-center text-sm text-gray-600">
        TredAir — demo booking experience. © 2026
      </div>
    </footer>
  );
};

export default Footer;
