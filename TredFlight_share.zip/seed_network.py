"""Upsert major origin/destination airports and synthetic demo flights.

Does NOT drop existing tables. Safe to re-run.

Seeds ~90 days of departures (every 3 days, 2 flights/day) per hub↔spoke
pair so flight search dates match user-selected depart/return days.

Usage (from repo root, venv active):
    python seed_network.py
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timedelta
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "backend"))

from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import SessionLocal
from app.data.major_airports import HUBS, MAJOR_AIRPORTS, POPULAR
from app import repositories as repo

HORIZON_DAYS = 90
DAY_STEP = 3
FLIGHTS_PER_DAY = 2

INVENTORY = {
    "PRIORITY": 30,
    "EXTRA_LEGROOM": 8,
    "BAG_20KG": -1,
    "SECURITY_FAST_TRACK": 15,
}


def _stable_price(origin: str, dest: str, day_offset: int, slot: int) -> float:
    h = hashlib.md5(f"{origin}{dest}{day_offset}{slot}".encode()).hexdigest()
    return round(39.0 + (int(h[:4], 16) % 180) + slot * 18.0, 2)


def seed(db: Session) -> None:
    for row in MAJOR_AIRPORTS:
        repo.ensure_airport(
            db,
            row["code"],
            name=row["name"],
            city=row["city"],
            country=row["country"],
        )
    db.commit()
    print(f"Major airports upserted: {len(MAJOR_AIRPORTS)}", flush=True)

    codes = {a["code"] for a in MAJOR_AIRPORTS}
    hubs = [h for h in HUBS if h in codes]
    spokes = [c for c in dict.fromkeys(POPULAR) if c in codes]
    pairs: list[tuple[str, str]] = []
    for hub in hubs:
        for spoke in spokes:
            if hub == spoke:
                continue
            pairs.append((hub, spoke))
            pairs.append((spoke, hub))

    created = 0
    skipped_days = 0
    base = datetime.utcnow().replace(hour=8, minute=0, second=0, microsecond=0)
    for origin, dest in pairs:
        for day_offset in range(0, HORIZON_DAYS, DAY_STEP):
            day = base + timedelta(days=day_offset)
            day_key = day.date().isoformat()
            if repo.list_flights_by_route(db, origin, dest, day=day_key, limit=1):
                skipped_days += 1
                continue
            for i in range(FLIGHTS_PER_DAY):
                depart = day.replace(hour=7 + i * 5, minute=(i * 17) % 60)
                arrive = depart + timedelta(hours=2, minutes=40)
                repo.create_flight(
                    db,
                    flight_number=f"TF{origin[0]}{dest[0]}{day.strftime('%y%m%d')}{i}",
                    origin=origin,
                    destination=dest,
                    depart_at=depart,
                    arrive_at=arrive,
                    base_price=_stable_price(origin, dest, day_offset, i),
                    inventory=INVENTORY,
                    load_factor=round(0.52 + (i * 0.12), 2),
                )
                created += 1
            if created and created % 40 == 0:
                db.commit()
                print(f"  … {created} flights", flush=True)
        db.commit()
    print(f"Route-days already seeded (skipped): {skipped_days}")
    print(f"Synthetic flights created: {created} (horizon={HORIZON_DAYS}d, step={DAY_STEP}d)")


def main() -> None:
    settings = get_settings()
    print(f"Seeding network into {settings.safe_database_target}")
    db = SessionLocal()
    try:
        seed(db)
    finally:
        db.close()


if __name__ == "__main__":
    main()
