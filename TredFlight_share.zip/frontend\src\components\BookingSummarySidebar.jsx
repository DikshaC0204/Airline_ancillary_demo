import React from 'react';
import { computeTotal } from '../context/BookingContext';

const PRODUCT_NAMES = {
  PRIORITY: 'Priority boarding',
  SECURITY_FAST_TRACK: 'Security Fast Track',
  LOUNGE: 'Lounge access',
  SEAT_STANDARD: 'Standard seat',
  SEAT_FRONT: 'Front row seat',
  EXTRA_LEGROOM: 'Extra legroom',
  BAG_10KG: 'Checked bag 10 kg',
  BAG_20KG: 'Checked bag 20 kg',
  BAG_26KG: 'Checked bag 26 kg',
  BAG_32KG: 'Checked bag 32 kg',
  FLEX: 'Travel Flex',
  AUTO_CHECKIN: 'Auto check-in',
  FARE_LOCK: 'Fare lock',
  SITTING_TOGETHER: 'Sitting together',
  FAMILY_BAG_BUNDLE: 'Family bag + seats',
  CAFE_VOUCHER: 'Café voucher',
  HOTEL: 'Hotel offer',
  CAR_RENTAL: 'Car rental',
  AIRPORT_PARKING: 'Airport parking',
  ESIM: 'Travel eSIM',
};

const productLabel = (code) => PRODUCT_NAMES[code] || String(code).replace(/_/g, ' ');

const BookingSummarySidebar = ({ booking, currentStep }) => {
  const total = computeTotal(booking);
  const steps = ['flights', 'passengers', 'seats', 'payment', 'confirmation'];
  const stepLabel = {
    flights: 'Flights',
    passengers: 'Passengers',
    seats: 'Seats',
    payment: 'Payment',
    confirmation: 'Confirmation',
  };
  const productPrices = booking.productPrices || {};
  const bag = booking.extras?.baggage;
  const seatPrice = booking.extras?.seat_price || 0;

  const ancillaryLines = (booking.selectedProducts || [])
    .filter((p) => typeof p === 'string')
    .filter((code) => {
      if (String(code).startsWith('BAG_') && bag) return false;
      if ((String(code).startsWith('SEAT') || code === 'EXTRA_LEGROOM') && seatPrice) return false;
      return true;
    });

  return (
    <div className="bg-white rounded-lg shadow-md w-full">
      <div className="p-4 border-b">
        <div className="font-bold text-sm">
          {booking.origin || '—'} → {booking.destination || '—'}
        </div>
        <div className="text-xs text-gray-600 mt-1">
          {(booking.party?.adults || 1) + (booking.party?.children || 0)} passenger(s) ·{' '}
          {booking.tripType === 'oneway' ? 'One way' : 'Return'}
        </div>
        <div className="flex flex-wrap gap-1 mt-3">
          {steps.map((s) => (
            <span
              key={s}
              className={`text-[10px] px-2 py-0.5 rounded ${
                s === currentStep ? 'bg-brand-coral text-white' : 'bg-gray-100 text-gray-600'
              }`}
            >
              {stepLabel[s]}
            </span>
          ))}
        </div>
      </div>

      <div className="p-4 border-b text-xs space-y-2">
        {booking.outboundFlight && (
          <div className="pb-2 border-b border-dashed">
            <h5 className="font-bold text-gray-800">
              Outbound: {booking.outboundFlight.from || booking.outboundFlight.origin} →{' '}
              {booking.outboundFlight.to || booking.outboundFlight.destination}
            </h5>
            <div className="flex justify-between mt-1">
              <span>Flight ticket</span>
              <span>
                $
                {Number(
                  booking.outboundFlight.base_price ?? booking.outboundFlight.price ?? 0
                ).toFixed(2)}
              </span>
            </div>
            {booking.outboundFlight.bundle?.price > 0 && (
              <div className="flex justify-between mt-1">
                <span>{booking.outboundFlight.bundle.name}</span>
                <span>${Number(booking.outboundFlight.bundle.price).toFixed(2)}</span>
              </div>
            )}
          </div>
        )}
        {booking.returnFlight && (
          <div>
            <h5 className="font-bold text-gray-800">
              Return: {booking.returnFlight.from || booking.returnFlight.origin} →{' '}
              {booking.returnFlight.to || booking.returnFlight.destination}
            </h5>
            <div className="flex justify-between mt-1">
              <span>Flight ticket</span>
              <span>
                $
                {Number(booking.returnFlight.base_price ?? booking.returnFlight.price ?? 0).toFixed(
                  2
                )}
              </span>
            </div>
            {booking.returnFlight.bundle?.price > 0 && (
              <div className="flex justify-between mt-1">
                <span>{booking.returnFlight.bundle.name}</span>
                <span>${Number(booking.returnFlight.bundle.price).toFixed(2)}</span>
              </div>
            )}
          </div>
        )}
        {bag && (
          <div className="flex justify-between">
            <span>Bag {bag.weight}</span>
            <span>${Number(bag.price).toFixed(2)}</span>
          </div>
        )}
        {seatPrice > 0 && (
          <div className="flex justify-between">
            <span>Seat {booking.extras.seat_label || ''}</span>
            <span>${Number(seatPrice).toFixed(2)}</span>
          </div>
        )}
        {ancillaryLines.map((code) => {
          const price = Number(productPrices[code] || 0);
          return (
            <div key={code} className="flex justify-between text-green-700">
              <span>{productLabel(code)}</span>
              <span>${price.toFixed(2)}</span>
            </div>
          );
        })}
      </div>

      <div className="bg-brand-navy text-white p-4 rounded-b-lg flex justify-between items-center">
        <span className="font-bold">TOTAL</span>
        <span className="font-black text-xl">${total.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default BookingSummarySidebar;
