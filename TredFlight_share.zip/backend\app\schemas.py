"""Pydantic request/response schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


# --- Catalogue / flights ---


class AirportOut(BaseModel):
    code: str
    name: str
    city: str
    country: str

    model_config = {"from_attributes": True}


class ProductOut(BaseModel):
    code: str
    name: str
    category: str
    description: str
    base_price: float
    includes: list[str] = []
    metadata_json: dict[str, Any] = {}

    model_config = {"from_attributes": True}


class InventoryOut(BaseModel):
    product_code: str
    remaining: int
    status: str


class FlightOut(BaseModel):
    id: int
    flight_number: str
    origin: str
    destination: str
    depart_at: datetime
    arrive_at: datetime
    base_price: float
    currency: str
    load_factor: float
    delay_minutes: int = 0
    schedule_changed: bool = False
    inventory: list[InventoryOut] = []

    model_config = {"from_attributes": True}


class FlightSearchParams(BaseModel):
    origin: str
    destination: str
    depart_date: str  # YYYY-MM-DD
    return_date: Optional[str] = None
    adults: int = 1
    children: int = 0
    infants: int = 0
    trip_type: Literal["return", "oneway"] = "return"


class FlightSearchResult(BaseModel):
    outbound: list[FlightOut]
    inbound: list[FlightOut] = []
    fare_bundles: list[ProductOut] = []
    message: Optional[str] = None


# --- Curation (requirements API shape) ---


class JourneyContext(BaseModel):
    origin: str
    destination: str
    depart: Optional[str] = None
    pax: int = 1
    adults: int = 1
    children: int = 0
    infants: int = 0
    fare: str = "BASIC"
    days_to_departure: int = 7
    trip_nights: int = 2
    return_trip: bool = True
    price_sensitivity: Literal["low", "medium", "high"] = "medium"
    load_factor: Optional[float] = None
    delay_minutes: int = 0
    schedule_changed: bool = False
    queue_long: bool = False


class EventItem(BaseModel):
    t: str
    e: str


class CurationRequest(BaseModel):
    moment: str
    channel: str = "WEB"
    passenger_ref: str = "SYN-000431"
    # Email(s) for future passenger_ref tagging — not consumed by model schemas yet.
    email: Optional[str] = None
    emails: list[str] = Field(default_factory=list)
    journey: JourneyContext
    event_stream: list[EventItem] = Field(default_factory=list)
    held_products: list[str] = Field(default_factory=list)
    inventory: dict[str, Any] = Field(default_factory=dict)
    declined_products: list[str] = Field(default_factory=list)
    revenue_fit_dial: Optional[float] = None


class RankedProduct(BaseModel):
    product: str
    name: str
    score: float
    reason: str
    price: float = 0.0
    category: str = "ANCILLARY"


class SuppressedProduct(BaseModel):
    product: str
    reason: str


class CurationResponse(BaseModel):
    action: Literal["OFFER", "BUNDLE", "NO_OFFER", "DEFER"]
    ranked: list[RankedProduct]
    suppressed: list[SuppressedProduct]
    fatigue_state: dict[str, int]
    moment: str
    explainability_note: str = ""
    model_source: str = ""
    serving_live: bool = False
    serving_endpoint: str = ""
    serving_latency_ms: float | None = None
    serving_http_status: int | None = None
    serving_rank_score: float | None = None
    serving_error: str | None = None
    serving_final_score: float | None = None
    serving_live_count: int = 0
    serving_total_count: int = 0
    serving_endpoints: list[dict[str, Any]] = Field(default_factory=list)

    model_config = {"protected_namespaces": ()}


# --- Bookings ---


class PassengerInput(BaseModel):
    first_name: str = ""
    last_name: str = ""
    email: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    type: Literal["adult", "child", "infant"] = "adult"


class BookingCreate(BaseModel):
    passenger_ref: Optional[str] = None
    trip_type: Literal["return", "oneway"] = "return"
    origin: str
    destination: str
    outbound_flight_id: int
    return_flight_id: Optional[int] = None
    fare_code: str = "BASIC"
    party: dict[str, int] = Field(default_factory=lambda: {"adults": 1, "children": 0, "infants": 0})
    passengers: list[PassengerInput] = Field(default_factory=list)
    selected_products: list[str] = Field(default_factory=list)
    extras: dict[str, Any] = Field(default_factory=dict)
    promo_code: Optional[str] = None


class BookingUpdate(BaseModel):
    passengers: Optional[list[PassengerInput]] = None
    fare_code: Optional[str] = None
    selected_products: Optional[list[str]] = None
    extras: Optional[dict[str, Any]] = None
    status: Optional[str] = None


class BookingOut(BaseModel):
    id: int
    pnr: str
    passenger_ref: str
    status: str
    trip_type: str
    origin: str
    destination: str
    outbound_flight_id: Optional[int]
    return_flight_id: Optional[int]
    fare_code: str
    party: dict[str, Any]
    passengers: list[Any]
    selected_products: list[str]
    extras: dict[str, Any]
    total_amount: float
    currency: str
    promo_code: Optional[str] = None
    created_at: datetime
    confirmed_at: Optional[datetime] = None
    outbound_flight: Optional[FlightOut] = None
    return_flight: Optional[FlightOut] = None

    model_config = {"from_attributes": True}


class DeclineOfferRequest(BaseModel):
    passenger_ref: str
    product: str
    moment: str


class HealthOut(BaseModel):
    status: str
    app: str
    storage: str
    ancillary_scorer: str = ""
    serving_endpoint: str = ""
    serving_configured: bool = False


class ScorerProbeOut(BaseModel):
    ok: bool
    source: str = ""
    endpoint: str = ""
    url: str = ""
    http_status: int | None = None
    latency_ms: float | None = None
    rank_score: float | None = None
    predictions: list | dict | None = None
    error: str | None = None
    used_local_fallback: bool = False
    endpoints: list[dict[str, Any]] = Field(default_factory=list)
    final_score: float | None = None
    composition: str = ""
    live_count: int = 0
    total_count: int = 0
