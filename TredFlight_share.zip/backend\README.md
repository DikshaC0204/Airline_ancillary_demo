# TredFlight backend

FastAPI service for flight search, bookings, inventory, and ancillary curation.
Connected to **Databricks Lakebase PostgreSQL** (`tredflights` schema from `init.sql`).

## Stack

- FastAPI + Uvicorn
- SQLAlchemy 2.x + `psycopg` (text() SQL, not ORM queries)
- Pydantic response schemas
- Seed data via repo-root `init.sql` / `apply_init_sql.py`

## Run

From repo root (venv active):

```bash
.\.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000 --app-dir backend
```

- OpenAPI: http://127.0.0.1:8000/docs  
- Health: http://127.0.0.1:8000/api/v1/health  

## Configuration

Uses repo-root `.env` (or `backend/.env`). See `.env.example`.

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` or `DB_USER`/`DB_PASSWORD` | Lakebase connection |
| `DB_SCHEMA` | Default `tredflights` |
| `CORS_ORIGINS` | Frontend origins |
| `REVENUE_FIT_DIAL` | Commercial dial 0–1 |
| `CURATION_SCORER` | `auto` (ACE if `ACE_ROOT` set, else Databricks if URL set, else local transformer), `ace`, `transformer`, `databricks`, `serving`, `rules` |
| `ACE_ROOT` | Path to Airline ACE V6 repo (embeds `airline_demo.v6` behind `/curate`) |
| `DATABRICKS_HOST` / `DATABRICKS_TOKEN` / `DATABRICKS_SERVING_ENDPOINT` | Model Serving |
| `ANCILLARY_SCORING_URL` | Direct scoring container (`/invocations`) |

## Package layout

```
app/
  main.py                 # App entry, CORS, DB probe
  config.py               # Lakebase URL + schema
  database.py             # Engine + search_path
  schemas.py              # API request/response models
  repositories.py         # Execute text() SQL, map rows
  models.py               # Schema docs only (not used at runtime)
  sql/                    # ALL text() SQL statements
    airports.py
    products.py
    flights.py
    passengers.py
    bookings.py
    curation.py
  api/routes.py           # REST endpoints
  services/curation_engine.py
  services/ancillary_model.py  # ACE / transformer / Databricks serving client
  services/ace_adapter.py      # embeds Airline ACE V6 from ACE_ROOT
  ml/                     # tiny transformer + bundled weights

```

## Main API groups (`/api/v1`)

| Area | Endpoints | Tables |
|------|-----------|--------|
| Catalogue | `GET /airports`, `GET /products`, `GET /flights/search` | airports, products, flights, inventory |
| Curation | `POST /curate`, `POST /curate/decline` | passenger_profiles, curation_logs |
| Bookings | `POST /bookings`, `GET|PATCH /bookings/{pnr}`, confirm, check-in | bookings, flights |

Demo PNRs from `init.sql`: `DEMO01` … `DEMO05`.
