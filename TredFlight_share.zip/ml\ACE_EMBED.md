# Airline ACE V6 — embed into TredFlight

TredFlight keeps `POST /api/v1/curate` for the React booking UI. When
`CURATION_SCORER=ace`, the backend imports Airline ACE V6 from `ACE_ROOT` and
maps its decision into the existing curation response.

## One-time setup

1. Create / activate a Python 3.12 venv for TredFlight (or reuse ACE's venv).
2. Install TredFlight deps, then ACE strict deps:

```powershell
pip install -r requirements.txt
pip install -r C:\Projects\Projects\TredFlight-Ancillary\Airline_ACE_V6_Databricks_Complete\requirements-strict.txt
```

3. Confirm ACE already has generated data + live-intent weights under:

- `Airline_ACE_V6_Databricks_Complete\data\generated\`
- `Airline_ACE_V6_Databricks_Complete\model_artifacts\live_intent\`

If missing, from the ACE repo:

```powershell
python scripts/run_pipeline.py
python scripts/validate_models.py
```

4. In `backend/.env`:

```env
CURATION_SCORER=ace
ACE_ROOT=C:\Projects\Projects\TredFlight-Ancillary\Airline_ACE_V6_Databricks_Complete
ANCILLARY_LOCAL_FALLBACK=true
```

5. Start TredFlight as usual on port 8000. Health should report
   `ancillary_scorer=ace-v6-local`.

**Important (Windows):** always start the API with *this* repo’s venv:

```powershell
cd C:\Projects\Projects\TredFlight-MLOps\TredFlight\backend
.\venv\Scripts\activate
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

If you mix another checkout’s Python (for example `C:\Projects\Projects\TredFlight\backend\venv`)
with this code, ACE will fail with `ModuleNotFoundError: pandas` and the UI will show
`transformer local fallback`. The curation panel note now includes the ACE error text when
that happens.

## What the Databricks notebooks are for

`Airline_ACE_V6_Databricks_Complete\databricks\notebooks\*.py` are for **cloud**
training / Delta / MLflow registration. They are not required to run the website
locally. Local website scoring uses `airline_demo.v6.service.V6DecisionService`
(the same code `scripts/run_v6_api.py` starts).

## Product ID mapping

| ACE | TredFlight UI |
|-----|---------------|
| PRIORITY | PRIORITY |
| FAST_TRACK | SECURITY_FAST_TRACK |
| BAG | BAG_20KG |
| SEAT_STD | SEAT_STANDARD |
| SEAT_LEG | EXTRA_LEGROOM |
| WIZZ_FLEX | FLEX |
| FAMILY_BASKET | FAMILY_BAG_BUNDLE |

Pre-booking moments (`SEARCH_RESULTS`, `FARE_COMPARISON`, `SEAT_MAP`,
`PAYMENT`, `BOOKING_CONFIRMATION`) use ACE. Other moments fall back to the
bundled transformer / rules when `ANCILLARY_LOCAL_FALLBACK=true`.
