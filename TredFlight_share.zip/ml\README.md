# Ancillary transformer — train, container, Databricks serving

TredFlight ranks ancillaries with a **tiny transformer** (2-layer encoder, 32-d, product scoring head). The React pages still call `POST /api/v1/curate`; only the scorer behind that contract changed.

This IDE cannot write notebooks into your Databricks workspace. Use the files in this folder.

## What runs where

```
React booking pages
        │  POST /api/v1/curate  (unchanged)
        ▼
FastAPI curation_engine
        │  hard filters: held fare, inventory, declines, severe ops
        ▼
ancillary_model.score_request
        ├─ DATABRICKS_SERVING_URL set  →  container / Model Serving
        ├─ else bundled .npz weights   →  local NumPy transformer
        └─ else                        →  original rules engine
```

`CURATION_SCORER=auto` (default) picks Databricks when a URL is configured, otherwise the bundled weights.

## 1. Train locally (already enough to run the app)

From repo root, venv active:

```powershell
pip install -r ml/requirements-train.txt
# CPU torch if needed:
# pip install torch --index-url https://download.pytorch.org/whl/cpu

cd backend
python -m app.ml.train --epochs 12 --samples 4000
```

Writes `backend/app/ml/artifacts/ancillary_transformer.npz`. Restart uvicorn. Booking pages auto-call `/curate` and show a **Model: transformer local** badge.

Training distills the previous rule engine plus random itineraries. The Databricks notebook can mix in real `tredflights.bookings.selected_products` labels from Lakebase.

## 2. Run the scoring container (local check)

From repo root:

```powershell
docker build -f ml/serving/Dockerfile -t tredflight-ancillary:latest .
docker run --rm -p 8080:8080 tredflight-ancillary:latest
```

Smoke test:

```powershell
curl http://127.0.0.1:8080/ping
curl -X POST http://127.0.0.1:8080/invocations `
  -H "Content-Type: application/json" `
  -d "{\"moment\":\"SEARCH_RESULTS\",\"channel\":\"WEB\",\"journey\":{\"origin\":\"LTN\",\"destination\":\"BUD\",\"fare\":\"BASIC\",\"pax\":1,\"adults\":1,\"children\":0,\"days_to_departure\":3,\"trip_nights\":2,\"return_trip\":true,\"price_sensitivity\":\"medium\"},\"held_products\":[],\"event_stream\":[],\"revenue_fit_dial\":0.45}"
```

Point FastAPI at the container:

```env
CURATION_SCORER=serving
ANCILLARY_SCORING_URL=http://127.0.0.1:8080/invocations
```

Without Docker, from repo root:

```powershell
$env:PYTHONPATH = (Resolve-Path backend).Path
python -m uvicorn server:app --app-dir ml/serving --host 127.0.0.1 --port 8080
```

## 3. Train on Databricks (Lakebase labels)

1. Repos → Add repo → this Git remote (or zip-upload `backend/` + `ml/`).
2. Import `ml/databricks/01_train_and_register.py` as a notebook.
3. Create secret scope `tredflight` with `db-user`, `db-password`, optional `db-host`.
4. Run on an ML runtime cluster (CPU is enough). It:
   - reads `tredflights.bookings` from Lakebase
   - trains the same transformer
   - logs an MLflow pyfunc (Unity Catalog name configurable)

## 4. Deploy a Databricks Model Serving container

Push the image to a registry the workspace can pull (Azure Container Registry is typical):

```powershell
az acr login --name <your-acr>
docker tag tredflight-ancillary:latest <your-acr>.azurecr.io/tredflight-ancillary:latest
docker push <your-acr>.azurecr.io/tredflight-ancillary:latest
```

Create the endpoint:

```powershell
$env:DATABRICKS_HOST = "https://<workspace>.azuredatabricks.net"
$env:DATABRICKS_TOKEN = "<PAT>"
$env:ANCILLARY_IMAGE = "<your-acr>.azurecr.io/tredflight-ancillary:latest"
$env:ACR_USERNAME = "<acr-user>"       # optional for private ACR
$env:ACR_PASSWORD = "<acr-password>"
python ml/databricks/02_deploy_serving.py
```

Or in the UI: **Serving → Create endpoint → Custom model → container image**, port **8080**. The image must expose `GET /ping` and `POST /invocations`.

Wait until the endpoint is `Ready`, then in TredFlight `.env`:

```env
CURATION_SCORER=databricks
DATABRICKS_HOST=https://<workspace>.azuredatabricks.net
DATABRICKS_TOKEN=<PAT>
DATABRICKS_SERVING_ENDPOINT=tredflight-ancillary
```

`GET /api/v1/health` reports `ancillary_scorer=databricks` when this is live. If serving is down, FastAPI falls back to the bundled local weights (`ANCILLARY_LOCAL_FALLBACK=true`).

### pyfunc endpoint (no Docker)

After the notebook registers the MLflow model: Serving → Create endpoint → pick `tredflight.default.ancillary_transformer`. Same `.env` as above. Nested `journey` objects work more reliably with the custom container; prefer the container for production.

## Request / response the container expects

`POST /invocations` accepts either a raw context object or Databricks envelopes (`dataframe_records` / `instances`).

```json
{
  "moment": "SEAT_MAP",
  "channel": "WEB",
  "journey": {
    "origin": "LTN",
    "destination": "BUD",
    "fare": "BASIC",
    "pax": 1,
    "adults": 1,
    "children": 0,
    "days_to_departure": 3,
    "trip_nights": 2,
    "return_trip": true,
    "price_sensitivity": "medium",
    "delay_minutes": 0,
    "queue_long": false
  },
  "event_stream": [{"t": "2026-01-01T10:00:00", "e": "SEAT_MAP_OPEN"}],
  "held_products": ["BASIC_FARE"],
  "declined_products": [],
  "revenue_fit_dial": 0.45
}
```

Response:

```json
{
  "predictions": [{ "PRIORITY": 0.71, "BAG_20KG": 0.22, "...": 0.0 }],
  "scores": { "PRIORITY": 0.71 },
  "source": "transformer-serving"
}
```

FastAPI maps those scores through the existing held / inventory / fatigue filters and returns the same `CurationResponse` the UI already renders.
