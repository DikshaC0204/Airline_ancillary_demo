"""SQLAlchemy text() statements for products catalogue."""

from sqlalchemy import text

LIST_PRODUCTS = text(
    """
    SELECT code, name, category, description, base_price, includes, metadata_json
    FROM products
    ORDER BY base_price
    """
)

LIST_PRODUCTS_BY_CATEGORY = text(
    """
    SELECT code, name, category, description, base_price, includes, metadata_json
    FROM products
    WHERE category = :category
    ORDER BY base_price
    """
)

GET_PRODUCT = text(
    """
    SELECT code, name, category, description, base_price, includes, metadata_json
    FROM products
    WHERE code = :code
    """
)

LIST_FARE_BUNDLES = text(
    """
    SELECT code, name, category, description, base_price, includes, metadata_json
    FROM products
    WHERE category = 'FARE'
    ORDER BY base_price
    """
)
