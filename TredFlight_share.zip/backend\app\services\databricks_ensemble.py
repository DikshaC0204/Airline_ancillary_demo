"""Databricks Model Serving ensemble for Airline ACE V6.

Pipeline:
  1. Nine product propensity models → P(purchase) per ancillary
  2. Mean propensity is copied into LambdaMART / LinUCB as
     propensity_score and candidate_fusion_score (no separate fusion model)
  3. LambdaMART ranker → rank_score
  4. LinUCB policy → policy value
  5. final = 0.55·LinUCB + 0.30·tanh(LambdaMART/3) + 0.15·mean(propensity)

Ready endpoints are called live. Not-ready / failed endpoints use a local
heuristic fallback so the website still produces a composed score.
"""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor, wait
from time import perf_counter, time
from typing import Any
import json
import logging
import math
import re
import threading

import requests

from app.config import get_settings
from app.data.major_airports import distance_miles as od_distance_miles
from app.services.serving_payloads import load_template, overlay_record, pin_record

log = logging.getLogger("app.databricks_ensemble")

# One pool for the whole process so /scorer/probe, /curate, and keepalive share in-flight calls.
_HTTP_POOL = ThreadPoolExecutor(max_workers=16, thread_name_prefix="dbx-serving")
_CACHE_LOCK = threading.Lock()
_RESULT_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}
_PENDING: dict[str, Future] = {}
_SCHEMA_COLUMNS: dict[str, list[str]] = {}
_CACHE_TTL_OK = 90.0
_CACHE_TTL_ERR = 4.0
_CACHE_TTL_STALE = 600.0
_KEEPALIVE_THREAD: threading.Thread | None = None
_KEEPALIVE_STOP = threading.Event()
_KEEPALIVE_STARTED = False

# Feature row accepted by the hosted LambdaMART pyfunc.
LAMBDAMART_RECORD: dict[str, float] = {
    "propensity_score": 0.72,
    "expected_revenue": 145.50,
    "embedding_similarity": 0.83,
    "cf_score": 0.61,
    "association_rule_score": 0.45,
    "content_similarity": 0.58,
    "cold_start_score": 0.12,
    "cold_start_confidence": 0.30,
    "journey_relevance": 0.67,
    "business_priority": 0.80,
    "inventory_score": 0.55,
    "candidate_fusion_score": 0.70,
    "price": 89.99,
    "bundle_savings": 15.00,
    "bundle_affinity": 0.40,
    "is_bundle": 1,
    "delay_minutes": 0.0,
    "connection_risk_score": 0.20,
    "airport_dwell_minutes": 45.0,
    "offer_fatigue_score": 0.10,
    "sequence_accept_probability": 0.65,
    "sequence_reject_probability": 0.35,
    "sequence_bundle_preference": 0.50,
    "sequence_candidate_score": 0.75,
    "operational_utility": 0.60,
    "fatigue_penalty": 0.05,
    "lounge_occupancy": 0.30,
    "gate_distance_minutes": 8.0,
    "security_wait_minutes": 12.0,
    "airport_congestion_score": 0.25,
    "minutes_to_departure": 90.0,
    "upgrade_inventory_remaining": 4.0,
    "offer_seen_count": 2.0,
    "offer_rejected_count": 0.0,
    "minutes_since_last_offer": 30.0,
    "segment_number": 1,
    "number_of_segments": 2,
    "effective_connection_buffer_minutes": 25.0,
}

# Numeric passenger/journey fields typical of ACE propensity LightGBM models.
PROPENSITY_RECORD: dict[str, float] = {
    "age": 36.0,
    "price_sensitivity": 0.45,
    "annual_trips": 6.0,
    "historical_ancillary_spend": 120.0,
    "digital_engagement_score": 0.62,
    "distance_miles": 2400.0,
    "duration_minutes": 310.0,
    "total_elapsed_minutes": 360.0,
    "business_route_score": 0.35,
    "leisure_route_score": 0.65,
    "lead_time_days": 21.0,
    "trip_duration_days": 5.0,
    "adults": 1.0,
    "children": 0.0,
    "party_size": 1.0,
    "upgrade_inventory": 4.0,
    "number_of_segments": 2.0,
    "number_of_stops": 1.0,
    "minimum_connection_buffer_minutes": 55.0,
    "international": 1.0,
    "segment_number": 1.0,
    "connection_risk_score": 0.20,
    "prior_product_impressions": 3.0,
    "prior_product_accepts": 1.0,
    "prior_product_clicks": 2.0,
    "prior_product_rejections": 0.0,
    "prior_product_accept_rate": 0.28,
    "prior_product_click_rate": 0.40,
    "prior_all_impressions": 8.0,
    "prior_all_accepts": 2.0,
    "prior_all_accept_rate": 0.22,
}

# Ready Databricks endpoints (underscore LinUCB is the ACE artifact name).
DEFAULT_ENDPOINTS: list[dict[str, str]] = [
    {"name": "propensity_bag", "role": "P(accept) checked bag", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_lounge", "role": "P(accept) lounge", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_meal", "role": "P(accept) meal", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_insurance", "role": "P(accept) insurance", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_wifi", "role": "P(accept) wifi / connectivity", "stage": "1_propensity", "kind": "propensity", "output_key": "purchase_probability"},
    {"name": "propensity_upgrade", "role": "P(accept) seat upgrade", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_seat_std", "role": "P(accept) standard seat", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_seat_leg", "role": "P(accept) extra-legroom seat", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "propensity_priority", "role": "P(accept) priority boarding", "stage": "1_propensity", "kind": "propensity", "output_key": "propensity_probability"},
    {"name": "lambdamart_ranker", "role": "Learning-to-rank", "stage": "2_rank", "kind": "lambdamart", "output_key": "rank_score"},
    {"name": "linucb_policy", "role": "Online policy / final action", "stage": "3_policy", "kind": "linucb", "output_key": "policy_value"},
]

# Endpoint → TredFlight catalogue code (insurance has no merch SKU).
PROPENSITY_TO_PRODUCT: dict[str, str] = {
    "propensity_bag": "BAG_20KG",
    "propensity_lounge": "LOUNGE",
    "propensity_meal": "CAFE_VOUCHER",
    "propensity_wifi": "ESIM",
    "propensity_upgrade": "SEAT_FRONT",
    "propensity_seat_std": "SEAT_STANDARD",
    "propensity_seat_leg": "EXTRA_LEGROOM",
    "propensity_priority": "PRIORITY",
}

MOMENT_PRODUCTS: dict[str, list[str]] = {
    # Passengers — bags + boarding / check-in / security (seats & lounge live elsewhere)
    "SEARCH_RESULTS": [
        "PRIORITY",
        "SECURITY_FAST_TRACK",
        "AUTO_CHECKIN",
        "BAG_20KG",
        "BAG_10KG",
    ],
    "SEARCH": [
        "PRIORITY",
        "SECURITY_FAST_TRACK",
        "AUTO_CHECKIN",
        "BAG_20KG",
        "BAG_10KG",
    ],
    "FARE_COMPARISON": [
        "FAMILY_BAG_BUNDLE",
        "BAG_20KG",
        "BAG_10KG",
        "SITTING_TOGETHER",
        "CAFE_VOUCHER",
    ],
    "FARE": [
        "FAMILY_BAG_BUNDLE",
        "BAG_20KG",
        "BAG_10KG",
        "SITTING_TOGETHER",
        "CAFE_VOUCHER",
    ],
    # Seats page — seat products only
    "SEAT_MAP": ["SEAT_FRONT", "EXTRA_LEGROOM", "SEAT_STANDARD"],
    "SEATS": ["SEAT_FRONT", "EXTRA_LEGROOM", "SEAT_STANDARD"],
    # Payment — remaining merch (meal / connectivity / parking)
    "PAYMENT": ["CAFE_VOUCHER", "ESIM", "AIRPORT_PARKING"],
    "CHECKOUT": ["CAFE_VOUCHER", "ESIM", "AIRPORT_PARKING"],
    # Post-booking — lounge-led + airport comfort
    "BOOKING_CONFIRMATION": ["LOUNGE", "ESIM", "CAFE_VOUCHER", "SECURITY_FAST_TRACK"],
    "CONFIRMATION": ["LOUNGE", "ESIM", "CAFE_VOUCHER", "SECURITY_FAST_TRACK"],
    "PRE_TRIP_REMINDER": ["LOUNGE", "ESIM", "BAG_20KG", "PRIORITY"],
    "PRE_TRIP": ["LOUNGE", "ESIM", "BAG_20KG", "PRIORITY"],
    "MANAGE_BOOKING": ["LOUNGE", "ESIM", "PRIORITY", "BAG_20KG"],
    "MMB": ["LOUNGE", "ESIM", "PRIORITY", "BAG_20KG"],
    "OPS": ["PRIORITY", "BAG_20KG"],
    "CHECK_IN": ["SECURITY_FAST_TRACK", "LOUNGE", "PRIORITY", "ESIM"],
    "CHECKIN": ["SECURITY_FAST_TRACK", "LOUNGE", "PRIORITY", "ESIM"],
    "AIRPORT_ENTRY": ["SECURITY_FAST_TRACK", "LOUNGE", "CAFE_VOUCHER", "ESIM"],
    "SECURITY": ["SECURITY_FAST_TRACK", "LOUNGE", "CAFE_VOUCHER"],
    "AIRPORT": ["SECURITY_FAST_TRACK", "LOUNGE", "CAFE_VOUCHER", "ESIM"],
}

LOCAL_PROPENSITY = {
    "propensity_bag": 0.41,
    "propensity_lounge": 0.33,
    "propensity_meal": 0.27,
    "propensity_insurance": 0.18,
    "propensity_wifi": 0.22,
    "propensity_upgrade": 0.29,
    "propensity_seat_std": 0.48,
    "propensity_seat_leg": 0.36,
    "propensity_priority": 0.52,
}


_SKIP_ENDPOINTS = {"recommendation_engine"}


def _configured_catalog() -> list[dict[str, str]]:
    settings = get_settings()
    raw = (getattr(settings, "databricks_serving_endpoints", "") or "").strip()
    if not raw:
        return list(DEFAULT_ENDPOINTS)
    wanted = {n.strip() for n in raw.split(",") if n.strip() and n.strip() not in _SKIP_ENDPOINTS}
    by_name = {e["name"]: e for e in DEFAULT_ENDPOINTS}
    out = [by_name[n] for n in wanted if n in by_name]
    for n in wanted:
        if n not in by_name and n not in _SKIP_ENDPOINTS:
            out.append(
                {
                    "name": n,
                    "role": "custom",
                    "stage": "custom",
                    "kind": "generic",
                    "output_key": "score",
                }
            )
    return out


def _price_sensitivity_num(label: str) -> float:
    return {"low": 0.2, "medium": 0.45, "high": 0.8}.get(str(label or "medium").lower(), 0.45)


def features_from_request(req: Any | None) -> dict[str, Any]:
    """Build serving rows from the live /curate journey (not a static probe)."""
    propensity = dict(PROPENSITY_RECORD)
    ranker = dict(LAMBDAMART_RECORD)
    moment = "SEARCH_RESULTS"
    if req is None:
        return {
            "propensity": propensity,
            "ranker": ranker,
            "moment": moment,
            "origin": "",
            "destination": "",
            "fare": "BASIC",
        }

    j = getattr(req, "journey", None)
    moment = str(getattr(req, "moment", moment) or moment).upper()
    days = float(getattr(j, "days_to_departure", 7) or 7)
    nights = float(getattr(j, "trip_nights", 2) or 2)
    adults = float(getattr(j, "adults", None) or getattr(j, "pax", 1) or 1)
    children = float(getattr(j, "children", 0) or 0)
    party = max(adults + children, float(getattr(j, "pax", 1) or 1))
    delay = float(getattr(j, "delay_minutes", 0) or 0)
    queue = bool(getattr(j, "queue_long", False))
    sens = _price_sensitivity_num(str(getattr(j, "price_sensitivity", "medium")))
    fare = str(getattr(j, "fare", "BASIC") or "BASIC").upper()
    origin = str(getattr(j, "origin", "") or "")
    destination = str(getattr(j, "destination", "") or "")
    miles = od_distance_miles(origin, destination)
    if miles is None:
        miles = float(getattr(j, "distance_miles", 0) or 0) or float(
            propensity.get("distance_miles") or 1200.0
        )
    duration_min = max(60.0, miles / 8.0)  # ~480 mph cruise heuristic
    events = getattr(req, "event_stream", None) or []
    held = list(getattr(req, "held_products", None) or [])
    declined = list(getattr(req, "declined_products", None) or [])
    email = str(getattr(req, "email", None) or "").strip() or None
    emails = [str(e).strip() for e in (getattr(req, "emails", None) or []) if str(e).strip()]
    if email and email not in emails:
        emails = [email, *emails]
    passenger_ref = str(getattr(req, "passenger_ref", "") or "")

    propensity.update(
        {
            "price_sensitivity": sens,
            "lead_time_days": days,
            "trip_duration_days": nights,
            "distance_miles": float(miles),
            "duration_minutes": float(duration_min),
            "total_elapsed_minutes": float(duration_min + 50.0),
            "leisure_route_score": 0.75 if nights >= 4 else 0.45,
            "business_route_score": 0.55 if nights <= 2 else 0.30,
            "international": 1.0 if miles >= 500 else 0.0,
            "adults": adults,
            "children": children,
            "party_size": party,
            "number_of_segments": 2.0 if bool(getattr(j, "return_trip", True)) else 1.0,
            "number_of_stops": 1.0 if bool(getattr(j, "return_trip", True)) else 0.0,
            "connection_risk_score": 0.35 if delay >= 60 else 0.15,
            "prior_product_rejections": float(len(declined)),
            "prior_product_accepts": float(len(held)),
            "prior_product_impressions": float(max(len(events), 1)),
            "prior_all_impressions": float(max(len(events), 2)),
            "prior_all_accepts": float(len(held)),
            "prior_all_accept_rate": min(0.9, 0.12 + 0.08 * len(held)),
            "digital_engagement_score": min(0.95, 0.35 + 0.08 * len(events)),
        }
    )
    if fare == "BASIC":
        propensity["historical_ancillary_spend"] = 40.0
    elif fare in {"PLUS", "FAMILY_PLUS"}:
        propensity["historical_ancillary_spend"] = 180.0

    minutes = max(30.0, days * 1440.0)
    ranker.update(
        {
            "price": 35.0 if fare == "BASIC" else 55.0,
            "delay_minutes": delay,
            "offer_fatigue_score": min(0.8, 0.08 * len(declined) + 0.04 * len(events)),
            "minutes_to_departure": minutes,
            "offer_seen_count": float(len(events)),
            "offer_rejected_count": float(len(declined)),
            "airport_congestion_score": 0.65 if queue else 0.22,
            "security_wait_minutes": 28.0 if queue else 8.0,
            "lounge_occupancy": 0.55 if queue else 0.28,
            "connection_risk_score": 0.35 if delay >= 60 else 0.15,
            "number_of_segments": 2 if bool(getattr(j, "return_trip", True)) else 1,
            "segment_number": 1,
            "is_bundle": 1 if party >= 3 else 0,
            "journey_relevance": 0.78 if moment in {"SEAT_MAP", "CHECK_IN", "AIRPORT_ENTRY"} else 0.62,
            "business_priority": 0.85 if moment in {"AIRPORT_ENTRY", "CHECK_IN"} else 0.70,
        }
    )
    return {
        "propensity": propensity,
        "ranker": ranker,
        "moment": moment,
        "origin": origin,
        "destination": destination,
        "fare": fare,
        "passenger_ref": passenger_ref,
        "email": email or (emails[0] if emails else None),
        "emails": emails,
    }


def _as_float(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, list) and value:
        return _as_float(value[0])
    return None


def _extract_scalar(data: Any, preferred: str) -> float | None:
    if isinstance(data, (int, float)) and not isinstance(data, bool):
        return float(data)
    if isinstance(data, list) and data:
        return _extract_scalar(data[0], preferred)
    if not isinstance(data, dict):
        return None
    preds = data.get("predictions", data.get("outputs"))
    if preferred in data:
        got = _as_float(data[preferred])
        if got is not None:
            return got
    if isinstance(preds, list) and preds:
        return _extract_scalar(preds[0], preferred)
    if isinstance(preds, dict):
        if preferred in preds:
            got = _as_float(preds[preferred])
            if got is not None:
                return got
        return _extract_scalar(preds, preferred)
    for key in (
        "purchase_probability",
        "propensity_probability",
        "rank_score",
        "candidate_fusion_score",
        "policy_value",
        "bandit_policy_value",
        "bandit_expected_reward",
        "score",
        "action_value",
    ):
        if key in data:
            got = _as_float(data[key])
            if got is not None:
                return got
    nums = [v for v in data.values() if isinstance(v, (int, float)) and not isinstance(v, bool)]
    if len(nums) == 1:
        return float(nums[0])
    if nums:
        return float(nums[0])
    return None


def _invocations_url(endpoint: str) -> str:
    settings = get_settings()
    host = (settings.databricks_host or "").rstrip("/")
    return f"{host}/serving-endpoints/{endpoint}/invocations"


def _payload_for(spec: dict[str, str], context: dict[str, Any]) -> dict[str, Any]:
    kind = spec["kind"]
    name = spec["name"]
    built_meta = {
        "origin": context.get("origin"),
        "destination": context.get("destination"),
        "fare": context.get("fare"),
        "moment": context.get("moment"),
    }
    propensity_row = dict(context.get("propensity_record") or PROPENSITY_RECORD)
    ranker_row = dict(context.get("ranker_record") or LAMBDAMART_RECORD)
    if kind == "propensity":
        return overlay_record(name, numeric=propensity_row, **built_meta)
    if kind == "lambdamart":
        row = ranker_row
        if context.get("propensity") is not None:
            row["propensity_score"] = float(context["propensity"])
        if context.get("fusion") is not None:
            row["candidate_fusion_score"] = float(context["fusion"])
        return overlay_record(name, numeric=row, **built_meta)
    if kind == "linucb":
        rank = float(context.get("rank_score") or 0.0)
        prop = float(context.get("propensity") or LAMBDAMART_RECORD["propensity_score"])
        fusion = float(context.get("fusion") or LAMBDAMART_RECORD["candidate_fusion_score"])
        numeric = {
            "propensity_score": prop,
            "candidate_fusion_score": fusion,
            "final_rank_score": rank,
            "delay_minutes": float(ranker_row.get("delay_minutes") or 0.0),
            "offer_fatigue_score": float(ranker_row.get("offer_fatigue_score") or 0.1),
            "minutes_to_departure": float(ranker_row.get("minutes_to_departure") or 90.0),
            "offer_seen_count": float(ranker_row.get("offer_seen_count") or 0.0),
            "offer_rejected_count": float(ranker_row.get("offer_rejected_count") or 0.0),
            "bandit_feature__propensity_score": prop,
            "bandit_feature__candidate_fusion_score": fusion,
            "bandit_feature__ranker_score_scaled": math.tanh(rank / 3.0),
            "bandit_feature__offer_fatigue_score": float(ranker_row.get("offer_fatigue_score") or 0.1),
            "bandit_feature__delay_scaled": min(2.0, float(ranker_row.get("delay_minutes") or 0.0) / 180.0),
            "bandit_policy_value": math.tanh(rank / 3.0) * 0.70 + fusion * 0.25 + 0.05,
        }
        return overlay_record(name, numeric=numeric, **built_meta)
    return overlay_record(name, numeric=ranker_row, **built_meta)


def _local_value(spec: dict[str, str], context: dict[str, Any]) -> float:
    name = spec["name"]
    kind = spec["kind"]
    if kind == "propensity":
        return float(LOCAL_PROPENSITY.get(name, 0.30))
    if kind == "lambdamart":
        prop = float(context.get("propensity") or LAMBDAMART_RECORD["propensity_score"])
        fusion = float(context.get("fusion") or LAMBDAMART_RECORD["candidate_fusion_score"])
        return 2.4 * fusion + 1.1 * prop - 0.6
    # linucb local: tanh(rank/3) plus light exploration
    rank = float(context.get("rank_score") or 0.0)
    fusion = float(context.get("fusion") or 0.5)
    return math.tanh(rank / 3.0) * 0.70 + fusion * 0.25 + 0.05


def _auth_headers() -> dict[str, str]:
    settings = get_settings()
    headers = {"Content-Type": "application/json"}
    if settings.databricks_token:
        headers["Authorization"] = f"Bearer {settings.databricks_token}"
    return headers


def _http_timeout(warmup: bool = False) -> tuple[float, float]:
    settings = get_settings()
    if warmup:
        read = float(getattr(settings, "databricks_warmup_timeout", 60) or 60)
        return (5.0, max(read, 45.0))
    read = max(float(settings.ancillary_scoring_timeout or 12), 8.0)
    return (3.0, read)


def _columns_from_error(text: str) -> tuple[list[str] | None, list[str] | None]:
    """Parse Databricks/MLflow schema errors into (missing, extra) column lists."""
    if not text:
        return None, None
    missing: list[str] | None = None
    extra: list[str] | None = None
    patterns = (
        (r"missing inputs?\s*:?\s*(\[[^\]]+\])", "missing"),
        (r"extra inputs?\s*:?\s*(\[[^\]]+\])", "extra"),
        (r"missing columns?\s*:?\s*(\[[^\]]+\])", "missing"),
        (r"extra columns?\s*:?\s*(\[[^\]]+\])", "extra"),
        (r"expected columns?[:\s`\[(]+([^\]`\)]+)", "missing"),
        (r"unrecognized columns?[:\s`\[(]+([^\]`\)]+)", "extra"),
        (r"not in the model signature[:\s`\[(]+([^\]`\)]+)", "extra"),
    )
    for pat, kind in patterns:
        match = re.search(pat, text, re.I)
        if not match:
            continue
        blob = match.group(1).strip()
        if blob.startswith("["):
            try:
                parsed = json.loads(blob.replace("'", '"'))
                cols = [str(x) for x in parsed] if isinstance(parsed, list) else []
            except Exception:  # noqa: BLE001
                cols = [c.strip().strip("'\"") for c in blob.strip("[]").split(",") if c.strip()]
        else:
            cols = [c.strip().strip("'\"") for c in blob.split(",") if c.strip().strip("'\"")]
        if kind == "missing":
            missing = cols
        else:
            extra = cols
    return missing, extra


def _align_record(name: str, record: dict[str, Any]) -> dict[str, Any]:
    if load_template(name):
        return pin_record(name, record)
    keys = _SCHEMA_COLUMNS.get(name)
    if not keys:
        return dict(record)
    return {k: record[k] if k in record else 0.0 for k in keys}


def _remember_schema(name: str, record: dict[str, Any], error_text: str) -> dict[str, Any] | None:
    missing, extra = _columns_from_error(error_text)
    if not missing and not extra:
        return None
    keys = list(record.keys())
    if extra:
        drop = set(extra)
        keys = [k for k in keys if k not in drop]
    if missing:
        keys = list(dict.fromkeys([*keys, *missing]))
    if not keys:
        return None
    _SCHEMA_COLUMNS[name] = keys
    return {k: record.get(k, 0.0) for k in keys}


def _post_once(url: str, record: dict[str, Any], timeout: tuple[float, float]) -> dict[str, Any]:
    started = perf_counter()
    try:
        resp = requests.post(
            url,
            json={"dataframe_records": [record]},
            headers=_auth_headers(),
            timeout=timeout,
        )
        latency_ms = round((perf_counter() - started) * 1000, 1)
        try:
            data = resp.json()
        except Exception:  # noqa: BLE001
            data = {"raw": (resp.text or "")[:800]}
        raw_err = None if resp.ok else (resp.text or json.dumps(data) if isinstance(data, dict) else str(data))
        err = (raw_err or "")[:400]
        if raw_err and "Failed to enforce schema" in raw_err:
            err = "Schema mismatch — payload columns do not match this endpoint"
        elif raw_err and "Read timed out" in raw_err:
            err = "Databricks read timeout while replica was waking"
        return {
            "http_status": resp.status_code,
            "latency_ms": latency_ms,
            "ok_http": bool(resp.ok),
            "body": data,
            "error": err or None,
            "error_raw": (raw_err or "")[:4000],
            "url": url,
        }
    except Exception as exc:  # noqa: BLE001
        err = f"{type(exc).__name__}: {exc}"
        short = "Databricks read timeout while replica was waking" if "timed out" in err.lower() else err[:240]
        return {
            "http_status": None,
            "latency_ms": round((perf_counter() - started) * 1000, 1),
            "ok_http": False,
            "body": None,
            "error": short,
            "error_raw": err,
            "url": url,
        }


def _post_endpoint(
    name: str,
    record: dict[str, Any],
    timeout: tuple[float, float] | None = None,
) -> dict[str, Any]:
    url = _invocations_url(name)
    timeout = timeout or _http_timeout(warmup=True)
    payload = _align_record(name, record)
    last = _post_once(url, payload, timeout)
    if last.get("ok_http"):
        return last
    if last.get("http_status") not in {400, 422}:
        return last
    if load_template(name):
        pinned = pin_record(name, payload)
        if list(pinned.keys()) != list(payload.keys()):
            return _post_once(url, pinned, timeout)
        return last
    retried = _remember_schema(name, payload, str(last.get("error_raw") or last.get("error") or ""))
    if not retried:
        return last
    return _post_once(url, retried, timeout)


def _cache_ttl(raw: dict[str, Any]) -> float:
    if raw.get("ok_http"):
        return _CACHE_TTL_OK
    if raw.get("http_status") is None:
        return 3.0
    return _CACHE_TTL_ERR


def _peek_cache(name: str) -> tuple[float | None, dict[str, Any] | None]:
    with _CACHE_LOCK:
        hit = _RESULT_CACHE.get(name)
    if not hit:
        return None, None
    return time() - hit[0], dict(hit[1])


def _post_and_cache(
    name: str,
    record: dict[str, Any],
    timeout: tuple[float, float],
) -> dict[str, Any]:
    try:
        raw = _post_endpoint(name, record, timeout)
        with _CACHE_LOCK:
            _RESULT_CACHE[name] = (time(), raw)
        if raw.get("ok_http"):
            log.info("Databricks %s live in %sms", name, raw.get("latency_ms"))
        else:
            log.warning("Databricks %s failed: %s", name, raw.get("error"))
        return raw
    finally:
        with _CACHE_LOCK:
            _PENDING.pop(name, None)


def _submit_invoke(
    name: str,
    record: dict[str, Any],
    timeout: tuple[float, float] | None = None,
) -> Future:
    timeout = timeout or _http_timeout(warmup=True)
    with _CACHE_LOCK:
        fut = _PENDING.get(name)
        if fut is not None and not fut.done():
            return fut
        fut = _HTTP_POOL.submit(_post_and_cache, name, record, timeout)
        _PENDING[name] = fut
        return fut


def _feature_context(built: dict[str, Any]) -> dict[str, Any]:
    return {
        "propensity_record": built["propensity"],
        "ranker_record": built["ranker"],
        "origin": built.get("origin"),
        "destination": built.get("destination"),
        "fare": built.get("fare"),
        "moment": built.get("moment"),
        "passenger_ref": built.get("passenger_ref"),
        "email": built.get("email"),
        "emails": built.get("emails") or [],
    }


def _warm_all() -> None:
    settings = get_settings()
    if not settings.databricks_host or not settings.databricks_token:
        return
    catalog = _configured_catalog()
    built = features_from_request(None)
    context = _feature_context(built)
    timeout = _http_timeout(warmup=True)
    log.info("Warming %s Databricks serving endpoints", len(catalog))
    for spec in catalog:
        name = spec["name"]
        age, cached = _peek_cache(name)
        if cached and cached.get("ok_http") and age is not None and age < _CACHE_TTL_OK:
            continue
        _submit_invoke(name, _payload_for(spec, context), timeout)


def _keepalive_loop() -> None:
    settings = get_settings()
    interval = max(60.0, float(getattr(settings, "databricks_keepalive_seconds", 180) or 180))
    while not _KEEPALIVE_STOP.wait(interval):
        try:
            _warm_all()
        except Exception:  # noqa: BLE001
            log.exception("Databricks serving keepalive failed")


def start_serving_keepalive() -> None:
    """Ping Databricks Model Serving in the background so replicas stay warm."""
    global _KEEPALIVE_THREAD, _KEEPALIVE_STARTED
    settings = get_settings()
    if not settings.databricks_host or not settings.databricks_token:
        return
    interval = float(getattr(settings, "databricks_keepalive_seconds", 180) or 0)
    with _CACHE_LOCK:
        if _KEEPALIVE_STARTED:
            return
        _KEEPALIVE_STARTED = True
        if interval > 0:
            thread = threading.Thread(target=_keepalive_loop, name="dbx-keepalive", daemon=True)
            _KEEPALIVE_THREAD = thread
            thread.start()
    _HTTP_POOL.submit(_warm_all)


def _result_row(spec: dict[str, str], live: bool, value: float | None, raw: dict[str, Any]) -> dict[str, Any]:
    warming = bool(raw.get("warming")) and not live
    if live:
        source = "databricks"
    elif warming:
        source = "warming"
    else:
        source = "local-fallback"
    error = None if live else (raw.get("error") or "endpoint not ready — local fallback")[:240]
    return {
        "name": spec["name"],
        "role": spec["role"],
        "stage": spec["stage"],
        "live": live,
        "source": source,
        "http_status": raw.get("http_status"),
        "latency_ms": raw.get("latency_ms"),
        "value": value,
        "output_key": spec["output_key"],
        "error": error,
        "url": raw.get("url") or "",
    }


def _compose_rows(
    catalog: list[dict[str, str]],
    built: dict[str, Any],
    raw_by_name: dict[str, dict[str, Any]],
    wall_ms: float,
) -> dict[str, Any]:
    context: dict[str, Any] = {
        "propensity_record": built["propensity"],
        "ranker_record": built["ranker"],
    }
    rows: list[dict[str, Any]] = []
    for spec in catalog:
        raw = raw_by_name.get(spec["name"]) or {
            "ok_http": False,
            "error": "not invoked",
            "http_status": None,
            "latency_ms": None,
            "url": _invocations_url(spec["name"]),
        }
        value = _extract_scalar(raw.get("body"), spec["output_key"]) if raw.get("ok_http") else None
        live = bool(raw.get("ok_http") and value is not None)
        if raw.get("ok_http") and value is None:
            # HTTP 200 with a non-numeric payload (e.g. LinUCB action label).
            live = True
            value = _local_value(spec, context)
        if not live:
            value = _local_value(spec, context)
        if spec["kind"] == "propensity":
            context.setdefault("propensity_values", {})
            context["propensity_values"][spec["name"]] = float(value or 0)
            vals = list(context["propensity_values"].values())
            context["propensity"] = sum(vals) / max(len(vals), 1)
            context["fusion"] = float(context["propensity"])
        elif spec["kind"] == "lambdamart":
            context["rank_score"] = float(value or 0)
        elif spec["kind"] == "linucb":
            context["policy_value"] = float(value or 0)
        rows.append(_result_row(spec, live, value, raw))

    live_count = sum(1 for r in rows if r["live"])
    warming_count = sum(1 for r in rows if r["source"] == "warming")
    rank = float(context.get("rank_score") or 0.0)
    fusion = float(context.get("fusion") or context.get("propensity") or 0.0)
    policy = context.get("policy_value")
    if policy is None:
        policy = math.tanh(rank / 3.0) * 0.70 + fusion * 0.25 + 0.05
    final_score = 0.55 * float(policy) + 0.30 * math.tanh(rank / 3.0) + 0.15 * fusion
    lambdamart = next((r for r in rows if r["name"] == "lambdamart_ranker"), None)
    rest = []
    if warming_count:
        rest.append(f"{warming_count} warming")
    fallback = len(rows) - live_count - warming_count
    if fallback > 0:
        rest.append(f"{fallback} local fallback")
    composition = (
        "final = 0.55·LinUCB + 0.30·tanh(LambdaMART/3) + 0.15·mean(propensity); "
        f"{live_count}/{len(rows)} endpoints live"
        + (f", {', '.join(rest)}" if rest else "")
    )
    product_scores: dict[str, float] = {}
    for name, value in (context.get("propensity_values") or {}).items():
        code = PROPENSITY_TO_PRODUCT.get(name)
        if not code:
            continue
        product_scores[code] = max(product_scores.get(code, 0.0), float(value or 0.0))

    # Non-modelled products: derive from related propensity scores (no fixed floors).
    mean_p = float(context.get("propensity") or 0.0)
    if "BAG_20KG" in product_scores:
        product_scores.setdefault("BAG_10KG", round(product_scores["BAG_20KG"] * 0.88, 4))
    if "PRIORITY" in product_scores:
        airport_bump = (
            0.08
            if built["moment"] in {"AIRPORT_ENTRY", "SECURITY", "AIRPORT", "BOOKING_CONFIRMATION", "CHECK_IN", "CHECKIN"}
            else 0.0
        )
        product_scores.setdefault(
            "SECURITY_FAST_TRACK",
            round(min(0.95, product_scores["PRIORITY"] * 0.92 + airport_bump), 4),
        )
        product_scores.setdefault(
            "AUTO_CHECKIN",
            round(min(0.95, product_scores["PRIORITY"] * 0.72 + mean_p * 0.15), 4),
        )
    elif mean_p > 0:
        product_scores.setdefault("AUTO_CHECKIN", round(min(0.9, mean_p * 0.85), 4))

    # Family-oriented derived products from bag / seat propensity (no fixed floors).
    bag = product_scores.get("BAG_20KG")
    seat = product_scores.get("SEAT_STANDARD") or product_scores.get("EXTRA_LEGROOM")
    if bag is not None:
        seat_for_bundle = float(seat) if seat is not None else float(mean_p or 0.35)
        product_scores.setdefault(
            "FAMILY_BAG_BUNDLE",
            round(min(0.95, 0.55 * float(bag) + 0.45 * seat_for_bundle), 4),
        )
    if seat is not None:
        product_scores.setdefault(
            "SITTING_TOGETHER",
            round(min(0.9, float(seat) * 0.85 + 0.05), 4),
        )
    elif bag is not None:
        product_scores.setdefault(
            "SITTING_TOGETHER",
            round(min(0.85, float(bag) * 0.7), 4),
        )

    # Soft defaults for payment SKUs without a dedicated propensity endpoint.
    mean_for_partners = float(context.get("propensity") or mean_p or 0.3)
    product_scores.setdefault(
        "AIRPORT_PARKING",
        round(min(0.8, mean_for_partners * 0.48 + 0.08), 4),
    )

    ok = bool(lambdamart and lambdamart["live"]) or live_count > 0
    if ok:
        error = None
    elif warming_count:
        error = f"waking {warming_count} Databricks replicas — offers from local fallback"
    else:
        error = "no Databricks endpoints responded"
    settings = get_settings()
    return {
        "ok": ok,
        "source": "databricks-ensemble" if live_count else ("warming" if warming_count else "local-fallback"),
        "endpoint": "ensemble",
        "url": _invocations_url("lambdamart_ranker") if settings.databricks_host else "",
        "http_status": lambdamart["http_status"] if lambdamart else None,
        "latency_ms": round(wall_ms, 1),
        "rank_score": context.get("rank_score"),
        "predictions": [{"rank_score": context.get("rank_score"), "final_score": final_score}],
        "error": error,
        "used_local_fallback": live_count < len(rows),
        "endpoints": rows,
        "final_score": round(float(final_score), 6),
        "composition": composition,
        "live_count": live_count,
        "total_count": len(rows),
        "product_scores": product_scores,
        "moment": built["moment"],
    }


def list_serving_status() -> dict[str, Any]:
    """Fast Ready/Not Ready listing — does not wait for model inference."""
    settings = get_settings()
    catalog = _configured_catalog()
    empty = {
        "ok": False,
        "source": "serving-status",
        "endpoint": "ensemble",
        "url": "",
        "http_status": None,
        "latency_ms": None,
        "rank_score": None,
        "predictions": None,
        "error": "DATABRICKS_HOST / DATABRICKS_TOKEN not set",
        "used_local_fallback": True,
        "endpoints": [],
        "final_score": None,
        "composition": "",
        "live_count": 0,
        "total_count": len(catalog),
    }
    if not settings.databricks_host or not settings.databricks_token:
        return empty
    started = perf_counter()
    ready_names: set[str] = set()
    error = None
    try:
        resp = requests.get(
            f"{settings.databricks_host}/api/2.0/serving-endpoints",
            headers=_auth_headers(),
            timeout=(3.0, 6.0),
        )
        data = resp.json() if resp.content else {}
        if not resp.ok:
            error = (resp.text or f"HTTP {resp.status_code}")[:400]
        else:
            for item in data.get("endpoints") or []:
                name = str(item.get("name") or "")
                state = ((item.get("state") or {}).get("ready") or "").upper()
                if name and state == "READY":
                    ready_names.add(name)
    except Exception as exc:  # noqa: BLE001
        error = f"{type(exc).__name__}: {exc}"
    rows = []
    for spec in catalog:
        cached = _RESULT_CACHE.get(spec["name"])
        cached_live = bool(cached and cached[1].get("ok_http"))
        ready = spec["name"] in ready_names
        rows.append(
            {
                "name": spec["name"],
                "role": spec["role"],
                "stage": spec["stage"],
                "live": cached_live or ready,
                "source": "databricks" if (cached_live or ready) else "not-ready",
                "http_status": cached[1].get("http_status") if cached else None,
                "latency_ms": cached[1].get("latency_ms") if cached else None,
                "value": None,
                "output_key": spec["output_key"],
                "error": None if ready else "Databricks reports not ready",
                "url": _invocations_url(spec["name"]),
            }
        )
    live_count = sum(1 for r in rows if r["live"])
    return {
        "ok": live_count > 0,
        "source": "serving-status",
        "endpoint": "ensemble",
        "url": _invocations_url("lambdamart_ranker"),
        "http_status": 200 if error is None else None,
        "latency_ms": round((perf_counter() - started) * 1000, 1),
        "rank_score": None,
        "predictions": None,
        "error": error,
        "used_local_fallback": live_count < len(rows),
        "endpoints": rows,
        "final_score": None,
        "composition": f"{live_count}/{len(rows)} endpoints Ready in Databricks",
        "live_count": live_count,
        "total_count": len(rows),
    }


def _dispatch_spec(
    spec: dict[str, str],
    context: dict[str, Any],
    timeout: tuple[float, float],
    raw_by_name: dict[str, dict[str, Any]],
    futs: dict[Future, dict[str, str]],
) -> None:
    name = spec["name"]
    payload = _payload_for(spec, context)
    age, cached = _peek_cache(name)
    ttl = _cache_ttl(cached) if cached else 0.0
    if cached and age is not None and age < ttl:
        cached["cached"] = True
        raw_by_name[name] = cached
        return
    if cached and cached.get("ok_http") and age is not None and age < _CACHE_TTL_STALE:
        stale = dict(cached)
        stale["cached"] = True
        raw_by_name[name] = stale
        _submit_invoke(name, payload, timeout)
        return
    futs[_submit_invoke(name, payload, timeout)] = spec


def _await_batch(
    futs: dict[Future, dict[str, str]],
    raw_by_name: dict[str, dict[str, Any]],
    remaining: float,
    started: float,
) -> set[Future]:
    pending: set[Future] = set()
    if not futs:
        return pending
    done, pending = wait(list(futs), timeout=max(0.0, remaining))
    for fut in done:
        spec = futs[fut]
        try:
            raw_by_name[spec["name"]] = fut.result()
        except Exception as exc:  # noqa: BLE001
            raw_by_name[spec["name"]] = {
                "ok_http": False,
                "error": f"{type(exc).__name__}: {exc}"[:240],
                "http_status": None,
                "latency_ms": round((perf_counter() - started) * 1000, 1),
                "url": _invocations_url(spec["name"]),
            }
    for fut in pending:
        spec = futs[fut]
        if spec["name"] in raw_by_name:
            continue
        raw_by_name[spec["name"]] = {
            "ok_http": False,
            "error": "warming Databricks replica — local fallback for this offer",
            "http_status": None,
            "latency_ms": round((perf_counter() - started) * 1000, 1),
            "url": _invocations_url(spec["name"]),
            "warming": True,
        }
    return pending


def _propensity_mean(catalog: list[dict[str, str]], raw_by_name: dict[str, dict[str, Any]]) -> float:
    vals: list[float] = []
    for spec in catalog:
        if spec["kind"] != "propensity":
            continue
        raw = raw_by_name.get(spec["name"]) or {}
        value = _extract_scalar(raw.get("body"), spec["output_key"]) if raw.get("ok_http") else None
        if value is None:
            value = LOCAL_PROPENSITY.get(spec["name"], 0.30)
        vals.append(float(value))
    return sum(vals) / max(len(vals), 1)


def run_ensemble(req: Any | None = None) -> dict[str, Any]:
    settings = get_settings()
    catalog = _configured_catalog()
    built = features_from_request(req)
    context = _feature_context(built)
    if not settings.databricks_host or not settings.databricks_token:
        raw_by_name = {
            spec["name"]: {
                "ok_http": False,
                "error": "DATABRICKS_HOST / DATABRICKS_TOKEN not set",
                "http_status": None,
                "latency_ms": None,
                "url": "",
            }
            for spec in catalog
        }
        out = _compose_rows(catalog, built, raw_by_name, 0.0)
        out["ok"] = False
        out["source"] = "unconfigured"
        out["error"] = "DATABRICKS_HOST / DATABRICKS_TOKEN not set — all local fallback"
        return out

    start_serving_keepalive()
    started = perf_counter()
    deadline = max(0.5, float(getattr(settings, "databricks_offer_deadline", 4.0) or 4.0))
    timeout = _http_timeout(warmup=True)
    raw_by_name: dict[str, dict[str, Any]] = {}
    pending: set[Future] = set()

    propensity_specs = [spec for spec in catalog if spec["kind"] == "propensity"]
    rank_specs = [spec for spec in catalog if spec["kind"] == "lambdamart"]
    policy_specs = [spec for spec in catalog if spec["kind"] not in {"propensity", "lambdamart"}]

    futs: dict[Future, dict[str, str]] = {}
    for spec in propensity_specs:
        _dispatch_spec(spec, context, timeout, raw_by_name, futs)
    pending |= _await_batch(futs, raw_by_name, max(0.0, deadline - (perf_counter() - started)), started)

    mean_p = _propensity_mean(catalog, raw_by_name)
    context["propensity"] = mean_p
    context["fusion"] = mean_p

    futs = {}
    for spec in rank_specs:
        _dispatch_spec(spec, context, timeout, raw_by_name, futs)
    pending |= _await_batch(futs, raw_by_name, max(0.0, deadline - (perf_counter() - started)), started)

    lm_raw = raw_by_name.get("lambdamart_ranker") or {}
    lm_val = _extract_scalar(lm_raw.get("body"), "rank_score") if lm_raw.get("ok_http") else None
    if lm_val is None:
        lm_val = _local_value({"name": "lambdamart_ranker", "kind": "lambdamart"}, context)
    context["rank_score"] = float(lm_val)

    futs = {}
    for spec in policy_specs:
        _dispatch_spec(spec, context, timeout, raw_by_name, futs)
    pending |= _await_batch(futs, raw_by_name, max(0.0, deadline - (perf_counter() - started)), started)

    wall_ms = (perf_counter() - started) * 1000
    if pending:
        log.info(
            "Offer deadline %.1fs: %s live from cache/response, %s still warming",
            deadline,
            sum(1 for r in raw_by_name.values() if r.get("ok_http")),
            len(pending),
        )
    return _compose_rows(catalog, built, raw_by_name, wall_ms)
