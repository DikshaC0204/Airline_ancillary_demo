"""Generate model_working.pdf on the user's Desktop."""

from pathlib import Path

from fpdf import FPDF

OUT = Path(r"C:\Users\vedula.kamesh\OneDrive - Tredence\Desktop\model_working.pdf")
OUT2 = Path(r"C:\Users\vedula.kamesh\Desktop\model_working.pdf")
FONT = Path(r"C:\Windows\Fonts\arial.ttf")
FONT_B = Path(r"C:\Windows\Fonts\arialbd.ttf")


class PDF(FPDF):
    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Body", "B", 9)
        self.set_text_color(30, 58, 95)
        self.cell(0, 8, "TredFlight - How Model Output Becomes Offers", align="L")
        self.ln(4)
        self.set_draw_color(200, 200, 200)
        self.line(self.l_margin, self.get_y(), self.w - self.r_margin, self.get_y())
        self.ln(6)

    def footer(self):
        self.set_y(-15)
        self.set_font("Body", "", 8)
        self.set_text_color(120, 120, 120)
        self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

    def h2(self, text):
        self.ln(3)
        self.set_x(self.l_margin)
        self.set_font("Body", "B", 13)
        self.set_text_color(25, 70, 120)
        self.multi_cell(0, 7, text)
        self.ln(2)

    def h3(self, text):
        self.ln(2)
        self.set_x(self.l_margin)
        self.set_font("Body", "B", 11)
        self.set_text_color(40, 40, 40)
        self.multi_cell(0, 6, text)
        self.ln(1)

    def body(self, text):
        self.set_x(self.l_margin)
        self.set_font("Body", "", 10)
        self.set_text_color(30, 30, 30)
        self.multi_cell(0, 5.5, text)
        self.ln(1)

    def bullet(self, text, indent=8):
        self.set_x(self.l_margin + indent)
        self.set_font("Body", "", 10)
        self.set_text_color(30, 30, 30)
        self.multi_cell(0, 5.5, f"-  {text}")
        self.ln(0.5)

    def mono(self, text):
        self.set_x(self.l_margin)
        self.set_font("Body", "", 9)
        self.set_fill_color(245, 247, 250)
        self.set_text_color(20, 20, 20)
        self.multi_cell(0, 5, text, fill=True)
        self.ln(2)

    def table(self, headers, rows, col_w=None):
        self.set_x(self.l_margin)
        if col_w is None:
            usable = self.w - self.l_margin - self.r_margin
            col_w = [usable / len(headers)] * len(headers)
        self.set_font("Body", "B", 9)
        self.set_fill_color(25, 70, 120)
        self.set_text_color(255, 255, 255)
        for i, h in enumerate(headers):
            self.cell(col_w[i], 7, h, border=1, fill=True, align="C")
        self.ln()
        self.set_font("Body", "", 8.5)
        self.set_text_color(30, 30, 30)
        fill = False
        for row in rows:
            line_h = 5.2
            # Use a fixed single-line row height for simplicity/stability
            row_h = 8
            if self.get_y() + row_h > self.h - 20:
                self.add_page()
                self.set_x(self.l_margin)
                self.set_font("Body", "B", 9)
                self.set_fill_color(25, 70, 120)
                self.set_text_color(255, 255, 255)
                for i, h in enumerate(headers):
                    self.cell(col_w[i], 7, h, border=1, fill=True, align="C")
                self.ln()
                self.set_font("Body", "", 8.5)
                self.set_text_color(30, 30, 30)
            if fill:
                self.set_fill_color(248, 250, 252)
            else:
                self.set_fill_color(255, 255, 255)
            self.set_x(self.l_margin)
            for i, cell in enumerate(row):
                text = str(cell)
                # Truncate very long cells to avoid overflow
                max_chars = max(int(col_w[i] / 1.7), 6)
                if len(text) > max_chars:
                    text = text[: max_chars - 1] + "..."
                self.cell(col_w[i], row_h, text, border=1, fill=True)
            self.ln(row_h)
            fill = not fill
        self.ln(3)


def main() -> None:
    pdf = PDF(format="A4")
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_font("Body", "", str(FONT))
    pdf.add_font("Body", "B", str(FONT_B))
    pdf.set_margins(16, 16, 16)
    pdf.add_page()

    pdf.set_font("Body", "B", 22)
    pdf.set_text_color(15, 40, 80)
    pdf.set_x(pdf.l_margin)
    pdf.multi_cell(0, 10, "TredFlight Offer Pipeline")
    pdf.set_font("Body", "B", 14)
    pdf.set_text_color(60, 90, 130)
    pdf.set_x(pdf.l_margin)
    pdf.multi_cell(0, 7, "How model output becomes page offers")
    pdf.ln(2)
    pdf.set_font("Body", "", 10)
    pdf.set_text_color(80, 80, 80)
    pdf.set_x(pdf.l_margin)
    pdf.multi_cell(
        0,
        5.5,
        "A worked example with numerical values - separating what Databricks "
        "models compute from what our backend / UI decides.",
    )
    pdf.ln(4)

    pdf.h2("1. Example passenger")
    pdf.table(
        ["Input", "Value"],
        [
            ["Route", "LTN -> BUD (~910 miles)"],
            ["Trip", "Return, 5 nights, BASIC fare"],
            ["Party", "1 adult, 0 children (solo)"],
            ["Lead time", "21 days to departure"],
            ["Flow", "Passengers -> Seats -> Payment -> Confirmation"],
        ],
        col_w=[45, 135],
    )
    pdf.body(
        "Each page calls POST /curate with the same journey but a different moment. "
        "Models score likelihood; we choose which SKUs are eligible on that page."
    )

    pdf.h2("2. Big picture — two layers")
    pdf.h3("Models (Databricks)")
    pdf.bullet("Nine product propensity endpoints -> P(buy) per ancillary")
    pdf.bullet("LambdaMART -> rank_score")
    pdf.bullet("LinUCB -> policy_value")
    pdf.bullet("Blend: final = 0.55*LinUCB + 0.30*tanh(LambdaMART/3) + 0.15*mean(P)")
    pdf.h3("Our backend / UI")
    pdf.bullet("Which SKUs are allowed on this page? (MOMENT_PRODUCTS + family rule)")
    pdf.bullet("Derive Fast Track / Auto Check-in / Bag 10kg / Family bundle from related propensities")
    pdf.bullet("Trip-length / distance presentation nudges")
    pdf.bullet("Drop held / declined / fare-included / inventory-blocked; sort; keep score >= 0.1; top 5")
    pdf.ln(1)
    pdf.body("Key idea: Models do NOT choose the page. The page moment catalogue does.")

    pdf.h2("3. Features we send into models (ours -> their input)")
    pdf.table(
        ["Feature", "Example", "Who sets it"],
        [
            ["trip_duration_days", "5", "Us (from dates)"],
            ["distance_miles", "~910", "Us (airport coords)"],
            ["lead_time_days", "21", "Us"],
            ["party_size / adults / children", "1 / 1 / 0", "Us"],
            ["price_sensitivity", "~0.8 (BASIC=high)", "Us mapping"],
        ],
        col_w=[55, 55, 70],
    )

    pdf.h2("4. Illustrative model propensities")
    pdf.table(
        ["Endpoint", "Product", "P (example)"],
        [
            ["propensity_priority", "PRIORITY", "0.52"],
            ["propensity_bag", "BAG_20KG", "0.41"],
            ["propensity_seat_leg", "EXTRA_LEGROOM", "0.36"],
            ["propensity_seat_std", "SEAT_STANDARD", "0.48"],
            ["propensity_upgrade", "SEAT_FRONT", "0.29"],
            ["propensity_meal", "CAFE_VOUCHER", "0.27"],
            ["propensity_wifi", "ESIM", "0.22"],
            ["propensity_lounge", "LOUNGE", "0.33"],
        ],
        col_w=[55, 55, 70],
    )
    pdf.body("Mean propensity used in the ensemble blend (illustrative):")
    pdf.mono("mean(P) ~ 0.36")
    pdf.body("Suppose LambdaMART rank_score = 1.8 and LinUCB policy_value = 0.62:")
    pdf.mono(
        "tanh(LM/3) = tanh(1.8/3) = tanh(0.6) ~ 0.54\n"
        "final = 0.55*0.62 + 0.30*0.54 + 0.15*0.36\n"
        "      = 0.341 + 0.162 + 0.054 = 0.56"
    )
    pdf.body(
        "That final score is a session-level quality / serving signal. Per-offer ranking "
        "on the website uses the per-product propensity scores (plus our derived SKUs), "
        "not this single blend alone."
    )

    pdf.add_page()
    pdf.h2("5. What we derive (no extra models)")
    pdf.table(
        ["Derived SKU", "Formula (approx)", "Example"],
        [
            ["SECURITY_FAST_TRACK", "0.92 * P_priority", "0.92 * 0.52 = 0.478"],
            ["AUTO_CHECKIN", "min(0.95, 0.72*P_priority + 0.15*meanP)", "~0.43"],
            ["BAG_10KG", "0.88 * P_bag", "0.88 * 0.41 = 0.361"],
            ["FAMILY_BAG_BUNDLE", "0.55*P_bag + 0.45*P_seat", "Family only"],
            ["SITTING_TOGETHER", "~0.85 * P_seat", "Family / party >= 2"],
        ],
        col_w=[48, 72, 60],
    )
    pdf.body(
        "Fast Track and Auto Check-in are not separate trained models — they shadow priority propensity."
    )

    pdf.h2("6. Passengers page (SEARCH_RESULTS, solo)")
    pdf.body("We allow only: Priority, Fast Track, Auto Check-in, BAG_20KG, BAG_10KG.")
    pdf.body("Journey nudge (ours): 5 nights -> bags x 1.28")
    pdf.mono("BAG_20KG: 0.41 * 1.28 = 0.525\nBAG_10KG: 0.361 * 1.28 = 0.462")
    pdf.body("Drop if score < 0.1; keep top 5:")
    pdf.table(
        ["Rank", "Product", "Score", "Source"],
        [
            ["1", "Priority Boarding", "0.52", "Model"],
            ["2", "BAG_20KG", "0.525", "Model + our x1.28"],
            ["3", "Fast Track", "0.478", "Derived"],
            ["4", "BAG_10KG", "0.462", "Derived + nudge"],
            ["5", "Auto Check-in", "0.43", "Derived"],
        ],
        col_w=[20, 50, 30, 80],
    )
    pdf.h3("Contrast — short trip (1 night, BASIC)")
    pdf.mono("0.41 * 0.22 = 0.090 < 0.1  => bags NOT suggested")
    pdf.body(
        "Only Priority / Fast Track / Auto Check-in show. On Payment, the static baggage "
        "cards still let the passenger buy a bag — that path is not model-driven."
    )

    pdf.h2("7. Seats page (SEAT_MAP)")
    pdf.body("We allow only: SEAT_FRONT, EXTRA_LEGROOM, SEAT_STANDARD.")
    pdf.body("Distance ~910 miles -> EXTRA_LEGROOM x 1.10")
    pdf.table(
        ["Product", "Raw P", "After nudge", "Shown?"],
        [
            ["SEAT_STANDARD", "0.48", "0.48", "Yes"],
            ["EXTRA_LEGROOM", "0.36", "0.396", "Yes"],
            ["SEAT_FRONT", "0.29", "0.29", "Yes"],
        ],
        col_w=[45, 40, 45, 50],
    )
    pdf.body(
        "Long-haul (>=1500 mi) uses x1.22 on legroom — still our presentation layer, not a model retrain."
    )

    pdf.h2("8. Payment page (PAYMENT)")
    pdf.body("Model catalogue (ours): CAFE_VOUCHER, ESIM, AIRPORT_PARKING only — no bags / boarding.")
    pdf.table(
        ["Product", "Score", "Who"],
        [
            ["Cafe voucher", "0.27", "Meal propensity"],
            ["eSIM", "0.22", "Wifi propensity"],
            ["Airport parking", "~0.25", "Soft default from mean(P); no dedicated model"],
        ],
        col_w=[45, 30, 105],
    )
    pdf.body(
        "Separate UI: checked-baggage picker if they never accepted a bag offer earlier — "
        "pure checkout UX, zero model involvement."
    )

    pdf.h2("9. Confirmation (BOOKING_CONFIRMATION)")
    pdf.body(
        "We allow: LOUNGE, ESIM, CAFE, SECURITY_FAST_TRACK (post-booking comfort). "
        "Lounge 0.33 from lounge propensity; Fast Track still derived from priority if not already held."
    )

    pdf.add_page()
    pdf.h2("10. Family variant (same pipeline, different catalogue)")
    pdf.body("Party: 2 adults + 1 child -> frontend moment FARE_COMPARISON.")
    pdf.body(
        "We allow: Family Bag Bundle, bags, Sitting Together, Cafe — NOT Priority / Fast Track / Auto Check-in."
    )
    pdf.mono(
        "FAMILY_BAG_BUNDLE = 0.55*0.41 + 0.45*0.48 = 0.442\n"
        "  then family nights>=3: x1.15 ~ 0.508\n"
        "SITTING_TOGETHER ~ 0.85*0.48 * 1.10_family ~ 0.45"
    )
    pdf.body("Same propensity endpoints; only eligibility + light multipliers change.")

    pdf.h2("11. Party / page catalogue cheat sheet")
    pdf.table(
        ["Party", "Moment", "Products"],
        [
            ["Solo / couple (no kids, party <= 2)", "SEARCH_RESULTS", "Priority, Fast Track, Auto Check-in, bags"],
            ["Family (kids or party >= 3)", "FARE_COMPARISON", "Family Bag Bundle, bags, Sitting Together, Cafe"],
            ["Any (Seats)", "SEAT_MAP", "Seat front / legroom / standard"],
            ["Any (Payment curated)", "PAYMENT", "Cafe, eSIM, airport parking"],
            ["Any (Payment bags UI)", "(static)", "Bag weight picker if no bag already held"],
            ["Post-booking", "BOOKING_CONFIRMATION", "Lounge-led extras"],
        ],
        col_w=[55, 40, 85],
    )

    pdf.h2("12. Models vs us")
    pdf.table(
        ["Responsibility", "Models", "Our backend / UI"],
        [
            ["P(buy bag/priority/seat/...)", "Yes", ""],
            ["LTR / policy blend (final)", "Yes (telemetry/health)", ""],
            ["Map endpoint -> SKU", "", "Yes"],
            ["Derive Fast Track / Auto / Bag10 / Family bundle", "", "Yes"],
            ["Which page sees which SKUs", "", "Yes"],
            ["Short-trip hide bags / long-trip / distance lift", "", "Yes"],
            ["Held / declined / fare / inventory", "", "Yes"],
            ["Top-N list (threshold 0.1, cap 5)", "", "Yes"],
            ["Payment baggage cards", "", "Static UI only"],
        ],
        col_w=[75, 40, 65],
    )

    pdf.h2("13. One-sentence mental model")
    pdf.body(
        'Models score "how likely"; we decide "allowed on this page + soft journey nudge + top 5"; '
        "payment bag tiles are a manual escape hatch when the model (correctly) stayed quiet on a short trip."
    )

    pdf.ln(6)
    pdf.set_font("Body", "", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.multi_cell(
        0,
        5,
        "Generated for TredFlight MLOps demo. Numbers in this document are illustrative "
        "walkthrough values, not a live /curate dump.",
    )

    OUT.parent.mkdir(parents=True, exist_ok=True)
    pdf.output(str(OUT))
    print(f"WROTE {OUT} ({OUT.stat().st_size} bytes)")
    if OUT2.resolve() != OUT.resolve():
        try:
            pdf.output(str(OUT2))
            print(f"ALSO {OUT2}")
        except OSError as exc:
            print(f"skip mirror: {exc}")


if __name__ == "__main__":
    main()
