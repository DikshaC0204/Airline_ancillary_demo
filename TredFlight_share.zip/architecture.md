# TredFlight Architecture

TredFlight is a **reusable flight scheduling + ancillary curation** web application. Carrier-specific branding is avoided in product catalogues and fare names; the site logo/name is **TredFlight**. The same codebase is intended for future airline projects with light configuration changes (catalogue, themes, `DATABASE_URL`).

Requirements source: Ancillary Curation Engine demo workbook (scenarios, product rules, single `/curate` API shape). Keep workbooks in a local `requirement/` folder — that path is **gitignored** and not part of the committed tree.

---

## 1. Goals

| Goal | How TredFlight addresses it |
|------|-------------------------------|
| Generic scheduling UI | Search → flights/fares → passengers/bags → seats → payment → confirmation → manage booking |
| Ancillary curation demo | One `/api/v1/curate` endpoint; ranked + suppressed + reasons |
| Empty-route demos | Flight search auto-creates persistent demo flights for any O&D |
| No cloud DB yet | SQLAlchemy + **SQLite file** locally |
| Easy DB migration later | Same ORM models; change `DATABASE_URL` to PostgreSQL |
| Reuse across projects | Generic product codes (`PRIORITY`, `FLEX`, `BAG_20KG`, fare `BASIC`/`GO`/`PLUS`/…) |

---

## 2. High-level system context

```mermaid
flowchart LR
  Browser["React SPA<br/>TredFlight UI"]
  API["FastAPI<br/>/api/v1"]
  Engine["Curation Engine<br/>Memory→Filter→Rank"]
  DB[("SQLAlchemy<br/>SQLite now / Postgres later")]

  Browser -->|REST JSON| API
  API --> Engine
  API --> DB
  Engine --> DB
```

---

## 3. Repository layout

```
TredFlight/
├── architecture.md          ← this file
├── requirements.txt         ← Python deps
├── backend/
│   ├── app/
│   │   ├── main.py          ← FastAPI app + CORS + startup seed
│   │   ├── config.py        ← DATABASE_URL, dial, CORS
│   │   ├── database.py      ← engine, Session, Base
│   │   ├── models.py        ← ORM tables
│   │   ├── schemas.py       ← Pydantic I/O
│   │   ├── seed.py          ← airports, products, demo flights
│   │   ├── api/routes.py    ← REST endpoints (+ auto-seed missing routes)
│   │   └── services/
│   │       └── curation_engine.py
│   ├── data/tredflight.db   ← created at runtime (gitignored)
│   └── .env.example
└── frontend/
    └── src/
        ├── api/client.js
        ├── context/BookingContext.jsx
        ├── components/…     ← Header, BookingWidget, DatePicker, CurationPanel, …
        └── pages/…          ← Home, Flights, Passengers, Seats, Payment, Confirmation, Manage
```

Local-only (gitignored): `requirement/` (Excel scenarios), `backend/venv/`, `frontend/node_modules/`, `frontend/.env.local`.

---

## 4. Local data storage (recommended approach)

### Decision: **SQLAlchemy + SQLite file**, not ad-hoc JSON

| Option | Pros | Cons | Verdict |
|--------|------|------|---------|
| Browser-only / localStorage | Zero backend | No shared bookings, weak for curation memory | Reject for server data |
| JSON files on disk | Simple | No queries, painful migrations, race conditions | Reject |
| **SQLite via SQLAlchemy** | Real relational schema; same models as Postgres; zero infra | Single-node write limits (fine for demos) | **Chosen** |
| Embedded Mongo / etc. | Flexible docs | Extra stack; weaker SQL migration story | Reject |

### Why this migrates cleanly later

1. All persistence goes through **SQLAlchemy models** (`Airport`, `Flight`, `Product`, `Booking`, `PassengerProfile`, `InventoryItem`, `CurationLog`).
2. Connection is a single setting:

```env
# Local (default)
DATABASE_URL=sqlite:///…/backend/data/tredflight.db

# When approved / provisioned
DATABASE_URL=postgresql+psycopg://USER:PASS@HOST:5432/tredflight
```

3. On deploy: install a Postgres driver (`psycopg`), set `DATABASE_URL`, run the app (or Alembic migrations when you add them). **No rewrite of business logic.**
4. Session booking draft also mirrors to `sessionStorage` on the frontend for UX resilience; authoritative PNRs live in the DB after create/confirm.

### Optional next step for production

Add **Alembic** migrations once the schema stabilizes. Until then `Base.metadata.create_all()` on startup is enough for demos.

---

## 5. Domain model

```mermaid
erDiagram
  Airport ||--o{ Flight : origin_dest
  Flight ||--o{ InventoryItem : has
  Product ||--o{ InventoryItem : stocked_as
  PassengerProfile ||--o{ Booking : books
  Flight ||--o{ Booking : outbound_return
  PassengerProfile ||--o{ CurationLog : decisions

  Airport {
    string code PK
    string city
  }
  Flight {
    int id PK
    string flight_number
    float load_factor
    int delay_minutes
  }
  Product {
    string code PK
    string category
    float base_price
    json includes
  }
  Booking {
    string pnr UK
    string status
    string fare_code
    json selected_products
  }
  PassengerProfile {
    string passenger_ref PK
    json held_products
    json declined_products
    json event_stream
  }
```

### Generic catalogue (no carrier brand names)

**Fares:** Basic, Smart, Go, Plus, Family Go, Family Plus  

**Ancillaries:** Priority Boarding, Security Fast Track, Lounge, seats (standard / front / XL), bags 10/20/26/32 kg, Travel Flex, Auto Check-in, Fare Lock, Sitting Together, Café voucher, Gift voucher, Family bag+seats bundle  

**Partners:** Hotel, Car rental, Airport parking, eSIM  

Entitlements on fares drive **suppression** (never re-sell what is already held).

---

## 6. Curation engine

Implements the demo pipeline from the requirements workbook:

```mermaid
flowchart TD
  Req["POST /api/v1/curate<br/>moment, channel, journey,<br/>events, held, inventory"]
  Mem["Memory<br/>PassengerProfile + declines"]
  Und["Understand<br/>party, lead time, seat-map opens,<br/>ops delay, queue"]
  Gen["Generate candidates<br/>by moment"]
  Fil["Filter<br/>held · inventory · fatigue"]
  Rank["Rank<br/>+ revenue/fit dial"]
  Sel["Select action<br/>OFFER | BUNDLE | NO_OFFER"]
  Out["ranked[] + suppressed[] + reasons"]

  Req --> Mem --> Und --> Gen --> Fil --> Rank --> Sel --> Out
```

### Moments covered

| Moment | Demo intent |
|--------|-------------|
| `SEARCH_RESULTS` | Cold-start; Priority ↑; short-trip bag suppressed; complements (Fast Track, Auto check-in, Flex) |
| `FARE_COMPARISON` | Family → shared bag+seats **bundle** |
| `SEAT_MAP` | Live intent from repeated map opens |
| `PAYMENT` | Price-sensitive low-ticket / dial-driven NO_OFFER (browse events alone do not skip offers) |
| `BOOKING_CONFIRMATION` | Entitlement filter; Fast Track complements Priority |
| `PRE_TRIP_REMINDER` | Do not repeat declined seats |
| `MANAGE_BOOKING` | Delay / schedule change boosts Flex |
| `CHECK_IN` | Near-departure: Priority + bag over seats |
| `AIRPORT_ENTRY` | Fast Track when Priority held + queue |

Commercial dial: `REVENUE_FIT_DIAL` (env) or per-request `revenue_fit_dial` (0 = fit/restraint, 1 = revenue).

### Memory vs current booking context

On `POST /curate`, the API loads `PassengerProfile` for **declines, event stream, and fatigue** only. It does **not** merge historical `profile.held_products` into the request. Entitlements come from the request’s fare + `held_products` so prior demo purchases do not falsely suppress every offer.

Explainability is intentional: UI always can show **ranked scores/reasons** and **suppressed** list.

---

## 7. Booking UX flow

```mermaid
sequenceDiagram
  actor User
  participant UI as React SPA
  participant API as FastAPI
  participant DB as SQLite/Postgres

  User->>UI: Search O&D / dates / pax
  UI->>API: GET /flights/search
  API->>DB: query flights (auto-create O&D if empty)
  API-->>UI: outbound / inbound / fare bundles
  UI->>API: POST /curate (SEARCH_RESULTS)
  User->>UI: Select flight + fare
  User->>UI: Passengers + bags (+ family curate)
  User->>UI: Seat map (events → SEAT_MAP curate)
  User->>UI: Payment (+ dial + PAYMENT curate)
  UI->>API: POST /bookings → PATCH → /confirm
  API->>DB: persist PNR + held products
  UI-->>User: Confirmation + manage/check-in demos
```

Frontend session state: `BookingContext` (+ `sessionStorage`). Backend is source of truth after PNR creation.

`GET /flights/search` calls `_ensure_route_flights`: if no seeded flights exist for the O&D, it inserts persistent demo flights + inventory so booking IDs stay valid across the flow.

---

## 8. API surface (`/api/v1`)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/health` | Liveness + storage hint |
| GET | `/airports` | Airport list |
| GET | `/products` | Catalogue (`?category=FARE`) |
| GET | `/flights/search` | O&D search |
| GET | `/flights/{id}` | Flight + inventory |
| POST | `/curate` | **Primary curation decision** |
| POST | `/curate/decline` | Fatigue / decline memory |
| POST | `/bookings` | Create draft booking |
| GET/PATCH | `/bookings/{pnr}` | Load / update |
| POST | `/bookings/{pnr}/confirm` | Confirm + sync held products |
| POST | `/bookings/{pnr}/check-in` | Check-in (seat rule demo) |

Interactive docs: `http://localhost:8000/docs`

---

## 9. Frontend structure

- **Brand:** header logo **TredFlight**; tokens `--color-brand-navy` (`#1e3a5f`), `--color-brand-coral` (`#fe5000`)
- **Home:** hero brand + search; Manage booking CTA below the widget (dropdowns are not clipped); no secondary marketing strip
- **Header:** Manage booking as a coral-outlined control next to Sign in
- **Pages:** Home, Flights, Passengers, Seats, Payment, Confirmation, Manage Booking
- **Inputs:** custom `DatePicker`; airport/passenger pickers close on outside click / Escape; field-level “X is required” validation
- **CurationPanel:** reusable explainable offer widget at each moment
- **API client:** `src/api/client.js` (default `http://localhost:8000/api/v1`; optional `VITE_API_BASE`)

---

## 10. Run locally

### Backend (port **8000** only)

```bash
cd backend
# Windows
.\venv\Scripts\activate
# or: python -m venv venv && pip install -r ../requirements.txt

uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

SQLite file appears at `backend/data/tredflight.db`. Seed data loads on startup.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. Vite proxies `/api` → `http://localhost:8000`.
---

## 11. Migrating to a provisioned database

1. Provision PostgreSQL (or compatible).
2. `pip install psycopg[binary]` (or `asyncpg` if you later move async).
3. Set env:

```env
DATABASE_URL=postgresql+psycopg://user:password@db-host:5432/tredflight
SEED_ON_STARTUP=true   # first boot only; then false
```

4. Deploy API; create tables (startup `create_all` or Alembic).
5. Point frontend `VITE_API_BASE` at the deployed API.
6. No change required to curation logic or React pages beyond API URL / theme / catalogue seed.

---

## 12. Reusing for another airline project

| Knob | Where |
|------|--------|
| Site name / colors | `Header`, `index.css` `@theme` |
| Airports & routes | `seed.py` |
| Fare/ancillary names & includes | `seed.py` + `curation_engine.PRODUCT_META` |
| Ranking heuristics | `services/curation_engine.py` |
| Commercial dial default | `REVENUE_FIT_DIAL` |
| Persistence | `DATABASE_URL` |

Keep product **codes** stable (`PRIORITY`, `FLEX`, …) so the engine and UI stay portable; only **display names** change per brand.

---

## 13. Non-goals / demo honesty

- Inventory and ops feeds are **mocked** (as noted in the Excel feedback column).
- Email/APP/Kiosk channels are represented as `channel` on the same `/curate` API, not as separate delivery pipelines.
- Payment is a demo form (no PCI processing).
- Curation is a transparent rule/score engine suitable for demos; swap `curate()` internals for ML later without changing the API contract.

---

## 15. Ancillary transformer

`POST /api/v1/curate` is unchanged. `curate()` scores catalogue products with a tiny transformer (local NumPy weights, optional Databricks / Docker serving) and still applies held-product, inventory, decline, and severe-ops filters.

| Mode | Env |
|------|-----|
| Bundled transformer (default) | `CURATION_SCORER=auto` and `backend/app/ml/artifacts/ancillary_transformer.npz` |
| Scoring container | `ANCILLARY_SCORING_URL=http://host:8080/invocations` |
| Databricks Model Serving | `DATABRICKS_HOST` + `DATABRICKS_TOKEN` + `DATABRICKS_SERVING_ENDPOINT` |
| Original rules | `CURATION_SCORER=rules` |

Train, container, and Databricks steps: [`ml/README.md`](./ml/README.md).

---

## 14. Security notes (when leaving local demo)

- Add auth for manage-booking / PNR lookup.
- Do not commit `.env` or `*.db` with production data.
- Restrict CORS to real front-end origins.
- Introduce Alembic + backups before production cutover.
