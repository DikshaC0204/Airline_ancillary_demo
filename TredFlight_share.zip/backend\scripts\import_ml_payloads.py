"""One-off: copy Desktop ML Payload .txt dicts into backend/app/data/serving_payloads/*.json."""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path

SRC = Path(r"C:\Users\vedula.kamesh\OneDrive - Tredence\Desktop\ML Payload")
DST = Path(__file__).resolve().parents[1] / "app" / "data" / "serving_payloads"

NAME_MAP = {
    "Propensity_bag": "propensity_bag",
    "Propensity_lounge": "propensity_lounge",
    "Propensity_meal": "propensity_meal",
    "Propensity_Insurance": "propensity_insurance",
    "Propensity_wifi": "propensity_wifi",
    "Propensity_Upgrade": "propensity_upgrade",
    "Propensity_Seat_Std": "propensity_seat_std",
    "Propensity_Seat_Leg": "propensity_seat_leg",
    "Propensity_Priority": "propensity_priority",
    "Lamdamart_Ranker": "lambdamart_ranker",
    "Lincucb_policy": "linucb_policy",
}


def _record_from_txt(text: str) -> dict:
    match = re.search(r"=\s*(\{.*\})\s*$", text, re.S)
    if not match:
        raise ValueError("no dict assignment found")
    payload = ast.literal_eval(match.group(1))
    records = payload.get("dataframe_records")
    if not isinstance(records, list) or not records:
        raise ValueError("dataframe_records missing")
    return dict(records[0])


def main() -> None:
    DST.mkdir(parents=True, exist_ok=True)
    for src_stem, dest_stem in NAME_MAP.items():
        path = SRC / f"{src_stem}.txt"
        if not path.exists():
            raise SystemExit(f"missing {path}")
        record = _record_from_txt(path.read_text(encoding="utf-8"))
        out = DST / f"{dest_stem}.json"
        out.write_text(json.dumps(record, indent=2), encoding="utf-8")
        print(f"{dest_stem}: {len(record)} columns -> {out.name}")


if __name__ == "__main__":
    main()
