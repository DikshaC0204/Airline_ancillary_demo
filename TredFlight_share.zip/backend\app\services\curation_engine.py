"""
Ancillary curation engine — deterministic demo implementation of the
Memory → Understand → Generate → Filter → Rank → Select pipeline.

Product codes are carrier-agnostic so the same engine can be reused across projects.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from app.schemas import (
    CurationRequest,
    CurationResponse,
    RankedProduct,
    SuppressedProduct,
)
from app.data.major_airports import distance_miles as od_distance_miles
from app.services.ancillary_model import score_request
from app.services.databricks_ensemble import (
    LOCAL_PROPENSITY,
    MOMENT_PRODUCTS,
    PROPENSITY_TO_PRODUCT,
)


def _serving_kwargs(scoring) -> dict[str, Any]:
    s = (scoring.extras or {}).get("serving") or {}
    return {
        "serving_live": bool(s.get("ok")),
        "serving_endpoint": str(s.get("endpoint") or ""),
        "serving_latency_ms": s.get("latency_ms"),
        "serving_http_status": s.get("http_status"),
        "serving_rank_score": s.get("rank_score"),
        "serving_error": s.get("error"),
        "serving_final_score": s.get("final_score"),
        "serving_live_count": int(s.get("live_count") or 0),
        "serving_total_count": int(s.get("total_count") or 0),
        "serving_endpoints": list(s.get("endpoints") or []),
    }


def _note_serving(note: str, scoring) -> str:
    s = (scoring.extras or {}).get("serving") or {}
    if not s:
        return note
    live = int(s.get("live_count") or 0)
    total = int(s.get("total_count") or 0)
    composed = s.get("composition") or ""
    if s.get("ok"):
        return (
            f"{note} Databricks ensemble {live}/{total} live, "
            f"final_score={s.get('final_score')} rank_score={s.get('rank_score')}. {composed}"
        )
    return f"{note} Databricks serving not live: {s.get('error')}"


# Products with a dedicated propensity endpoint (scores must come from the model).
MODELED_PRODUCTS = set(PROPENSITY_TO_PRODUCT.values())

# Products without a dedicated model — filled from related propensity scores.
DERIVED_PRODUCTS = {
    "SECURITY_FAST_TRACK",
    "AUTO_CHECKIN",
    "BAG_10KG",
    "FAMILY_BAG_BUNDLE",
    "SITTING_TOGETHER",
}


def _is_family_party(journey: Any) -> bool:
    children = int(getattr(journey, "children", 0) or 0)
    adults = int(getattr(journey, "adults", None) or getattr(journey, "pax", 1) or 1)
    party = max(int(getattr(journey, "pax", 0) or 0), adults + children)
    return children > 0 or party >= 3


def _is_short_cabin_trip(journey: Any) -> bool:
    nights = int(getattr(journey, "trip_nights", 7) or 7)
    fare = str(getattr(journey, "fare", "BASIC") or "BASIC").upper()
    return nights <= 2 and fare == "BASIC"


def _journey_miles(journey: Any) -> float:
    miles = getattr(journey, "distance_miles", None)
    if miles is not None:
        try:
            return float(miles)
        except (TypeError, ValueError):
            pass
    computed = od_distance_miles(
        str(getattr(journey, "origin", "") or ""),
        str(getattr(journey, "destination", "") or ""),
    )
    return float(computed or 0.0)


def _apply_journey_context(code: str, score: float, journey: Any) -> float:
    """Presentation nudge from trip length / distance — does not retrain models.

    Short cabin trips demote bags for solo/couple so they usually fall out of
    suggestions (baggage picker still available). Families keep bag affinity —
    kids/gear rarely skip checked bags even on short stays. Longer stays and
    longer sectors gently lift bags / extra legroom when the model is middling.
    """
    nights = int(getattr(journey, "trip_nights", 2) or 2)
    miles = _journey_miles(journey)
    family = _is_family_party(journey)
    adjusted = float(score)

    if code.startswith("BAG_") or code == "FAMILY_BAG_BUNDLE":
        if _is_short_cabin_trip(journey) and not family:
            adjusted *= 0.22
        elif family and nights >= 3:
            adjusted = min(0.95, adjusted * 1.15)
        elif nights >= 5:
            adjusted = min(0.95, adjusted * 1.28)
        elif nights >= 3:
            adjusted = min(0.95, adjusted * 1.12)

    if code == "SITTING_TOGETHER" and family:
        adjusted = min(0.95, adjusted * 1.10)

    if code == "EXTRA_LEGROOM":
        if miles >= 1500:
            adjusted = min(0.95, adjusted * 1.22)
        elif miles >= 800:
            adjusted = min(0.95, adjusted * 1.10)

    if code == "SEAT_FRONT" and miles >= 1500:
        adjusted = min(0.95, adjusted * 1.08)

    return adjusted


def _page_relevant_codes(moment: str, journey: Any) -> list[str]:
    """Moment + party catalogue — eligibility only; scores stay model/derived."""
    moment = moment.upper().strip()
    family = _is_family_party(journey)
    party = max(
        int(getattr(journey, "pax", 0) or 0),
        int(getattr(journey, "adults", 0) or 0) + int(getattr(journey, "children", 0) or 0),
    )

    # Passengers moments: family vs solo/couple catalogues (frontend picks the moment)
    if moment in {"SEARCH_RESULTS", "SEARCH", "FARE_COMPARISON", "FARE"}:
        if family:
            # Family-relevant only — no Priority / Fast Track / Auto Check-in
            allowed = list(
                MOMENT_PRODUCTS.get("FARE_COMPARISON")
                or [
                    "FAMILY_BAG_BUNDLE",
                    "BAG_20KG",
                    "BAG_10KG",
                    "SITTING_TOGETHER",
                    "CAFE_VOUCHER",
                ]
            )
        else:
            # Solo / couple — boarding + bags
            allowed = list(
                MOMENT_PRODUCTS.get("SEARCH_RESULTS")
                if moment in {"FARE_COMPARISON", "FARE"}
                else (MOMENT_PRODUCTS.get(moment) or MOMENT_PRODUCTS["SEARCH_RESULTS"])
            )
    else:
        allowed = list(MOMENT_PRODUCTS.get(moment) or [])

    out: list[str] = []
    for code in allowed:
        if code == "FAMILY_BAG_BUNDLE" and not family:
            continue
        if code == "SITTING_TOGETHER" and party < 2:
            continue
        out.append(code)
    return out


def _rank_from_serving(req: CurationRequest, state: EngineState, scoring) -> list[RankedProduct]:
    """Rank page-relevant products using model scores; derived products keep ensemble values."""
    serving = (scoring.extras or {}).get("serving") or {}
    scores = serving.get("product_scores") or {}
    if not scores:
        return []
    moment = req.moment.upper().strip()
    allowed = _page_relevant_codes(moment, req.journey)
    included = set(_included_for_display(req.held_products, req.journey.fare))
    ranked: list[RankedProduct] = []
    for code in allowed:
        meta = PRODUCT_META.get(code)
        if not meta:
            continue
        if _is_held(code, state.held) or code in included or code in state.declined:
            continue
        if code not in scores:
            continue
        raw = _apply_journey_context(code, float(scores.get(code) or 0.0), req.journey)
        if raw < 0.1:
            continue
        if code in MODELED_PRODUCTS:
            reason = f"Model propensity for {moment.replace('_', ' ').title()}"
        elif code in DERIVED_PRODUCTS:
            reason = f"Derived from related propensity for {moment.replace('_', ' ').title()}"
        else:
            reason = f"Catalogue score for {moment.replace('_', ' ').title()}"
        ranked.append(
            RankedProduct(
                product=code,
                name=str(meta["name"]),
                score=round(raw, 3),
                reason=reason,
                price=float(meta["price"]),
                category=str(meta["category"]),
            )
        )
    ranked.sort(key=lambda row: row.score, reverse=True)
    return ranked[:5]

# Display names for ranked output
PRODUCT_META: dict[str, dict[str, Any]] = {
    "PRIORITY": {"name": "Priority Boarding", "price": 14.0, "category": "ANCILLARY"},
    "SECURITY_FAST_TRACK": {"name": "Security Fast Track", "price": 12.0, "category": "ANCILLARY"},
    "LOUNGE": {"name": "Lounge Access", "price": 35.0, "category": "ANCILLARY"},
    "SEAT_STANDARD": {"name": "Standard Seat", "price": 8.0, "category": "ANCILLARY"},
    "SEAT_FRONT": {"name": "Front Row Seat", "price": 18.0, "category": "ANCILLARY"},
    "EXTRA_LEGROOM": {"name": "Extra Legroom Seat", "price": 28.0, "category": "ANCILLARY"},
    "BAG_10KG": {"name": "Checked Bag 10 kg", "price": 25.0, "category": "ANCILLARY"},
    "BAG_20KG": {"name": "Checked Bag 20 kg", "price": 35.0, "category": "ANCILLARY"},
    "BAG_26KG": {"name": "Checked Bag 26 kg", "price": 45.0, "category": "ANCILLARY"},
    "BAG_32KG": {"name": "Checked Bag 32 kg", "price": 55.0, "category": "ANCILLARY"},
    "FLEX": {"name": "Travel Flex", "price": 22.0, "category": "ANCILLARY"},
    "AUTO_CHECKIN": {"name": "Auto Check-in", "price": 6.0, "category": "ANCILLARY"},
    "FARE_LOCK": {"name": "Fare Lock", "price": 9.0, "category": "ANCILLARY"},
    "SITTING_TOGETHER": {"name": "Sitting Together", "price": 16.0, "category": "ANCILLARY"},
    "FAMILY_BAG_BUNDLE": {"name": "Family Bag + Seats Bundle", "price": 49.0, "category": "BUNDLE"},
    "CAFE_VOUCHER": {"name": "Café & Boutique Voucher", "price": 10.0, "category": "ANCILLARY"},
    "HOTEL": {"name": "Hotel Offer", "price": 0.0, "category": "PARTNER"},
    "CAR_RENTAL": {"name": "Car Rental", "price": 0.0, "category": "PARTNER"},
    "AIRPORT_PARKING": {"name": "Airport Parking", "price": 18.0, "category": "PARTNER"},
    "ESIM": {"name": "Travel eSIM", "price": 12.0, "category": "PARTNER"},
}

# Internal tokens we never show as "already included" extras
_HIDDEN_HELD = {
    "UNDERSEAT_BAG",
    "BASIC_FARE",
    "AIRPORT_CHECKIN",
    "BASIC",
    "SMART",
    "GO",
    "PLUS",
    "FAMILY_GO",
    "FAMILY_PLUS",
}

FARE_INCLUDES: dict[str, list[str]] = {
    "BASIC": ["UNDERSEAT_BAG", "BASIC_FARE"],
    "SMART": ["UNDERSEAT_BAG", "BASIC_FARE", "PRIORITY", "SEAT_STANDARD"],
    "GO": ["UNDERSEAT_BAG", "BASIC_FARE", "BAG_20KG", "SEAT_STANDARD", "AUTO_CHECKIN"],
    "PLUS": [
        "UNDERSEAT_BAG",
        "BASIC_FARE",
        "PRIORITY",
        "SEAT_PREMIUM",
        "BAG_32KG",
        "FLEX",
        "AUTO_CHECKIN",
    ],
    "FAMILY_GO": ["UNDERSEAT_BAG", "BASIC_FARE", "BAG_20KG", "SEAT_STANDARD", "SITTING_TOGETHER"],
    "FAMILY_PLUS": [
        "UNDERSEAT_BAG",
        "BASIC_FARE",
        "PRIORITY",
        "BAG_32KG",
        "SEAT_PREMIUM",
        "FLEX",
        "SITTING_TOGETHER",
    ],
}

# Holding KEY also covers these lower/equal entitlements.
# SEAT_STANDARD must NOT cover SEAT_FRONT / EXTRA_LEGROOM (those remain upsellable).
ENTITLEMENT_COVERS: dict[str, set[str]] = {
    "BAG_10KG": {"BAG_10KG"},
    "BAG_20KG": {"BAG_20KG", "BAG_10KG"},
    "BAG_26KG": {"BAG_26KG", "BAG_20KG", "BAG_10KG"},
    "BAG_32KG": {"BAG_32KG", "BAG_26KG", "BAG_20KG", "BAG_10KG"},
    "SEAT_STANDARD": {"SEAT_STANDARD"},
    "SEAT_FRONT": {"SEAT_FRONT", "SEAT_STANDARD"},
    "EXTRA_LEGROOM": {"EXTRA_LEGROOM", "SEAT_STANDARD"},
    "SEAT_PREMIUM": {"SEAT_PREMIUM", "SEAT_FRONT", "EXTRA_LEGROOM", "SEAT_STANDARD"},
    "PRIORITY": {"PRIORITY"},
    "FLEX": {"FLEX"},
    "AUTO_CHECKIN": {"AUTO_CHECKIN"},
    "SITTING_TOGETHER": {"SITTING_TOGETHER"},
    "SECURITY_FAST_TRACK": {"SECURITY_FAST_TRACK"},
}
ENTITLEMENT_ALIASES = ENTITLEMENT_COVERS


@dataclass
class Candidate:
    code: str
    score: float
    reason: str
    suppressed: bool = False
    suppress_reason: str = ""


@dataclass
class EngineState:
    held: set[str] = field(default_factory=set)
    declined: set[str] = field(default_factory=set)
    events: list[str] = field(default_factory=list)
    inventory: dict[str, Any] = field(default_factory=dict)
    dial: float = 0.45


def _normalize_inventory(raw: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in (raw or {}).items():
        key = str(k).upper()
        if isinstance(v, str):
            out[key] = v.upper()
        else:
            out[key] = v
    return out


def _inventory_blocks(code: str, inventory: dict[str, Any]) -> str | None:
    if code not in inventory:
        return None
    val = inventory[code]
    if val == 0 or val == "SOLD_OUT" or val == "CLOSED":
        return "inventory sold out / capped"
    return None


def _is_held(code: str, held: set[str]) -> bool:
    """True if passenger already has this product or a covering upgrade."""
    return code in held


def _included_for_display(held_products: list[str] | set[str], fare: str) -> list[str]:
    """Fare entitlements plus products the passenger has already added."""
    fare_list = list(FARE_INCLUDES.get(str(fare or "BASIC").upper(), FARE_INCLUDES["BASIC"]))
    visible: list[str] = []
    seen: set[str] = set()
    extra = [str(c).upper() for c in (held_products or [])]
    for code in fare_list + extra:
        if code in _HIDDEN_HELD or code in seen:
            continue
        if code not in PRODUCT_META:
            continue
        seen.add(code)
        visible.append(code)
    visible.sort(key=lambda c: fare_list.index(c) if c in fare_list else 99)
    return visible


def _expand_held(held_products: list[str], fare: str) -> set[str]:
    held = {str(c).upper() for c in (held_products or [])}
    held.update(FARE_INCLUDES.get(str(fare or "BASIC").upper(), FARE_INCLUDES["BASIC"]))
    expanded: set[str] = set(held)
    for item in list(held):
        expanded.update(ENTITLEMENT_COVERS.get(item, {item}))
    return expanded


def _generate_candidates(req: CurationRequest, state: EngineState) -> list[Candidate]:
    """Rules / local fallback when serving scores are unavailable.

    Uses local propensity defaults for modelled products, then derives the rest.
    Ranking still follows those scores — no hand-picked product order.
    """
    moment = req.moment.upper().strip()
    j = req.journey
    party_size = max(j.pax, j.adults + j.children)
    is_family = party_size >= 3 or j.children > 0
    price_sensitive = j.price_sensitivity == "high" or j.fare.upper() == "BASIC"
    candidates: list[Candidate] = []

    def add(code: str, score: float, reason: str, *, suppressed: bool = False, suppress_reason: str = "") -> None:
        candidates.append(
            Candidate(
                code=code,
                score=score,
                reason=reason,
                suppressed=suppressed,
                suppress_reason=suppress_reason,
            )
        )

    # Map local propensity defaults → product codes (model-shaped fallback).
    local_scores: dict[str, float] = {}
    for name, value in LOCAL_PROPENSITY.items():
        code = PROPENSITY_TO_PRODUCT.get(name)
        if code:
            local_scores[code] = float(value)
    if "BAG_20KG" in local_scores:
        local_scores.setdefault("BAG_10KG", round(local_scores["BAG_20KG"] * 0.88, 4))
    if "PRIORITY" in local_scores:
        local_scores.setdefault("SECURITY_FAST_TRACK", round(local_scores["PRIORITY"] * 0.92, 4))
        local_scores.setdefault(
            "AUTO_CHECKIN",
            round(min(0.95, local_scores["PRIORITY"] * 0.72), 4),
        )
    if "BAG_20KG" in local_scores and "SEAT_STANDARD" in local_scores:
        local_scores.setdefault(
            "FAMILY_BAG_BUNDLE",
            round(min(0.95, 0.55 * local_scores["BAG_20KG"] + 0.45 * local_scores["SEAT_STANDARD"]), 4),
        )
        local_scores.setdefault(
            "SITTING_TOGETHER",
            round(min(0.9, local_scores["SEAT_STANDARD"] * 0.85), 4),
        )

    mean_local = (
        sum(local_scores.values()) / len(local_scores) if local_scores else float(LOCAL_PROPENSITY.get("propensity_meal", 0.27))
    )
    local_scores.setdefault("AIRPORT_PARKING", round(min(0.8, mean_local * 0.48 + 0.08), 4))
    local_scores.setdefault("CAFE_VOUCHER", float(LOCAL_PROPENSITY.get("propensity_meal", 0.27)))
    local_scores.setdefault("ESIM", float(LOCAL_PROPENSITY.get("propensity_wifi", 0.22)))
    local_scores.setdefault("LOUNGE", float(LOCAL_PROPENSITY.get("propensity_lounge", 0.33)))

    # Ops / confirmation specials that are not propensity-driven.
    if moment in {"MANAGE_BOOKING", "MMB", "OPS"} and (j.delay_minutes >= 180 or j.schedule_changed and j.delay_minutes >= 60):
        if j.delay_minutes >= 180:
            return [
                Candidate(
                    code="NO_OFFER",
                    score=0.0,
                    reason="severe disruption — restraint",
                    suppressed=True,
                    suppress_reason="NO_OFFER under severe ops",
                )
            ]

    if moment in {"BOOKING_CONFIRMATION", "CONFIRMATION"}:
        if "PRIORITY" in state.held and "SECURITY_FAST_TRACK" not in state.held:
            local_scores["SECURITY_FAST_TRACK"] = max(local_scores.get("SECURITY_FAST_TRACK", 0), 0.74)
        local_scores.setdefault("LOUNGE", float(LOCAL_PROPENSITY.get("propensity_lounge", 0.33)))
        local_scores.setdefault("ESIM", float(LOCAL_PROPENSITY.get("propensity_wifi", 0.22)))
        local_scores.setdefault("CAFE_VOUCHER", float(LOCAL_PROPENSITY.get("propensity_meal", 0.27)))

    if moment in {"AIRPORT_ENTRY", "SECURITY", "AIRPORT"}:
        if j.queue_long and "SECURITY_FAST_TRACK" in local_scores:
            local_scores["SECURITY_FAST_TRACK"] = min(0.95, local_scores["SECURITY_FAST_TRACK"] + 0.1)

    if moment in {"PAYMENT", "CHECKOUT"} and price_sensitive:
        if "CAFE_VOUCHER" in local_scores:
            local_scores["CAFE_VOUCHER"] = min(0.95, local_scores["CAFE_VOUCHER"] * 1.05)

    allowed = set(_page_relevant_codes(moment, j))
    if moment in {"FARE_COMPARISON", "FARE"} and is_family:
        allowed.update({"FAMILY_BAG_BUNDLE", "SITTING_TOGETHER", "BAG_20KG", "CAFE_VOUCHER"})

    for code in allowed:
        if code not in PRODUCT_META:
            continue
        score = _apply_journey_context(code, float(local_scores.get(code) or 0.0), j)
        if score < 0.1:
            if code.startswith("BAG_") and _is_short_cabin_trip(j):
                add(
                    code,
                    score,
                    "low bag propensity on short cabin trip",
                    suppressed=True,
                    suppress_reason="short cabin trip — checked bag not suggested (optional picker still available)",
                )
            continue
        source = "local propensity" if code in MODELED_PRODUCTS else "derived from local propensity"
        add(code, score, f"{source} fallback for {moment.replace('_', ' ').title()}")

    if moment in {"PRE_TRIP_REMINDER", "PRE_TRIP"}:
        if "SEAT_STANDARD" in state.declined or "EXTRA_LEGROOM" in state.declined:
            for c in candidates:
                if c.code in {"SEAT_STANDARD", "EXTRA_LEGROOM", "SEAT_FRONT"}:
                    c.suppressed = True
                    c.suppress_reason = "fatigue / prior decline — seat not repeated"

    return candidates


def _candidates_from_scores(scores: dict[str, float], reasons: dict[str, str], journey: Any | None = None) -> list[Candidate]:
    out: list[Candidate] = []
    for code, score in scores.items():
        if code not in PRODUCT_META:
            continue
        adjusted = _apply_journey_context(code, float(score), journey) if journey is not None else float(score)
        out.append(
            Candidate(
                code=code,
                score=adjusted,
                reason=reasons.get(code, "transformer propensity"),
            )
        )
    return out


def _filter_and_rank(
    candidates: list[Candidate], state: EngineState
) -> tuple[list[Candidate], list[Candidate]]:
    ranked: list[Candidate] = []
    suppressed: list[Candidate] = []

    for c in candidates:
        if c.code == "NO_OFFER":
            suppressed.append(c)
            continue
        if c.suppressed:
            suppressed.append(c)
            continue
        if _is_held(c.code, state.held):
            c.suppressed = True
            c.suppress_reason = "already held / included in fare"
            suppressed.append(c)
            continue
        if c.code in state.declined:
            continue
        block = _inventory_blocks(c.code, state.inventory)
        if block:
            c.suppressed = True
            c.suppress_reason = block
            suppressed.append(c)
            continue
        # dial nudge: higher dial boosts higher-priced items slightly
        meta = PRODUCT_META.get(c.code, {})
        price = float(meta.get("price", 0))
        c.score = min(0.99, c.score + state.dial * (price / 200.0))
        ranked.append(c)

    ranked.sort(key=lambda x: x.score, reverse=True)
    return ranked, suppressed


def _to_ranked(c: Candidate) -> RankedProduct:
    meta = PRODUCT_META.get(c.code, {"name": c.code, "price": 0.0, "category": "ANCILLARY"})
    return RankedProduct(
        product=c.code,
        name=meta["name"],
        score=round(c.score, 3),
        reason=c.reason,
        price=float(meta["price"]),
        category=str(meta["category"]),
    )


def curate(req: CurationRequest, revenue_fit_dial: float = 0.45) -> CurationResponse:
    dial = req.revenue_fit_dial if req.revenue_fit_dial is not None else revenue_fit_dial
    dial = max(0.0, min(1.0, dial))

    held = _expand_held(req.held_products, req.journey.fare)
    events = [e.e for e in req.event_stream]
    state = EngineState(
        held=held,
        declined=set(req.declined_products or []),
        events=events,
        inventory=_normalize_inventory(req.inventory),
        dial=dial,
    )

    moment_u = req.moment.upper().strip()
    if moment_u in {"MANAGE_BOOKING", "MMB", "OPS"} and req.journey.delay_minutes >= 180:
        return CurationResponse(
            action="NO_OFFER",
            ranked=[],
            suppressed=[
                SuppressedProduct(product="NO_OFFER", reason="NO_OFFER under severe ops"),
            ],
            fatigue_state={"impressions": 1, "declines": len(state.declined)},
            moment=req.moment,
            explainability_note="Severe disruption — restraint is a business rule, not a model score.",
            model_source="rules",
        )

    # High load factor → treat Priority/XL as constrained if not already in inventory map
    if req.journey.load_factor is not None and req.journey.load_factor >= 0.95:
        state.inventory.setdefault("EXTRA_LEGROOM", 0)
        if "PRIORITY" not in state.inventory:
            state.inventory["PRIORITY"] = 0

    scoring = score_request(req, dial, events)
    model_source = scoring.source

    # ACE V6 already applied entitlements / inventory / fatigue. Prefer its
    # ranked catalogue products. If ACE returns NO_OFFER or only unmapped
    # items (insurance / carbon offset), fall through so the website still
    # shows bookable ancillaries from the transformer or rules engine.
    if model_source.startswith("ace-v6") and scoring.extras:
        extras = scoring.extras
        ace_action = str(extras.get("action") or "NO_OFFER").upper()
        if ace_action not in {"OFFER", "BUNDLE", "NO_OFFER", "DEFER"}:
            ace_action = "OFFER" if extras.get("ranked") else "NO_OFFER"
        included_codes = set(_included_for_display(req.held_products, req.journey.fare))
        page_codes = set(_page_relevant_codes(req.moment, req.journey))
        ranked_products: list[RankedProduct] = []
        for row in extras.get("ranked") or []:
            code = str(row.get("product") or "")
            if not code or code not in PRODUCT_META:
                continue
            if page_codes and code not in page_codes:
                continue
            if _is_held(code, state.held) or code in included_codes or code in state.declined:
                continue
            meta = PRODUCT_META[code]
            score = _apply_journey_context(code, float(row.get("score") or 0.0), req.journey)
            if score < 0.1:
                continue
            ranked_products.append(
                RankedProduct(
                    product=code,
                    name=str(row.get("name") or meta["name"]),
                    score=round(score, 3),
                    reason=str(row.get("reason") or "ACE V6 ranked"),
                    price=float(meta["price"]),
                    category=str(meta["category"]),
                )
            )
        ranked_products.sort(key=lambda row: row.score, reverse=True)
        if ranked_products:
            suppressed_products = [
                SuppressedProduct(
                    product=code,
                    reason="included in selected fare"
                    if code
                    in FARE_INCLUDES.get(str(req.journey.fare or "BASIC").upper(), [])
                    else "already added",
                )
                for code in _included_for_display(req.held_products, req.journey.fare)
            ]
            payload = extras.get("passenger_payload") or {}
            note = (
                f"Ranked by Airline ACE V6 ({model_source}). "
                f"decision_id={extras.get('decision_id') or 'n/a'}. "
                f"reason={extras.get('reason_code') or ace_action}."
            )
            if isinstance(payload, dict) and payload.get("headline"):
                note += f" Offer: {payload.get('headline')}"
            if scoring.error:
                note += f" Note: {scoring.error}"
            serving_ranked = _rank_from_serving(req, state, scoring)
            if serving_ranked:
                ranked_products = serving_ranked
                model_source = "databricks-ensemble"
                note = (
                    f"Ranked by Databricks serving ensemble for {req.moment}. "
                    + (f"ACE decision_id={extras.get('decision_id') or 'n/a'}. " if extras.get("decision_id") else "")
                    + note
                )
            return CurationResponse(
                action="BUNDLE" if ace_action == "BUNDLE" else "OFFER",
                ranked=ranked_products[:5],
                suppressed=suppressed_products,
                fatigue_state={"impressions": 1, "declines": len(state.declined)},
                moment=req.moment,
                explainability_note=_note_serving(note, scoring),
                model_source=model_source,
                **_serving_kwargs(scoring),
            )
        scoring.scores = {}
        scoring.source = "ace-v6-rules-fallback"
        model_source = scoring.source
        if not scoring.error:
            scoring.error = str(extras.get("reason_code") or ace_action)

    if scoring.scores and not model_source.startswith("rules") and not model_source.startswith("ace-v6"):
        candidates = _candidates_from_scores(scoring.scores, scoring.reasons, req.journey)
        # Keep only page-relevant SKUs when transformer returns a full catalogue.
        page_codes = set(_page_relevant_codes(req.moment, req.journey))
        if page_codes:
            candidates = [c for c in candidates if c.code in page_codes]
        note_prefix = f"Ranked by {model_source}."
        if scoring.error:
            note_prefix += f" ACE error: {scoring.error}."
    else:
        candidates = _generate_candidates(req, state)
        if scoring.source.startswith("ace-v6"):
            model_source = scoring.source
            note_prefix = (
                "ACE had no mapped catalogue offers"
                f" ({scoring.error or 'NO_OFFER'}); ranked by rules engine."
            )
        else:
            model_source = scoring.source or "rules"
            note_prefix = "Ranked by rules engine (transformer unavailable)."
        if scoring.error and not scoring.source.startswith("ace-v6"):
            note_prefix += f" Scorer error: {scoring.error}."

    ranked, suppressed = _filter_and_rank(candidates, state)
    # Drop very-low transformer scores so the panel stays focused
    if scoring.scores and not model_source.startswith("rules"):
        low, keep = [], []
        for c in ranked:
            if c.score < 0.1:
                c.suppressed = True
                c.suppress_reason = "transformer score below offer threshold"
                low.append(c)
            else:
                keep.append(c)
        ranked, suppressed = keep, suppressed + low

    impressions = 1
    declines = len(state.declined)

    if not ranked:
        action: str = "NO_OFFER"
        note = f"{note_prefix} All candidates filtered — restraint is a modelled outcome."
    elif ranked[0].code == "FAMILY_BAG_BUNDLE" or any(
        PRODUCT_META.get(c.code, {}).get("category") == "BUNDLE" for c in ranked[:1]
    ):
        action = "BUNDLE"
        note = f"{note_prefix} Party-level basket ranked above per-passenger duplicates."
    else:
        action = "OFFER"
        note = f"{note_prefix} Hard filters (held, inventory, declines, ops) still apply."

    # S4 extreme fit dial with no engagement → allow empty
    if req.moment.upper() in {"PAYMENT", "CHECKOUT"} and dial < 0.2 and req.journey.price_sensitivity == "high":
        if ranked and ranked[0].score < 0.4:
            return CurationResponse(
                action="NO_OFFER",
                ranked=[],
                suppressed=[SuppressedProduct(product=c.code, reason=c.suppress_reason or c.reason) for c in ranked]
                + [SuppressedProduct(product=c.code, reason=c.suppress_reason or c.reason) for c in suppressed],
                fatigue_state={"impressions": impressions, "declines": declines},
                moment=req.moment,
                explainability_note=_note_serving(
                    "Fit dial set low — engine chooses restraint over low-fit push.",
                    scoring,
                ),
                model_source=model_source,
                **_serving_kwargs(scoring),
            )

    serving_ranked = _rank_from_serving(req, state, scoring)
    if serving_ranked:
        return CurationResponse(
            action="BUNDLE" if serving_ranked[0].category == "BUNDLE" else "OFFER",
            ranked=serving_ranked,
            suppressed=[
                SuppressedProduct(
                    product=code,
                    reason="included in selected fare"
                    if code in FARE_INCLUDES.get(str(req.journey.fare or "BASIC").upper(), [])
                    else "already added",
                )
                for code in _included_for_display(req.held_products, req.journey.fare)
            ],
            fatigue_state={"impressions": impressions, "declines": declines},
            moment=req.moment,
            explainability_note=_note_serving(
                f"Ranked by Databricks serving ensemble for {req.moment}.",
                scoring,
            ),
            model_source="databricks-ensemble",
            **_serving_kwargs(scoring),
        )

    return CurationResponse(
        action=action,  # type: ignore[arg-type]
        ranked=[
            _to_ranked(c)
            for c in ranked[:5]
            if c.code not in _included_for_display(req.held_products, req.journey.fare)
            and c.code not in state.declined
        ],
        suppressed=[
            SuppressedProduct(
                product=code,
                reason="included in selected fare"
                if code in FARE_INCLUDES.get(str(req.journey.fare or "BASIC").upper(), [])
                else "already added",
            )
            for code in _included_for_display(req.held_products, req.journey.fare)
        ],
        fatigue_state={"impressions": impressions, "declines": declines},
        moment=req.moment,
        explainability_note=_note_serving(note, scoring),
        model_source=model_source,
        **_serving_kwargs(scoring),
    )
