"""Tiny pre-norm transformer encoder + product scoring head.

PyTorch is used only for training. Inference is implemented in NumPy so the
FastAPI process does not need torch at runtime.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from app.ml.features import N_NUMERIC, PRODUCT_CODES, SEQ_LEN, vocab_size

D_MODEL = 32
NHEAD = 4
NLAYERS = 2
FF_DIM = 64
EPS = 1e-5


def _softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    shifted = x - np.max(x, axis=axis, keepdims=True)
    exp = np.exp(shifted)
    return exp / np.sum(exp, axis=axis, keepdims=True)


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -20.0, 20.0)))


def _layer_norm(x: np.ndarray, gamma: np.ndarray, beta: np.ndarray) -> np.ndarray:
    mean = x.mean(axis=-1, keepdims=True)
    var = x.var(axis=-1, keepdims=True)
    return gamma * (x - mean) / np.sqrt(var + EPS) + beta


def _linear(x: np.ndarray, weight: np.ndarray, bias: np.ndarray) -> np.ndarray:
    # PyTorch Linear: y = x @ W.T + b  with W shape (out, in)
    return x @ weight.T + bias


def _mha(
    x: np.ndarray,
    wq: np.ndarray,
    bq: np.ndarray,
    wk: np.ndarray,
    bk: np.ndarray,
    wv: np.ndarray,
    bv: np.ndarray,
    wo: np.ndarray,
    bo: np.ndarray,
    nhead: int = NHEAD,
) -> np.ndarray:
    batch, seq, dim = x.shape
    head_dim = dim // nhead
    q = _linear(x, wq, bq).reshape(batch, seq, nhead, head_dim).transpose(0, 2, 1, 3)
    k = _linear(x, wk, bk).reshape(batch, seq, nhead, head_dim).transpose(0, 2, 1, 3)
    v = _linear(x, wv, bv).reshape(batch, seq, nhead, head_dim).transpose(0, 2, 1, 3)
    attn = _softmax((q @ k.transpose(0, 1, 3, 2)) / np.sqrt(head_dim), axis=-1)
    out = (attn @ v).transpose(0, 2, 1, 3).reshape(batch, seq, dim)
    return _linear(out, wo, bo)


class NumpyAncillaryTransformer:
    def __init__(self, weights: dict[str, np.ndarray]):
        self.w = weights

    @classmethod
    def load(cls, path: str | Path) -> "NumpyAncillaryTransformer":
        raw = np.load(path, allow_pickle=False)
        return cls({k: raw[k] for k in raw.files})

    def encode(self, token_ids: np.ndarray, numeric: np.ndarray) -> np.ndarray:
        """Return CLS hidden states. token_ids (B, T), numeric (B, N) -> (B, D)."""
        w = self.w
        tok = w["tok_emb"][token_ids]  # (B, T, D)
        pos_idx = np.arange(tok.shape[1])
        x = tok + w["pos_emb"][pos_idx]
        num_tok = _linear(numeric, w["num_proj.weight"], w["num_proj.bias"])[:, None, :]
        x = np.concatenate([num_tok, x[:, 1:, :]], axis=1)

        for i in range(NLAYERS):
            p = f"layers.{i}."
            h = _layer_norm(x, w[p + "ln1.weight"], w[p + "ln1.bias"])
            x = x + _mha(
                h,
                w[p + "q.weight"],
                w[p + "q.bias"],
                w[p + "k.weight"],
                w[p + "k.bias"],
                w[p + "v.weight"],
                w[p + "v.bias"],
                w[p + "o.weight"],
                w[p + "o.bias"],
            )
            h = _layer_norm(x, w[p + "ln2.weight"], w[p + "ln2.bias"])
            ff = np.maximum(0.0, _linear(h, w[p + "ff1.weight"], w[p + "ff1.bias"]))
            x = x + _linear(ff, w[p + "ff2.weight"], w[p + "ff2.bias"])

        cls = _layer_norm(x[:, 0, :], w["final_ln.weight"], w["final_ln.bias"])
        return cls

    def logits(self, token_ids: np.ndarray, numeric: np.ndarray) -> np.ndarray:
        cls = self.encode(token_ids, numeric)
        return _linear(cls, self.w["score.weight"], self.w["score.bias"])

    def predict_proba(self, token_ids: np.ndarray, numeric: np.ndarray) -> np.ndarray:
        if token_ids.ndim == 1:
            token_ids = token_ids[None, :]
        if numeric.ndim == 1:
            numeric = numeric[None, :]
        return _sigmoid(self.logits(token_ids, numeric))

    def score_map(self, token_ids: np.ndarray, numeric: np.ndarray) -> dict[str, float]:
        probs = self.predict_proba(token_ids, numeric)[0]
        return {code: float(probs[i]) for i, code in enumerate(PRODUCT_CODES)}


def default_artifact_path() -> Path:
    return Path(__file__).resolve().parent / "artifacts" / "ancillary_transformer.npz"


def build_torch_module():
    """Return an untrained PyTorch module matching NumpyAncillaryTransformer."""
    import torch
    from torch import nn

    class EncoderLayer(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.ln1 = nn.LayerNorm(D_MODEL, eps=EPS)
            self.q = nn.Linear(D_MODEL, D_MODEL)
            self.k = nn.Linear(D_MODEL, D_MODEL)
            self.v = nn.Linear(D_MODEL, D_MODEL)
            self.o = nn.Linear(D_MODEL, D_MODEL)
            self.ln2 = nn.LayerNorm(D_MODEL, eps=EPS)
            self.ff1 = nn.Linear(D_MODEL, FF_DIM)
            self.ff2 = nn.Linear(FF_DIM, D_MODEL)

        def forward(self, x: "torch.Tensor") -> "torch.Tensor":
            batch, seq, dim = x.shape
            head_dim = dim // NHEAD
            h = self.ln1(x)
            q = self.q(h).view(batch, seq, NHEAD, head_dim).transpose(1, 2)
            k = self.k(h).view(batch, seq, NHEAD, head_dim).transpose(1, 2)
            v = self.v(h).view(batch, seq, NHEAD, head_dim).transpose(1, 2)
            attn = torch.softmax((q @ k.transpose(-2, -1)) / (head_dim ** 0.5), dim=-1)
            merged = (attn @ v).transpose(1, 2).contiguous().view(batch, seq, dim)
            x = x + self.o(merged)
            h = self.ln2(x)
            return x + self.ff2(torch.relu(self.ff1(h)))

    class AncillaryTransformer(nn.Module):
        def __init__(self) -> None:
            super().__init__()
            self.tok_emb = nn.Embedding(vocab_size(), D_MODEL)
            self.pos_emb = nn.Embedding(SEQ_LEN, D_MODEL)
            self.num_proj = nn.Linear(N_NUMERIC, D_MODEL)
            self.layers = nn.ModuleList([EncoderLayer() for _ in range(NLAYERS)])
            self.final_ln = nn.LayerNorm(D_MODEL, eps=EPS)
            self.score = nn.Linear(D_MODEL, len(PRODUCT_CODES))

        def forward(self, token_ids: "torch.Tensor", numeric: "torch.Tensor") -> "torch.Tensor":
            tok = self.tok_emb(token_ids)
            pos = self.pos_emb(torch.arange(tok.size(1), device=tok.device))
            x = tok + pos
            num_tok = self.num_proj(numeric).unsqueeze(1)
            x = torch.cat([num_tok, x[:, 1:, :]], dim=1)
            for layer in self.layers:
                x = layer(x)
            cls = self.final_ln(x[:, 0, :])
            return self.score(cls)

    return AncillaryTransformer()


def export_torch_state(module: Any, path: str | Path) -> Path:
    import torch

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = module.state_dict()
    arrays: dict[str, np.ndarray] = {
        "tok_emb": state["tok_emb.weight"].detach().cpu().numpy(),
        "pos_emb": state["pos_emb.weight"].detach().cpu().numpy(),
        "num_proj.weight": state["num_proj.weight"].detach().cpu().numpy(),
        "num_proj.bias": state["num_proj.bias"].detach().cpu().numpy(),
        "final_ln.weight": state["final_ln.weight"].detach().cpu().numpy(),
        "final_ln.bias": state["final_ln.bias"].detach().cpu().numpy(),
        "score.weight": state["score.weight"].detach().cpu().numpy(),
        "score.bias": state["score.bias"].detach().cpu().numpy(),
    }
    for i in range(NLAYERS):
        prefix = f"layers.{i}."
        src = f"layers.{i}."
        for name in ("ln1.weight", "ln1.bias", "ln2.weight", "ln2.bias"):
            arrays[prefix + name] = state[src + name].detach().cpu().numpy()
        for name in ("q", "k", "v", "o", "ff1", "ff2"):
            arrays[prefix + f"{name}.weight"] = state[src + f"{name}.weight"].detach().cpu().numpy()
            arrays[prefix + f"{name}.bias"] = state[src + f"{name}.bias"].detach().cpu().numpy()
    np.savez_compressed(path, **arrays)
    return path
