"""
ORM models retained for schema documentation only.

Runtime data access uses SQLAlchemy text() statements in app/sql/
executed via app/repositories.py against the Lakebase `tredflights` schema
(created by repo-root init.sql). Do not use these models for queries.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Airport(Base):
    __tablename__ = "airports"

    code: Mapped[str] = mapped_column(String(8), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    city: Mapped[str] = mapped_column(String(80))
    country: Mapped[str] = mapped_column(String(80), default="")


class Product(Base):
    __tablename__ = "products"

    code: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(40))
    description: Mapped[str] = mapped_column(Text, default="")
    base_price: Mapped[float] = mapped_column(Float, default=0.0)
    includes: Mapped[list] = mapped_column(JSON, default=list)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class Flight(Base):
    __tablename__ = "flights"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    flight_number: Mapped[str] = mapped_column(String(16), index=True)
    origin: Mapped[str] = mapped_column(String(8), ForeignKey("airports.code"))
    destination: Mapped[str] = mapped_column(String(8), ForeignKey("airports.code"))
    depart_at: Mapped[datetime] = mapped_column(DateTime)
    arrive_at: Mapped[datetime] = mapped_column(DateTime)
    base_price: Mapped[float] = mapped_column(Float)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    load_factor: Mapped[float] = mapped_column(Float, default=0.65)
    delay_minutes: Mapped[int] = mapped_column(Integer, default=0)
    schedule_changed: Mapped[bool] = mapped_column(Boolean, default=False)

    inventory: Mapped[list["InventoryItem"]] = relationship(
        back_populates="flight", cascade="all, delete-orphan"
    )


class InventoryItem(Base):
    __tablename__ = "inventory"
    __table_args__ = (UniqueConstraint("flight_id", "product_code", name="uq_flight_product"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flights.id"))
    product_code: Mapped[str] = mapped_column(String(64), ForeignKey("products.code"))
    remaining: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="OPEN")

    flight: Mapped[Flight] = relationship(back_populates="inventory")


class PassengerProfile(Base):
    __tablename__ = "passenger_profiles"

    passenger_ref: Mapped[str] = mapped_column(String(64), primary_key=True)
    display_name: Mapped[str] = mapped_column(String(120), default="")
    cohort: Mapped[str] = mapped_column(String(64), default="leisure_cold_start")
    fatigue_impressions: Mapped[int] = mapped_column(Integer, default=0)
    fatigue_declines: Mapped[int] = mapped_column(Integer, default=0)
    declined_products: Mapped[list] = mapped_column(JSON, default=list)
    event_stream: Mapped[list] = mapped_column(JSON, default=list)
    held_products: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class Booking(Base):
    __tablename__ = "bookings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pnr: Mapped[str] = mapped_column(String(12), unique=True, index=True)
    passenger_ref: Mapped[str] = mapped_column(String(64), ForeignKey("passenger_profiles.passenger_ref"))
    status: Mapped[str] = mapped_column(String(24), default="DRAFT")
    trip_type: Mapped[str] = mapped_column(String(16), default="return")
    origin: Mapped[str] = mapped_column(String(8))
    destination: Mapped[str] = mapped_column(String(8))
    outbound_flight_id: Mapped[Optional[int]] = mapped_column(ForeignKey("flights.id"), nullable=True)
    return_flight_id: Mapped[Optional[int]] = mapped_column(ForeignKey("flights.id"), nullable=True)
    fare_code: Mapped[str] = mapped_column(String(32), default="BASIC")
    party: Mapped[dict] = mapped_column(JSON, default=dict)
    passengers: Mapped[list] = mapped_column(JSON, default=list)
    selected_products: Mapped[list] = mapped_column(JSON, default=list)
    extras: Mapped[dict] = mapped_column(JSON, default=dict)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    promo_code: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    confirmed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class CurationLog(Base):
    __tablename__ = "curation_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    passenger_ref: Mapped[str] = mapped_column(String(64), index=True)
    moment: Mapped[str] = mapped_column(String(40))
    channel: Mapped[str] = mapped_column(String(16))
    request_json: Mapped[dict] = mapped_column(JSON, default=dict)
    response_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
