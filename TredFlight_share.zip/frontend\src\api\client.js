const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api/v1';

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  health: () => request('/health'),
  probeScorer: () => request('/scorer/probe?light=true'),
  probeScorerLive: () => request('/scorer/probe'),
  airports: () => request('/airports'),
  products: (category) =>
    request(category ? `/products?category=${encodeURIComponent(category)}` : '/products'),
  searchFlights: (params) => {
    const cleaned = Object.fromEntries(
      Object.entries(params || {}).filter(
        ([, v]) => v !== undefined && v !== null && String(v).trim() !== ''
      )
    );
    const q = new URLSearchParams(cleaned).toString();
    return request(`/flights/search?${q}`);
  },
  getFlight: (id) => request(`/flights/${id}`),
  curate: (body) =>
    request('/curate', { method: 'POST', body: JSON.stringify(body) }),
  declineOffer: (body) =>
    request('/curate/decline', { method: 'POST', body: JSON.stringify(body) }),
  createBooking: (body) =>
    request('/bookings', { method: 'POST', body: JSON.stringify(body) }),
  getBooking: (pnr) => request(`/bookings/${pnr}`),
  updateBooking: (pnr, body) =>
    request(`/bookings/${pnr}`, { method: 'PATCH', body: JSON.stringify(body) }),
  confirmBooking: (pnr) =>
    request(`/bookings/${pnr}/confirm`, { method: 'POST' }),
  checkIn: (pnr) =>
    request(`/bookings/${pnr}/check-in`, { method: 'POST' }),
};

export function daysUntil(isoDate) {
  if (!isoDate) return 7;
  const target = new Date(isoDate);
  const now = new Date();
  return Math.max(0, Math.ceil((target - now) / (1000 * 60 * 60 * 24)));
}

/** Nights between depart and return (one-way defaults to 1). */
export function tripNights(departIso, returnIso, tripType = 'return') {
  if (!departIso) return 2;
  if (tripType === 'oneway' || !returnIso) return 1;
  const depart = new Date(departIso);
  const ret = new Date(returnIso);
  if (Number.isNaN(depart.getTime()) || Number.isNaN(ret.getTime())) return 2;
  const nights = Math.round((ret - depart) / (1000 * 60 * 60 * 24));
  return Math.max(1, nights);
}

export default api;
