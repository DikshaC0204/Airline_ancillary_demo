"""Static reference data used by the booking API."""
