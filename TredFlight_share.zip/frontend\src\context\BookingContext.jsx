import React, { createContext, useContext, useMemo, useState, useEffect, useCallback } from 'react';

const STORAGE_KEY = 'tredflight_booking_v1';

const defaultBooking = {
  tripType: 'return',
  origin: 'GYD',
  destination: 'BUD',
  departDate: '',
  returnDate: '',
  party: { adults: 1, children: 0, infants: 0 },
  passenger_ref: 'SYN-000431',
  outboundFlight: null,
  returnFlight: null,
  fareCode: 'BASIC',
  passengers: [{ first_name: '', last_name: '', email: '', age: '', gender: null, type: 'adult' }],
  selectedProducts: [],
  extras: {},
  eventStream: [],
  declinedProducts: [],
  heldProducts: ['BASIC_FARE'],
  pnr: null,
  curation: null,
  postBookingPayment: false,
  revenueFitDial: 0.45,
};

const BookingContext = createContext(null);

function loadInitial() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw) return { ...defaultBooking, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return defaultBooking;
}

export function BookingProvider({ children }) {
  const [booking, setBooking] = useState(loadInitial);

  useEffect(() => {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(booking));
    } catch {
      /* ignore */
    }
  }, [booking]);

  const pushEvent = useCallback((eventName) => {
    setBooking((prev) => ({
      ...prev,
      eventStream: [
        ...(prev.eventStream || []),
        { t: new Date().toISOString(), e: eventName },
      ].slice(-40),
    }));
  }, []);

  const resetBooking = useCallback(() => setBooking(defaultBooking), []);

  const value = useMemo(
    () => ({ booking, setBooking, pushEvent, resetBooking }),
    [booking, pushEvent, resetBooking]
  );

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error('useBooking must be used within BookingProvider');
  return ctx;
}

export function computeTotal(booking) {
  const outbound = booking.outboundFlight?.base_price ?? booking.outboundFlight?.price ?? 0;
  const ret = booking.returnFlight?.base_price ?? booking.returnFlight?.price ?? 0;
  const outBundle = booking.outboundFlight?.bundle?.price ?? 0;
  const retBundle = booking.returnFlight?.bundle?.price ?? 0;
  const bag = booking.extras?.baggage?.price ?? 0;
  const seat = booking.extras?.seat_price ?? 0;
  const productPrices = booking.productPrices || {};
  const selectedSum = (booking.selectedProducts || [])
    .filter((p) => typeof p === 'string')
    .reduce((s, code) => {
      // Avoid double-counting bag/seat already in extras
      if (String(code).startsWith('BAG_') && bag) return s;
      if (String(code).startsWith('SEAT') || code === 'EXTRA_LEGROOM') {
        if (seat) return s;
      }
      return s + (productPrices[code] || 0);
    }, 0);
  return outbound + ret + outBundle + retBundle + bag + seat + selectedSum;
}
