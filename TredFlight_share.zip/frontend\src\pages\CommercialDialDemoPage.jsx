import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import { api } from '../api/client';

/**
 * Leadership / QA page for the commercial revenue ↔ fit dial.
 * Same layout style as /demo/scenarios.
 */
const BASE_REQUEST = {
  moment: 'PAYMENT',
  channel: 'WEB',
  passenger_ref: 'SYN-DEMO-DIAL',
  journey: {
    origin: 'LTN',
    destination: 'BUD',
    pax: 1,
    adults: 1,
    children: 0,
    fare: 'BASIC',
    days_to_departure: 7,
    trip_nights: 3,
    return_trip: true,
    price_sensitivity: 'high',
  },
  held_products: ['BASIC_FARE'],
  event_stream: [],
  declined_products: [],
  inventory: {},
};

const PRESETS = [
  { id: 'fit', label: 'Fit / restraint', value: 0.15, expected: 'Fewer or lower-pressure offers.' },
  { id: 'balanced', label: 'Balanced', value: 0.45, expected: 'Typical mix of comfort and bag offers.' },
  { id: 'revenue', label: 'Revenue', value: 0.85, expected: 'Higher-priced ancillaries ranked first.' },
];

const CommercialDialDemoPage = () => {
  const [dial, setDial] = useState(0.45);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const run = async (value) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.curate({
        ...BASE_REQUEST,
        revenue_fit_dial: value,
      });
      setResult(data);
    } catch (err) {
      setError(err.message || 'Curate failed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    run(dial);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <header className="bg-white rounded-lg shadow-md border p-6">
          <p className="text-brand-coral font-black text-sm uppercase tracking-wider">TredAir</p>
          <h1 className="text-3xl font-black text-brand-navy mt-1">Commercial dial</h1>
          <p className="text-gray-600 mt-2 max-w-3xl">
            Move revenue ↔ fit and see how{' '}
            <code className="text-xs bg-gray-100 px-1 rounded">POST /api/v1/curate</code> re-ranks
            offers. This control is for demos only — it is not shown on the booking pages.
          </p>
        </header>

        <section className="bg-white rounded-lg shadow-md border overflow-hidden">
          <div className="bg-brand-navy text-white px-5 py-4">
            <div className="text-brand-coral text-xs font-bold uppercase tracking-wider">
              Demo · PAYMENT · WEB
            </div>
            <h2 className="text-xl font-black mt-1">Revenue ↔ fit</h2>
          </div>
          <div className="p-5 space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Commercial dial
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={dial}
                onChange={(e) => setDial(Number(e.target.value))}
                className="w-full accent-brand-coral"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Fit / restraint</span>
                <span className="font-mono text-gray-800">{Number(dial).toFixed(2)}</span>
                <span>Revenue</span>
              </div>
              <button
                type="button"
                onClick={() => run(dial)}
                disabled={loading}
                className="mt-3 bg-brand-coral text-white font-bold px-4 py-2 rounded-md disabled:opacity-60"
              >
                {loading ? 'Ranking…' : 'Apply dial'}
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setDial(p.value);
                    run(p.value);
                  }}
                  className={`text-sm font-semibold px-3 py-1.5 rounded-md border ${
                    Math.abs(dial - p.value) < 0.001
                      ? 'bg-brand-navy text-white border-brand-navy'
                      : 'bg-white text-brand-navy border-gray-300'
                  }`}
                >
                  {p.label} ({p.value.toFixed(2)})
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-xs font-bold uppercase text-gray-500">Setup</div>
                <p className="text-gray-700 mt-1">
                  Basic fare, LTN→BUD, high price sensitivity, payment moment.
                </p>
                <div className="text-xs font-bold uppercase text-gray-500 mt-3">Expected</div>
                <p className="text-gray-700 mt-1">
                  Low dial → restraint. High dial → more expensive extras first.
                </p>
              </div>
              <div className="bg-slate-50 rounded-md border p-4 min-h-[160px]">
                <div className="text-xs font-bold uppercase text-brand-navy">Live engine output</div>
                {loading && <p className="text-sm text-gray-500 mt-3">Ranking…</p>}
                {error && <p className="text-sm text-red-600 mt-3">{error}</p>}
                {result && !loading && (
                  <div className="mt-3 space-y-2">
                    <div className="text-xs text-gray-500">
                      Action {result.action}
                      {result.model_source ? ` · ${result.model_source}` : ''}
                    </div>
                    <ul className="space-y-2">
                      {(result.ranked || []).map((item) => (
                        <li key={item.product} className="border rounded-md p-2 bg-white">
                          <div className="font-bold text-brand-navy">{item.name}</div>
                          <div className="text-xs text-gray-600">
                            Score {Number(item.score).toFixed(2)}
                            {item.price > 0 ? ` · $${Number(item.price).toFixed(2)}` : ''}
                          </div>
                        </li>
                      ))}
                    </ul>
                    {!result.ranked?.length && (
                      <p className="text-sm text-gray-600">No offers at this dial.</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default CommercialDialDemoPage;
