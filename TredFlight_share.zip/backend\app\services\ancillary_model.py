"""Ancillary scoring client: ACE V6, local transformer, remote serving, or rules."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import threading

import requests

from app.config import get_settings
from app.ml.features import PRODUCT_CODES, explain_product, normalize_moment
from app.schemas import CurationRequest
from app.services.databricks_ensemble import LAMBDAMART_RECORD, run_ensemble

LAMBDAMART_PROBE_RECORD = LAMBDAMART_RECORD


@dataclass
class ScoringResult:
    scores: dict[str, float]
    reasons: dict[str, str]
    source: str
    error: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)


def _payload_from_request(req: CurationRequest, dial: float, events: list[str]) -> dict[str, Any]:
    emails = list(req.emails or [])
    if req.email and req.email not in emails:
        emails = [req.email, *emails]
    return {
        "moment": req.moment,
        "channel": req.channel,
        "passenger_ref": req.passenger_ref,
        "email": req.email or (emails[0] if emails else None),
        "emails": emails,
        "journey": req.journey.model_dump(),
        "event_stream": [{"t": e.t, "e": e.e} for e in req.event_stream],
        "events": events,
        "held_products": req.held_products,
        "declined_products": req.declined_products,
        "revenue_fit_dial": dial,
        "inventory": req.inventory,
        "products": PRODUCT_CODES,
    }


def _score_local(payload: dict[str, Any]) -> ScoringResult:
    from app.ml.infer import score_payload

    out = score_payload(payload)
    return ScoringResult(scores=out["scores"], reasons=out["reasons"], source=out["source"])


def _score_ace(req: CurationRequest, dial: float, events: list[str]) -> ScoringResult:
    from app.services.ace_adapter import score_with_ace

    out = score_with_ace(req, dial, events)
    return ScoringResult(
        scores=out["scores"],
        reasons=out["reasons"],
        source=out["source"],
        extras=out.get("extras") or {},
    )


def probe_serving() -> dict[str, Any]:
    """Call every configured Databricks serving endpoint; fall back locally per model."""
    return run_ensemble()


def _score_serving(payload: dict[str, Any], url: str, token: str | None, timeout: float) -> ScoringResult:
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    body = {"dataframe_records": [payload]}
    resp = requests.post(url, json=body, headers=headers, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()

    scores: dict[str, float] | None = None
    if isinstance(data, dict):
        if isinstance(data.get("scores"), dict):
            scores = {str(k): float(v) for k, v in data["scores"].items()}
        elif isinstance(data.get("predictions"), list) and data["predictions"]:
            first = data["predictions"][0]
            if isinstance(first, dict):
                scores = {str(k): float(v) for k, v in first.items()}
        elif isinstance(data.get("predictions"), dict):
            scores = {str(k): float(v) for k, v in data["predictions"].items()}
    if not scores:
        raise ValueError(f"Unexpected serving response keys: {list(data) if isinstance(data, dict) else type(data)}")

    moment = normalize_moment(str(payload.get("moment") or "SEARCH_RESULTS"))
    reasons = {code: explain_product(code, scores.get(code, 0.0), moment) for code in PRODUCT_CODES}
    source = "transformer-databricks" if "databricks" in url.lower() or "serving-endpoints" in url.lower() else "transformer-serving"
    return ScoringResult(scores=scores, reasons=reasons, source=source)


def score_request(req: CurationRequest, dial: float, events: list[str]) -> ScoringResult:
    settings = get_settings()
    payload = _payload_from_request(req, dial, events)
    mode = (settings.curation_scorer or "auto").lower()
    serving_box: dict[str, Any] = {}
    serving_thread: threading.Thread | None = None
    if settings.databricks_invoke_on_curate:
        def _run_ensemble() -> None:
            serving_box["serving"] = run_ensemble(req)

        serving_thread = threading.Thread(target=_run_ensemble, name="dbx-ensemble", daemon=True)
        serving_thread.start()

    def _attach(result: ScoringResult) -> ScoringResult:
        if serving_thread is not None:
            wait_s = max(6.0, float(getattr(settings, "databricks_offer_deadline", 4.0) or 4.0) + 2.0)
            serving_thread.join(timeout=wait_s)
            serving_probe = serving_box.get("serving")
            if serving_probe:
                result.extras["serving"] = serving_probe
        return result

    if mode == "rules":
        return _attach(ScoringResult(scores={}, reasons={}, source="rules"))

    def _local() -> ScoringResult:
        return _score_local(payload)

    def _ace() -> ScoringResult:
        return _score_ace(req, dial, events)

    want_ace = mode == "ace" or (mode == "auto" and bool(settings.ace_root))
    serving_url = settings.ancillary_serving_url
    lambdamart = "lambdamart" in (settings.databricks_serving_endpoint or "").lower() or "lambdamart" in serving_url.lower()
    want_serving = (not lambdamart) and (
        mode in {"databricks", "serving"}
        or (mode == "auto" and bool(serving_url) and not want_ace)
    )

    if mode == "transformer":
        try:
            return _attach(_local())
        except Exception as exc:  # noqa: BLE001
            return _attach(ScoringResult(scores={}, reasons={}, source="rules-fallback", error=str(exc)))

    if want_ace:
        try:
            return _attach(_ace())
        except Exception as exc:  # noqa: BLE001
            import logging

            logging.getLogger("app.ancillary").exception("ACE scoring failed; falling back if enabled")
            ace_error = f"{type(exc).__name__}: {exc}"
            if mode == "ace" and not settings.ancillary_local_fallback:
                return _attach(ScoringResult(scores={}, reasons={}, source="rules-fallback", error=ace_error))
            try:
                local = _local()
                local.source = "transformer-local-fallback"
                local.error = ace_error
                return _attach(local)
            except Exception as local_exc:  # noqa: BLE001
                return _attach(
                    ScoringResult(
                        scores={},
                        reasons={},
                        source="rules-fallback",
                        error=f"ACE: {ace_error}; local: {type(local_exc).__name__}: {local_exc}",
                    )
                )

    if want_serving:
        if not serving_url:
            return _attach(
                ScoringResult(
                    scores={},
                    reasons={},
                    source="rules-fallback",
                    error="ANCILLARY_SCORING_URL / DATABRICKS_SERVING_URL is not set",
                )
            )
        try:
            return _attach(
                _score_serving(
                    payload,
                    serving_url,
                    settings.databricks_token,
                    settings.ancillary_scoring_timeout,
                )
            )
        except Exception as exc:  # noqa: BLE001 — degrade to local/rules
            if mode in {"databricks", "serving"} and not settings.ancillary_local_fallback:
                return _attach(ScoringResult(scores={}, reasons={}, source="rules-fallback", error=str(exc)))
            try:
                local = _local()
                local.source = "transformer-local-fallback"
                local.error = str(exc)
                return _attach(local)
            except Exception as local_exc:  # noqa: BLE001
                return _attach(ScoringResult(scores={}, reasons={}, source="rules-fallback", error=str(local_exc)))

    try:
        return _attach(_local())
    except Exception as exc:  # noqa: BLE001
        return _attach(ScoringResult(scores={}, reasons={}, source="rules-fallback", error=str(exc)))


def scorer_status() -> dict[str, str]:
    settings = get_settings()
    mode = (settings.curation_scorer or "auto").lower()
    serving = {
        "serving_endpoint": settings.databricks_serving_endpoint,
        "serving_url": settings.ancillary_serving_url,
        "serving_configured": bool(settings.ancillary_serving_url),
    }
    if mode == "rules":
        return {"mode": mode, "active": "rules", **serving}
    if mode in {"ace", "auto"} and settings.ace_root:
        from pathlib import Path

        root = Path(settings.ace_root)
        if root.is_dir() and (root / "airline_demo" / "v6" / "service.py").exists():
            return {"mode": mode, "active": "ace-v6-local", "ace_root": settings.ace_root, **serving}
        if mode == "ace":
            return {
                "mode": mode,
                "active": "rules-fallback",
                "error": f"ACE_ROOT invalid or incomplete: {settings.ace_root}",
                **serving,
            }
    if settings.ancillary_serving_url and mode in {"auto", "databricks", "serving"}:
        kind = "databricks" if "serving-endpoints" in settings.ancillary_serving_url else "serving"
        return {"mode": mode, "active": kind, "url": settings.ancillary_serving_url, **serving}
    try:
        from app.ml.infer import load_local_model

        load_local_model()
        return {"mode": mode, "active": "transformer-local", **serving}
    except Exception as exc:  # noqa: BLE001
        return {"mode": mode, "active": "rules-fallback", "error": str(exc), **serving}
