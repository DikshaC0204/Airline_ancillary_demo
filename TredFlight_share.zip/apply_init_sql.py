"""Apply init.sql to Databricks Lakebase Postgres (schema: tredflights).

Usage (from project root, with venv active):
    python apply_init_sql.py

Requires DB_USER + DB_PASSWORD (or DATABASE_URL) in .env.
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from urllib.parse import quote_plus, urlparse, urlunparse

from dotenv import load_dotenv
import psycopg

ROOT = Path(__file__).resolve().parent
INIT_SQL = ROOT / "init.sql"
SCHEMA = "tredflights"
HOST = "ep-late-art-e3d9qikt.database.westus.azuredatabricks.net"
DB_NAME = "databricks_postgres"


def load_database_url() -> str:
    load_dotenv(ROOT / ".env")

    database_url = os.getenv("DATABASE_URL", "").strip().strip("'\"")
    if database_url and database_url.startswith("postgresql"):
        return database_url

    user = os.getenv("DB_USER", "").strip().strip("'\"")
    password = os.getenv("DB_PASSWORD", "").strip().strip("'\"")
    if not user or not password:
        raise SystemExit(
            "Missing DB credentials. Set DATABASE_URL or DB_USER + DB_PASSWORD in .env"
        )

    return (
        f"postgresql://{quote_plus(user)}:{quote_plus(password)}"
        f"@{HOST}/{DB_NAME}?sslmode=require"
    )


def to_psycopg_url(url: str) -> str:
    """Normalize SQLAlchemy-style URLs to libpq/psycopg form."""
    url = re.sub(r"^postgresql\+psycopg[23]?:", "postgresql:", url)
    url = re.sub(r"^postgres:", "postgresql:", url)
    return url


def main() -> None:
    if not INIT_SQL.exists():
        raise SystemExit(f"init.sql not found: {INIT_SQL}")

    db_url = to_psycopg_url(load_database_url())
    sql = INIT_SQL.read_text(encoding="utf-8")

    parsed = urlparse(db_url)
    safe_target = urlunparse(
        (parsed.scheme, parsed.hostname or "", parsed.path, "", "", "")
    )
    print(f"Connecting to {safe_target}")
    print(f"Schema: {SCHEMA}")
    print(f"Applying: {INIT_SQL}")

    with psycopg.connect(db_url, autocommit=True) as conn:
        conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}"')
        conn.execute(f'SET search_path TO "{SCHEMA}"')

        # Verify schema is active before applying DDL/DML
        current = conn.execute("SELECT current_schema()").fetchone()[0]
        print(f"current_schema() -> {current}")

        # init.sql contains its own BEGIN/COMMIT; run as one script
        conn.execute(sql)

        tables = conn.execute(
            """
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = %s
              AND table_type = 'BASE TABLE'
            ORDER BY table_name
            """,
            (SCHEMA,),
        ).fetchall()

    print("Applied successfully.")
    print(f"Tables in {SCHEMA}:")
    for (name,) in tables:
        print(f"  - {name}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001 - surface DB errors clearly for operators
        print(f"FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
