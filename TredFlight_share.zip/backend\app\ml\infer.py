"""Load the bundled transformer weights and score a context once."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

from app.ml.features import encode_from_mapping, explain_product, normalize_moment
from app.ml.transformer import NumpyAncillaryTransformer, default_artifact_path


@lru_cache(maxsize=1)
def load_local_model(path: str | None = None) -> NumpyAncillaryTransformer:
    artifact = Path(path) if path else default_artifact_path()
    if not artifact.exists():
        raise FileNotFoundError(f"Ancillary transformer weights not found: {artifact}")
    return NumpyAncillaryTransformer.load(artifact)


def score_payload(payload: dict[str, Any], weights_path: str | None = None) -> dict[str, Any]:
    token_ids, numeric = encode_from_mapping(payload)
    model = load_local_model(weights_path)
    scores = model.score_map(token_ids, numeric)
    moment = normalize_moment(str(payload.get("moment") or "SEARCH_RESULTS"))
    reasons = {code: explain_product(code, value, moment) for code, value in scores.items()}
    return {"scores": scores, "reasons": reasons, "source": "transformer-local"}
