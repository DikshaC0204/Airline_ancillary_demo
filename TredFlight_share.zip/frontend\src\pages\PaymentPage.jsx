import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import BookingSummarySidebar from '../components/BookingSummarySidebar';
import CurationPanel from '../components/CurationPanel';
import { FieldError, FormErrorBanner } from '../components/FieldError';
import { useBooking, computeTotal } from '../context/BookingContext';
import { api, daysUntil, tripNights } from '../api/client';

const BaggageCard = ({ weight, price, selectedWeight, onSelect }) => {
  const isSelected = weight === selectedWeight;
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect(weight, price)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') onSelect(weight, price);
      }}
      className={`border rounded-lg p-4 text-center cursor-pointer transition ${
        isSelected
          ? 'border-brand-coral ring-2 ring-brand-coral'
          : 'border-gray-300 hover:border-brand-navy'
      }`}
    >
      <div className="text-4xl">🧳</div>
      <div className="font-bold text-lg mt-2">{weight}</div>
      <div className={`font-bold mt-2 ${isSelected ? 'text-brand-coral' : 'text-gray-700'}`}>
        ${price.toFixed(2)}
      </div>
    </div>
  );
};

const hasBagFromPassengerOffers = (booking) => {
  // Model/curation accept on passengers puts the code in heldProducts.
  // Payment self-serve picker only uses extras.baggage + selectedProducts.
  return (booking.heldProducts || []).some(
    (c) => String(c).startsWith('BAG_') || c === 'FAMILY_BAG_BUNDLE'
  );
};

const PaymentPage = () => {
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState(null);
  const [card, setCard] = useState({
    name: '',
    number: '',
    expiry: '',
    cvc: '',
  });
  const [fieldErrors, setFieldErrors] = useState({});
  const isPostBookingAddOn = Boolean(booking.pnr && booking.postBookingPayment);

  const journey = useMemo(
    () => ({
      origin: booking.origin,
      destination: booking.destination,
      pax: (booking.party?.adults || 1) + (booking.party?.children || 0),
      adults: booking.party?.adults || 1,
      children: booking.party?.children || 0,
      fare: booking.fareCode || 'BASIC',
      days_to_departure: daysUntil(booking.outboundFlight?.depart_at || booking.departDate),
      trip_nights: tripNights(
        booking.outboundFlight?.depart_at || booking.departDate,
        booking.returnFlight?.depart_at || booking.returnDate,
        booking.tripType
      ),
      return_trip: booking.tripType !== 'oneway',
      price_sensitivity: booking.fareCode === 'BASIC' ? 'high' : 'medium',
    }),
    [booking]
  );

  // Static opt-in when no bag was suggested/accepted earlier — not model-driven.
  const showBaggagePicker = !isPostBookingAddOn && !hasBagFromPassengerOffers(booking);

  const handleAddBaggage = (weight, price) => {
    const code = `BAG_${weight.toUpperCase()}`;
    setBooking((prev) => {
      const already = prev.extras?.baggage?.weight === weight;
      if (already) {
        return {
          ...prev,
          extras: { ...prev.extras, baggage: null },
          selectedProducts: (prev.selectedProducts || []).filter((p) => !String(p).startsWith('BAG_')),
          productPrices: Object.fromEntries(
            Object.entries(prev.productPrices || {}).filter(([k]) => !String(k).startsWith('BAG_'))
          ),
        };
      }
      return {
        ...prev,
        extras: { ...prev.extras, baggage: { weight, price, code } },
        selectedProducts: [
          ...new Set([
            ...(prev.selectedProducts || []).filter((p) => !String(p).startsWith('BAG_')),
            code,
          ]),
        ],
        productPrices: { ...(prev.productPrices || {}), [code]: price },
      };
    });
  };

  const setCardField = (key, value) => {
    setCard((prev) => ({ ...prev, [key]: value }));
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
    setError(null);
  };

  const validateCard = () => {
    const next = {};
    if (!card.name.trim()) next.name = 'Name on card is required';
    const digits = card.number.replace(/\s+/g, '');
    if (!digits) next.number = 'Card number is required';
    else if (!/^\d{12,19}$/.test(digits)) next.number = 'Please enter a valid card number';
    if (!card.expiry.trim()) next.expiry = 'Expiry is required';
    else if (!/^(0[1-9]|1[0-2])\s*\/\s*\d{2}$/.test(card.expiry.trim())) {
      next.expiry = 'Please enter expiry as MM/YY';
    }
    if (!card.cvc.trim()) next.cvc = 'CVC is required';
    else if (!/^\d{3,4}$/.test(card.cvc.trim())) next.cvc = 'Please enter a valid CVC';
    if (!booking.outboundFlight?.id) next.flight = 'Please select a flight before payment.';
    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const confirm = async () => {
    if (!validateCard()) {
      setError('Please enter the highlighted payment details to continue.');
      return;
    }
    setPaying(true);
    setError(null);
    try {
      if (isPostBookingAddOn) {
        const pnr = booking.pnr;
        await api.updateBooking(pnr, {
          passengers: booking.passengers,
          selected_products: (booking.selectedProducts || []).filter((p) => typeof p === 'string'),
          extras: booking.extras,
          fare_code: booking.fareCode,
        });
        setBooking((prev) => ({
          ...prev,
          postBookingPayment: false,
          heldProducts: [
            ...new Set([
              ...(prev.heldProducts || []),
              ...((prev.selectedProducts || []).filter((p) => typeof p === 'string')),
            ]),
          ],
        }));
        navigate('/confirmation');
        return;
      }

      let pnr = booking.pnr;
      if (!pnr) {
        const passengersPayload = (booking.passengers || []).map((p) => ({
          ...p,
          age: p.age === '' || p.age == null ? null : Number(p.age),
          email: p.email || null,
        }));
        const created = await api.createBooking({
          passenger_ref: booking.passenger_ref,
          trip_type: booking.tripType,
          origin: booking.origin,
          destination: booking.destination,
          outbound_flight_id: booking.outboundFlight.id,
          return_flight_id: booking.returnFlight?.id || null,
          fare_code: booking.fareCode || 'BASIC',
          party: booking.party,
          passengers: passengersPayload,
          selected_products: (booking.selectedProducts || []).filter((p) => typeof p === 'string'),
          extras: booking.extras,
        });
        pnr = created.pnr;
        setBooking((prev) => ({ ...prev, pnr }));
      }
      await api.updateBooking(pnr, {
        passengers: booking.passengers,
        selected_products: (booking.selectedProducts || []).filter((p) => typeof p === 'string'),
        extras: booking.extras,
        fare_code: booking.fareCode,
      });
      const confirmed = await api.confirmBooking(pnr);
      setBooking((prev) => ({
        ...prev,
        pnr: confirmed.pnr,
        postBookingPayment: false,
        heldProducts: [
          ...new Set([
            ...(prev.heldProducts || []),
            confirmed.fare_code,
            ...(confirmed.selected_products || []),
          ]),
        ],
      }));
      navigate('/confirmation');
    } catch (err) {
      setError(err.message);
    } finally {
      setPaying(false);
    }
  };

  const inputClass = (key) =>
    `border rounded-md p-3 w-full ${
      fieldErrors[key] ? 'border-red-500 ring-1 ring-red-500' : 'border-gray-300'
    }`;

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-screen-xl mx-auto p-4 lg:p-8 flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-[280px] flex-shrink-0">
          <div className="sticky top-6">
            <BookingSummarySidebar booking={booking} currentStep="payment" />
          </div>
        </aside>

        <main className="flex-grow space-y-6">
          {showBaggagePicker && (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-black text-brand-navy mb-1">CHECKED-IN BAGGAGE</h3>
              <p className="text-sm text-gray-500 mb-6">
                Optional — add a bag here if it wasn&apos;t offered earlier (e.g. short trips). Not a
                model suggestion.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <BaggageCard
                  weight="10kg"
                  price={25.0}
                  selectedWeight={booking.extras?.baggage?.weight}
                  onSelect={handleAddBaggage}
                />
                <BaggageCard
                  weight="20kg"
                  price={35.0}
                  selectedWeight={booking.extras?.baggage?.weight}
                  onSelect={handleAddBaggage}
                />
                <BaggageCard
                  weight="26kg"
                  price={45.0}
                  selectedWeight={booking.extras?.baggage?.weight}
                  onSelect={handleAddBaggage}
                />
                <BaggageCard
                  weight="32kg"
                  price={55.0}
                  selectedWeight={booking.extras?.baggage?.weight}
                  onSelect={handleAddBaggage}
                />
              </div>
            </div>
          )}

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-black text-brand-navy mb-2">
              {isPostBookingAddOn ? 'PAY FOR ADDED OFFERS' : 'PAYMENT'}
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Demo checkout — no real card capture. Total due:{' '}
              <strong>${computeTotal(booking).toFixed(2)}</strong>
              {isPostBookingAddOn && booking.pnr ? (
                <span className="block mt-1 text-xs text-gray-500">
                  Paying extras for booking {booking.pnr}
                </span>
              ) : null}
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Name on card *
                </label>
                <input
                  className={inputClass('name')}
                  placeholder="Name on card"
                  value={card.name}
                  onChange={(e) => setCardField('name', e.target.value)}
                  aria-required="true"
                />
                <FieldError message={fieldErrors.name} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Card number *
                </label>
                <input
                  className={inputClass('number')}
                  placeholder="Card number (demo)"
                  value={card.number}
                  onChange={(e) => setCardField('number', e.target.value)}
                  aria-required="true"
                />
                <FieldError message={fieldErrors.number} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">MM/YY *</label>
                <input
                  className={inputClass('expiry')}
                  placeholder="MM/YY"
                  value={card.expiry}
                  onChange={(e) => setCardField('expiry', e.target.value)}
                  aria-required="true"
                />
                <FieldError message={fieldErrors.expiry} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">CVC *</label>
                <input
                  className={inputClass('cvc')}
                  placeholder="CVC"
                  value={card.cvc}
                  onChange={(e) => setCardField('cvc', e.target.value)}
                  aria-required="true"
                />
                <FieldError message={fieldErrors.cvc} />
              </div>
            </div>
            <FormErrorBanner message={error} />
          </div>

          {!isPostBookingAddOn && (
            <CurationPanel
              moment="PAYMENT"
              heading="Get Offers"
              title="Café, connectivity & travel extras"
              journey={journey}
              heldProducts={booking.heldProducts}
              eventStream={[]}
              declinedProducts={booking.declinedProducts}
              passengerRef={booking.passenger_ref}
              onAccept={(item) =>
                setBooking((prev) => ({
                  ...prev,
                  selectedProducts: [...new Set([...(prev.selectedProducts || []), item.product])],
                  heldProducts: [...new Set([...(prev.heldProducts || []), item.product])],
                  productPrices: { ...(prev.productPrices || {}), [item.product]: item.price },
                }))
              }
              onDecline={(item) =>
                setBooking((prev) => ({
                  ...prev,
                  declinedProducts: [...new Set([...(prev.declinedProducts || []), item.product])],
                }))
              }
            />
          )}

          <button
            type="button"
            disabled={paying}
            onClick={confirm}
            className="w-full bg-brand-coral text-white font-bold text-lg py-3 rounded-md disabled:opacity-60"
          >
            {paying
              ? 'Confirming…'
              : isPostBookingAddOn
                ? 'Pay for added offers'
                : 'Pay & confirm booking'}
          </button>
        </main>
      </div>
    </div>
  );
};

export default PaymentPage;
