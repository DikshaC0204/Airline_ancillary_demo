import React, { useEffect, useMemo, useRef, useState } from 'react';

const WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function toISODate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function parseISODate(value) {
  if (!value) return null;
  const [y, m, d] = value.split('-').map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}

function formatDisplay(value) {
  const d = parseISODate(value);
  if (!d) return '';
  return d.toLocaleDateString(undefined, {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

function startOfDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

/**
 * Branded popover calendar — opens on click, closes on outside click / Escape / selection.
 */
const DatePicker = ({
  label = 'Date',
  value,
  onChange,
  minDate,
  hidden = false,
  keepSpace = false,
  placeholder = 'Select date',
  error = false,
  required = false,
}) => {
  const rootRef = useRef(null);
  const [open, setOpen] = useState(false);
  const selected = parseISODate(value);
  const min = minDate ? startOfDay(parseISODate(minDate) || new Date(minDate)) : startOfDay(new Date());

  const initialMonth = selected || min || new Date();
  const [viewYear, setViewYear] = useState(initialMonth.getFullYear());
  const [viewMonth, setViewMonth] = useState(initialMonth.getMonth());

  useEffect(() => {
    if (!open) return undefined;
    const onDoc = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  useEffect(() => {
    if (selected) {
      setViewYear(selected.getFullYear());
      setViewMonth(selected.getMonth());
    }
  }, [value]);

  const cells = useMemo(() => {
    const first = new Date(viewYear, viewMonth, 1);
    const startPad = first.getDay();
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
    const grid = [];
    for (let i = 0; i < startPad; i += 1) grid.push(null);
    for (let day = 1; day <= daysInMonth; day += 1) {
      grid.push(new Date(viewYear, viewMonth, day));
    }
    while (grid.length % 7 !== 0) grid.push(null);
    return grid;
  }, [viewYear, viewMonth]);

  const prevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else setViewMonth((m) => m - 1);
  };

  const nextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else setViewMonth((m) => m + 1);
  };

  if (hidden && !keepSpace) return null;

  return (
    <div
      className={`relative col-span-1 min-w-0 ${hidden ? 'invisible pointer-events-none' : ''}`}
      ref={rootRef}
      aria-hidden={hidden || undefined}
    >
      <button
        type="button"
        onClick={() => !hidden && setOpen((o) => !o)}
        className={`booking-field border rounded-md px-3 py-1.5 font-semibold w-full text-left focus:outline-none transition flex flex-col justify-center ${
          error
            ? 'border-red-500 ring-1 ring-red-500'
            : open
              ? 'border-brand-coral ring-1 ring-brand-coral'
              : 'border-gray-300 focus:border-brand-coral'
        }`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={label}
        aria-invalid={error || undefined}
        aria-required={required || undefined}
        tabIndex={hidden ? -1 : 0}
      >
        <span className="block text-[10px] uppercase tracking-wide text-gray-500 font-bold leading-none mb-0.5">
          {label}
          {required ? ' *' : ''}
        </span>
        <span className={`text-sm truncate ${value ? 'text-gray-900' : 'text-gray-400'}`}>
          {value ? formatDisplay(value) : placeholder}
        </span>
      </button>

      {open && !hidden && (
        <div className="absolute top-full left-0 mt-2 z-40 w-[300px] bg-white border border-gray-200 rounded-xl shadow-2xl p-3 animate-fadeIn">
          <div className="flex items-center justify-between mb-3 px-1">
            <button
              type="button"
              onClick={prevMonth}
              className="w-8 h-8 rounded-full hover:bg-gray-100 font-bold text-brand-navy"
              aria-label="Previous month"
            >
              ‹
            </button>
            <div className="font-bold text-brand-navy">
              {MONTHS[viewMonth]} {viewYear}
            </div>
            <button
              type="button"
              onClick={nextMonth}
              className="w-8 h-8 rounded-full hover:bg-gray-100 font-bold text-brand-navy"
              aria-label="Next month"
            >
              ›
            </button>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEKDAYS.map((d) => (
              <div key={d} className="text-center text-[11px] font-bold text-gray-400 py-1">
                {d}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, idx) => {
              if (!day) return <div key={`e-${idx}`} className="h-9" />;
              const iso = toISODate(day);
              const disabled = startOfDay(day) < min;
              const isSelected = value === iso;
              const isToday = toISODate(new Date()) === iso;
              return (
                <button
                  key={iso}
                  type="button"
                  disabled={disabled}
                  onClick={() => {
                    onChange?.(iso);
                    setOpen(false);
                  }}
                  className={`h-9 rounded-lg text-sm font-semibold transition ${
                    disabled
                      ? 'text-gray-300 cursor-not-allowed'
                      : isSelected
                        ? 'bg-brand-coral text-white shadow'
                        : isToday
                          ? 'bg-brand-navy/10 text-brand-navy hover:bg-brand-navy hover:text-white'
                          : 'text-gray-800 hover:bg-gray-100'
                  }`}
                >
                  {day.getDate()}
                </button>
              );
            })}
          </div>

          <div className="flex justify-between mt-3 pt-2 border-t">
            <button
              type="button"
              className="text-xs font-semibold text-gray-500 hover:text-brand-navy"
              onClick={() => {
                onChange?.('');
                setOpen(false);
              }}
            >
              Clear
            </button>
            <button
              type="button"
              className="text-xs font-bold text-brand-coral hover:underline"
              onClick={() => {
                const today = toISODate(new Date());
                if (startOfDay(new Date()) >= min) {
                  onChange?.(today);
                  setOpen(false);
                }
              }}
            >
              Today
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatePicker;
