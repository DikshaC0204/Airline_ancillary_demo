# TredFlight frontend

React + Vite + Tailwind CSS SPA for the TredFlight booking and ancillary-curation experience.

## Stack

- React 19 + React Router 7
- Vite 8
- Tailwind CSS 4 (`@theme` brand tokens: `brand-navy` `#1e3a5f`, `brand-coral` `#fe5000`)
- Session booking state via `BookingContext` (+ `sessionStorage`)

## Scripts

```bash
npm install
npm run dev       # http://localhost:5173
npm run build
npm run preview
npm run lint
```

## Environment

Copy `.env.example` to `.env.local` if needed:

```env
VITE_API_BASE=http://localhost:8000/api/v1
```

Vite also proxies `/api` → `http://localhost:8000` (see `vite.config.js`).

## Main routes

| Path | Page |
|------|------|
| `/` | Home + search widget |
| `/flights` | Flight results + fare bundles + curation |
| `/passengers` | Passenger details + bags |
| `/seats` | Seat map + live-intent curation |
| `/payment` | Demo payment + revenue/fit dial |
| `/confirmation` | PNR + entitlement offers |
| `/manage` | Manage booking / check-in / post-booking moments |

## Key folders

```
src/
  api/client.js           # REST client
  context/BookingContext.jsx
  components/             # Header, BookingWidget, DatePicker, CurationPanel, …
  pages/                  # Route screens
```

## UI notes

- Origin / destination and passenger pickers: click to open, click outside or Escape to close
- Departure / return use a custom branded `DatePicker` (not the native browser date control)
- Header **Manage booking** is a coral-bordered button; home also links to `/manage` below the search widget
- Interactive controls use `cursor: pointer` globally
- Site logo text: **TredFlight**; fare/ancillary names are generic (Basic, Go, Plus, Priority, …)

Backend must be running on **port 8000** for live search, booking, and curation. See root [`README.md`](../README.md) and [`architecture.md`](../architecture.md).
