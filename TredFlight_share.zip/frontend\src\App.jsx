import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { BookingProvider } from './context/BookingContext';
import HomePage from './pages/HomePage';
import FlightsPage from './pages/FlightsPage';
import PassengersPage from './pages/PassengersPage';
import SeatsPage from './pages/SeatsPage';
import PaymentPage from './pages/PaymentPage';
import ConfirmationPage from './pages/ConfirmationPage';
import ManageBookingPage from './pages/ManageBookingPage';
import ScenarioDemoPage from './pages/ScenarioDemoPage';
import CommercialDialDemoPage from './pages/CommercialDialDemoPage';

function App() {
  return (
    <BookingProvider>
      <Router>
        <div className="min-h-screen bg-gray-100">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/flights" element={<FlightsPage />} />
            <Route path="/passengers" element={<PassengersPage />} />
            <Route path="/seats" element={<SeatsPage />} />
            <Route path="/payment" element={<PaymentPage />} />
            <Route path="/summary" element={<PaymentPage />} />
            <Route path="/confirmation" element={<ConfirmationPage />} />
            <Route path="/manage" element={<ManageBookingPage />} />
            <Route path="/demo/scenarios" element={<ScenarioDemoPage />} />
            <Route path="/demo/commercial-dial" element={<CommercialDialDemoPage />} />
          </Routes>
        </div>
      </Router>
    </BookingProvider>
  );
}

export default App;
