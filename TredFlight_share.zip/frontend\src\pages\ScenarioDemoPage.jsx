import React, { useEffect, useState } from 'react';
import Header from '../components/Header';
import { api } from '../api/client';

/**
 * Leadership / QA walkthrough for the 10 Excel demo scenarios.
 * Auto-runs curate for each scenario and renders explainable results.
 */
const SCENARIOS = [
  {
    id: 'S1',
    moment: 'SEARCH_RESULTS',
    title: 'Cold start at search results',
    channel: 'WEB',
    setup:
      'New passenger, no history. LTN→BUD, departing in 3 days, 2-night return, Basic fare.',
    proves: 'Ranks a never-seen passenger via route cohorts; bag suppressed for short cabin-only trip.',
    expected: 'Priority first, standard seat second, checked bag suppressed.',
    passenger_ref: 'SYN-DEMO-S1',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 3,
      trip_nights: 2,
      return_trip: true,
      price_sensitivity: 'medium',
    },
    held_products: ['BASIC_FARE'],
    event_stream: [],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S2',
    moment: 'FARE_COMPARISON',
    title: 'Family basket at fare comparison',
    channel: 'WEB',
    setup: 'Two adults + two children, LTN→ALC, six weeks out, seven nights, Basic.',
    proves: 'Prices the party as one basket, not four individuals.',
    expected: 'BUNDLE — shared 20 kg bag + seats together above individual bag.',
    passenger_ref: 'SYN-DEMO-S2',
    journey: {
      origin: 'LTN',
      destination: 'ALC',
      pax: 4,
      adults: 2,
      children: 2,
      fare: 'BASIC',
      days_to_departure: 42,
      trip_nights: 7,
      return_trip: true,
      price_sensitivity: 'medium',
    },
    held_products: ['BASIC_FARE'],
    event_stream: [],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S3',
    moment: 'SEAT_MAP',
    title: 'Live intent on the seat map',
    channel: 'WEB',
    setup: 'Continue S1 passenger. Seat map opened twice with no selection.',
    proves: 'Reads behavioural sequence, not a static profile.',
    expected: 'Seat products escalate above Priority; reason names repeated map opens.',
    passenger_ref: 'SYN-DEMO-S3',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 3,
      trip_nights: 2,
      return_trip: true,
    },
    held_products: ['BASIC_FARE'],
    event_stream: [
      { t: '-00:04:12', e: 'SEARCH_RESULTS_VIEW' },
      { t: '-00:02:50', e: 'SEAT_MAP_OPEN' },
      { t: '-00:01:05', e: 'SEAT_MAP_OPEN' },
    ],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S4a',
    moment: 'PAYMENT',
    title: 'Price-sensitive payment — fit dial (0.2)',
    channel: 'WEB',
    setup: 'Solo, cheapest fare, no ancillary engagement. Revenue/fit dial at fit.',
    proves: 'Dial shifts ranking between restraint and revenue.',
    expected: 'Low-ticket Auto check-in or NO_OFFER under fit dial.',
    passenger_ref: 'SYN-DEMO-S4A',
    revenue_fit_dial: 0.2,
    journey: {
      origin: 'LTN',
      destination: 'ALC',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 42,
      trip_nights: 7,
      return_trip: true,
      price_sensitivity: 'high',
    },
    held_products: ['BASIC_FARE'],
    event_stream: [{ t: '-00:10:00', e: 'SEARCH_RESULTS_VIEW' }],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S4b',
    moment: 'PAYMENT',
    title: 'Price-sensitive payment — revenue dial (0.85)',
    channel: 'WEB',
    setup: 'Same passenger; dial moved toward revenue.',
    proves: 'Commercial dial changes the ranked set without new code.',
    expected: 'Smallest bag tier or stronger monetisation push.',
    passenger_ref: 'SYN-DEMO-S4B',
    revenue_fit_dial: 0.85,
    journey: {
      origin: 'LTN',
      destination: 'ALC',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 42,
      trip_nights: 7,
      return_trip: true,
      price_sensitivity: 'high',
    },
    held_products: ['BASIC_FARE'],
    event_stream: [{ t: '-00:10:00', e: 'SEARCH_RESULTS_VIEW' }],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S5',
    moment: 'SEAT_MAP',
    title: 'Inventory-constrained flight',
    channel: 'WEB',
    setup: 'Extra-legroom sold out; Priority capped. Inventory mocked in demo.',
    proves: 'Filter stage will not sell what cannot be delivered.',
    expected: 'EXTRA_LEGROOM under suppressed with inventory reason.',
    passenger_ref: 'SYN-DEMO-S5',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 5,
      trip_nights: 4,
      return_trip: true,
    },
    held_products: ['BASIC_FARE'],
    event_stream: [{ t: '-00:01:00', e: 'SEAT_MAP_OPEN' }],
    declined_products: [],
    inventory: { EXTRA_LEGROOM: 0, PRIORITY: 0, BAG_20KG: 'OPEN' },
  },
  {
    id: 'S6',
    moment: 'BOOKING_CONFIRMATION',
    title: 'Entitlement check on confirmation',
    channel: 'WEB',
    setup: 'Passenger on Plus / Priority held in-path.',
    proves: 'Does not re-sell what is already owned; offers true complements.',
    expected: 'Owned ancillaries suppressed; Security Fast Track ranked.',
    passenger_ref: 'SYN-DEMO-S6',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'PLUS',
      days_to_departure: 10,
      trip_nights: 5,
      return_trip: true,
    },
    held_products: [
      'PLUS',
      'PRIORITY',
      'SEAT_PREMIUM',
      'BAG_32KG',
      'FLEX',
      'AUTO_CHECKIN',
    ],
    event_stream: [],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S7',
    moment: 'PRE_TRIP_REMINDER',
    title: 'Pre-trip reminder — decline does not return',
    channel: 'APP',
    setup: 'Same passenger as seat-map decline (S3). Seat previously declined.',
    proves: 'Shared fatigue memory across moments / channels.',
    expected: 'Seat not repeated; Flex or bag instead.',
    passenger_ref: 'SYN-DEMO-S7',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 2,
      trip_nights: 2,
      return_trip: true,
    },
    held_products: ['BASIC_FARE'],
    event_stream: [],
    declined_products: ['SEAT_STANDARD'],
    inventory: {},
  },
  {
    id: 'S8',
    moment: 'MANAGE_BOOKING',
    title: 'Ops delay reweights manage-booking offers',
    channel: 'MMB',
    setup: 'Inject ~2 hour delay / schedule change on the flight.',
    proves: 'Operational state changes commercial output; restraint under severe disruption.',
    expected: 'Flex rises; Priority and seats fall.',
    passenger_ref: 'SYN-DEMO-S8',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 1,
      trip_nights: 2,
      return_trip: true,
      delay_minutes: 120,
      schedule_changed: true,
    },
    held_products: ['BASIC_FARE'],
    event_stream: [],
    declined_products: [],
    inventory: {},
  },
  {
    id: 'S9',
    moment: 'CHECK_IN',
    title: 'Time proximity at check-in',
    channel: 'WEB',
    setup: 'T-20h. No seat purchased; cabin-only baggage state.',
    proves: 'Same catalogue, different answer because the moment changed.',
    expected: 'Priority and bag above seats; seat value decayed.',
    passenger_ref: 'SYN-DEMO-S9',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 0,
      trip_nights: 2,
      return_trip: true,
    },
    held_products: ['BASIC_FARE'],
    event_stream: [],
    declined_products: ['SEAT_STANDARD'],
    inventory: {},
  },
  {
    id: 'S10',
    moment: 'AIRPORT_ENTRY',
    title: 'Right product at the airport',
    channel: 'KIOSK',
    setup: 'Holds Priority, not Fast Track; long security queue.',
    proves: 'Product-level precision — Priority does not cover security.',
    expected: 'Security Fast Track first; reason names queue + entitlement gap.',
    passenger_ref: 'SYN-DEMO-S10',
    journey: {
      origin: 'LTN',
      destination: 'BUD',
      pax: 1,
      adults: 1,
      children: 0,
      fare: 'BASIC',
      days_to_departure: 0,
      trip_nights: 2,
      return_trip: true,
      queue_long: true,
    },
    held_products: ['BASIC_FARE', 'PRIORITY'],
    event_stream: [],
    declined_products: [],
    inventory: {},
  },
];

const ResultBlock = ({ result }) => {
  if (!result) return null;
  return (
    <div className="mt-4 space-y-3" data-testid="curation-result">
      <div className="flex flex-wrap gap-2 text-xs">
        <span className="bg-gray-100 px-2 py-1 rounded font-semibold">Action: {result.action}</span>
        {result.model_source && (
          <span className="bg-brand-navy/10 text-brand-navy px-2 py-1 rounded font-semibold">
            Model: {String(result.model_source).replace(/-/g, ' ')}
          </span>
        )}
        <span className="bg-gray-100 px-2 py-1 rounded">
          Fatigue: {result.fatigue_state?.impressions || 0} / {result.fatigue_state?.declines || 0}
        </span>
      </div>
      {result.ranked?.length > 0 && (
        <div>
          <h5 className="text-xs font-bold uppercase text-brand-navy mb-2">Ranked offers</h5>
          <ul className="space-y-2">
            {result.ranked.map((item) => (
              <li key={item.product} className="border rounded-md p-3 bg-white">
                <div className="font-bold text-brand-navy">
                  {item.name}{' '}
                  <span className="text-xs font-mono text-gray-500">({item.product})</span>
                </div>
                <div className="text-xs text-gray-600 mt-1">
                  Score {Number(item.score).toFixed(2)} — {item.reason}
                </div>
                {item.price > 0 && (
                  <div className="text-sm font-semibold mt-1">${Number(item.price).toFixed(2)}</div>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      {result.suppressed?.length > 0 && (
        <div>
          <h5 className="text-xs font-bold uppercase text-gray-500 mb-2">Suppressed</h5>
          <ul className="space-y-1 text-xs text-gray-600">
            {result.suppressed.map((item) => (
              <li key={item.product} className="bg-gray-50 border rounded px-2 py-1.5">
                <span className="font-semibold">{item.product}</span> — {item.reason}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

const ScenarioCard = ({ scenario, result, error, loading }) => (
  <section
    id={scenario.id}
    data-scenario={scenario.id}
    className="bg-white rounded-lg shadow-md border border-gray-100 overflow-hidden scroll-mt-6"
  >
    <div className="bg-brand-navy text-white px-5 py-4">
      <div className="text-brand-coral text-xs font-bold uppercase tracking-wider">
        Scenario {scenario.id} · {scenario.moment} · {scenario.channel}
      </div>
      <h2 className="text-xl font-black mt-1">{scenario.title}</h2>
    </div>
    <div className="p-5 grid md:grid-cols-2 gap-4">
      <div className="space-y-3 text-sm">
        <div>
          <div className="text-xs font-bold uppercase text-gray-500">Setup</div>
          <p className="text-gray-700 mt-1">{scenario.setup}</p>
        </div>
        <div>
          <div className="text-xs font-bold uppercase text-gray-500">Expected</div>
          <p className="text-gray-700 mt-1">{scenario.expected}</p>
        </div>
        <div>
          <div className="text-xs font-bold uppercase text-gray-500">Proves</div>
          <p className="text-gray-700 mt-1">{scenario.proves}</p>
        </div>
      </div>
      <div className="bg-slate-50 rounded-md border p-4 min-h-[160px]">
        <div className="text-xs font-bold uppercase text-brand-navy">Live engine output</div>
        {loading && <p className="text-sm text-gray-500 mt-3">Ranking…</p>}
        {error && <p className="text-sm text-red-600 mt-3">{error}</p>}
        <ResultBlock result={result} />
      </div>
    </div>
  </section>
);

const ScenarioDemoPage = () => {
  const [results, setResults] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const nextResults = {};
      const nextErrors = {};
      for (const s of SCENARIOS) {
        try {
          const data = await api.curate({
            moment: s.moment,
            channel: s.channel,
            passenger_ref: s.passenger_ref,
            journey: s.journey,
            event_stream: s.event_stream,
            held_products: s.held_products,
            inventory: s.inventory,
            declined_products: s.declined_products,
            revenue_fit_dial: s.revenue_fit_dial,
          });
          nextResults[s.id] = data;
        } catch (err) {
          nextErrors[s.id] = err.message || 'Curate failed';
        }
      }
      if (!cancelled) {
        setResults(nextResults);
        setErrors(nextErrors);
        setLoading(false);
        setReady(true);
        document.body.dataset.demoReady = 'true';
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen" data-demo-ready={ready ? 'true' : 'false'}>
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        <header className="bg-white rounded-lg shadow-md border p-6">
          <p className="text-brand-coral font-black text-sm uppercase tracking-wider">TredFlight</p>
          <h1 className="text-3xl font-black text-brand-navy mt-1">
            Ancillary curation — scenario evidence pack
          </h1>
          <p className="text-gray-600 mt-2 max-w-3xl">
            Live runs of the ten demo scenarios from the requirements workbook. Each card shows
            setup, expected behaviour, and the explainable ranked / suppressed output from{' '}
            <code className="text-xs bg-gray-100 px-1 rounded">POST /api/v1/curate</code>.
          </p>
          <p className="text-xs text-gray-500 mt-3">
            Status: {loading ? 'Running scenarios…' : `Complete (${Object.keys(results).length} / ${SCENARIOS.length})`}
          </p>
        </header>

        {SCENARIOS.map((s) => (
          <ScenarioCard
            key={s.id}
            scenario={s}
            result={results[s.id]}
            error={errors[s.id]}
            loading={loading && !results[s.id] && !errors[s.id]}
          />
        ))}
      </div>
    </div>
  );
};

export default ScenarioDemoPage;
