"""SQLAlchemy text() statements for flights + inventory."""

from sqlalchemy import text

LIST_FLIGHTS_BY_ROUTE = text(
    """
    SELECT
        f.id,
        f.flight_number,
        f.origin,
        f.destination,
        f.depart_at,
        f.arrive_at,
        f.base_price,
        f.currency,
        f.load_factor,
        f.delay_minutes,
        f.schedule_changed,
        COALESCE(
            json_agg(
                json_build_object(
                    'product_code', i.product_code,
                    'remaining', i.remaining,
                    'status', i.status
                )
                ORDER BY i.product_code
            ) FILTER (WHERE i.id IS NOT NULL),
            '[]'::json
        ) AS inventory
    FROM flights f
    LEFT JOIN inventory i ON i.flight_id = f.id
    WHERE f.origin = :origin
      AND f.destination = :destination
      AND f.depart_at >= COALESCE(CAST(:day_from AS timestamp), '-infinity'::timestamp)
      AND f.depart_at < COALESCE(CAST(:day_to AS timestamp), 'infinity'::timestamp)
    GROUP BY f.id
    ORDER BY f.depart_at
    LIMIT :lim
    """
)

ROUTE_HAS_FLIGHTS = text(
    """
    SELECT 1
    FROM flights
    WHERE origin = :origin
      AND destination = :destination
    LIMIT 1
    """
)

FLIGHT_NUMBER_EXISTS = text(
    """
    SELECT 1
    FROM flights
    WHERE flight_number = :flight_number
    LIMIT 1
    """
)

GET_FLIGHT = text(
    """
    SELECT
        f.id,
        f.flight_number,
        f.origin,
        f.destination,
        f.depart_at,
        f.arrive_at,
        f.base_price,
        f.currency,
        f.load_factor,
        f.delay_minutes,
        f.schedule_changed,
        COALESCE(
            json_agg(
                json_build_object(
                    'product_code', i.product_code,
                    'remaining', i.remaining,
                    'status', i.status
                )
                ORDER BY i.product_code
            ) FILTER (WHERE i.id IS NOT NULL),
            '[]'::json
        ) AS inventory
    FROM flights f
    LEFT JOIN inventory i ON i.flight_id = f.id
    WHERE f.id = :flight_id
    GROUP BY f.id
    """
)

GET_FLIGHT_BASE = text(
    """
    SELECT id, flight_number, origin, destination, depart_at, arrive_at,
           base_price, currency, load_factor, delay_minutes, schedule_changed
    FROM flights
    WHERE id = :flight_id
    """
)

INSERT_FLIGHT = text(
    """
    INSERT INTO flights (
        flight_number, origin, destination, depart_at, arrive_at,
        base_price, currency, load_factor, delay_minutes, schedule_changed
    )
    VALUES (
        :flight_number, :origin, :destination, :depart_at, :arrive_at,
        :base_price, :currency, :load_factor, :delay_minutes, :schedule_changed
    )
    RETURNING id
    """
)

INSERT_INVENTORY = text(
    """
    INSERT INTO inventory (flight_id, product_code, remaining, status)
    VALUES (:flight_id, :product_code, :remaining, :status)
    ON CONFLICT ON CONSTRAINT uq_flight_product DO NOTHING
    """
)
