"""Deterministic feature encoding for the ancillary transformer.

Context is a short token sequence plus a numeric vector. Product scores are
produced by a two-tower head (context CLS · product embedding).
"""

from __future__ import annotations

from typing import Any, Iterable, Sequence

import numpy as np

PRODUCT_CODES: list[str] = [
    "PRIORITY",
    "SECURITY_FAST_TRACK",
    "LOUNGE",
    "SEAT_STANDARD",
    "SEAT_FRONT",
    "EXTRA_LEGROOM",
    "BAG_10KG",
    "BAG_20KG",
    "BAG_26KG",
    "BAG_32KG",
    "FLEX",
    "AUTO_CHECKIN",
    "FARE_LOCK",
    "SITTING_TOGETHER",
    "FAMILY_BAG_BUNDLE",
    "CAFE_VOUCHER",
    "HOTEL",
    "CAR_RENTAL",
    "AIRPORT_PARKING",
    "ESIM",
]

MOMENTS: list[str] = [
    "SEARCH_RESULTS",
    "FARE_COMPARISON",
    "SEAT_MAP",
    "PAYMENT",
    "BOOKING_CONFIRMATION",
    "PRE_TRIP_REMINDER",
    "MANAGE_BOOKING",
    "CHECK_IN",
    "AIRPORT_ENTRY",
]

MOMENT_ALIASES: dict[str, str] = {
    "SEARCH": "SEARCH_RESULTS",
    "FARE": "FARE_COMPARISON",
    "SEATS": "SEAT_MAP",
    "CHECKOUT": "PAYMENT",
    "CONFIRMATION": "BOOKING_CONFIRMATION",
    "PRE_TRIP": "PRE_TRIP_REMINDER",
    "MMB": "MANAGE_BOOKING",
    "OPS": "MANAGE_BOOKING",
    "CHECKIN": "CHECK_IN",
    "SECURITY": "AIRPORT_ENTRY",
    "AIRPORT": "AIRPORT_ENTRY",
}

FARES: list[str] = ["BASIC", "SMART", "GO", "PLUS", "FAMILY_GO", "FAMILY_PLUS"]
AIRPORTS: list[str] = ["LTN", "BUD", "ALC", "GYD", "TIA", "EVN", "CRL", "GDN"]
PRICE_SENS: list[str] = ["low", "medium", "high"]
CHANNELS: list[str] = ["WEB", "APP", "EMAIL", "KIOSK"]

SPECIAL_TOKENS: list[str] = [
    "PAD",
    "CLS",
    "UNK",
    "FAMILY",
    "SOLO",
    "RETURN",
    "ONEWAY",
    "DELAY_OPS",
    "NORMAL_OPS",
    "SEAT_INTENT",
    "NO_SEAT_INTENT",
    "QUEUE_LONG",
    "QUEUE_OK",
]

SEQ_LEN = 12  # numeric CLS + 11 categorical tokens
N_NUMERIC = 10

REASON_HINTS: dict[str, str] = {
    "PRIORITY": "boarding comfort fit for this itinerary and moment",
    "SECURITY_FAST_TRACK": "security-lane complement when queues or Priority are in play",
    "LOUNGE": "airport comfort upsell after booking",
    "SEAT_STANDARD": "seat selection propensity from map intent and party",
    "SEAT_FRONT": "front-cabin seat interest from dwell and trip value",
    "EXTRA_LEGROOM": "extra-legroom interest from repeated seat-map intent",
    "BAG_10KG": "low-tier bag fit for price-sensitive checkout",
    "BAG_20KG": "checked-bag propensity from stay length and party size",
    "BAG_26KG": "heavier bag tier for longer leisure stays",
    "BAG_32KG": "largest bag tier for long / family trips",
    "FLEX": "schedule-risk / disruption flexibility",
    "AUTO_CHECKIN": "low-ticket convenience at payment or search",
    "FARE_LOCK": "fare-uncertainty hedge when departure is far out",
    "SITTING_TOGETHER": "party seating together for family compositions",
    "FAMILY_BAG_BUNDLE": "shared family basket beats per-passenger bags",
    "CAFE_VOUCHER": "retail voucher as a light ancillary",
    "HOTEL": "partner hotel interest on multi-night trips",
    "CAR_RENTAL": "partner car interest on longer leisure stays",
    "AIRPORT_PARKING": "origin parking for return trips",
    "ESIM": "destination connectivity after confirmation",
}


def _build_vocab() -> dict[str, int]:
    tokens: list[str] = []
    tokens.extend(SPECIAL_TOKENS)
    tokens.extend(f"MOMENT:{m}" for m in MOMENTS)
    tokens.extend(f"FARE:{f}" for f in FARES)
    tokens.extend(f"AIRPORT:{a}" for a in AIRPORTS)
    tokens.extend(f"SENS:{s}" for s in PRICE_SENS)
    tokens.extend(f"CH:{c}" for c in CHANNELS)
    tokens.extend(f"PROD:{p}" for p in PRODUCT_CODES)
    return {t: i for i, t in enumerate(tokens)}


VOCAB: dict[str, int] = _build_vocab()
PRODUCT_INDEX: dict[str, int] = {c: i for i, c in enumerate(PRODUCT_CODES)}


def vocab_size() -> int:
    return len(VOCAB)


def normalize_moment(moment: str) -> str:
    key = (moment or "SEARCH_RESULTS").upper().strip()
    return MOMENT_ALIASES.get(key, key if key in MOMENTS else "SEARCH_RESULTS")


def _tid(token: str) -> int:
    return VOCAB.get(token, VOCAB["UNK"])


def _seat_map_opens(events: Sequence[str]) -> int:
    return sum(1 for e in events if "SEAT_MAP" in str(e).upper())


def encode_context(
    *,
    moment: str,
    channel: str = "WEB",
    origin: str = "LTN",
    destination: str = "BUD",
    fare: str = "BASIC",
    pax: int = 1,
    adults: int = 1,
    children: int = 0,
    infants: int = 0,
    days_to_departure: int = 7,
    trip_nights: int = 2,
    return_trip: bool = True,
    price_sensitivity: str = "medium",
    load_factor: float | None = None,
    delay_minutes: int = 0,
    schedule_changed: bool = False,
    queue_long: bool = False,
    events: Iterable[str] = (),
    held_count: int = 0,
    declined_count: int = 0,
    dial: float = 0.45,
) -> tuple[np.ndarray, np.ndarray]:
    """Return (token_ids [SEQ_LEN], numeric [N_NUMERIC]) as float32/int64 arrays."""
    moment_n = normalize_moment(moment)
    event_list = [str(e) for e in events]
    opens = _seat_map_opens(event_list)
    party = max(int(pax or 0), int(adults or 0) + int(children or 0), 1)
    is_family = party >= 3 or int(children or 0) > 0
    fare_u = (fare or "BASIC").upper()
    if fare_u not in FARES:
        fare_u = "BASIC"
    ch = (channel or "WEB").upper()
    if ch not in CHANNELS:
        ch = "WEB"
    sens = (price_sensitivity or "medium").lower()
    if sens not in PRICE_SENS:
        sens = "medium"
    origin_u = (origin or "UNK").upper()
    dest_u = (destination or "UNK").upper()
    delayed = int(delay_minutes or 0) >= 60 or bool(schedule_changed)

    tokens = [
        "CLS",
        f"MOMENT:{moment_n}",
        f"FARE:{fare_u}",
        f"AIRPORT:{origin_u}" if origin_u in AIRPORTS else "UNK",
        f"AIRPORT:{dest_u}" if dest_u in AIRPORTS else "UNK",
        f"SENS:{sens}",
        f"CH:{ch}",
        "FAMILY" if is_family else "SOLO",
        "RETURN" if return_trip else "ONEWAY",
        "DELAY_OPS" if delayed else "NORMAL_OPS",
        "SEAT_INTENT" if opens >= 2 else "NO_SEAT_INTENT",
        "QUEUE_LONG" if queue_long else "QUEUE_OK",
    ]
    token_ids = np.array([_tid(t) for t in tokens], dtype=np.int64)

    lf = 0.7 if load_factor is None else float(load_factor)
    numeric = np.array(
        [
            min(max(int(days_to_departure or 0), 0), 120) / 60.0,
            min(max(int(trip_nights or 0), 0), 21) / 14.0,
            min(party, 8) / 6.0,
            min(max(lf, 0.0), 1.0),
            min(max(int(delay_minutes or 0), 0), 240) / 180.0,
            min(max(float(dial), 0.0), 1.0),
            min(opens, 6) / 5.0,
            min(int(declined_count or 0), 8) / 5.0,
            min(int(held_count or 0), 10) / 8.0,
            min(int(children or 0) + int(infants or 0), 4) / 3.0,
        ],
        dtype=np.float32,
    )
    return token_ids, numeric


def encode_from_mapping(payload: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    journey = payload.get("journey") or {}
    events = payload.get("events") or payload.get("event_stream") or []
    event_names: list[str] = []
    for e in events:
        if isinstance(e, dict):
            event_names.append(str(e.get("e") or e.get("event") or ""))
        else:
            event_names.append(str(e))
    held = payload.get("held_products") or []
    declined = payload.get("declined_products") or []
    return encode_context(
        moment=str(payload.get("moment") or "SEARCH_RESULTS"),
        channel=str(payload.get("channel") or "WEB"),
        origin=str(journey.get("origin") or "LTN"),
        destination=str(journey.get("destination") or "BUD"),
        fare=str(journey.get("fare") or "BASIC"),
        pax=int(journey.get("pax") or 1),
        adults=int(journey.get("adults") or 1),
        children=int(journey.get("children") or 0),
        infants=int(journey.get("infants") or 0),
        days_to_departure=int(journey.get("days_to_departure") or 7),
        trip_nights=int(journey.get("trip_nights") or 2),
        return_trip=bool(journey.get("return_trip", True)),
        price_sensitivity=str(journey.get("price_sensitivity") or "medium"),
        load_factor=journey.get("load_factor"),
        delay_minutes=int(journey.get("delay_minutes") or 0),
        schedule_changed=bool(journey.get("schedule_changed") or False),
        queue_long=bool(journey.get("queue_long") or False),
        events=event_names,
        held_count=len(held),
        declined_count=len(declined),
        dial=float(payload.get("revenue_fit_dial") if payload.get("revenue_fit_dial") is not None else 0.45),
    )


def explain_product(code: str, score: float, moment: str) -> str:
    hint = REASON_HINTS.get(code, "ancillary propensity from trip context")
    return f"transformer · {normalize_moment(moment)} · {hint} (p={score:.2f})"
