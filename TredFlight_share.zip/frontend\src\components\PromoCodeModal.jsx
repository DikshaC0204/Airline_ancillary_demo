import React from 'react';

const PromoCodeModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-center items-center bg-black/40 backdrop-blur-[2px] p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="promo-modal-title"
      >
        <div className="flex justify-between items-center mb-4">
          <h3 id="promo-modal-title" className="text-xl font-bold text-gray-800">
            Promo Code
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-500 text-2xl leading-none hover:text-gray-800 cursor-pointer"
            aria-label="Close"
          >
            &times;
          </button>
        </div>
        <p className="text-sm text-gray-600 mb-4">
          Enter a promo code. After validation you return to search.
        </p>
        <input
          type="text"
          placeholder="Promo code"
          className="border border-gray-300 rounded-md p-3 w-full mb-4 focus:outline-none focus:ring-2 focus:ring-brand-coral/30 focus:border-brand-coral"
        />
        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 rounded-md font-semibold text-gray-700 bg-gray-200 hover:bg-gray-300 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 rounded-md font-bold text-white bg-brand-coral hover:brightness-95 cursor-pointer"
          >
            Validate
          </button>
        </div>
      </div>
    </div>
  );
};

export default PromoCodeModal;
