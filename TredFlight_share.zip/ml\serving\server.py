"""Scoring container for Databricks Model Serving / any container host.

Compatible with:
  GET  /ping
  POST /invocations   Databricks envelope (dataframe_records | instances)
  POST /predict       Direct JSON body (same as TredFlight /curate context)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

ROOT = Path(__file__).resolve().parent
for candidate in (ROOT, ROOT.parent.parent / "backend"):
    resolved = candidate.resolve()
    if (resolved / "app" / "ml").exists() and str(resolved) not in sys.path:
        sys.path.insert(0, str(resolved))

from app.ml.infer import score_payload  # noqa: E402

app = FastAPI(title="TredFlight ancillary scorer", version="1.0.0")
WEIGHTS = os.getenv("ANCILLARY_WEIGHTS_PATH", "")


def _score(record: dict[str, Any]) -> dict[str, Any]:
    try:
        return score_payload(record, weights_path=WEIGHTS or None)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"score failed: {exc}") from exc


@app.get("/ping")
@app.get("/health")
def ping() -> dict[str, str]:
    return {"status": "ok", "model": "ancillary-transformer"}


@app.post("/predict")
def predict(body: dict[str, Any]) -> dict[str, Any]:
    return _score(body)


@app.post("/invocations")
def invocations(body: dict[str, Any]) -> JSONResponse:
    records: list[dict[str, Any]]
    if isinstance(body.get("dataframe_records"), list):
        records = body["dataframe_records"]
    elif isinstance(body.get("instances"), list):
        records = body["instances"]
    elif isinstance(body.get("inputs"), list):
        records = body["inputs"]
    else:
        records = [body]
    if not records:
        raise HTTPException(status_code=400, detail="empty payload")
    scored = [_score(r) for r in records]
    first = scored[0]
    return JSONResponse(
        {
            "predictions": [row["scores"] for row in scored],
            "scores": first["scores"],
            "reasons": first["reasons"],
            "source": "transformer-serving",
        }
    )
