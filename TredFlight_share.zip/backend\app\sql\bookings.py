"""SQLAlchemy text() statements for bookings."""

from sqlalchemy import text

INSERT_BOOKING = text(
    """
    INSERT INTO bookings (
        pnr, passenger_ref, status, trip_type,
        origin, destination, outbound_flight_id, return_flight_id,
        fare_code, party, passengers, selected_products, extras,
        total_amount, currency, promo_code
    )
    VALUES (
        :pnr, :passenger_ref, :status, :trip_type,
        :origin, :destination, :outbound_flight_id, :return_flight_id,
        :fare_code, CAST(:party AS jsonb), CAST(:passengers AS jsonb),
        CAST(:selected_products AS jsonb), CAST(:extras AS jsonb),
        :total_amount, :currency, :promo_code
    )
    RETURNING id
    """
)

GET_BOOKING_BY_PNR = text(
    """
    SELECT
        id, pnr, passenger_ref, status, trip_type,
        origin, destination, outbound_flight_id, return_flight_id,
        fare_code, party, passengers, selected_products, extras,
        total_amount, currency, promo_code, created_at, confirmed_at
    FROM bookings
    WHERE pnr = :pnr
    """
)

GET_BOOKING_BY_ID = text(
    """
    SELECT
        id, pnr, passenger_ref, status, trip_type,
        origin, destination, outbound_flight_id, return_flight_id,
        fare_code, party, passengers, selected_products, extras,
        total_amount, currency, promo_code, created_at, confirmed_at
    FROM bookings
    WHERE id = :booking_id
    """
)

UPDATE_BOOKING = text(
    """
    UPDATE bookings
    SET
        passengers = CAST(:passengers AS jsonb),
        fare_code = :fare_code,
        selected_products = CAST(:selected_products AS jsonb),
        extras = CAST(:extras AS jsonb),
        status = :status,
        confirmed_at = :confirmed_at,
        total_amount = :total_amount
    WHERE pnr = :pnr
    """
)
