import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import BookingSummarySidebar from '../components/BookingSummarySidebar';
import CurationPanel from '../components/CurationPanel';
import { FieldError, FormErrorBanner } from '../components/FieldError';
import { useBooking } from '../context/BookingContext';
import { daysUntil, tripNights } from '../api/client';

const PassengersPage = () => {
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');

  const handlePassengerInput = (e, index) => {
    const { name, value } = e.target;
    const updated = [...(booking.passengers || [])];
    const keyMap = {
      firstName: 'first_name',
      lastName: 'last_name',
      email: 'email',
      age: 'age',
    };
    const key = keyMap[name] || name;
    updated[index] = { ...updated[index], [key]: value };
    setBooking((prev) => ({ ...prev, passengers: updated }));
    setErrors((prev) => {
      const next = { ...prev };
      delete next[`${index}.${key}`];
      return next;
    });
    setFormError('');
  };

  const validate = () => {
    const next = {};
    const list = booking.passengers || [];
    if (list.length === 0) {
      setFormError('At least one passenger is required.');
      setErrors({});
      return false;
    }
    list.forEach((p, index) => {
      if (!String(p.first_name || '').trim()) {
        next[`${index}.first_name`] = 'First name is required';
      }
      if (!String(p.last_name || '').trim()) {
        next[`${index}.last_name`] = 'Last name is required';
      }
      const email = String(p.email || '').trim();
      if (!email) {
        next[`${index}.email`] = 'Email is required';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        next[`${index}.email`] = 'Please enter a valid email';
      }
      const ageRaw = String(p.age ?? '').trim();
      if (!ageRaw) {
        next[`${index}.age`] = 'Age is required';
      } else {
        const age = Number(ageRaw);
        if (!Number.isFinite(age) || age < 0 || age > 120) {
          next[`${index}.age`] = 'Please enter a valid age';
        }
      }
    });
    setErrors(next);
    if (Object.keys(next).length) {
      setFormError('Please enter all passenger details to continue.');
      return false;
    }
    setFormError('');
    return true;
  };

  const handleContinue = () => {
    if (!validate()) return;
    navigate('/seats');
  };

  const journey = {
    origin: booking.origin,
    destination: booking.destination,
    pax: (booking.party?.adults || 1) + (booking.party?.children || 0),
    adults: booking.party?.adults || 1,
    children: booking.party?.children || 0,
    fare: booking.fareCode || 'BASIC',
    days_to_departure: daysUntil(booking.outboundFlight?.depart_at || booking.departDate),
    trip_nights: tripNights(
      booking.outboundFlight?.depart_at || booking.departDate,
      booking.returnFlight?.depart_at || booking.returnDate,
      booking.tripType
    ),
    return_trip: booking.tripType !== 'oneway',
    price_sensitivity: booking.fareCode === 'BASIC' ? 'high' : 'medium',
    load_factor: booking.outboundFlight?.load_factor,
  };

  const passengerEmails = (booking.passengers || [])
    .map((p) => String(p.email || '').trim())
    .filter(Boolean);

  const inventoryMap = {};
  (booking.outboundFlight?.inventory || []).forEach((i) => {
    inventoryMap[i.product_code] = i.remaining;
  });

  const partySize =
    (booking.party?.adults || 1) + (booking.party?.children || 0);
  const isFamily = (booking.party?.children || 0) > 0 || partySize >= 3;
  const offerMoment = isFamily ? 'FARE_COMPARISON' : 'SEARCH_RESULTS';

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-screen-xl mx-auto p-4 lg:p-8 flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-[280px] flex-shrink-0">
          <div className="sticky top-6">
            <BookingSummarySidebar booking={booking} currentStep="passengers" />
          </div>
        </aside>

        <main className="flex-grow space-y-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-black text-brand-navy mb-1">PASSENGER DETAILS</h3>
            <p className="text-sm text-gray-500 mb-4">Fields marked with * are required.</p>
            {(booking.passengers || []).map((p, index) => (
              <div key={index} className="mb-6 last:mb-0">
                <div className="text-xs font-bold text-gray-500 mb-2 uppercase">
                  Passenger {index + 1}
                  {p.type ? ` · ${p.type}` : ''}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">
                      First name *
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      placeholder="First name"
                      value={p.first_name || ''}
                      onChange={(e) => handlePassengerInput(e, index)}
                      className={`border rounded-md p-3 w-full ${
                        errors[`${index}.first_name`]
                          ? 'border-red-500 ring-1 ring-red-500'
                          : 'border-gray-300'
                      }`}
                      aria-required="true"
                      aria-invalid={Boolean(errors[`${index}.first_name`])}
                    />
                    <FieldError message={errors[`${index}.first_name`]} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">
                      Last name *
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      placeholder="Last name"
                      value={p.last_name || ''}
                      onChange={(e) => handlePassengerInput(e, index)}
                      className={`border rounded-md p-3 w-full ${
                        errors[`${index}.last_name`]
                          ? 'border-red-500 ring-1 ring-red-500'
                          : 'border-gray-300'
                      }`}
                      aria-required="true"
                      aria-invalid={Boolean(errors[`${index}.last_name`])}
                    />
                    <FieldError message={errors[`${index}.last_name`]} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      placeholder="name@example.com"
                      value={p.email || ''}
                      onChange={(e) => handlePassengerInput(e, index)}
                      className={`border rounded-md p-3 w-full ${
                        errors[`${index}.email`]
                          ? 'border-red-500 ring-1 ring-red-500'
                          : 'border-gray-300'
                      }`}
                      aria-required="true"
                      aria-invalid={Boolean(errors[`${index}.email`])}
                    />
                    <FieldError message={errors[`${index}.email`]} />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 mb-1">
                      Age *
                    </label>
                    <input
                      type="number"
                      name="age"
                      placeholder="Age"
                      min="0"
                      max="120"
                      value={p.age ?? ''}
                      onChange={(e) => handlePassengerInput(e, index)}
                      className={`border rounded-md p-3 w-full ${
                        errors[`${index}.age`]
                          ? 'border-red-500 ring-1 ring-red-500'
                          : 'border-gray-300'
                      }`}
                      aria-required="true"
                      aria-invalid={Boolean(errors[`${index}.age`])}
                    />
                    <FieldError message={errors[`${index}.age`]} />
                  </div>
                </div>
              </div>
            ))}
            <FormErrorBanner message={formError} />
          </div>

          <CurationPanel
            moment={offerMoment}
            heading="Get Offers"
            title={
              isFamily
                ? `Family offers for ${partySize} travellers`
                : 'Bags, boarding & check-in offers'
            }
            autoFetch={false}
            journey={journey}
            heldProducts={booking.heldProducts}
            eventStream={booking.eventStream}
            declinedProducts={booking.declinedProducts}
            inventory={inventoryMap}
            passengerRef={booking.passenger_ref}
            email={passengerEmails[0] || ''}
            emails={passengerEmails}
            onAccept={(item) =>
              setBooking((prev) => ({
                ...prev,
                selectedProducts: [...new Set([...(prev.selectedProducts || []), item.product])],
                heldProducts: [...new Set([...(prev.heldProducts || []), item.product])],
                productPrices: { ...(prev.productPrices || {}), [item.product]: item.price },
              }))
            }
            onDecline={(item) =>
              setBooking((prev) => ({
                ...prev,
                declinedProducts: [...new Set([...(prev.declinedProducts || []), item.product])],
              }))
            }
          />

          <button
            type="button"
            onClick={handleContinue}
            className="w-full bg-brand-coral text-white font-bold text-lg py-3 rounded-md"
          >
            Continue to Seats
          </button>
        </main>
      </div>
    </div>
  );
};

export default PassengersPage;
