import React, { useState } from 'react';

const BundleCard = ({ title, features, price, isSelected, onSelect }) => (
  <div
    role="button"
    tabIndex={0}
    onClick={onSelect}
    onKeyDown={(e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onSelect?.();
      }
    }}
    className={`border rounded-lg p-4 flex flex-col justify-between transition-all h-full cursor-pointer hover:border-brand-navy/60 ${
      isSelected ? 'border-brand-navy ring-2 ring-brand-navy' : 'border-gray-200'
    }`}
  >
    <div>
      <h4 className="font-black text-lg text-brand-navy">{title}</h4>
      <ul className="mt-3 space-y-2 text-xs text-gray-600">
        {features.map((f) => (
          <li key={f}>{f}</li>
        ))}
      </ul>
    </div>
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onSelect?.();
      }}
      className="mt-4 w-full py-2 font-bold rounded-md bg-brand-navy text-white hover:opacity-90 cursor-pointer"
    >
      +${price.toFixed(2)}
    </button>
  </div>
);

const formatTime = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

const formatDate = (iso) => {
  if (!iso) return '';
  return new Date(iso).toLocaleDateString(undefined, {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
};

const BUNDLE_FEATURES = {
  SMART: [
    '✓ Cabin bag under the seat',
    '✓ Choose a standard seat',
    '✓ Priority boarding',
  ],
  GO: [
    '✓ 20 kg checked bag',
    '✓ Standard seat included',
    '✓ Online check-in included',
  ],
  PLUS: [
    '✓ 32 kg checked bag',
    '✓ Extra-legroom / front seat',
    '✓ Flexible changes (Travel Flex)',
    '✓ Priority boarding',
  ],
  BASIC: ['✓ Cabin bag under the seat'],
};

const FEATURE_LABELS = {
  UNDERSEAT_BAG: 'Cabin bag under the seat',
  BASIC_FARE: 'Basic fare',
  PRIORITY: 'Priority boarding',
  SEAT_STANDARD: 'Standard seat included',
  SEAT_PREMIUM: 'Extra-legroom / front seat',
  BAG_20KG: '20 kg checked bag',
  BAG_32KG: '32 kg checked bag',
  FLEX: 'Flexible changes (Travel Flex)',
  AUTO_CHECKIN: 'Online check-in included',
  SITTING_TOGETHER: 'Sitting together',
};

const friendlyFeatures = (code, includes) => {
  if (BUNDLE_FEATURES[code]) return BUNDLE_FEATURES[code];
  return (includes || []).slice(0, 4).map((x) => {
    const key = String(x).toUpperCase();
    const label = FEATURE_LABELS[key] || key.replace(/_/g, ' ').toLowerCase();
    return `✓ ${label}`;
  });
};

const DEFAULT_BUNDLES = [
  {
    code: 'SMART',
    name: 'Smart',
    price: 18,
    features: BUNDLE_FEATURES.SMART,
  },
  {
    code: 'GO',
    name: 'Go',
    price: 36.3,
    features: BUNDLE_FEATURES.GO,
  },
  {
    code: 'PLUS',
    name: 'Plus',
    price: 60.45,
    features: BUNDLE_FEATURES.PLUS,
  },
];

const FlightWithOptions = ({ flight, fareBundles, onFlightAndBundleSelect }) => {
  const [showOptions, setShowOptions] = useState(false);
  const [selectedBundle, setSelectedBundle] = useState(null);

  const bundlesFromApi = (fareBundles || [])
    .filter((b) => ['SMART', 'GO', 'PLUS', 'BASIC'].includes(b.code))
    .map((b) => ({
      code: b.code,
      name: b.name,
      price: b.base_price,
      features: friendlyFeatures(b.code, b.includes),
    }));
  const bundles = bundlesFromApi.length > 0 ? bundlesFromApi : DEFAULT_BUNDLES;

  const displayBundles = bundles.filter((b) => b.code !== 'BASIC').slice(0, 3);
  if (displayBundles.length === 0) {
    displayBundles.push(...DEFAULT_BUNDLES);
  }

  const price = flight.base_price ?? flight.price ?? 0;
  const from = flight.origin || flight.from;
  const to = flight.destination || flight.to;
  const time =
    flight.depart_at && flight.arrive_at
      ? `${formatTime(flight.depart_at)} - ${formatTime(flight.arrive_at)}`
      : flight.time;
  const date = flight.depart_at ? formatDate(flight.depart_at) : flight.date;

  const handleSelectFlight = () => {
    const next = !showOptions;
    setShowOptions(next);
    if (next) {
      const basic = { code: 'BASIC', name: 'Basic', price: 0 };
      setSelectedBundle(basic);
      onFlightAndBundleSelect({ ...flight, price, from, to, time, date, bundle: basic });
    }
  };

  const handleSelectBundle = (bundle) => {
    setSelectedBundle(bundle);
    onFlightAndBundleSelect({
      ...flight,
      price,
      from,
      to,
      time,
      date,
      bundle: { name: bundle.name, price: bundle.price, code: bundle.code },
    });
  };

  return (
    <section className="bg-white rounded-lg shadow-md">
      <header className="p-4 border-b flex justify-between items-center">
        <h3 className="font-bold text-lg text-gray-800">
          {from} → {to}
        </h3>
        <span className="text-xs font-mono text-gray-500">{flight.flight_number}</span>
      </header>

      <div className="p-4 space-y-4">
        <div
          className={`border rounded-lg p-4 cursor-pointer flex justify-between items-center transition-all ${
            showOptions ? 'border-brand-coral ring-2 ring-brand-coral' : 'border-gray-300'
          }`}
          onClick={handleSelectFlight}
        >
          <div>
            <div className="font-semibold text-gray-600 text-sm">{date}</div>
            <div className="font-extrabold text-xl text-gray-900">{time}</div>
            {flight.load_factor >= 0.9 && (
              <div className="text-xs text-amber-600 mt-1 font-semibold">
                High load ({Math.round(flight.load_factor * 100)}%)
              </div>
            )}
          </div>
          <div className="font-black text-2xl text-brand-navy">${Number(price).toFixed(2)}</div>
        </div>
      </div>

      {showOptions && (
        <div className="p-4 border-t bg-gray-50 animate-fadeIn">
          <p className="text-sm text-gray-600 mb-3">
            Select a fare bundle (Basic is free — entitlements filter later offers).
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
            {displayBundles.map((b) => (
              <BundleCard
                key={b.code}
                title={b.name}
                features={b.features?.length ? b.features : [`✓ ${b.name} fare`]}
                price={b.price}
                isSelected={selectedBundle?.code === b.code || selectedBundle?.name === b.name}
                onSelect={() => handleSelectBundle(b)}
              />
            ))}
          </div>
        </div>
      )}
    </section>
  );
};

export default FlightWithOptions;
