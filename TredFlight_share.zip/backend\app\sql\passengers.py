"""SQLAlchemy text() statements for passenger profiles."""

from sqlalchemy import text

GET_PASSENGER = text(
    """
    SELECT
        passenger_ref, display_name, cohort,
        fatigue_impressions, fatigue_declines,
        declined_products, event_stream, held_products,
        created_at, updated_at
    FROM passenger_profiles
    WHERE passenger_ref = :passenger_ref
    """
)

INSERT_PASSENGER = text(
    """
    INSERT INTO passenger_profiles (
        passenger_ref, display_name, cohort, held_products
    )
    VALUES (
        :passenger_ref, :display_name, :cohort, CAST(:held_products AS jsonb)
    )
    ON CONFLICT (passenger_ref) DO NOTHING
    """
)

UPDATE_PASSENGER_CURATION = text(
    """
    UPDATE passenger_profiles
    SET
        declined_products = CAST(:declined_products AS jsonb),
        event_stream = CAST(:event_stream AS jsonb),
        fatigue_impressions = :fatigue_impressions,
        updated_at = (NOW() AT TIME ZONE 'UTC')
    WHERE passenger_ref = :passenger_ref
    """
)

UPDATE_PASSENGER_DECLINE = text(
    """
    UPDATE passenger_profiles
    SET
        declined_products = CAST(:declined_products AS jsonb),
        fatigue_declines = :fatigue_declines,
        updated_at = (NOW() AT TIME ZONE 'UTC')
    WHERE passenger_ref = :passenger_ref
    """
)

UPDATE_PASSENGER_HELD = text(
    """
    UPDATE passenger_profiles
    SET
        held_products = CAST(:held_products AS jsonb),
        updated_at = (NOW() AT TIME ZONE 'UTC')
    WHERE passenger_ref = :passenger_ref
    """
)
