import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import CurationPanel from '../components/CurationPanel';
import { FieldError } from '../components/FieldError';
import { useBooking } from '../context/BookingContext';
import { api, daysUntil, tripNights } from '../api/client';

const ManageBookingPage = () => {
  const navigate = useNavigate();
  const { booking, setBooking } = useBooking();
  const [pnrInput, setPnrInput] = useState(booking.pnr || '');
  const [loaded, setLoaded] = useState(null);
  const [message, setMessage] = useState('');
  const [opsDelay, setOpsDelay] = useState(120);
  const [queueLong, setQueueLong] = useState(true);

  const [pnrError, setPnrError] = useState('');

  const active = loaded || (booking.pnr ? booking : null);

  const journey = useMemo(() => {
    const origin = active?.origin || booking.origin;
    const destination = active?.destination || booking.destination;
    const depart = active?.outbound_flight?.depart_at || booking.outboundFlight?.depart_at || booking.departDate;
    const ret =
      active?.return_flight?.depart_at || booking.returnFlight?.depart_at || booking.returnDate;
    const tripType = active?.trip_type || booking.tripType || 'return';
    return {
      origin,
      destination,
      depart,
      pax: (booking.party?.adults || 1) + (booking.party?.children || 0) || 1,
      adults: booking.party?.adults || 1,
      children: booking.party?.children || 0,
      fare: active?.fare_code || booking.fareCode || 'BASIC',
      days_to_departure: daysUntil(depart),
      trip_nights: tripNights(depart, ret, tripType),
      return_trip: tripType !== 'oneway',
      delay_minutes: opsDelay,
      schedule_changed: opsDelay > 0,
      queue_long: queueLong,
    };
  }, [active, booking, opsDelay, queueLong]);

  const load = async () => {
    setMessage('');
    if (!pnrInput.trim()) {
      setPnrError('PNR is required');
      return;
    }
    setPnrError('');
    try {
      const data = await api.getBooking(pnrInput.trim().toUpperCase());
      setLoaded(data);
      setBooking((prev) => ({
        ...prev,
        pnr: data.pnr,
        origin: data.origin,
        destination: data.destination,
        fareCode: data.fare_code,
        selectedProducts: data.selected_products || [],
        extras: data.extras || {},
        passengers: data.passengers || prev.passengers,
        passenger_ref: data.passenger_ref,
        outboundFlight: data.outbound_flight,
        returnFlight: data.return_flight,
        heldProducts: [
          data.fare_code,
          'BASIC_FARE',
          ...(data.selected_products || []),
        ],
      }));
      setMessage(`Loaded ${data.pnr} (${data.status})`);
    } catch (err) {
      setMessage(err.message);
    }
  };

  const doCheckIn = async () => {
    const pnr = pnrInput.trim().toUpperCase() || booking.pnr;
    if (!pnr) {
      setPnrError('PNR is required to check in');
      return;
    }
    setPnrError('');
    try {
      const data = await api.checkIn(pnr);
      setLoaded(data);
      setMessage(`Checked in. Rule: ${data.extras?.check_in_rule || 'ok'}`);
    } catch (err) {
      setMessage(err.message);
    }
  };

  const acceptOfferAndPay = (item) => {
    setBooking((prev) => ({
      ...prev,
      pnr: active?.pnr || prev.pnr,
      selectedProducts: [...new Set([...(prev.selectedProducts || []), item.product])],
      heldProducts: [...new Set([...(prev.heldProducts || []), item.product])],
      productPrices: { ...(prev.productPrices || {}), [item.product]: item.price },
      postBookingPayment: true,
    }));
    navigate('/payment');
  };

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-3xl mx-auto p-4 lg:p-8 space-y-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-black text-brand-navy">Manage booking</h2>
          <p className="text-sm text-gray-600 mt-1">
            Post-booking moments: pre-trip reminder, ops disruption, check-in, airport entry.
          </p>
          <div className="mt-4">
            <label className="block text-xs font-semibold text-gray-600 mb-1">PNR *</label>
            <div className="flex gap-2">
              <input
                className={`border rounded-md p-3 flex-grow font-mono uppercase ${
                  pnrError ? 'border-red-500 ring-1 ring-red-500' : 'border-gray-300'
                }`}
                placeholder="PNR"
                value={pnrInput}
                onChange={(e) => {
                  setPnrInput(e.target.value);
                  setPnrError('');
                }}
                aria-required="true"
              />
              <button
                type="button"
                onClick={load}
                className="bg-brand-navy text-white font-bold px-4 rounded-md"
              >
                Load
              </button>
              <button
                type="button"
                onClick={doCheckIn}
                className="bg-brand-coral text-white font-bold px-4 rounded-md"
              >
                Check in
              </button>
            </div>
            <FieldError message={pnrError} />
          </div>
          {message && (
            <p className={`text-sm mt-3 ${message.includes('404') || message.toLowerCase().includes('not found') ? 'text-red-600' : 'text-gray-700'}`}>
              {message}
            </p>
          )}
          {active && (
            <div className="mt-4 text-sm grid grid-cols-2 gap-2">
              <div>
                <span className="text-gray-500">Route</span>
                <div className="font-bold">
                  {active.origin} → {active.destination}
                </div>
              </div>
              <div>
                <span className="text-gray-500">Status</span>
                <div className="font-bold">{active.status || 'SESSION'}</div>
              </div>
              <div>
                <span className="text-gray-500">Fare</span>
                <div className="font-bold">{active.fare_code || booking.fareCode}</div>
              </div>
              <div>
                <span className="text-gray-500">Products</span>
                <div className="font-mono text-xs">
                  {(active.selected_products || booking.selectedProducts || []).join(', ') || '—'}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white p-4 rounded-lg shadow-md space-y-3">
          <h3 className="font-bold text-brand-navy">Synthetic ops / airport signals</h3>
          <label className="block text-sm">
            Inject delay (minutes): {opsDelay}
            <input
              type="range"
              min="0"
              max="240"
              step="15"
              value={opsDelay}
              onChange={(e) => setOpsDelay(Number(e.target.value))}
              className="w-full accent-brand-coral"
            />
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={queueLong}
              onChange={(e) => setQueueLong(e.target.checked)}
            />
            Long security queue at airport
          </label>
        </div>

        <CurationPanel
          moment="PRE_TRIP_REMINDER"
          heading="Get Offers"
          title="Pre-trip offers"
          journey={journey}
          heldProducts={booking.heldProducts}
          declinedProducts={booking.declinedProducts}
          eventStream={booking.eventStream}
          passengerRef={booking.passenger_ref}
          onAccept={acceptOfferAndPay}
        />

        <CurationPanel
          moment="MANAGE_BOOKING"
          heading="Get Offers"
          title="Manage booking offers"
          journey={journey}
          heldProducts={booking.heldProducts}
          declinedProducts={booking.declinedProducts}
          passengerRef={booking.passenger_ref}
          onAccept={acceptOfferAndPay}
        />

        <CurationPanel
          moment="CHECK_IN"
          heading="Get Offers"
          title="Check-in offers"
          journey={{ ...journey, days_to_departure: 0 }}
          heldProducts={booking.heldProducts}
          declinedProducts={booking.declinedProducts}
          passengerRef={booking.passenger_ref}
          onAccept={acceptOfferAndPay}
        />

        <CurationPanel
          moment="AIRPORT_ENTRY"
          heading="Get Offers"
          title="Airport offers"
          journey={journey}
          heldProducts={
            booking.heldProducts?.includes('PRIORITY')
              ? booking.heldProducts
              : [...(booking.heldProducts || []), 'PRIORITY']
          }
          declinedProducts={booking.declinedProducts}
          passengerRef={booking.passenger_ref}
          onAccept={acceptOfferAndPay}
        />
      </div>
    </div>
  );
};

export default ManageBookingPage;
