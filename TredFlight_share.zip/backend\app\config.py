"""Application settings — Databricks Lakebase PostgreSQL."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from urllib.parse import quote_plus, urlparse, urlunparse
import os
import re

from dotenv import load_dotenv

# Load project-root .env then backend/.env (backend wins on conflicts)
_BACKEND_DIR = Path(__file__).resolve().parent.parent
_ROOT_DIR = _BACKEND_DIR.parent
load_dotenv(_ROOT_DIR / ".env")
load_dotenv(_BACKEND_DIR / ".env", override=True)

LAKEBASE_HOST = "ep-late-art-e3d9qikt.database.westus.azuredatabricks.net"
LAKEBASE_DB = "databricks_postgres"
DEFAULT_SCHEMA = "tredflights"


def _normalize_sqlalchemy_url(url: str) -> str:
    """Ensure SQLAlchemy uses the psycopg3 driver."""
    url = url.strip().strip("'\"")
    url = re.sub(r"^postgres://", "postgresql://", url)
    if url.startswith("postgresql://") and not url.startswith("postgresql+"):
        url = "postgresql+psycopg://" + url[len("postgresql://") :]
    url = re.sub(r"^postgresql\+psycopg2://", "postgresql+psycopg://", url)
    return url


def _build_database_url() -> str:
    explicit = os.getenv("DATABASE_URL", "").strip().strip("'\"")
    if explicit.startswith("postgresql") or explicit.startswith("postgres"):
        return _normalize_sqlalchemy_url(explicit)

    user = os.getenv("DB_USER", "").strip().strip("'\"")
    password = os.getenv("DB_PASSWORD", "").strip().strip("'\"")
    host = os.getenv("DB_HOST", LAKEBASE_HOST).strip().strip("'\"")
    db_name = os.getenv("DB_NAME", LAKEBASE_DB).strip().strip("'\"")
    if user and password:
        return (
            f"postgresql+psycopg://{quote_plus(user)}:{quote_plus(password)}"
            f"@{host}/{db_name}?sslmode=require"
        )

    raise RuntimeError(
        "Database not configured. Set DATABASE_URL or DB_USER + DB_PASSWORD in .env"
    )


class Settings:
    def __init__(self) -> None:
        self.app_name: str = os.getenv("APP_NAME", "TredFlight")
        self.api_prefix: str = os.getenv("API_PREFIX", "/api/v1")
        self.database_url: str = _build_database_url()
        self.db_schema: str = os.getenv("DB_SCHEMA", DEFAULT_SCHEMA).strip() or DEFAULT_SCHEMA
        origins = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
        self.cors_origins: list[str] = [o.strip() for o in origins.split(",") if o.strip()]
        self.revenue_fit_dial: float = float(os.getenv("REVENUE_FIT_DIAL", "0.45"))
        # Lakebase is seeded via init.sql — do not auto-seed on startup
        self.seed_on_startup: bool = os.getenv("SEED_ON_STARTUP", "false").lower() in (
            "1",
            "true",
            "yes",
        )
        # auto: ACE when ACE_ROOT is set, else Databricks serving, else bundled transformer, else rules
        self.curation_scorer: str = os.getenv("CURATION_SCORER", "auto").strip().lower() or "auto"
        self.ace_root: str = os.getenv("ACE_ROOT", "").strip().strip("'\"")
        self.databricks_host: str = os.getenv("DATABRICKS_HOST", "").strip().rstrip("/")
        self.databricks_token: str = (
            os.getenv("DATABRICKS_TOKEN", "").strip() or os.getenv("DATABRICKS_PAT", "").strip()
        )
        serving_url = (
            os.getenv("ANCILLARY_SCORING_URL", "").strip()
            or os.getenv("DATABRICKS_SERVING_URL", "").strip()
        )
        endpoint = os.getenv("DATABRICKS_SERVING_ENDPOINT", "").strip()
        if serving_url:
            self.ancillary_serving_url: str = serving_url
        elif self.databricks_host and endpoint:
            self.ancillary_serving_url = (
                f"{self.databricks_host}/serving-endpoints/{endpoint}/invocations"
            )
        else:
            self.ancillary_serving_url = ""
        # Bound for the single-URL serving client. Ensemble HTTP uses
        # DATABRICKS_WARMUP_TIMEOUT so scale-from-zero replicas can finish waking
        # in the background without blocking Get Offers.
        self.ancillary_scoring_timeout: float = float(os.getenv("ANCILLARY_SCORING_TIMEOUT", "25"))
        self.ancillary_local_fallback: bool = os.getenv("ANCILLARY_LOCAL_FALLBACK", "true").lower() in (
            "1",
            "true",
            "yes",
        )
        # Hit Model Serving on every /curate (and /scorer/probe) so Databricks
        # inference metrics move even when catalogue ranking still uses ACE.
        invoke_flag = os.getenv("DATABRICKS_INVOKE_ON_CURATE", "true").strip().lower()
        self.databricks_invoke_on_curate: bool = invoke_flag in ("1", "true", "yes")
        self.databricks_serving_endpoint: str = os.getenv("DATABRICKS_SERVING_ENDPOINT", "").strip()
        self.databricks_serving_endpoints: str = os.getenv("DATABRICKS_SERVING_ENDPOINTS", "").strip()
        # How long /curate waits for live scores before returning local fallback.
        self.databricks_offer_deadline: float = float(os.getenv("DATABRICKS_OFFER_DEADLINE", "4"))
        # HTTP read timeout for ensemble invokes (background warmup / in-flight).
        self.databricks_warmup_timeout: float = float(os.getenv("DATABRICKS_WARMUP_TIMEOUT", "60"))
        # Ping all endpoints on this interval so scale-to-zero replicas stay up.
        # Set 0 to disable.
        self.databricks_keepalive_seconds: float = float(os.getenv("DATABRICKS_KEEPALIVE_SECONDS", "180"))

    @property
    def safe_database_target(self) -> str:
        parsed = urlparse(self.database_url.replace("postgresql+psycopg://", "postgresql://", 1))
        return urlunparse((parsed.scheme, parsed.hostname or "", parsed.path, "", "", ""))


@lru_cache
def get_settings() -> Settings:
    return Settings()
