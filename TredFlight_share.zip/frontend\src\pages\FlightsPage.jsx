import React, { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import BookingSummarySidebar from '../components/BookingSummarySidebar';
import FlightWithOptions from '../components/FlightWithOptions';
import { FormErrorBanner } from '../components/FieldError';
import { useBooking } from '../context/BookingContext';
import { api } from '../api/client';

const FlightsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { booking, setBooking, pushEvent } = useBooking();
  const [search, setSearch] = useState({ outbound: [], inbound: [], fare_bundles: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectionError, setSelectionError] = useState('');
  const loggedView = useRef(false);

  // Prefer navigation state (just submitted search) over any stale session values
  const nav = location.state || {};
  const origin = (nav.origin || booking.origin || 'GYD').toUpperCase();
  const destination = (nav.destination || booking.destination || 'BUD').toUpperCase();
  const departDate = (nav.departDate ?? booking.departDate) || '';
  const returnDate = (nav.returnDate ?? booking.returnDate) || '';
  const tripType = nav.tripType || booking.tripType || 'return';

  useEffect(() => {
    // Sync nav criteria into booking once when landing from search
    if (nav.origin || nav.destination) {
      setBooking((prev) => ({
        ...prev,
        origin,
        destination,
        departDate,
        returnDate,
        tripType,
        party: nav.party || prev.party,
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    if (!loggedView.current) {
      loggedView.current = true;
      pushEvent('SEARCH_RESULTS_VIEW');
    }

    api
      .searchFlights({
        origin,
        destination,
        depart_date: departDate,
        return_date: returnDate,
        trip_type: tripType,
      })
      .then((data) => {
        if (!cancelled) setSearch(data || { outbound: [], inbound: [], fare_bundles: [] });
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || 'Flight search failed');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [origin, destination, departDate, returnDate, tripType, pushEvent]);

  const handleOutboundSelect = (flightWithBundle) => {
    setSelectionError('');
    const fareCode = flightWithBundle.bundle?.code || 'BASIC';
    setBooking((prev) => ({
      ...prev,
      outboundFlight: flightWithBundle,
      fareCode,
      farePrice: flightWithBundle.bundle?.price || 0,
      heldProducts: [
        ...new Set(
          [fareCode, 'BASIC_FARE', ...(prev.selectedProducts || []).filter((p) => typeof p === 'string')]
        ),
      ],
    }));
  };

  const handleReturnSelect = (flightWithBundle) => {
    setSelectionError('');
    setBooking((prev) => ({ ...prev, returnFlight: flightWithBundle }));
  };

  const handleContinue = () => {
    if (!booking.outboundFlight) {
      setSelectionError('Please select an outbound flight and fare plan.');
      return;
    }
    if (tripType !== 'oneway' && !booking.returnFlight) {
      setSelectionError('Please select a return flight and fare plan.');
      return;
    }
    setSelectionError('');
    navigate('/passengers');
  };

  const outbound = search.outbound || [];
  const inbound = search.inbound || [];
  const showEmpty = !loading && !error && outbound.length === 0;

  return (
    <div className="bg-gray-100 min-h-screen">
      <Header />
      <div className="max-w-screen-xl mx-auto p-4 lg:p-8 flex flex-col lg:flex-row gap-8">
        <aside className="w-full lg:w-[280px] flex-shrink-0">
          <div className="sticky top-6 space-y-4">
            <BookingSummarySidebar
              booking={{ ...booking, origin, destination, tripType }}
              currentStep="flights"
            />
          </div>
        </aside>

        <main className="flex-grow space-y-8">
          <div className="bg-white rounded-lg shadow-sm px-4 py-3 text-sm text-gray-700">
            Searching <span className="font-bold">{origin} → {destination}</span>
            {departDate ? ` · Depart ${departDate}` : ''}
            {tripType !== 'oneway' && returnDate ? ` · Return ${returnDate}` : ''}
            {` · ${(booking.party?.adults || 1) + (booking.party?.children || 0)} passenger(s)`}
          </div>

          {loading && <p className="text-gray-600">Searching flights…</p>}
          {error && (
            <p className="text-red-600 text-sm">
              Could not reach API ({error}). Start the backend on port 8000.
            </p>
          )}

          {showEmpty && (
            <div className="bg-amber-50 border border-amber-200 text-amber-900 rounded-lg p-4 text-sm">
              No flights found for this route. Try another origin/destination or date, then search
              again.
            </div>
          )}

          {!loading && outbound.length > 0 && (
            <h3 className="text-lg font-black text-brand-navy">Outbound flights</h3>
          )}
          {outbound.map((f) => (
            <FlightWithOptions
              key={`out-${f.id}`}
              flight={f}
              fareBundles={search.fare_bundles}
              onFlightAndBundleSelect={handleOutboundSelect}
            />
          ))}

          {tripType !== 'oneway' && inbound.length > 0 && (
            <h3 className="text-lg font-black text-brand-navy">Return flights</h3>
          )}
          {tripType !== 'oneway' &&
            inbound.map((f) => (
              <FlightWithOptions
                key={`ret-${f.id}`}
                flight={f}
                fareBundles={search.fare_bundles}
                onFlightAndBundleSelect={handleReturnSelect}
              />
            ))}

          <FormErrorBanner message={selectionError} />

          <button
            type="button"
            onClick={handleContinue}
            className="w-full bg-brand-coral text-white font-bold text-lg py-3 rounded-md hover:brightness-95 transition-colors"
          >
            Continue to Passengers
          </button>
        </main>
      </div>
    </div>
  );
};

export default FlightsPage;
