"""SQLAlchemy text() statements for curation audit logs."""

from sqlalchemy import text

INSERT_CURATION_LOG = text(
    """
    INSERT INTO curation_logs (
        passenger_ref, moment, channel, request_json, response_json
    )
    VALUES (
        :passenger_ref, :moment, :channel,
        CAST(:request_json AS jsonb), CAST(:response_json AS jsonb)
    )
    RETURNING id
    """
)
