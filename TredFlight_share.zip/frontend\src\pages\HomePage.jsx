import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import BookingWidget from '../components/BookingWidget';
import Footer from '../components/Footer';

const HomePage = () => {
  return (
    <div className="bg-slate-50 min-h-screen flex flex-col">
      <Header />

      <section className="relative flex-1">
        <div
          className="h-[480px] w-full bg-cover bg-center flex flex-col justify-center items-start px-6 md:px-12 pb-8"
          style={{
            backgroundImage:
              "linear-gradient(120deg, rgba(30,58,95,0.75), rgba(30,58,95,0.35)), url('https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=2074&auto=format&fit=crop')",
          }}
        >
          <div className="max-w-xl text-white animate-fadeIn">
            <p className="text-brand-coral font-black text-5xl md:text-6xl tracking-tight mb-8">
              TredAir
            </p>
            <a
              href="#book"
              className="inline-block text-3xl md:text-5xl font-black tracking-wide text-white hover:text-brand-coral transition-colors"
            >
              Book now →
            </a>
          </div>
        </div>

        <div id="book" className="px-4 pt-10 md:pt-14">
          <BookingWidget />
        </div>

        <div className="max-w-5xl mx-auto px-4 pt-16 pb-20">
          <div className="bg-white rounded-lg shadow-md border border-gray-100 px-6 py-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-xl font-black text-brand-navy">Already booked?</h2>
              <p className="text-sm text-gray-600 mt-1">
                Look up your PNR or manage your trip.
              </p>
            </div>
            <Link
              to="/manage"
              className="inline-flex justify-center items-center bg-brand-coral text-white font-bold px-6 py-3 rounded-md hover:brightness-95 transition shrink-0"
            >
              Manage booking
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;
