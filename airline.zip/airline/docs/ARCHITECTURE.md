# Advanced Architecture

## Offline training and artifact build

```text
Simulator
  → event platform and point-in-time materializer
  → passenger feature platform and Digital Twin
  → HDBSCAN cohorts
  → embeddings and FAISS
  → calibrated ancillary propensity models
  → item CF and FP-Growth
  → causal multi-task Journey Transformer
  → hybrid candidate fusion
  → dynamic bundle actions
  → inventory-aware LambdaMART training
  → contextual-bandit logged environment, training and OPE
  → SHAP, replay, trace, RAG and business metrics
```

## Online decision loop

```text
Passenger or operational event
  → current journey state
  → point-in-time features
  → sequence inference
  → eligible single and bundle candidates
  → inventory and suppression constraints
  → LambdaMART scores
  → safe contextual-bandit action
  → response and reward log
  → next redecision
```

## Design principles

1. No future feature can enter an earlier decision.
2. Candidate generation and hard constraints are separate from learned ranking.
3. Singles, bundles and no-offer share one action space.
4. Acceptance, rejection and ignore behavior change later actions.
5. Every policy action has a probability for off-policy evaluation.
6. All model outputs are persisted and visible in the UI.
7. Explanation uses both model attributions and an auditable deterministic trace.
