# Validation Report

The bundled repository was executed end to end in strict preferred-algorithm mode.

## Completed training and build stages

- Synthetic passenger, booking, event, interaction and inventory generation
- Point-in-time feature materialization with late-feature availability indicators
- Passenger Digital Twin and HDBSCAN cohorts
- Passenger/offer embeddings and FAISS retrieval
- Nine calibrated LightGBM ancillary propensity models
- Collaborative filtering and FP-Growth association rules
- Multi-task causal Journey Transformer
- Dynamic singles and bundles
- LightGBM LambdaMART ranking
- Shared LinUCB contextual bandit with no-offer action
- IPS and doubly robust off-policy evaluation
- SHAP explanations
- Inventory allocation, journey replay and decision traces
- Locally trained SentenceTransformer and FAISS RAG index
- Business-value comparison

## Bundled validation scale

| Item | Count |
|---|---:|
| Passengers | 300 |
| Bookings | 556 |
| Decision sessions | 3,698 |
| Sequence training examples | 5,460 |
| Bandit action rows | 25,947 |
| RAG evidence documents | 4,329 |
| Trained propensity models | 9 |

## Selected metrics

| Metric | Result |
|---|---:|
| Journey Transformer next-event accuracy | 0.4934 |
| Journey Transformer response accuracy | 0.8045 |
| Journey Transformer bundle-preference accuracy | 0.6592 |
| LambdaMART NDCG@3 | 0.8799 |
| LambdaMART NDCG@5 | 0.9152 |
| Contextual-bandit doubly robust value | 0.0216 |
| Contextual-bandit effective sample size | 1,323.9 |
| No-offer selection rate | 10.44% |
| Bundle selection rate | 20.71% |

The revenue comparison is generated from the synthetic passenger-response environment and is an illustration, not a forecast for a real airline.

## Code and runtime checks

- `python -m compileall -q airline_demo scripts tests` — passed
- Streamlit application compilation — passed
- FastAPI module compilation — passed
- `python scripts/healthcheck.py` — passed
- `pytest -q` — 11 tests passed
- Delay-triggered live redecision demo — passed
- Grounded passenger-scoped RAG demo — passed

Detailed step timings are stored in `validation_log.json`.
