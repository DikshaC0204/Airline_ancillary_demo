# Business Value

The demo compares a static baseline strategy with AI-personalized decisioning.

Business metrics include:

- Expected revenue per recommendation
- Revenue lift over static baseline
- Bundle attach opportunity
- Conversion estimate
- Offer performance by touchpoint
- Offer performance by cohort
- Inventory-blocked opportunities
