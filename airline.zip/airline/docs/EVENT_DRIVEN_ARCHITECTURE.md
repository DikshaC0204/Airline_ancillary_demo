# Event-Driven Journey and Point-in-Time Features

## Purpose

Airline data does not arrive all at once. Search behavior exists before an order; seat-map behavior appears later; check-in, bags, gate, delay and boarding status appear close to departure. The platform therefore represents the journey as an ordered event stream rather than one static booking row.

## Event flow

```text
search_started
flight_selected
seat_map_opened
offer_impression / clicked / rejected / accepted / ignored
payment_started
confirmation_viewed
checkin_completed
airport_arrival
flight_delayed
gate_changed
boarding_started
passenger_boarded
in_flight_session_started
flight_arrived
```

Every event contains `event_id`, `event_timestamp`, `passenger_id`, `booking_id`, `flight_id`, `journey_stage`, `offer_id`, `outcome`, `decision_id`, `source_system`, and `event_payload`.

## Point-in-time correctness

For a decision at time `T`, the materializer uses only events whose timestamp is less than or equal to `T`. A delay published at 16:05 cannot appear in a 16:00 feature vector. This avoids future-data leakage in both training and replay.

Dynamic features have value and availability columns, for example:

```text
delay_minutes
delay_minutes_available
connection_risk_score
connection_risk_score_available
seat_map_available
lounge_occupancy
checkin_completed
boarding_started
offer_fatigue_score
minutes_since_last_offer
```

The registry records the first possible stage, trigger event, source system and time-to-live.

## Re-decision

```text
Event arrives
  → materialize updated snapshot
  → identify current touchpoint and feasible actions
  → update sequence-model state
  → rescore propensities and operational utility
  → regenerate singles and bundles
  → apply inventory and interaction suppression
  → LambdaMART rerank
  → contextual bandit select
  → record action probability and outcome
```

The Streamlit Live Event Lab demonstrates this loop in session state. The batch pipeline creates the corresponding full journey replay and audit artifacts.
