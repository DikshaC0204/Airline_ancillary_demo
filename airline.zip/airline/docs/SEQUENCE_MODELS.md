# Causal Journey Transformer

## Role

Tabular propensity models estimate product-level purchase probability. The causal Journey Transformer models the ordered path that produced the passenger's current state. It captures recency, event order, touchpoint transitions and prior offer responses.

## Tokens and context

Events are tokenized from combinations of event type, touchpoint, offer and response. A causal attention mask prevents the model from reading future events. Training examples are prefixes of each booking journey.

## Multi-task outputs

The model has four heads:

- next-event classification;
- next-response classification;
- bundle-versus-single preference;
- time to next event.

The saved state table contains predictions and a learned sequence-state embedding for every booking and touchpoint. These become inputs to candidate fusion, bundles, LambdaMART and the contextual bandit.

## Online behavior

The deep model is not retrained after every passenger click. A click, rejection or operational event is appended to the sequence; inference runs again and immediately creates a new state. Model retraining can remain daily or weekly while event-time inference is real-time.

## Leakage control

Training prefixes contain only events observed before the target event. The prediction target is the next event or response. Operational fields are introduced only after their source event timestamp.
