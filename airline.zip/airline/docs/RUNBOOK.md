# Runbook

## First run

```bash
pip install -r requirements.txt
python scripts/run_pipeline.py
streamlit run airline_demo/app.py
```

## If dependency check fails

Install the missing package listed in the error. Showcase mode does not silently downgrade algorithms.

## If RAG model download fails

SentenceTransformers loads `sentence-transformers/all-MiniLM-L6-v2`. The first run may need internet access or a pre-cached model.

## Increase training data

```bash
AIRLINE_DEMO_PASSENGERS=5000 python scripts/run_pipeline.py
```
