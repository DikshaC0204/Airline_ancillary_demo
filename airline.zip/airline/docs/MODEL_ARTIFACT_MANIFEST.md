# Model and Artifact Manifest

| Component | Trained/built artifact | Used by |
|---|---|---|
| HDBSCAN | `model_artifacts/cohorts/hdbscan_cohort_model.joblib` | Digital Twin/cohort context |
| Nine calibrated LightGBMs | `model_artifacts/propensity/*_model.joblib` | Candidate propensity |
| Passenger/offer FAISS | `model_artifacts/embeddings/faiss_offer_index.bin` | Offer retrieval |
| Item CF | `data/generated/hybrid_recommender/item_item_similarity.csv` | Candidate generation |
| FP-Growth | `association_rules.csv` | Candidate and bundle generation |
| Causal Journey Transformer | `model_artifacts/sequence_models/causal_journey_transformer.pt` | Sequence state and next behavior |
| Dynamic bundles | `data/generated/bundles/dynamic_bundles.csv` | Action set |
| LambdaMART | `model_artifacts/ranking/lambdamart_ranker.joblib` | Baseline rank |
| Contextual bandit | `model_artifacts/bandits/linucb_policy.joblib` | Final online action |
| SHAP | `data/generated/explainability/top_attributions.csv` | Local explanations |
| RAG encoder/index | `model_artifacts/rag/local_sentence_transformer/`, `faiss_rag_index.bin` | Grounded Copilot |
| Replay/trace | `simulation/journey_replay.csv`, `decision_trace_steps.csv` | UI and audit |
