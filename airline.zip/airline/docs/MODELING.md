# Modeling Details

## Cohorts

HDBSCAN is trained on engineered Digital Twin dimensions.

## Propensity

One LightGBM classifier per ancillary is trained on passenger, booking, route, fare and behavioral features. Probabilities are calibrated with isotonic calibration.

## Retrieval

Passenger and offer embeddings are generated from Digital Twin and offer semantic metadata. FAISS retrieves nearest offers.

## Hybrid recommender

Candidate fusion combines propensity, embedding similarity, FAISS retrieval, collaborative filtering, association rules, journey relevance, business priority and inventory eligibility.

## Ranking

LightGBM `LGBMRanker` with LambdaMART objective ranks single offers and bundles by session/touchpoint query group.

## Explainability

SHAP values are generated for the LambdaMART ranker and sampled propensity models.

## RAG

Evidence documents are built from Digital Twin, ranker outputs, inventory audit, SHAP explanations, decision traces and business metrics. SentenceTransformers embeds the evidence and FAISS retrieves it.
