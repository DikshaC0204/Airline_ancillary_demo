# Safe Contextual Bandit Policy

## Position in the stack

LambdaMART provides a strong supervised baseline rank. The contextual bandit makes the final online action decision across eligible singles, bundles and the no-offer action.

```text
context = passenger + journey sequence + operational event + inventory + fatigue
actions = eligible single offers + eligible bundles + no offer
reward = commercial value + engagement - rejection/fatigue/service penalties
```

## Implementation

The demo trains a shared LinUCB policy using action-dependent features. It estimates expected reward and an uncertainty bonus. Exploration occurs only after eligibility, prior-purchase, rejection and inventory guardrails.

The no-offer action is retained because preserving the passenger experience can be optimal. A guardrail allows it when fatigue is high or all feasible commercial actions are weak; it is not allowed to dominate ordinary sessions.

## Logged-policy contract

Every training decision records:

- full context and action features;
- feasible action set;
- chosen action;
- logging probability;
- outcome and reward;
- policy/model versions;
- inventory state.

The repository calculates inverse propensity scoring and doubly robust off-policy estimates, plus effective sample size. This is essential before comparing or promoting a new policy.

## Production note

The repository has no genuine airline randomized exploration history, so it creates a transparent synthetic logging policy and passenger-response environment. Production training must use real, governed decision logs and conservative rollout controls.
