# Presenter Story: One Passenger, Continuously Changing Decisions

Select a Gold corporate traveler on a long route.

## 1. Search

The system sees repeated route searches, schedule sensitivity and logged-in history. The causal sequence state indicates business urgency. A flexible-fare action ranks ahead of ancillary products.

## 2. Seat selection

The seat map becomes available. Aisle/extra-legroom interest increases comfort intent. Show an extra-legroom single. In the replay, the passenger may reject it; that product is suppressed later.

## 3. Payment

Fare, basket and corporate-payment features become available. Propensity, FAISS, collaborative filtering and association rules generate eligible singles and bundles. LambdaMART ranks them and the bandit chooses one action or no offer.

## 4. Confirmation

The policy sees the earlier rejection/ignore history and fatigue. It can choose no offer rather than repeat an irrelevant product.

## 5. Check-in

Actual aircraft, seat inventory, check-in status and airport products become available. Upgrade, priority and lounge actions are regenerated and reranked.

## 6. Airport disruption

Inject a 105-minute delay in the Live Event Lab. `delay_minutes`, dwell time, connection risk and operational utility become available only now. Lounge, meal and Wi-Fi utility rises; priority urgency can fall. The before/after cards show the resulting rank change.

## 7. Passenger response

Click Accept, Reject or Ignore. Accepted products are added to purchased state; rejected products are suppressed. The next call to the live scorer produces a new action set and policy ranking.

## 8. Explainability

Open Sequence Intelligence, Candidate Fusion, LambdaMART/SHAP and Decision Trace. Then ask the RAG Copilot why the offer changed after the delay and how the prior rejection affected it.

## 9. Value

Close with expected revenue, bundle mix, no-offer preservation, stage-level uplift and off-policy evaluation. Explain that the policy optimizes both commercial outcome and experience rather than maximizing impressions.
