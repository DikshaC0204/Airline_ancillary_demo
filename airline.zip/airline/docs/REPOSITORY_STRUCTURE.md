# Repository Structure

```text
airline_ai_decision_platform_advanced/
├── airline_demo/
│   ├── app.py                         # Guided Streamlit workbench
│   ├── pipeline.py                    # End-to-end pipeline orchestration
│   ├── pipeline_worker.py             # Isolated stage execution
│   ├── config/                        # Catalog, journey and path configuration
│   ├── simulator/                     # Synthetic airline data environment
│   ├── event_platform/                # Events, late features and point-in-time state
│   ├── feature_platform/              # Passenger and booking feature engineering
│   ├── passenger_intelligence/        # HDBSCAN cohorts and Digital Twin enrichment
│   ├── embeddings/                    # Passenger/offer vectors and FAISS
│   ├── ml_platform/                   # Propensity, CF and association rules
│   ├── sequence_models/               # Causal multi-task Journey Transformer
│   ├── recommendation/                # Eligibility, fusion and dynamic bundles
│   ├── inventory/                     # Capacity checks, allocation and consumption
│   ├── ranking/                       # LambdaMART learning-to-rank
│   ├── bandits/                       # LinUCB, logging policy and off-policy evaluation
│   ├── explainability/                # SHAP output generation
│   ├── simulation/                    # Event replay and live scenario rescoring
│   ├── decision_engine/               # Auditable decision traces
│   ├── rag/                           # Locally trained Transformer + FAISS grounding
│   ├── analytics/                     # Business/customer-experience reporting
│   └── serving/                       # FastAPI endpoints
├── scripts/                           # Pipeline, healthcheck and focused demos
├── tests/                             # Artifact, leakage, event, suppression and RAG tests
├── docs/                              # Architecture, modeling, demo and migration guides
├── data/generated/                    # Bundled validation data and decision artifacts
├── model_artifacts/                   # Bundled trained models and vector indexes
├── requirements.txt
├── README.md
├── PREFERRED_ALGORITHMS.md
└── validation_log.json
```
