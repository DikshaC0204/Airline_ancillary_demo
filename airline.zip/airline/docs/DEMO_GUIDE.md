# Demo Guide

1. Run `python scripts/run_pipeline.py`.
2. Launch `streamlit run airline_demo/app.py`.
3. Start in Demo Cockpit.
4. Select a booking and a touchpoint.
5. Walk the audience through the tabs in order.
6. In Touchpoint Journey Simulator, change stages and show how the top recommendation changes.
7. In Inventory Intelligence, show blocked and allocated offers.
8. In SHAP and Decision Trace, show why the decision was made.
9. In RAG Copilot, ask: `Why was this bundle recommended?`.
10. Close with Business Value Dashboard.
