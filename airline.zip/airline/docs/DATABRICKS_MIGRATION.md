# Databricks Migration Blueprint

The local repository is deliberately artifact-oriented so every module has a direct Lakehouse equivalent.

## Data layers

| Local artifact | Databricks target |
|---|---|
| `passengers.csv`, `bookings.csv`, raw events | Bronze Delta tables / Auto Loader |
| point-in-time snapshots | Silver feature tables with event-time joins |
| Digital Twins and cohorts | Gold passenger intelligence tables |
| candidates, bundles and ranked actions | Gold decision tables |
| decision and bandit logs | Append-only Delta decision telemetry |
| RAG evidence | Delta evidence table + Vector Search index |

Suggested tables:

```text
bronze_passenger_events
bronze_offer_interactions
bronze_flight_operations
bronze_inventory_events
silver_journey_state
silver_point_in_time_features
silver_offer_catalog
silver_inventory_snapshots
gold_passenger_digital_twins
gold_sequence_state
gold_candidate_fusion
gold_dynamic_bundles
gold_policy_decisions
gold_decision_traces
gold_rag_evidence
gold_business_metrics
```

## Feature Engineering

Use Databricks Feature Engineering for stable passenger features and event-time journey features. Every dynamic feature must include a timestamp and source. Training sets should use point-in-time lookups so delay, gate and inventory values cannot leak backward.

## Training and registry

Track HDBSCAN, LightGBM propensity models, the PyTorch Journey Transformer, LambdaMART and the contextual-bandit policy in MLflow. Register model signatures, feature schemas, metrics and data versions. Bundle the offer catalog and action-feature schema as versioned model dependencies.

## Streaming re-decision

```text
Kafka/Kinesis/Event Hubs
  → Structured Streaming Bronze events
  → stateful journey feature update
  → online feature table
  → model serving call
  → eligibility/inventory service
  → contextual policy selection
  → append decision log with propensity
```

Operational events that should trigger redecision include delay, cancellation, aircraft swap, gate change, inventory change, check-in, bag drop, boarding and passenger offer response.

## Serving

- Serve the Journey Transformer, propensity models and LambdaMART through Databricks Model Serving or a composite service.
- Keep hard eligibility and inventory constraints in a deterministic decision service.
- Store contextual-bandit action probabilities and policy version for every decision.
- Use online tables or a low-latency store for current journey state and inventory.

## Vector retrieval and RAG

Replace local FAISS indexes with Databricks Vector Search. Write evidence records from Digital Twin, sequence state, candidate fusion, inventory audit, SHAP and decision trace into Delta, then synchronize the index. Answers should retain source identifiers and decision timestamps.

## Policy evaluation and rollout

Use Delta decision logs to calculate IPS, doubly robust estimates, effective sample size, segment coverage and confidence intervals. Promote policies through shadow, canary and constrained exploration stages. Guardrails must remain external to the learned policy.

## Monitoring

Monitor:

- feature freshness and missingness by touchpoint;
- sequence drift and next-event accuracy;
- propensity AUC and calibration;
- NDCG and candidate coverage;
- contextual-bandit reward, regret and exploration coverage;
- no-offer and bundle rates;
- inventory rejection rates;
- customer fatigue and repeated-offer violations;
- revenue, margin and service metrics.
