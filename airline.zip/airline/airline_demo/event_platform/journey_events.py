from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any

import numpy as np
import pandas as pd

from airline_demo.config.settings import ANCILLARIES, DATA_DIR, JOURNEY_STAGES, RANDOM_SEED
from airline_demo.recommendation.eligibility import offer_stage_eligible
from airline_demo.simulator.data_generator import latent_offer_propensity


STAGE_OFFSETS_MINUTES = {
    'search': -60 * 24 * 35,
    'flight_selection': -60 * 24 * 34,
    'seat_selection': -60 * 24 * 30,
    'payment': -60 * 24 * 30 + 35,
    'confirmation': -60 * 24 * 29,
    'checkin': -60 * 20,
    'airport': -150,
    'boarding': -35,
    'in_flight': 45,
    'arrival': 390,
}

BASE_STAGE_EVENTS = {
    'search': 'search_started',
    'flight_selection': 'flight_selected',
    'seat_selection': 'seat_map_opened',
    'payment': 'payment_started',
    'confirmation': 'confirmation_viewed',
    'checkin': 'checkin_completed',
    'airport': 'airport_arrival',
    'boarding': 'boarding_started',
    'in_flight': 'in_flight_session_started',
    'arrival': 'flight_arrived',
}

FEATURE_REGISTRY = [
    ('search_repetition_count', 'search', 'search_started', 86400 * 45, 'digital_analytics'),
    ('schedule_sensitivity', 'search', 'search_started', 86400 * 45, 'digital_analytics'),
    ('nonstop_preference', 'search', 'search_started', 86400 * 45, 'digital_analytics'),
    ('channel', 'search', 'search_started', 86400 * 45, 'digital_analytics'),
    ('selected_fare_family', 'flight_selection', 'flight_selected', 86400 * 90, 'offer_order'),
    ('selected_cabin', 'flight_selection', 'flight_selected', 86400 * 90, 'offer_order'),
    ('number_of_stops', 'flight_selection', 'flight_selected', 86400 * 90, 'offer_order'),
    ('seat_map_available', 'seat_selection', 'seat_map_opened', 600, 'seat_map'),
    ('seat_map_dwell_seconds', 'seat_selection', 'seat_map_opened', 1800, 'digital_analytics'),
    ('seats_viewed_count', 'seat_selection', 'seat_map_opened', 1800, 'digital_analytics'),
    ('aisle_preference', 'seat_selection', 'seat_map_opened', 86400 * 30, 'seat_map'),
    ('adjacent_seat_need', 'seat_selection', 'seat_map_opened', 86400 * 30, 'seat_map'),
    ('basket_value', 'payment', 'payment_started', 3600, 'checkout'),
    ('basket_ancillary_count', 'payment', 'payment_started', 3600, 'checkout'),
    ('corporate_payment', 'payment', 'payment_started', 86400 * 90, 'payment'),
    ('manage_booking_open_count', 'confirmation', 'confirmation_viewed', 86400 * 30, 'digital_analytics'),
    ('checkin_completed', 'checkin', 'checkin_completed', 86400, 'departure_control'),
    ('actual_aircraft_known', 'checkin', 'checkin_completed', 1800, 'departure_control'),
    ('bag_declared', 'checkin', 'checkin_completed', 86400, 'departure_control'),
    ('upgrade_inventory_remaining', 'checkin', 'checkin_completed', 300, 'inventory'),
    ('bag_drop_completed', 'checkin', 'bag_drop_completed', 86400, 'departure_control'),
    ('checked_bag_count', 'checkin', 'bag_drop_completed', 86400, 'departure_control'),
    ('airport_arrival_detected', 'airport', 'airport_arrival', 21600, 'mobile_app'),
    ('security_completed', 'airport', 'security_completed', 21600, 'airport_operations'),
    ('security_wait_minutes', 'airport', 'security_completed', 600, 'airport_operations'),
    ('airport_congestion_score', 'airport', 'airport_arrival', 300, 'airport_operations'),
    ('current_gate', 'airport', 'gate_assigned', 900, 'airport_operations'),
    ('delay_minutes', 'airport', 'flight_delayed', 900, 'flight_operations'),
    ('gate_distance_minutes', 'airport', 'gate_assigned', 900, 'airport_operations'),
    ('connection_risk_score', 'airport', 'flight_delayed', 600, 'operations_analytics'),
    ('lounge_occupancy', 'airport', 'airport_arrival', 300, 'lounge_system'),
    ('boarding_started', 'boarding', 'boarding_started', 3600, 'departure_control'),
    ('boarding_group', 'boarding', 'boarding_started', 3600, 'departure_control'),
    ('passenger_boarded', 'boarding', 'passenger_boarded', 86400, 'departure_control'),
    ('wifi_operational', 'in_flight', 'in_flight_session_started', 600, 'aircraft_connectivity'),
    ('remaining_flight_minutes', 'in_flight', 'in_flight_session_started', 600, 'flight_operations'),
    ('actual_arrival_delay', 'arrival', 'flight_arrived', 86400, 'flight_operations'),
    ('connection_success', 'arrival', 'flight_arrived', 86400, 'flight_operations'),
]


def _event_row(
    event_id: str,
    event_type: str,
    timestamp: datetime,
    booking: pd.Series,
    stage: str,
    payload: dict[str, Any] | None = None,
    offer_id: str = '',
    outcome: str = '',
    decision_id: str = '',
) -> dict[str, Any]:
    payload = payload or {}
    return {
        'event_id': event_id,
        'event_type': event_type,
        'event_timestamp': timestamp.isoformat(),
        'passenger_id': booking.passenger_id,
        'booking_id': booking.booking_id,
        'flight_id': booking.flight_id,
        'journey_stage': stage,
        'offer_id': offer_id,
        'outcome': outcome,
        'decision_id': decision_id,
        'source_system': payload.pop('source_system', 'journey_simulator'),
        'event_payload': json.dumps(payload, sort_keys=True),
    }


def build_event_journeys(seed: int = RANDOM_SEED) -> None:
    """Create a chronological, event-rich passenger journey for every booking.

    The generated stream is point-in-time safe: operational events such as a delay
    only appear at the timestamp at which they become known.
    """
    rng = np.random.default_rng(seed + 101)
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv').set_index('passenger_id')
    rows: list[dict[str, Any]] = []
    interactions: list[dict[str, Any]] = []
    counter = 0

    for _, b in bookings.iterrows():
        p = passengers.loc[b.passenger_id]
        booking_ts = pd.Timestamp(b.booking_timestamp).to_pydatetime()
        departure = booking_ts + timedelta(days=int(b.lead_time_days))
        fatigue = 0
        purchased: set[str] = set()
        rejected: set[str] = set()

        for stage_idx, stage in enumerate(JOURNEY_STAGES):
            ts = departure + timedelta(minutes=STAGE_OFFSETS_MINUTES[stage])
            counter += 1
            base_payload: dict[str, Any] = {
                'stage_index': stage_idx,
                'minutes_to_departure': int((departure - ts).total_seconds() / 60),
                'channel': 'app' if float(p.digital_engagement_score) > 0.62 else 'web',
            }
            if stage == 'search':
                base_payload.update({
                    'search_repetition_count': int(rng.integers(1, 6)),
                    'schedule_sensitivity': round(float(np.clip(0.35 + 0.45 * float(b.business_route_score) + rng.normal(0, .12), 0, 1)), 3),
                    'nonstop_preference': round(float(np.clip(.55 + .30 * float(b.business_route_score), 0, 1)), 3),
                    'channel': base_payload['channel'],
                })
            elif stage == 'flight_selection':
                base_payload.update({'selected_fare_family': b.fare_family, 'selected_cabin': b.cabin, 'number_of_stops': 0})
            elif stage == 'seat_selection':
                base_payload.update({
                    'seat_map_available': 1,
                    'seat_map_dwell_seconds': int(rng.integers(25, 360)),
                    'seats_viewed_count': int(rng.integers(2, 14)),
                    'aisle_preference': int(p.persona in ['Business', 'Premium']),
                    'adjacent_seat_need': int(int(b.party_size) > 1),
                })
            elif stage == 'payment':
                base_payload.update({
                    'basket_value': round(95 + float(b.distance_miles) * .055, 2),
                    'basket_ancillary_count': len(purchased),
                    'corporate_payment': int(bool(p.corporate_flag)),
                })
            elif stage == 'confirmation':
                base_payload.update({'manage_booking_open_count': int(rng.integers(1, 5))})
            elif stage == 'checkin':
                base_payload.update({
                    'checkin_completed': 1,
                    'actual_aircraft_known': 1,
                    'bag_declared': int(p.persona in ['Family', 'Leisure']),
                    'upgrade_inventory_remaining': int(max(0, b.upgrade_inventory)),
                })
            elif stage == 'airport':
                base_payload.update({
                    'airport_arrival_detected': 1,
                    'gate_distance_minutes': int(rng.integers(4, 24)),
                    'lounge_occupancy': round(float(rng.uniform(.20, .88)), 3),
                    'airport_congestion_score': round(float(rng.uniform(.15, .92)), 3),
                })
            elif stage == 'boarding':
                base_payload.update({'boarding_started': 1, 'boarding_group': int(rng.integers(1, 7))})
            elif stage == 'in_flight':
                base_payload.update({'wifi_operational': int(bool(b.wifi_available)), 'remaining_flight_minutes': max(30, int(b.duration_minutes) - 45)})
            elif stage == 'arrival':
                base_payload.update({'actual_arrival_delay': 0, 'connection_success': 1})

            rows.append(_event_row(f'EVT{counter:09d}', BASE_STAGE_EVENTS[stage], ts, b, stage, dict(base_payload)))

            if stage == 'checkin' and int(base_payload.get('bag_declared', 0)) == 1:
                counter += 1
                rows.append(_event_row(
                    f'EVT{counter:09d}', 'bag_drop_completed', ts + timedelta(minutes=12), b, stage,
                    {'bag_drop_completed': 1, 'checked_bag_count': int(rng.integers(1, 3)), 'source_system': 'departure_control'},
                ))

            if stage == 'airport':
                assigned_gate = f"A{int(rng.integers(1, 38))}"
                counter += 1
                rows.append(_event_row(
                    f'EVT{counter:09d}', 'gate_assigned', ts + timedelta(minutes=3), b, stage,
                    {'current_gate': assigned_gate, 'gate_distance_minutes': int(base_payload['gate_distance_minutes']), 'source_system': 'airport_operations'},
                ))
                counter += 1
                rows.append(_event_row(
                    f'EVT{counter:09d}', 'security_completed', ts + timedelta(minutes=10), b, stage,
                    {'security_completed': 1, 'security_wait_minutes': int(rng.integers(5, 48)), 'source_system': 'airport_operations'},
                ))

            # Operational events only become available later in the journey.
            if stage == 'airport' and rng.random() < 0.34:
                delay_minutes = int(rng.choice([30, 45, 60, 90, 105, 120, 180], p=[.12, .14, .18, .19, .13, .16, .08]))
                delay_ts = ts + timedelta(minutes=int(rng.integers(3, 22)))
                counter += 1
                rows.append(_event_row(
                    f'EVT{counter:09d}', 'flight_delayed', delay_ts, b, stage,
                    {
                        'delay_minutes': delay_minutes,
                        'delay_reason': rng.choice(['late_inbound_aircraft', 'weather', 'air_traffic_control', 'crew_rotation']),
                        'estimated_departure': (departure + timedelta(minutes=delay_minutes)).isoformat(),
                        'connection_risk_score': round(float(np.clip(delay_minutes / 210 + rng.normal(0, .06), 0, 1)), 3),
                        'source_system': 'flight_operations',
                    },
                ))
                if rng.random() < 0.28:
                    counter += 1
                    rows.append(_event_row(
                        f'EVT{counter:09d}', 'gate_changed', delay_ts + timedelta(minutes=4), b, stage,
                        {'old_gate': f'A{int(rng.integers(1, 30))}', 'new_gate': f'B{int(rng.integers(1, 40))}', 'current_gate': f'B{int(rng.integers(1, 40))}', 'gate_distance_minutes': int(rng.integers(8, 31)), 'source_system': 'airport_operations'},
                    ))

            # Generate 1–2 realistic offer interactions at stages where offers are valid.
            eligible = [a for a in ANCILLARIES if offer_stage_eligible(a['offer_id'], stage) and a['offer_id'] not in purchased and a['offer_id'] not in rejected]
            if eligible and stage not in ['arrival']:
                scored = []
                for anc in eligible:
                    prob = latent_offer_propensity(
                        str(p.persona), anc['offer_id'], float(p.price_sensitivity), stage,
                        str(b.fare_family), int(b.party_size), str(p.loyalty_tier), float(b.business_route_score),
                    )
                    # Delay-related utility is only applied after the delay event can exist.
                    scored.append((prob, anc))
                scored.sort(key=lambda x: x[0], reverse=True)
                n_show = 1 if fatigue >= 3 or rng.random() < .72 else min(2, len(scored))
                for rank, (prob, anc) in enumerate(scored[:n_show], start=1):
                    decision_id = f'DEC_{b.booking_id}_{stage}_{rank}'
                    show_ts = ts + timedelta(minutes=8 + rank * 2)
                    counter += 1
                    rows.append(_event_row(
                        f'EVT{counter:09d}', 'offer_impression', show_ts, b, stage,
                        {'offer_name': anc['name'], 'price': anc['price'], 'position': rank, 'fatigue_before': fatigue}, anc['offer_id'], '', decision_id,
                    ))
                    fatigue += 1
                    adjusted = float(np.clip(prob - .055 * max(0, fatigue - 2), .01, .95))
                    u = rng.random()
                    if u < adjusted:
                        outcome, event_type = 'accepted', 'offer_accepted'
                        purchased.add(anc['offer_id'])
                    elif u < adjusted + .20:
                        outcome, event_type = 'rejected', 'offer_rejected'
                        rejected.add(anc['offer_id'])
                    elif u < adjusted + .48:
                        outcome, event_type = 'clicked', 'offer_clicked'
                    else:
                        outcome, event_type = 'ignored', 'offer_ignored'
                    response_ts = show_ts + timedelta(minutes=int(rng.integers(1, 8)))
                    counter += 1
                    rows.append(_event_row(
                        f'EVT{counter:09d}', event_type, response_ts, b, stage,
                        {'offer_name': anc['name'], 'price': anc['price'], 'simulated_accept_probability': round(adjusted, 5), 'fatigue_after': fatigue},
                        anc['offer_id'], outcome, decision_id,
                    ))
                    interactions.append({
                        'decision_id': decision_id, 'booking_id': b.booking_id, 'passenger_id': b.passenger_id,
                        'flight_id': b.flight_id, 'journey_stage': stage, 'decision_timestamp': show_ts.isoformat(),
                        'offer_id': anc['offer_id'], 'offer_name': anc['name'], 'price': anc['price'],
                        'position': rank, 'outcome': outcome, 'reward': {'accepted': 1.0 + anc['price'] / 150, 'clicked': .2, 'ignored': -.05, 'rejected': -.4}[outcome],
                        'simulated_accept_probability': adjusted, 'fatigue_before': fatigue - 1,
                    })

            if stage == 'boarding':
                counter += 1
                rows.append(_event_row(f'EVT{counter:09d}', 'passenger_boarded', ts + timedelta(minutes=18), b, stage, {'passenger_boarded': 1, 'source_system': 'departure_control'}))

    events = pd.DataFrame(rows).sort_values(['booking_id', 'event_timestamp', 'event_id']).reset_index(drop=True)
    events['event_sequence_number'] = events.groupby('booking_id').cumcount() + 1
    events.to_csv(DATA_DIR / 'event_platform' / 'journey_event_stream.csv', index=False)
    pd.DataFrame(interactions).to_csv(DATA_DIR / 'event_platform' / 'offer_interaction_log.csv', index=False)
    pd.DataFrame(FEATURE_REGISTRY, columns=['feature_name', 'first_possible_stage', 'trigger_event', 'ttl_seconds', 'source_system']).to_csv(
        DATA_DIR / 'event_platform' / 'feature_availability_registry.csv', index=False
    )
