from __future__ import annotations

import numpy as np
import pandas as pd

from airline_demo.config.settings import DATA_DIR


def enrich_candidate_fusion_with_event_and_sequence_features() -> None:
    candidates = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv')
    stages = pd.read_csv(DATA_DIR / 'event_platform' / 'stage_feature_snapshots.csv')
    seq = pd.read_csv(DATA_DIR / 'sequence_models' / 'sequence_state_features.csv')
    keep_stage = [
        'booking_id', 'journey_stage', 'delay_minutes', 'delay_minutes_available', 'connection_risk_score',
        'connection_risk_score_available', 'gate_distance_minutes', 'lounge_occupancy', 'offer_fatigue_score',
        'offer_seen_count', 'offer_rejected_count', 'offer_accepted_count', 'minutes_to_departure',
        'checkin_completed', 'airport_arrival_detected', 'boarding_started', 'passenger_boarded',
        'security_wait_minutes', 'airport_congestion_score', 'upgrade_inventory_remaining',
        'seat_map_dwell_seconds', 'seats_viewed_count', 'minutes_since_last_offer',
    ]
    keep_stage = [c for c in keep_stage if c in stages.columns]
    context = stages[keep_stage].rename(columns={'journey_stage': 'touchpoint_stage'})
    seq_keep = [
        'booking_id', 'touchpoint_stage', 'sequence_accept_probability', 'sequence_reject_probability',
        'sequence_ignore_probability', 'sequence_bundle_preference', 'predicted_minutes_to_next_event',
        'sequence_state_norm', 'predicted_next_event', 'predicted_next_event_probability',
    ]
    enriched = candidates.merge(context, on=['booking_id', 'touchpoint_stage'], how='left').merge(
        seq[seq_keep], on=['booking_id', 'touchpoint_stage'], how='left'
    )
    numeric_defaults = {
        'delay_minutes': 0.0, 'delay_minutes_available': 0.0, 'connection_risk_score': 0.0,
        'connection_risk_score_available': 0.0, 'gate_distance_minutes': 0.0, 'lounge_occupancy': 0.0,
        'offer_fatigue_score': 0.0, 'offer_seen_count': 0.0, 'offer_rejected_count': 0.0,
        'offer_accepted_count': 0.0, 'minutes_to_departure': 0.0, 'sequence_accept_probability': .15,
        'sequence_reject_probability': .15, 'sequence_ignore_probability': .30, 'sequence_bundle_preference': .30,
        'predicted_minutes_to_next_event': 120.0, 'sequence_state_norm': 1.0,
        'predicted_next_event_probability': 0.0, 'security_wait_minutes': 0.0,
        'airport_congestion_score': 0.0, 'upgrade_inventory_remaining': 0.0,
        'seat_map_dwell_seconds': 0.0, 'seats_viewed_count': 0.0, 'minutes_since_last_offer': 0.0,
    }
    enriched = enriched.fillna(numeric_defaults)
    enriched['airport_dwell_minutes'] = np.where(
        enriched['touchpoint_stage'].isin(['airport', 'boarding']),
        np.maximum(30, -enriched['minutes_to_departure']) + enriched['delay_minutes'].clip(lower=0),
        0.0,
    )
    enriched['operational_utility'] = 0.0
    delay_scale = np.clip(enriched['delay_minutes'] / 180.0, 0, 1)
    congestion_scale = np.clip(enriched['airport_congestion_score'], 0, 1)
    security_scale = np.clip(enriched['security_wait_minutes'] / 60.0, 0, 1)
    gate_scale = np.clip(enriched['gate_distance_minutes'] / 35.0, 0, 1)
    lounge_space = 1 - np.clip(enriched['lounge_occupancy'], 0, 1)
    lounge_mask = enriched.offer_id == 'LOUNGE'
    enriched.loc[lounge_mask, 'operational_utility'] += (
        .42 * delay_scale[lounge_mask] + .12 * congestion_scale[lounge_mask]
        + .10 * lounge_space[lounge_mask] - .08 * gate_scale[lounge_mask]
    )
    enriched.loc[enriched.offer_id == 'MEAL', 'operational_utility'] += .24 * delay_scale[enriched.offer_id == 'MEAL']
    enriched.loc[enriched.offer_id == 'WIFI', 'operational_utility'] += .20 * delay_scale[enriched.offer_id == 'WIFI']
    priority_mask = enriched.offer_id == 'PRIORITY'
    enriched.loc[priority_mask, 'operational_utility'] += (
        -.18 * delay_scale[priority_mask] + .10 * security_scale[priority_mask] + .08 * gate_scale[priority_mask]
    )
    upgrade_mask = enriched.offer_id == 'UPGRADE'
    enriched.loc[upgrade_mask, 'operational_utility'] += .08 * np.clip(enriched.loc[upgrade_mask, 'upgrade_inventory_remaining'] / 8, 0, 1)
    enriched['fatigue_penalty'] = np.clip(enriched['offer_fatigue_score'] * .16, 0, .16)
    enriched['sequence_candidate_score'] = np.clip(
        .65 * enriched['sequence_accept_probability'] + .20 * (1 - enriched['sequence_reject_probability']) + .15 * enriched['predicted_next_event_probability'], 0, 1
    )
    enriched['journey_relevance'] = np.clip(enriched['journey_relevance'] + enriched['operational_utility'] - .05 * enriched['offer_fatigue_score'], 0, 1.35)
    enriched['propensity_score'] = np.clip(
        .72 * enriched['propensity_score'] + .28 * enriched['sequence_candidate_score'] + .12 * enriched['operational_utility'] - enriched['fatigue_penalty'], .005, .98
    )
    enriched['expected_revenue'] = enriched['price'] * enriched['propensity_score'] * enriched['journey_relevance'] * enriched['inventory_score'] * (~enriched['already_purchased'].astype(bool)).astype(int)
    enriched['candidate_fusion_score'] = np.clip(
        .28 * enriched['propensity_score'] + .14 * enriched['embedding_similarity'] + .11 * enriched['cf_score'] +
        .09 * enriched['association_rule_score'] + .10 * np.minimum(enriched['journey_relevance'], 1) +
        .07 * enriched['business_priority'] + .06 * enriched['inventory_score'] + .11 * enriched['sequence_candidate_score'] +
        .08 * enriched['operational_utility'] - .05 * enriched['offer_fatigue_score'], 0, 1.5
    )
    enriched.to_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv', index=False)
