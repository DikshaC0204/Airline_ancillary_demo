from __future__ import annotations

import json
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd

from airline_demo.config.settings import DATA_DIR, JOURNEY_STAGES

DYNAMIC_DEFAULTS: dict[str, Any] = {
    'search_repetition_count': np.nan,
    'schedule_sensitivity': np.nan,
    'nonstop_preference': np.nan,
    'channel': '',
    'selected_fare_family': '',
    'selected_cabin': '',
    'number_of_stops': np.nan,
    'seat_map_available': 0,
    'seat_map_dwell_seconds': np.nan,
    'seats_viewed_count': np.nan,
    'aisle_preference': np.nan,
    'adjacent_seat_need': np.nan,
    'basket_value': np.nan,
    'basket_ancillary_count': np.nan,
    'corporate_payment': np.nan,
    'manage_booking_open_count': np.nan,
    'checkin_completed': 0,
    'actual_aircraft_known': 0,
    'bag_declared': np.nan,
    'bag_drop_completed': 0,
    'checked_bag_count': np.nan,
    'upgrade_inventory_remaining': np.nan,
    'airport_arrival_detected': 0,
    'security_completed': 0,
    'security_wait_minutes': np.nan,
    'airport_congestion_score': np.nan,
    'current_gate': '',
    'delay_minutes': np.nan,
    'delay_reason': '',
    'gate_distance_minutes': np.nan,
    'connection_risk_score': np.nan,
    'lounge_occupancy': np.nan,
    'boarding_started': 0,
    'boarding_group': np.nan,
    'passenger_boarded': 0,
    'wifi_operational': np.nan,
    'remaining_flight_minutes': np.nan,
    'actual_arrival_delay': np.nan,
    'connection_success': np.nan,
    'last_offer_id': '',
    'last_offer_outcome': '',
    'last_offer_price': np.nan,
    'offer_seen_count': 0,
    'offer_rejected_count': 0,
    'offer_accepted_count': 0,
    'offer_ignored_count': 0,
    'offer_clicked_count': 0,
    'minutes_since_last_offer': np.nan,
    'offer_fatigue_score': 0.0,
}


def _available(v: Any) -> int:
    if v is None:
        return 0
    if isinstance(v, float) and np.isnan(v):
        return 0
    if v == '':
        return 0
    return 1


def materialize_point_in_time_features() -> None:
    events = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_event_stream.csv')
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv').set_index('booking_id')
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv').set_index('passenger_id')
    events['event_timestamp'] = pd.to_datetime(events['event_timestamp'])
    snapshots: list[dict[str, Any]] = []

    for booking_id, group in events.sort_values('event_timestamp').groupby('booking_id', sort=False):
        b = bookings.loc[booking_id]
        p = passengers.loc[b.passenger_id]
        state = dict(DYNAMIC_DEFAULTS)
        last_offer_ts: pd.Timestamp | None = None
        previous_stage: str | None = None
        departure = pd.Timestamp(b.booking_timestamp) + pd.Timedelta(days=int(b.lead_time_days))
        for r in group.itertuples():
            # Offer fatigue decays between touchpoints because many stages are hours or days apart.
            # This preserves negative-interaction memory without making every late-stage journey saturated.
            if previous_stage is not None and r.journey_stage != previous_stage:
                state['offer_fatigue_score'] = float(np.clip(state['offer_fatigue_score'] * .68, 0, 1))
            previous_stage = r.journey_stage
            payload = json.loads(r.event_payload) if isinstance(r.event_payload, str) and r.event_payload else {}
            for key, value in payload.items():
                if key in state:
                    state[key] = value
            if r.event_type == 'offer_impression':
                state['offer_seen_count'] += 1
                state['offer_fatigue_score'] += .055
                state['last_offer_id'] = str(r.offer_id or '')
                state['last_offer_price'] = float(payload.get('price', 0) or 0)
                if last_offer_ts is not None:
                    state['minutes_since_last_offer'] = (r.event_timestamp - last_offer_ts).total_seconds() / 60
                last_offer_ts = r.event_timestamp
            elif r.event_type == 'offer_rejected':
                state['offer_rejected_count'] += 1
                state['last_offer_outcome'] = 'rejected'
                state['offer_fatigue_score'] += .15
            elif r.event_type == 'offer_accepted':
                state['offer_accepted_count'] += 1
                state['last_offer_outcome'] = 'accepted'
                state['offer_fatigue_score'] -= .20
            elif r.event_type == 'offer_ignored':
                state['offer_ignored_count'] += 1
                state['last_offer_outcome'] = 'ignored'
                state['offer_fatigue_score'] += .07
            elif r.event_type == 'offer_clicked':
                state['offer_clicked_count'] += 1
                state['last_offer_outcome'] = 'clicked'
                state['offer_fatigue_score'] += .02

            state['offer_fatigue_score'] = float(np.clip(state['offer_fatigue_score'], 0, 1))
            row: dict[str, Any] = {
                'snapshot_id': f"SNAP_{r.event_id}", 'event_id': r.event_id, 'event_type': r.event_type,
                'event_timestamp': r.event_timestamp.isoformat(), 'event_sequence_number': int(r.event_sequence_number),
                'passenger_id': r.passenger_id, 'booking_id': booking_id, 'flight_id': r.flight_id,
                'journey_stage': r.journey_stage, 'offer_id': r.offer_id, 'outcome': r.outcome,
                'minutes_to_departure': (departure - r.event_timestamp).total_seconds() / 60,
                'event_age_seconds': 0.0,
                'loyalty_tier': p.loyalty_tier, 'persona': p.persona, 'price_sensitivity': p.price_sensitivity,
                'corporate_flag': int(bool(p.corporate_flag)), 'digital_engagement_score': p.digital_engagement_score,
                'fare_family': b.fare_family, 'cabin': b.cabin, 'party_size': b.party_size,
                'distance_miles': b.distance_miles, 'business_route_score': b.business_route_score,
            }
            row.update(state)
            for feature_name, value in state.items():
                if feature_name not in ['offer_seen_count', 'offer_rejected_count', 'offer_accepted_count', 'offer_ignored_count', 'offer_clicked_count', 'offer_fatigue_score']:
                    row[f'{feature_name}_available'] = _available(value)
            snapshots.append(row)

    snap = pd.DataFrame(snapshots)
    snap.to_csv(DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv', index=False)

    # Last known snapshot at each touchpoint, used for online scoring and UI comparison.
    # Vectorized sorting/drop-duplicates avoids repeated DataFrame scans per booking/stage.
    stage_snap = (
        snap.sort_values(['booking_id', 'journey_stage', 'event_timestamp', 'event_sequence_number'])
        .drop_duplicates(['booking_id', 'journey_stage'], keep='last')
    )
    stage_snap.to_csv(DATA_DIR / 'event_platform' / 'stage_feature_snapshots.csv', index=False)


def point_in_time_snapshot(booking_id: str, decision_timestamp: str) -> pd.Series:
    """Return the latest snapshot whose event timestamp is not after the decision."""
    snap = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv')
    snap['event_timestamp'] = pd.to_datetime(snap['event_timestamp'])
    ts = pd.Timestamp(decision_timestamp)
    rows = snap[(snap.booking_id == booking_id) & (snap.event_timestamp <= ts)].sort_values('event_timestamp')
    if rows.empty:
        raise KeyError(f'No point-in-time snapshot for booking={booking_id} at {decision_timestamp}')
    return rows.iloc[-1]
