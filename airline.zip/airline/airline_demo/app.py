from __future__ import annotations

import json

import pandas as pd
import plotly.express as px
import streamlit as st

from airline_demo.config.settings import DATA_DIR, JOURNEY_STAGES
from airline_demo.rag.rag_index import answer_question
from airline_demo.inventory.inventory_engine import required_resources
from airline_demo.simulation.journey_replay import score_live_scenario
from airline_demo.theme import PREMIUM_CSS

st.set_page_config(page_title='Airline AI Journey Decision Intelligence', layout='wide', page_icon='✈️')
st.markdown(PREMIUM_CSS, unsafe_allow_html=True)


def path(rel: str):
    return DATA_DIR / rel


@st.cache_data(show_spinner=False)
def csv(rel: str) -> pd.DataFrame:
    return pd.read_csv(path(rel))


def metric_card(label: str, value: str, caption: str = '') -> None:
    st.markdown(f"<div class='metric-card'><div class='cyan'>{label}</div><h2>{value}</h2><div>{caption}</div></div>", unsafe_allow_html=True)


def action_card(row: pd.Series, title: str = 'Selected action') -> None:
    st.markdown(
        f"""
        <div class='offer-card'>
          <div class='cyan'>{title}</div>
          <h3>{row.get('offer_name', row.get('selected_offer', 'No action'))} <span class='badge'>{row.get('candidate_type','')}</span></h3>
          <div class='purple'>{str(row.get('products', row.get('selected_products',''))).replace('|',' + ')}</div>
          <p>Price <span class='gold'>${float(row.get('price',0)):.2f}</span> · Expected revenue <span class='gold'>${float(row.get('expected_revenue',0)):.2f}</span></p>
          <p>Policy value {float(row.get('live_policy_value', row.get('bandit_policy_value',0))):.3f} · Propensity {float(row.get('propensity_score',0)):.1%}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


required = [
    'simulation/journey_replay.csv', 'bandits/bandit_policy_decisions.csv',
    'sequence_models/sequence_state_features.csv', 'ranking/ltr_ranked_candidates.csv',
    'event_platform/journey_feature_snapshots.csv', 'business_metrics/business_value_summary.csv',
]
missing = [r for r in required if not path(r).exists()]
if missing:
    st.error('Pipeline artifacts are missing. Run `python scripts/run_pipeline.py`. Missing: ' + ', '.join(missing))
    st.stop()

replay = csv('simulation/journey_replay.csv')
bookings = csv('bookings.csv')
passengers = csv('passengers.csv')
twins = csv('feature_store/digital_twins.csv')
sequence = csv('sequence_models/sequence_state_features.csv')
policy = csv('bandits/bandit_policy_decisions.csv')
ranked = csv('ranking/ltr_ranked_candidates.csv')

st.title('✈️ Airline AI Journey Decision Intelligence Platform')
st.caption('Event-time features → Digital Twin → Causal Journey Transformer → Hybrid Candidates → Dynamic Singles/Bundles → Inventory → LambdaMART → Safe Contextual Bandit → Outcome Learning')

selector = bookings.merge(passengers[['passenger_id', 'persona', 'loyalty_tier']], on='passenger_id', how='left')
selected_booking = st.selectbox(
    'Select passenger journey', selector.booking_id.tolist(),
    format_func=lambda b: f"{b} · {selector.loc[selector.booking_id == b, 'passenger_id'].iloc[0]} · {selector.loc[selector.booking_id == b, 'persona'].iloc[0]} · {selector.loc[selector.booking_id == b, 'origin'].iloc[0]}→{selector.loc[selector.booking_id == b, 'destination'].iloc[0]}",
)
b = selector[selector.booking_id == selected_booking].iloc[0]
p = passengers[passengers.passenger_id == b.passenger_id].iloc[0]
twin = twins[twins.passenger_id == b.passenger_id].iloc[0]
journey = replay[replay.booking_id == selected_booking].sort_values('stage_order')

c1, c2, c3, c4 = st.columns(4)
with c1: metric_card('Passenger', p.passenger_id, f"{p.persona} · {p.loyalty_tier}")
with c2: metric_card('Route', f"{b.origin} → {b.destination}", f"{b.fare_family} · {b.cabin}")
with c3: metric_card('Cohort', str(twin.get('cohort_label', twin.get('archetype_seed', 'Unknown'))), str(twin.get('dominant_orientation', '')))
with c4:
    accepted = int((journey.outcome == 'accepted').sum())
    metric_card('Journey outcomes', f"{accepted} accepted", f"{int((journey.outcome == 'rejected').sum())} rejected · {int((journey.outcome == 'no_offer').sum())} no-offer")

st.markdown("<div class='timeline'>" + ''.join([f"<span>{s}</span>" for s in JOURNEY_STAGES]) + "</div>", unsafe_allow_html=True)

labels = [
    '1 Journey Command Center', '2 Live Event & Interaction Lab', '3 Feature Evolution',
    '4 Sequence Intelligence', '5 Contextual Bandit', '6 Digital Twin & Cohorts',
    '7 Propensity, Embeddings & Retrieval', '8 Hybrid Candidates & Bundles', '9 Inventory Intelligence',
    '10 LambdaMART & SHAP', '11 Decision Trace', '12 Grounded RAG Copilot',
    '13 Business Value', '14 Architecture & Model Registry',
]
tabs = st.tabs(labels)

with tabs[0]:
    st.subheader('The passenger journey, one decision after another')
    view = journey[['journey_stage', 'trigger_event', 'selected_offer', 'candidate_type', 'price', 'outcome', 'offer_changed', 'expected_revenue', 'fatigue_after']].copy()
    st.dataframe(view, use_container_width=True, hide_index=True)
    if not journey.empty:
        fig = px.line(journey, x='journey_stage', y='expected_revenue', markers=True, hover_data=['selected_offer', 'outcome', 'trigger_event'], title='How the selected action and value evolve across the journey')
        st.plotly_chart(fig, use_container_width=True)
        stage = st.select_slider('Inspect a journey decision', options=journey.journey_stage.tolist(), value=journey.journey_stage.iloc[min(5, len(journey)-1)])
        row = journey[journey.journey_stage == stage].iloc[0]
        left, right = st.columns([1, 1.3])
        with left:
            action_card(pd.Series({'offer_name': row.selected_offer, 'candidate_type': row.candidate_type, 'products': row.selected_products, 'price': row.price, 'expected_revenue': row.expected_revenue, 'bandit_policy_value': row.bandit_policy_value}), 'Final policy action')
            st.markdown(f"**Passenger response:** `{row.outcome}` · reward `{row.reward:.3f}`")
            st.write(row.decision_explanation)
        with right:
            st.markdown('**Features that became available or changed**')
            st.json(json.loads(row.features_new_or_changed))
            st.markdown('**Top three actions considered**')
            st.dataframe(pd.DataFrame(json.loads(row.top_three_actions)), use_container_width=True, hide_index=True)
            suppressed = pd.DataFrame(json.loads(row.suppressed_candidates))
            if not suppressed.empty:
                st.markdown('**Suppressed due to prior interactions**')
                st.dataframe(suppressed, use_container_width=True, hide_index=True)

with tabs[1]:
    st.subheader('Inject an operational event and react to customer behavior in real time')
    lab_stage = st.selectbox('Decision touchpoint', JOURNEY_STAGES, index=JOURNEY_STAGES.index('airport'), key='lab_stage')
    state_key = f'interaction_state_{selected_booking}'
    inventory_table = csv('inventory/inventory_snapshots.csv')
    flight_rows = inventory_table[inventory_table.flight_id == b.flight_id]
    initial_inventory = flight_rows.iloc[0].to_dict() if not flight_rows.empty else {'flight_id': b.flight_id}
    if state_key not in st.session_state:
        st.session_state[state_key] = {'purchased': set(), 'rejected': set(), 'history': [], 'inventory': initial_inventory}
    state = st.session_state[state_key]

    col1, col2, col3 = st.columns(3)
    with col1: delay = st.slider('Flight delay minutes', 0, 240, 105, step=15)
    with col2: lounge_occ = st.slider('Lounge occupancy', 0.0, 1.0, 0.55, step=0.05)
    with col3: fatigue = st.slider('Current offer fatigue', 0.0, 1.0, 0.25, step=0.05)
    col4, col5, col6, col7 = st.columns(4)
    with col4: gate_distance = st.slider('Gate walking time', 2, 40, 12, step=1)
    with col5: security_wait = st.slider('Security wait minutes', 0, 60, 18, step=2)
    with col6: airport_congestion = st.slider('Airport congestion', 0.0, 1.0, 0.45, step=0.05)
    with col7: upgrade_remaining = st.slider('Upgrade inventory', 0, 12, int(state['inventory'].get('upgrade_capacity', 3)), step=1)
    state['inventory']['upgrade_capacity'] = upgrade_remaining
    state['inventory']['upgrade_inventory_remaining'] = upgrade_remaining

    live_args = dict(
        lounge_occupancy=lounge_occ, fatigue_score=fatigue, gate_distance_minutes=gate_distance,
        security_wait_minutes=security_wait, airport_congestion_score=airport_congestion,
        upgrade_inventory_remaining=upgrade_remaining, inventory_state=state['inventory'],
        purchased_products=state['purchased'], rejected_products=state['rejected'],
    )
    before = score_live_scenario(selected_booking, lab_stage, delay_minutes=0, **live_args)
    after = score_live_scenario(selected_booking, lab_stage, delay_minutes=delay, **live_args)
    if after.empty:
        st.warning('No saved candidate set exists for this touchpoint.')
    else:
        bc, ac = st.columns(2)
        with bc:
            st.markdown('#### Before injected event')
            action_card(before.iloc[0], 'Top action before event')
        with ac:
            st.markdown('#### After injected event and redecision')
            action_card(after.iloc[0], 'Top action after event')
        compare = after.head(8)[['live_rank', 'offer_name', 'candidate_type', 'price', 'propensity_score', 'expected_revenue', 'operational_utility', 'live_policy_value', 'live_uncertainty', 'suppression_reason']]
        st.dataframe(compare, use_container_width=True, hide_index=True)
        selected = after.iloc[0]
        products = {x for x in str(selected.products).split('|') if x}
        a, r, i, reset = st.columns(4)
        if a.button('✅ Accept selected action', use_container_width=True):
            state['purchased'] |= products
            consumed = {}
            for resource, amount in required_resources(products).items():
                if isinstance(amount, bool):
                    continue
                before_value = float(state['inventory'].get(resource, 0))
                state['inventory'][resource] = max(0.0, before_value - float(amount))
                consumed[resource] = {'before': before_value, 'after': state['inventory'][resource]}
            state['history'].append({'stage': lab_stage, 'offer': selected.offer_name, 'outcome': 'accepted', 'delay': delay, 'inventory_consumed': consumed})
            st.rerun()
        if r.button('❌ Reject selected action', use_container_width=True):
            state['rejected'] |= products
            state['history'].append({'stage': lab_stage, 'offer': selected.offer_name, 'outcome': 'rejected', 'delay': delay})
            st.rerun()
        if i.button('➖ Ignore selected action', use_container_width=True):
            state['history'].append({'stage': lab_stage, 'offer': selected.offer_name, 'outcome': 'ignored', 'delay': delay})
            st.rerun()
        if reset.button('Reset live journey', use_container_width=True):
            st.session_state[state_key] = {'purchased': set(), 'rejected': set(), 'history': [], 'inventory': initial_inventory}
            st.rerun()
        st.info(f"Purchased: {sorted(state['purchased']) or 'none'} · Rejected/suppressed: {sorted(state['rejected']) or 'none'}")
        live_inventory_fields = ['upgrade_capacity', 'extra_legroom_capacity', 'premium_meal_capacity', 'lounge_capacity', 'priority_capacity', 'cargo_bag_capacity', 'wifi_available']
        st.markdown('#### Live flight inventory after accepted actions')
        st.dataframe(pd.DataFrame([{k: state['inventory'].get(k) for k in live_inventory_fields}]), use_container_width=True, hide_index=True)
        if state['history']:
            st.dataframe(pd.DataFrame(state['history']), use_container_width=True, hide_index=True)

with tabs[2]:
    st.subheader('Point-in-time features: only information known at that moment is used')
    events = csv('event_platform/journey_event_stream.csv')
    ev = events[events.booking_id == selected_booking].copy()
    st.dataframe(ev[['event_sequence_number', 'event_timestamp', 'journey_stage', 'event_type', 'offer_id', 'outcome', 'source_system', 'event_payload']], use_container_width=True, hide_index=True)
    snapshots = csv('event_platform/journey_feature_snapshots.csv')
    ss = snapshots[snapshots.booking_id == selected_booking]
    dynamic_cols = [c for c in [
        'event_timestamp', 'journey_stage', 'event_type', 'search_repetition_count', 'schedule_sensitivity',
        'selected_fare_family', 'seat_map_dwell_seconds', 'seats_viewed_count', 'basket_value',
        'checkin_completed', 'bag_drop_completed', 'upgrade_inventory_remaining', 'security_wait_minutes',
        'airport_congestion_score', 'current_gate', 'delay_minutes', 'delay_minutes_available',
        'gate_distance_minutes', 'connection_risk_score', 'lounge_occupancy', 'offer_seen_count',
        'offer_rejected_count', 'offer_accepted_count', 'last_offer_id', 'last_offer_outcome',
        'offer_fatigue_score', 'minutes_since_last_offer', 'minutes_to_departure'
    ] if c in ss]
    st.markdown('#### Feature snapshot evolution')
    st.dataframe(ss[dynamic_cols], use_container_width=True, hide_index=True)
    st.markdown('#### Feature availability registry')
    st.dataframe(csv('event_platform/feature_availability_registry.csv'), use_container_width=True, hide_index=True)

with tabs[3]:
    st.subheader('Causal Journey Transformer: what happened so far and what is likely next')
    metrics = json.loads(path('sequence_models/sequence_model_metrics.json').read_text())
    m1, m2, m3, m4 = st.columns(4)
    with m1: metric_card('Next-event accuracy', f"{metrics['next_event_accuracy']:.1%}")
    with m2: metric_card('Response accuracy', f"{metrics['next_response_accuracy']:.1%}")
    with m3: metric_card('Bundle preference accuracy', f"{metrics['bundle_preference_accuracy']:.1%}")
    with m4: metric_card('Time-to-next MAE', f"{metrics['time_to_next_event_mae_minutes']:.1f} min")
    seq = sequence[sequence.booking_id == selected_booking].copy()
    st.dataframe(seq[['touchpoint_stage', 'predicted_next_event', 'predicted_next_event_probability', 'sequence_accept_probability', 'sequence_reject_probability', 'sequence_bundle_preference', 'predicted_minutes_to_next_event']], use_container_width=True, hide_index=True)
    fig = px.line(seq, x='touchpoint_stage', y=['sequence_accept_probability', 'sequence_reject_probability', 'sequence_bundle_preference'], markers=True, title='Sequence state changes after every event')
    st.plotly_chart(fig, use_container_width=True)
    st.caption('The model is a trained causal PyTorch Transformer with next-event, response, bundle-preference and time-to-next-event heads. It never reads future events.')

with tabs[4]:
    st.subheader('Safe contextual bandit: exploit, explore, or choose no offer')
    metrics = json.loads(path('bandits/bandit_metrics.json').read_text())
    m1, m2, m3, m4 = st.columns(4)
    with m1: metric_card('Logged mean reward', f"{metrics['logging_policy_mean_reward']:.3f}")
    with m2: metric_card('IPS policy value', f"{metrics['ips_estimated_policy_value']:.3f}")
    with m3: metric_card('Doubly robust value', f"{metrics['doubly_robust_estimated_policy_value']:.3f}")
    with m4: metric_card('Effective sample size', f"{metrics['effective_sample_size']:.0f}", f"{metrics['bundle_selection_rate']:.1%} bundles · {metrics['no_offer_selection_rate']:.1%} no offer")
    bandit_stage = st.selectbox('Inspect action policy at touchpoint', JOURNEY_STAGES, index=JOURNEY_STAGES.index('airport'), key='bandit_stage')
    pg = policy[policy.session_id == f'{selected_booking}__{bandit_stage}'].sort_values('bandit_rank')
    st.dataframe(pg[['bandit_rank', 'offer_name', 'candidate_type', 'rank_position', 'bandit_policy_value', 'bandit_expected_reward', 'bandit_uncertainty', 'exploration_bonus', 'target_policy_probability', 'bandit_selected']], use_container_width=True, hide_index=True)
    st.plotly_chart(px.bar(pg.head(10), x='offer_name', y=['bandit_expected_reward', 'exploration_bonus'], title='Expected reward plus exploration bonus'), use_container_width=True)
    st.markdown('#### Learned policy feature weights')
    st.dataframe(csv('bandits/bandit_feature_weights.csv').head(30), use_container_width=True, hide_index=True)
    st.caption('Exploration happens only inside the eligible, inventory-feasible action set. Already purchased/rejected products are suppressed. “No offer” is a valid action.')

with tabs[5]:
    st.subheader('Passenger Digital Twin and HDBSCAN behavioral cohort')
    dims = ['emb_comfort', 'emb_business', 'emb_family', 'emb_budget', 'emb_premium', 'emb_digital', 'emb_convenience', 'emb_airport', 'emb_inflight']
    td = pd.DataFrame({'dimension': [d.replace('emb_', '').title() for d in dims], 'score': [float(twin.get(d, 0)) for d in dims]})
    st.plotly_chart(px.bar(td, x='dimension', y='score', range_y=[0, 1], title=str(twin.get('digital_twin_summary', 'Digital Twin'))), use_container_width=True)
    cohorts = csv('passenger_intelligence/ml_behavioral_cohorts.csv')
    st.dataframe(cohorts[cohorts.passenger_id == b.passenger_id], use_container_width=True, hide_index=True)
    st.dataframe(csv('passenger_intelligence/ml_cohort_profiles.csv'), use_container_width=True, hide_index=True)

with tabs[6]:
    st.subheader('Propensity models, behavioral embeddings and FAISS retrieval')
    props = csv('model_reports/propensity_scores.csv')
    ps = props[props.booking_id == selected_booking].sort_values('propensity_score', ascending=False)
    st.plotly_chart(px.bar(ps, x='offer_name', y='propensity_score', range_y=[0, 1], title='Calibrated LightGBM ancillary propensities'), use_container_width=True)
    retrieval = csv('retrieval/passenger_offer_retrieval.csv')
    rt = retrieval[retrieval.passenger_id == b.passenger_id].sort_values('retrieval_rank')
    st.dataframe(rt, use_container_width=True, hide_index=True)
    st.dataframe(csv('model_reports/propensity_model_registry.csv'), use_container_width=True, hide_index=True)

with tabs[7]:
    st.subheader('Hybrid candidate fusion and dynamic bundle-versus-single actions')
    stage = st.selectbox('Touchpoint', JOURNEY_STAGES, index=JOURNEY_STAGES.index('airport'), key='fusion_stage')
    fusion = csv('hybrid_recommender/fusion_candidates.csv')
    fg = fusion[fusion.session_id == f'{selected_booking}__{stage}'].sort_values('candidate_fusion_score', ascending=False)
    cols = [c for c in ['offer_name', 'eligible', 'propensity_score', 'embedding_similarity', 'cf_score', 'association_rule_score', 'sequence_candidate_score', 'operational_utility', 'offer_fatigue_score', 'expected_revenue', 'candidate_fusion_score'] if c in fg]
    st.dataframe(fg[cols], use_container_width=True, hide_index=True)
    bundles = csv('bundles/dynamic_bundles.csv')
    bg = bundles[bundles.session_id == f'{selected_booking}__{stage}'].sort_values('candidate_fusion_score', ascending=False)
    st.markdown('#### Dynamically generated bundles')
    st.dataframe(bg, use_container_width=True, hide_index=True)

with tabs[8]:
    st.subheader('Inventory-aware actions and constrained allocation')
    inv = csv('inventory/inventory_snapshots.csv')
    st.dataframe(inv[inv.flight_id == b.flight_id], use_container_width=True, hide_index=True)
    alloc = csv('inventory/flight_inventory_allocation.csv')
    st.dataframe(alloc[alloc.booking_id == selected_booking].sort_values(['session_id', 'final_rank_score'], ascending=[True, False]), use_container_width=True, hide_index=True)
    st.caption('Accepted actions can consume upgrade, extra-legroom, meal, lounge, priority, bag and Wi-Fi resources. Ineligible actions never enter the bandit action set.')

with tabs[9]:
    st.subheader('LambdaMART baseline ranking and SHAP explanation')
    stage = st.selectbox('Ranking touchpoint', JOURNEY_STAGES, index=JOURNEY_STAGES.index('airport'), key='rank_stage')
    rg = ranked[ranked.session_id == f'{selected_booking}__{stage}'].sort_values('rank_position')
    st.dataframe(rg[['rank_position', 'offer_name', 'candidate_type', 'price', 'propensity_score', 'expected_revenue', 'final_rank_score']], use_container_width=True, hide_index=True)
    st.dataframe(csv('ranking/ltr_feature_importance.csv'), use_container_width=True, hide_index=True)
    if not rg.empty:
        shapdf = csv('explainability/top_attributions.csv')
        local = shapdf[shapdf.candidate_id == rg.iloc[0].candidate_id]
        if not local.empty:
            st.plotly_chart(px.bar(local, x='feature', y='contribution', color='direction', title='Local SHAP drivers for the top LambdaMART action'), use_container_width=True)

with tabs[10]:
    st.subheader('Auditable decision trace from event to outcome')
    stage = st.selectbox('Trace touchpoint', JOURNEY_STAGES, index=JOURNEY_STAGES.index('airport'), key='trace_stage')
    traces = csv('decision_trace/decision_trace_steps.csv')
    tg = traces[traces.session_id == f'{selected_booking}__{stage}'].sort_values('step_number')
    st.dataframe(tg[['step_number', 'step_name', 'step_status']], use_container_width=True, hide_index=True)
    for _, row in tg.iterrows():
        with st.expander(f"{int(row.step_number)} · {row.step_name}"):
            st.json(json.loads(row.evidence))

with tabs[11]:
    st.subheader('Grounded RAG Copilot over the model and journey evidence')
    q = st.text_input('Ask about this passenger journey', 'Why did the offer change after the delay, and how did prior rejection affect the next action?')
    if st.button('Ask grounded copilot'):
        with st.spinner('Retrieving sequence, policy, replay, inventory and explanation evidence...'):
            answer = answer_question(q, passenger_id=b.passenger_id)
        st.markdown(answer['answer'])
        st.dataframe(pd.DataFrame(answer['evidence']), use_container_width=True, hide_index=True)

with tabs[12]:
    st.subheader('Business value and customer-experience control')
    summary = csv('business_metrics/business_value_summary.csv')
    cols = st.columns(4)
    for i, row in enumerate(summary.itertuples()):
        with cols[i % 4]: metric_card(str(row.metric), str(row.value))
    by_stage = csv('business_metrics/offer_performance_by_stage.csv')
    st.plotly_chart(px.bar(by_stage, x='touchpoint_stage', y='expected_revenue', hover_data=['no_offer_rate', 'exploration_bonus'], title='Policy value by touchpoint'), use_container_width=True)
    outcomes = csv('business_metrics/journey_outcomes_by_stage.csv')
    st.plotly_chart(px.bar(outcomes, x='journey_stage', y='count', color='outcome', title='Accept, reject, ignore and no-offer outcomes across the journey'), use_container_width=True)

with tabs[13]:
    st.subheader('How the models are stitched together')
    st.code('''
Raw passenger, booking, offer, inventory and event data
  → point-in-time feature materialization
  → passenger features + Digital Twin + HDBSCAN cohort
  → causal Journey Transformer state and next-behavior predictions
  → LightGBM calibrated propensities
  → embeddings + FAISS + collaborative filtering + FP-Growth
  → candidate fusion and dynamic singles/bundles
  → journey eligibility and inventory constraints
  → LambdaMART baseline ranking
  → constrained LinUCB contextual bandit, including no-offer
  → accept/reject/ignore reward logging and suppression
  → event-triggered redecision at the next touchpoint
  → SHAP, decision trace, RAG and business-value reporting
''', language='text')
    registry = pd.DataFrame([
        ['HDBSCAN', 'Behavioral cohorts', 'Weekly/monthly', 'hdbscan_cohort_model.joblib'],
        ['LightGBM + isotonic', 'Per-ancillary purchase propensity', 'Daily/weekly', 'propensity/*.joblib'],
        ['Causal PyTorch Transformer', 'Sequence state, next event, response, time and bundle preference', 'Daily/weekly', 'causal_journey_transformer.pt'],
        ['FAISS', 'Passenger-offer and RAG retrieval', 'Daily', 'faiss indexes'],
        ['Item CF + FP-Growth', 'Co-purchase and association candidates', 'Daily/weekly', 'CSV artifacts'],
        ['LambdaMART', 'Baseline action ranking', 'Daily/weekly', 'lambdamart_ranker.joblib'],
        ['Shared LinUCB', 'Safe online final action selection', 'Online/micro-batch', 'linucb_policy.joblib'],
        ['SHAP', 'Local model explanation', 'Per decision/batch', 'top_attributions.csv'],
    ], columns=['Model', 'Role', 'Update cadence', 'Artifact'])
    st.dataframe(registry, use_container_width=True, hide_index=True)
