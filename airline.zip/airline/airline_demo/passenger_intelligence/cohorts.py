from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from airline_demo.config.settings import DATA_DIR, DIGITAL_TWIN_DIMS, MODEL_DIR, RANDOM_SEED


def _label_cluster(profile: pd.Series) -> str:
    scores = {
        'Corporate Road Warrior': profile.get('emb_business', 0) + 0.4 * profile.get('emb_inflight', 0),
        'Family Vacation Planner': profile.get('emb_family', 0) + 0.2 * profile.get('emb_convenience', 0),
        'Premium Comfort Seeker': profile.get('emb_premium', 0) + 0.4 * profile.get('emb_comfort', 0),
        'Budget Explorer': profile.get('emb_budget', 0),
        'Weekend Leisure Explorer': profile.get('leisure_route_avg', 0) + 0.2 * profile.get('emb_inflight', 0),
    }
    return max(scores, key=scores.get)


def train_hdbscan_cohorts() -> None:
    import hdbscan

    features = pd.read_csv(DATA_DIR / 'feature_store' / 'passenger_features.csv')
    X_raw = features[DIGITAL_TWIN_DIMS].fillna(0).values
    scaler = StandardScaler()
    X = scaler.fit_transform(X_raw)
    min_cluster_size = max(20, min(80, len(features) // 20))
    clusterer = hdbscan.HDBSCAN(min_cluster_size=min_cluster_size, min_samples=max(8, min_cluster_size // 2), prediction_data=True)
    labels = clusterer.fit_predict(X)
    probs = getattr(clusterer, 'probabilities_', np.ones(len(features)))
    outlier = getattr(clusterer, 'outlier_scores_', np.zeros(len(features)))

    cohort = pd.DataFrame({
        'passenger_id': features['passenger_id'],
        'cluster_id': labels,
        'cluster_probability': probs,
        'outlier_score': outlier,
    })
    merged = cohort.merge(features[['passenger_id', 'persona', 'leisure_route_avg'] + DIGITAL_TWIN_DIMS], on='passenger_id', how='left')
    profiles = []
    for cid, g in merged.groupby('cluster_id'):
        if cid == -1:
            label = 'Behavioral Outlier'
        else:
            label = _label_cluster(g.mean(numeric_only=True))
        row = {'cluster_id': int(cid), 'cohort_label': label, 'size': int(len(g)), 'avg_probability': float(g['cluster_probability'].mean())}
        for dim in DIGITAL_TWIN_DIMS:
            row[f'avg_{dim}'] = float(g[dim].mean())
        profiles.append(row)
    profiles = pd.DataFrame(profiles).sort_values('cluster_id')
    label_map = dict(zip(profiles.cluster_id, profiles.cohort_label))
    cohort['cohort_label'] = cohort.cluster_id.map(label_map)

    cohort.to_csv(DATA_DIR / 'passenger_intelligence' / 'ml_behavioral_cohorts.csv', index=False)
    profiles.to_csv(DATA_DIR / 'passenger_intelligence' / 'ml_cohort_profiles.csv', index=False)
    joblib.dump({'clusterer': clusterer, 'scaler': scaler, 'dimensions': DIGITAL_TWIN_DIMS, 'label_map': label_map}, MODEL_DIR / 'cohorts' / 'hdbscan_cohort_model.joblib')

    twins_path = DATA_DIR / 'feature_store' / 'digital_twins.csv'
    twins = pd.read_csv(twins_path)
    twins = twins.merge(cohort[['passenger_id', 'cluster_id', 'cohort_label', 'cluster_probability', 'outlier_score']], on='passenger_id', how='left')
    twins.to_csv(twins_path, index=False)
