from __future__ import annotations

import json
import joblib
import numpy as np
import pandas as pd

from airline_demo.config.settings import DATA_DIR, MODEL_DIR
from airline_demo.ranking.lambdamart import RANK_FEATURES
from airline_demo.ml_platform.propensity import _training_frame, _encode


def _top_contributors(values, feature_names, n=5):
    order = np.argsort(np.abs(values))[::-1][:n]
    return [{'feature': feature_names[i], 'contribution': float(values[i]), 'direction': 'positive' if values[i] >= 0 else 'negative'} for i in order]


def generate_shap_explanations(sample_size: int = 250) -> None:
    import shap

    ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    ranked_sample = ranked.sort_values('rank_position').head(sample_size).copy()
    rank_payload = joblib.load(MODEL_DIR / 'ranking' / 'lambdamart_ranker.joblib')
    ranker = rank_payload['ranker']
    X_rank = ranked_sample[RANK_FEATURES].astype(float).replace([np.inf, -np.inf], 0).fillna(0)
    explainer = shap.TreeExplainer(ranker)
    shap_values = explainer.shap_values(X_rank)
    rank_rows, payloads = [], {}
    for i, (_, r) in enumerate(ranked_sample.iterrows()):
        contribs = _top_contributors(shap_values[i], RANK_FEATURES, 6)
        payloads[r['candidate_id']] = {'candidate_id': r['candidate_id'], 'model': 'LambdaMART ranker', 'top_contributors': contribs}
        for c in contribs:
            rank_rows.append({'model': 'LambdaMART ranker', 'candidate_id': r['candidate_id'], 'session_id': r['session_id'], **c})

    prop_rows = []
    df = _training_frame()
    top_offer_ids = ranked_sample[ranked_sample['candidate_type'] == 'single']['offer_id'].drop_duplicates().head(4).tolist()
    for offer_id in top_offer_ids:
        path = MODEL_DIR / 'propensity' / f'{offer_id}_model.joblib'
        if not path.exists():
            continue
        payload = joblib.load(path)
        sub = df[df.offer_id == offer_id].head(min(80, len(df[df.offer_id == offer_id]))).copy()
        X = _encode(sub, payload['feature_columns'])
        expl = shap.TreeExplainer(payload['base_model'])
        sv = expl.shap_values(X)
        if isinstance(sv, list):
            sv = sv[1]
        for i in range(min(20, len(sub))):
            contribs = _top_contributors(sv[i], payload['feature_columns'], 5)
            cid = f"PROP_{offer_id}_{i}"
            payloads[cid] = {'candidate_id': cid, 'model': f'Propensity {offer_id}', 'top_contributors': contribs}
            for c in contribs:
                prop_rows.append({'model': f'Propensity {offer_id}', 'candidate_id': cid, 'session_id': sub.iloc[i]['session_id'], **c})

    out = pd.DataFrame(rank_rows + prop_rows)
    out.to_csv(DATA_DIR / 'explainability' / 'shap_values.csv', index=False)
    out.to_csv(DATA_DIR / 'explainability' / 'top_attributions.csv', index=False)
    (DATA_DIR / 'explainability' / 'local_explanation_payloads.json').write_text(json.dumps(payloads, indent=2), encoding='utf-8')
