from __future__ import annotations

from datetime import datetime, timedelta
import numpy as np
import pandas as pd

from airline_demo.config.settings import ANCILLARIES, DATA_DIR, DEFAULT_PASSENGERS, JOURNEY_STAGES, RANDOM_SEED
from airline_demo.utils import ensure_dirs

PERSONAS = ['Business', 'Family', 'Leisure', 'Budget', 'Premium', 'Student']
ARCHETYPE = {
    'Business': 'Corporate Road Warrior',
    'Family': 'Family Vacation Planner',
    'Leisure': 'Weekend Leisure Explorer',
    'Budget': 'Budget Explorer',
    'Premium': 'Premium Comfort Seeker',
    'Student': 'Budget Explorer',
}
ROUTES = [
    ('JFK', 'LAX', 2475, 360, 0.94, 0.58, True),
    ('JFK', 'MIA', 1090, 185, 0.55, 0.88, True),
    ('ORD', 'SEA', 1720, 275, 0.72, 0.62, True),
    ('DFW', 'LAS', 1050, 170, 0.48, 0.94, True),
    ('ATL', 'BOS', 945, 150, 0.68, 0.58, True),
    ('SFO', 'JFK', 2586, 370, 0.90, 0.63, True),
    ('LAX', 'HNL', 2556, 350, 0.35, 0.98, False),
]


def _sigmoid(x: float) -> float:
    return float(1.0 / (1.0 + np.exp(-x)))


def latent_offer_propensity(persona: str, offer_id: str, price_sensitivity: float, stage: str, fare: str, party_size: int, loyalty: str, route_business: float) -> float:
    score = -2.25
    if persona == 'Business':
        score += {'LOUNGE': 1.55, 'WIFI': 1.25, 'SEAT_LEG': 1.25, 'PRIORITY': 0.95, 'UPGRADE': 1.35}.get(offer_id, 0.05)
    if persona == 'Family':
        score += {'BAG': 1.55, 'SEAT_STD': 1.10, 'MEAL': 0.95, 'INSURANCE': 0.65}.get(offer_id, 0.0)
    if persona == 'Premium':
        score += {'LOUNGE': 1.45, 'PRIORITY': 1.05, 'UPGRADE': 1.70, 'SEAT_LEG': 1.30, 'WIFI': 0.65}.get(offer_id, 0.0)
    if persona in ['Budget', 'Student']:
        score += {'BAG': 0.65, 'SEAT_STD': 0.55, 'MEAL': 0.25, 'INSURANCE': 0.15}.get(offer_id, -0.15)
    if persona == 'Leisure':
        score += {'BAG': 0.55, 'SEAT_STD': 0.40, 'MEAL': 0.45, 'INSURANCE': 0.45, 'WIFI': 0.25}.get(offer_id, 0.0)
    if offer_id in ['LOUNGE', 'UPGRADE', 'PRIORITY', 'WIFI']:
        score += route_business * 0.55
    if party_size > 2 and offer_id in ['BAG', 'SEAT_STD', 'MEAL']:
        score += 0.55
    if loyalty in ['Gold', 'Platinum'] and offer_id in ['LOUNGE', 'UPGRADE', 'PRIORITY', 'SEAT_LEG']:
        score += 0.55
    if fare in ['Business'] and offer_id in ['UPGRADE', 'LOUNGE']:
        score -= 1.20
    if fare in ['Basic Economy'] and offer_id in ['BAG', 'SEAT_STD']:
        score += 0.40
    if stage in ['checkin', 'airport', 'boarding'] and offer_id in ['LOUNGE', 'PRIORITY', 'WIFI', 'UPGRADE']:
        score += 0.40
    score -= 1.10 * price_sensitivity * (0.8 if offer_id in ['UPGRADE', 'LOUNGE', 'SEAT_LEG'] else 0.5)
    return float(np.clip(_sigmoid(score), 0.01, 0.96))


def generate_data(n_passengers: int | None = None, seed: int = RANDOM_SEED) -> None:
    ensure_dirs()
    if n_passengers is None:
        n_passengers = DEFAULT_PASSENGERS
    rng = np.random.default_rng(seed)
    base_time = datetime(2026, 1, 1, 8, 0, 0)

    passenger_rows = []
    for i in range(n_passengers):
        persona = rng.choice(PERSONAS, p=[0.24, 0.18, 0.25, 0.13, 0.10, 0.10])
        loyalty_probs = {
            'Business': [0.12, 0.25, 0.37, 0.26],
            'Premium': [0.08, 0.20, 0.35, 0.37],
            'Family': [0.45, 0.30, 0.18, 0.07],
            'Leisure': [0.52, 0.27, 0.15, 0.06],
            'Budget': [0.70, 0.20, 0.08, 0.02],
            'Student': [0.78, 0.17, 0.04, 0.01],
        }[persona]
        loyalty = rng.choice(['None', 'Silver', 'Gold', 'Platinum'], p=loyalty_probs)
        price = float(np.clip(rng.normal(0.72 if persona in ['Budget', 'Student'] else 0.34 if persona in ['Business', 'Premium'] else 0.52, 0.15), 0.02, 0.98))
        annual = int(rng.integers(14, 48)) if persona == 'Business' else int(rng.integers(1, 9))
        spend_multiplier = {'Business': 2.0, 'Premium': 2.5, 'Family': 1.2, 'Leisure': 0.9, 'Budget': 0.45, 'Student': 0.30}[persona]
        passenger_rows.append({
            'passenger_id': f'P{i + 1:06d}', 'persona': persona, 'archetype_seed': ARCHETYPE[persona],
            'age': int(rng.integers(18, 75)), 'loyalty_tier': loyalty, 'corporate_flag': bool(persona == 'Business'),
            'price_sensitivity': price, 'annual_trips': annual,
            'historical_ancillary_spend': round(float(rng.gamma(3.0, 75.0) * spend_multiplier), 2),
            'home_airport': rng.choice(['JFK', 'LAX', 'ORD', 'DFW', 'ATL', 'SFO']),
            'digital_engagement_score': round(float(np.clip(rng.normal(0.72 if persona in ['Business', 'Premium', 'Student'] else 0.55, 0.18), 0, 1)), 3),
        })
    passengers = pd.DataFrame(passenger_rows)

    booking_rows = []
    for _, p in passengers.iterrows():
        trips = 3 if p.persona == 'Business' else 2 if p.persona in ['Premium', 'Leisure'] else 1
        for _ in range(trips):
            o, d, miles, duration, bscore, lscore, wifi = ROUTES[int(rng.integers(0, len(ROUTES)))]
            fare_probs = {
                'Business': [0.04, 0.34, 0.27, 0.22, 0.13],
                'Premium': [0.02, 0.28, 0.23, 0.30, 0.17],
                'Family': [0.26, 0.43, 0.20, 0.09, 0.02],
                'Leisure': [0.28, 0.44, 0.18, 0.08, 0.02],
                'Budget': [0.53, 0.36, 0.08, 0.025, 0.005],
                'Student': [0.60, 0.32, 0.06, 0.015, 0.005],
            }[p.persona]
            fare = rng.choice(['Basic Economy', 'Economy', 'Economy Flex', 'Premium Economy', 'Business'], p=fare_probs)
            stage = rng.choice(JOURNEY_STAGES[:-1], p=[0.08, 0.08, 0.14, 0.20, 0.08, 0.16, 0.10, 0.10, 0.06])
            adults = 2 if p.persona == 'Family' else int(rng.choice([1, 2], p=[0.82, 0.18]))
            children = int(rng.integers(1, 4)) if p.persona == 'Family' else 0
            booking_rows.append({
                'booking_id': f'B{len(booking_rows) + 1:07d}',
                'session_id': f'S{len(booking_rows) + 1:07d}',
                'passenger_id': p.passenger_id,
                'flight_id': f'FL_{o}_{d}_{int(rng.integers(1, 10)):02d}',
                'origin': o, 'destination': d, 'distance_miles': miles, 'duration_minutes': duration,
                'business_route_score': bscore, 'leisure_route_score': lscore,
                'fare_family': fare,
                'cabin': 'Business' if fare == 'Business' else 'Premium Economy' if fare == 'Premium Economy' else 'Economy',
                'lead_time_days': int(rng.integers(1, 120)), 'trip_duration_days': int(rng.integers(1, 15)),
                'adults': adults, 'children': children, 'party_size': adults + children,
                'wifi_available': bool(wifi), 'lounge_available': bool(o in ['JFK', 'ORD', 'DFW', 'ATL', 'SFO']),
                'upgrade_inventory': int(rng.integers(0, 8)), 'international': bool(rng.random() < 0.18),
                'journey_stage': stage,
                'booking_timestamp': (base_time + timedelta(minutes=int(rng.integers(0, 250000)))).isoformat(),
            })
    bookings = pd.DataFrame(booking_rows)

    inventory_rows = []
    for flight_id, g in bookings.groupby('flight_id'):
        first = g.iloc[0]
        pax = len(g)
        inventory_rows.append({
            'flight_id': flight_id, 'origin': first.origin, 'destination': first.destination,
            'booked_passengers': int(pax),
            'upgrade_capacity': int(max(0, 3 + rng.integers(0, 8) - pax // 35)),
            'extra_legroom_capacity': int(max(0, 10 + rng.integers(0, 22) - pax // 10)),
            'premium_meal_capacity': int(max(0, 25 + rng.integers(0, 45) - pax // 4)),
            'lounge_capacity': int(max(0, 15 + rng.integers(0, 35) - pax // 5)) if first.origin in ['JFK', 'ORD', 'DFW', 'ATL', 'SFO'] else 0,
            'priority_capacity': int(max(0, 35 + rng.integers(0, 75) - pax // 3)),
            'cargo_bag_capacity': int(max(0, 40 + rng.integers(0, 85) - pax // 2)),
            'wifi_available': bool(first.wifi_available), 'last_updated_event': 'initial_inventory_snapshot',
        })
    inventory = pd.DataFrame(inventory_rows)

    offer_rows, purchase_rows, event_rows = [], [], []
    for _, b in bookings.iterrows():
        p = passengers.loc[passengers.passenger_id == b.passenger_id].iloc[0]
        event_rows.append({
            'event_id': f'EVT{len(event_rows) + 1:08d}', 'booking_id': b.booking_id,
            'flight_id': b.flight_id, 'passenger_id': b.passenger_id, 'event_type': 'stage_entered',
            'journey_stage': b.journey_stage, 'offer_id': '', 'timestamp': b.booking_timestamp,
        })
        basket = []
        for anc in ANCILLARIES:
            propensity = latent_offer_propensity(p.persona, anc['offer_id'], p.price_sensitivity, b.journey_stage, b.fare_family, int(b.party_size), p.loyalty_tier, float(b.business_route_score))
            clicked = bool(rng.random() < min(0.93, propensity + 0.14))
            accepted = bool(clicked and rng.random() < propensity)
            rejected = bool(clicked and not accepted and rng.random() < 0.50)
            ignored = not clicked and not rejected
            ts = base_time + timedelta(minutes=int(rng.integers(0, 250000)))
            offer_rows.append({
                'offer_event_id': f'OFF{len(offer_rows) + 1:08d}', 'booking_id': b.booking_id,
                'session_id': b.session_id, 'flight_id': b.flight_id, 'passenger_id': b.passenger_id,
                'offer_id': anc['offer_id'], 'offer_name': anc['name'], 'journey_stage': b.journey_stage,
                'price': anc['price'], 'clicked': clicked, 'accepted': accepted, 'rejected': rejected,
                'ignored': ignored, 'timestamp': ts.isoformat(),
            })
            if accepted:
                basket.append(anc['offer_id'])
                purchase_rows.append({
                    'purchase_id': f'PUR{len(purchase_rows) + 1:08d}', 'booking_id': b.booking_id,
                    'session_id': b.session_id, 'flight_id': b.flight_id, 'passenger_id': b.passenger_id,
                    'offer_id': anc['offer_id'], 'purchase_amount': anc['price'], 'timestamp': ts.isoformat(),
                })
        if len(basket) >= 2 and rng.random() < 0.18:
            event_rows.append({
                'event_id': f'EVT{len(event_rows) + 1:08d}', 'booking_id': b.booking_id,
                'flight_id': b.flight_id, 'passenger_id': b.passenger_id, 'event_type': 'bundle_like_behavior',
                'journey_stage': b.journey_stage, 'offer_id': '+'.join(sorted(basket[:3])), 'timestamp': b.booking_timestamp,
            })

    outputs = {
        'passengers.csv': passengers, 'bookings.csv': bookings, 'flights.csv': inventory[['flight_id', 'origin', 'destination', 'booked_passengers']].drop_duplicates(),
        'inventory_snapshots_raw.csv': inventory, 'offer_history.csv': pd.DataFrame(offer_rows),
        'purchases.csv': pd.DataFrame(purchase_rows), 'journey_events.csv': pd.DataFrame(event_rows),
        'ancillaries.csv': pd.DataFrame(ANCILLARIES),
    }
    for name, df in outputs.items():
        df.to_csv(DATA_DIR / name, index=False)
