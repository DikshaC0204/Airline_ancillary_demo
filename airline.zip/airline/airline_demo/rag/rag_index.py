from __future__ import annotations

import json
import os
from functools import lru_cache

import numpy as np
import pandas as pd
import torch

from airline_demo.config.settings import DATA_DIR, MODEL_DIR, RANDOM_SEED

LOCAL_MODEL_DIR = MODEL_DIR / 'rag' / 'local_sentence_transformer'


def _doc(doc_id: str, source: str, passenger_id: str, session_id: str, text: str, metadata: dict) -> dict:
    return {'doc_id': doc_id, 'source': source, 'passenger_id': passenger_id, 'session_id': session_id, 'text': text, 'metadata': metadata}


def _build_documents() -> list[dict]:
    """Create compact, information-dense evidence documents.

    One journey decision document combines sequence state, final policy action,
    outcome, event context and inventory/ranking evidence. This keeps the vector
    index useful without creating one document for every intermediate row.
    """
    docs = []
    twins = pd.read_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv')
    policy = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    sequence = pd.read_csv(DATA_DIR / 'sequence_models' / 'sequence_state_features.csv')
    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv')
    shap_df = pd.read_csv(DATA_DIR / 'explainability' / 'top_attributions.csv') if (DATA_DIR / 'explainability' / 'top_attributions.csv').exists() else pd.DataFrame()
    business = pd.read_csv(DATA_DIR / 'business_metrics' / 'business_value_summary.csv')

    for _, r in twins.head(2500).iterrows():
        docs.append(_doc(
            f"DT_{r.passenger_id}", 'digital_twin', r.passenger_id, '',
            f"Passenger {r.passenger_id}: {r.get('digital_twin_summary','')}. Cohort {r.get('cohort_label','unknown')}. "
            f"Business {r.get('emb_business',0):.2f}, comfort {r.get('emb_comfort',0):.2f}, family {r.get('emb_family',0):.2f}, "
            f"budget {r.get('emb_budget',0):.2f}, premium {r.get('emb_premium',0):.2f}, digital {r.get('emb_digital',0):.2f}.",
            {'cohort_label': r.get('cohort_label'), 'dominant_orientation': r.get('dominant_orientation')},
        ))

    combined = replay.merge(
        sequence,
        left_on=['booking_id', 'journey_stage'], right_on=['booking_id', 'touchpoint_stage'],
        how='left', suffixes=('', '_sequence'),
    ).merge(
        policy[[
            'session_id', 'candidate_id', 'offer_name', 'rank_position', 'final_rank_score', 'bandit_rank',
            'bandit_policy_value', 'bandit_expected_reward', 'bandit_uncertainty', 'exploration_bonus',
            'target_policy_probability', 'propensity_score', 'inventory_reason', 'delay_minutes',
            'offer_fatigue_score', 'sequence_bundle_preference',
        ]],
        left_on=['selected_candidate_id'], right_on=['candidate_id'], how='left', suffixes=('', '_policy'),
    )
    numeric_fill = ['predicted_next_event_probability', 'sequence_accept_probability', 'sequence_reject_probability',
                    'sequence_bundle_preference_sequence', 'sequence_bundle_preference', 'predicted_minutes_to_next_event',
                    'rank_position', 'final_rank_score', 'bandit_policy_value_policy', 'bandit_policy_value',
                    'bandit_expected_reward', 'bandit_uncertainty', 'exploration_bonus_policy', 'exploration_bonus',
                    'delay_minutes', 'offer_fatigue_score']
    for col in numeric_fill:
        if col in combined.columns:
            combined[col] = pd.to_numeric(combined[col], errors='coerce').fillna(0.0)
    for col in ['predicted_next_event', 'inventory_reason']:
        if col in combined.columns:
            combined[col] = combined[col].fillna('')

    max_decision_docs = int(os.getenv('AIRLINE_RAG_MAX_DECISION_DOCS', '12000'))
    if len(combined) > max_decision_docs:
        combined = combined.sample(max_decision_docs, random_state=RANDOM_SEED)
    for _, r in combined.iterrows():
        docs.append(_doc(
            f"JOURNEY_{r.booking_id}_{r.journey_stage}", 'journey_decision', r.passenger_id, f"{r.booking_id}__{r.journey_stage}",
            f"Passenger {r.passenger_id}, booking {r.booking_id}, stage {r.journey_stage}, trigger {r.trigger_event}. "
            f"Causal journey Transformer predicted next event {r.get('predicted_next_event','unknown')} with probability {r.get('predicted_next_event_probability',0):.3f}; "
            f"accept probability {r.get('sequence_accept_probability',0):.3f}; reject probability {r.get('sequence_reject_probability',0):.3f}; "
            f"bundle preference {r.get('sequence_bundle_preference_sequence', r.get('sequence_bundle_preference',0)):.3f}; time to next event {r.get('predicted_minutes_to_next_event',0):.1f} minutes. "
            f"LambdaMART rank {int(r.get('rank_position',0) or 0)}, score {r.get('final_rank_score',0):.3f}. "
            f"Contextual bandit selected {r.selected_offer} type {r.candidate_type}, policy value {r.get('bandit_policy_value_policy', r.get('bandit_policy_value',0)):.3f}, "
            f"expected reward {r.get('bandit_expected_reward',0):.3f}, uncertainty {r.get('bandit_uncertainty',0):.3f}, exploration bonus {r.get('exploration_bonus_policy', r.get('exploration_bonus',0)):.3f}. "
            f"Delay {r.get('delay_minutes',0):.0f} minutes; fatigue {r.get('offer_fatigue_score',0):.3f}; inventory {r.get('inventory_reason','')}. "
            f"Outcome {r.outcome}, reward {r.reward:.3f}; purchased after {r.purchased_products_after}; rejected after {r.rejected_products_after}. "
            f"Offer changed {bool(r.offer_changed)} with revenue delta {r.expected_revenue_delta:.2f}. Explanation: {r.decision_explanation}.",
            {'booking_id': r.booking_id, 'stage': r.journey_stage, 'selected_offer': r.selected_offer, 'outcome': r.outcome},
        ))

    if not shap_df.empty:
        for cid, g in list(shap_df.groupby('candidate_id'))[:1500]:
            parts = [f"{x.feature} contributed {x.contribution:.4f} {x.direction}" for x in g.head(6).itertuples()]
            docs.append(_doc(f"SHAP_{cid}", 'shap_explanation', '', str(g.iloc[0].session_id), f"SHAP explanation for {cid}: " + '; '.join(parts), {'candidate_id': cid}))
    text = '; '.join([f"{r.metric}={r.value}" for r in business.itertuples()])
    docs.append(_doc('BUSINESS_VALUE', 'business_metrics', '', '', f"Business value summary: {text}", {}))
    return docs



def _pair_indices(evidence: pd.DataFrame, max_pairs: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Create same-passenger/session positives and cross-passenger negatives."""
    rng = np.random.default_rng(RANDOM_SEED)
    frame = evidence.reset_index(drop=True)
    groups: dict[str, list[int]] = {}
    for idx, row in frame.iterrows():
        passenger = str(row.passenger_id or '').strip()
        session = str(row.session_id or '').strip()
        key = f'P::{passenger}' if passenger else (f'S::{session}' if session else '')
        if key:
            groups.setdefault(key, []).append(idx)

    positives: list[tuple[int, int]] = []
    for idxs in groups.values():
        if len(idxs) < 2:
            continue
        rng.shuffle(idxs)
        for i in range(len(idxs) - 1):
            positives.append((idxs[i], idxs[i + 1]))
    rng.shuffle(positives)
    positives = positives[: max(1, max_pairs // 2)]

    passenger_values = frame.passenger_id.fillna('').astype(str).to_numpy()
    negatives: list[tuple[int, int]] = []
    attempts = 0
    while len(negatives) < len(positives) and attempts < max(1000, len(positives) * 30):
        a = int(rng.integers(0, len(frame)))
        b = int(rng.integers(0, len(frame)))
        attempts += 1
        if a == b:
            continue
        pa, pb = passenger_values[a], passenger_values[b]
        if pa and pb and pa == pb:
            continue
        negatives.append((a, b))
    if not positives or not negatives:
        raise RuntimeError('Insufficient evidence relationships to train the RAG Transformer.')

    pairs = positives + negatives
    labels = np.array([1.0] * len(positives) + [-1.0] * len(negatives), dtype='float32')
    order = rng.permutation(len(pairs))
    a = np.array([pairs[i][0] for i in order], dtype=np.int64)
    b = np.array([pairs[i][1] for i in order], dtype=np.int64)
    return a, b, labels[order]


def _mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).to(last_hidden_state.dtype)
    summed = (last_hidden_state * mask).sum(dim=1)
    denom = mask.sum(dim=1).clamp(min=1e-6)
    return torch.nn.functional.normalize(summed / denom, p=2, dim=1)


def _train_local_sentence_transformer(evidence: pd.DataFrame) -> tuple[object, dict]:
    """Train an actual compact Transformer encoder from the local evidence corpus.

    A WordPiece tokenizer and a small BERT encoder are initialized locally, then
    contrastively fine-tuned on same-passenger/session and cross-passenger pairs.
    The trained backbone is wrapped as a SentenceTransformer with mean pooling
    and normalization. No remote model download is required.
    """
    from sentence_transformers import SentenceTransformer, models
    from tokenizers import BertWordPieceTokenizer
    from transformers import BertConfig, BertModel, PreTrainedTokenizerFast
    from torch import nn

    torch.manual_seed(RANDOM_SEED)
    torch.set_num_threads(max(1, int(os.getenv('AIRLINE_TORCH_THREADS', '2'))))
    rng = np.random.default_rng(RANDOM_SEED)
    texts = evidence.text.fillna('').astype(str).tolist()
    rag_dir = MODEL_DIR / 'rag'
    backbone_dir = rag_dir / 'local_tiny_bert_backbone'
    corpus_path = rag_dir / 'rag_training_corpus.txt'
    backbone_dir.mkdir(parents=True, exist_ok=True)
    corpus_path.write_text('\n'.join(t.replace('\n', ' ') for t in texts), encoding='utf-8')

    vocab_size = int(os.getenv('AIRLINE_RAG_VOCAB', '2400'))
    tokenizer_builder = BertWordPieceTokenizer(lowercase=True, strip_accents=True)
    tokenizer_builder.train(
        files=[str(corpus_path)],
        vocab_size=vocab_size,
        min_frequency=2,
        special_tokens=['[PAD]', '[UNK]', '[CLS]', '[SEP]', '[MASK]'],
        wordpieces_prefix='##',
    )
    tokenizer_builder.save_model(str(backbone_dir))
    tokenizer = PreTrainedTokenizerFast(
        tokenizer_object=tokenizer_builder._tokenizer,
        unk_token='[UNK]', sep_token='[SEP]', pad_token='[PAD]',
        cls_token='[CLS]', mask_token='[MASK]',
    )
    tokenizer.model_max_length = int(os.getenv('AIRLINE_RAG_MAX_LEN', '112'))
    tokenizer.save_pretrained(backbone_dir)

    hidden = int(os.getenv('AIRLINE_RAG_HIDDEN_SIZE', '64'))
    layers = int(os.getenv('AIRLINE_RAG_LAYERS', '2'))
    heads = int(os.getenv('AIRLINE_RAG_ATTENTION_HEADS', '4'))
    max_len = int(os.getenv('AIRLINE_RAG_MAX_LEN', '112'))
    config = BertConfig(
        vocab_size=len(tokenizer),
        hidden_size=hidden,
        num_hidden_layers=layers,
        num_attention_heads=heads,
        intermediate_size=hidden * 3,
        hidden_dropout_prob=.08,
        attention_probs_dropout_prob=.08,
        max_position_embeddings=max(128, max_len + 8),
        pad_token_id=tokenizer.pad_token_id,
    )
    encoder = BertModel(config)

    pair_a, pair_b, pair_labels = _pair_indices(
        evidence, int(os.getenv('AIRLINE_RAG_TRAIN_PAIRS', '1600'))
    )
    optimizer = torch.optim.AdamW(
        encoder.parameters(),
        lr=float(os.getenv('AIRLINE_RAG_LR', '0.0008')),
        weight_decay=1e-4,
    )
    loss_fn = nn.CosineEmbeddingLoss(margin=.15)
    batch_size = int(os.getenv('AIRLINE_RAG_BATCH_SIZE', '32'))
    epochs = int(os.getenv('AIRLINE_RAG_EPOCHS', '2'))
    history = []
    encoder.train()
    for epoch in range(epochs):
        order = rng.permutation(len(pair_a))
        losses = []
        for start in range(0, len(order), batch_size):
            ids = order[start:start + batch_size]
            ta = [texts[int(i)] for i in pair_a[ids]]
            tb = [texts[int(i)] for i in pair_b[ids]]
            a_inputs = tokenizer(ta, padding=True, truncation=True, max_length=max_len, return_tensors='pt')
            b_inputs = tokenizer(tb, padding=True, truncation=True, max_length=max_len, return_tensors='pt')
            za = _mean_pool(encoder(**a_inputs).last_hidden_state, a_inputs['attention_mask'])
            zb = _mean_pool(encoder(**b_inputs).last_hidden_state, b_inputs['attention_mask'])
            target = torch.tensor(pair_labels[ids], dtype=torch.float32)
            loss = loss_fn(za, zb, target)
            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(encoder.parameters(), 1.5)
            optimizer.step()
            losses.append(float(loss.detach()))
        history.append({'epoch': epoch + 1, 'contrastive_loss': float(np.mean(losses))})

    encoder.save_pretrained(backbone_dir)
    transformer_module = models.Transformer(str(backbone_dir), max_seq_length=max_len)
    pooling_module = models.Pooling(
        transformer_module.get_embedding_dimension(), pooling_mode='mean'
    )
    st_model = SentenceTransformer(modules=[transformer_module, pooling_module, models.Normalize()])
    st_model.save(str(LOCAL_MODEL_DIR))

    # Evaluate separation on a held sample of positive and negative pairs.
    sample_n = min(200, len(pair_a))
    eval_ids = np.arange(sample_n)
    ea = st_model.encode([texts[int(i)] for i in pair_a[eval_ids]], batch_size=64, show_progress_bar=False, normalize_embeddings=True)
    eb = st_model.encode([texts[int(i)] for i in pair_b[eval_ids]], batch_size=64, show_progress_bar=False, normalize_embeddings=True)
    sims = np.sum(ea * eb, axis=1)
    labels = pair_labels[eval_ids]
    metrics = {
        'architecture': f'SentenceTransformer(local BERT {layers} layers, hidden {hidden}, mean pooling, normalization)',
        'documents': len(texts),
        'vocabulary_size': len(tokenizer),
        'embedding_dimension': hidden,
        'contrastive_training_pairs': int(len(pair_a)),
        'positive_pair_mean_cosine': float(np.mean(sims[labels > 0])) if np.any(labels > 0) else 0.0,
        'negative_pair_mean_cosine': float(np.mean(sims[labels < 0])) if np.any(labels < 0) else 0.0,
        'remote_download_required': False,
        'training_history': history,
    }
    (DATA_DIR / 'rag' / 'embedding_model_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    return st_model, metrics


@lru_cache(maxsize=1)
def _embedding_model():
    from sentence_transformers import SentenceTransformer
    configured = os.getenv('AIRLINE_RAG_EMBEDDING_MODEL', '').strip()
    if configured:
        return SentenceTransformer(configured)
    return SentenceTransformer(str(LOCAL_MODEL_DIR), local_files_only=True)


def build_rag_index() -> None:
    import faiss

    docs = _build_documents()
    docs_path = DATA_DIR / 'rag' / 'evidence_documents.jsonl'
    docs_path.write_text('\n'.join(json.dumps(d, default=str) for d in docs), encoding='utf-8')
    evidence = pd.DataFrame([{k: d[k] for k in ['doc_id', 'source', 'passenger_id', 'session_id', 'text']} for d in docs]).fillna('')
    evidence.to_csv(DATA_DIR / 'rag' / 'evidence_index.csv', index=False)

    configured = os.getenv('AIRLINE_RAG_EMBEDDING_MODEL', '').strip()
    if configured:
        model = _embedding_model()
    else:
        model, _ = _train_local_sentence_transformer(evidence)
        _embedding_model.cache_clear()
    embeddings = model.encode(
        evidence.text.tolist(),
        batch_size=int(os.getenv('AIRLINE_RAG_ENCODE_BATCH_SIZE', '96')),
        show_progress_bar=False,
        convert_to_numpy=True,
        normalize_embeddings=True,
    ).astype('float32')
    index = faiss.IndexFlatIP(embeddings.shape[1])
    index.add(embeddings)
    faiss.write_index(index, str(MODEL_DIR / 'rag' / 'faiss_rag_index.bin'))
    np.save(DATA_DIR / 'rag' / 'rag_embeddings.npy', embeddings)


def retrieve_evidence(question: str, passenger_id: str | None = None, top_k: int = 6) -> pd.DataFrame:
    import faiss

    evidence = pd.read_csv(DATA_DIR / 'rag' / 'evidence_index.csv').fillna('')
    index = faiss.read_index(str(MODEL_DIR / 'rag' / 'faiss_rag_index.bin'))
    query = question if not passenger_id else f"{question} passenger {passenger_id}"
    q = _embedding_model().encode(
        [query], normalize_embeddings=True, convert_to_numpy=True, show_progress_bar=False
    ).astype('float32')

    # Passenger-specific questions must not be answered with evidence from a
    # different passenger.  Search the full compact index, then enforce an
    # entity filter while retaining optional global business evidence only for
    # explicitly commercial questions.
    search_k = len(evidence) if passenger_id else min(top_k * 8, len(evidence))
    scores, idxs = index.search(q, search_k)
    candidates = []
    commercial_question = any(token in question.lower() for token in ['business', 'revenue', 'uplift', 'value', 'conversion'])
    for score, idx in zip(scores[0], idxs[0]):
        if idx < 0:
            continue
        row = evidence.iloc[int(idx)].to_dict()
        row_passenger = str(row.get('passenger_id', ''))
        source = str(row.get('source', ''))
        if passenger_id and row_passenger != passenger_id:
            if not (commercial_question and not row_passenger and source == 'business_metrics'):
                continue
        specificity = 1 if passenger_id and row_passenger == passenger_id else 0
        row['retrieval_score'] = float(score) + .07 * specificity
        candidates.append(row)
    audit = pd.DataFrame(candidates)
    if not audit.empty:
        audit = audit.sort_values('retrieval_score', ascending=False).head(top_k)
    audit.to_csv(DATA_DIR / 'rag' / 'retrieval_audit.csv', index=False)
    return audit


def answer_question(question: str, passenger_id: str | None = None) -> dict:
    evidence = retrieve_evidence(question, passenger_id=passenger_id, top_k=6)
    if evidence.empty:
        return {'answer': 'No grounded evidence was retrieved.', 'evidence': []}
    lines = ['Grounded answer from the passenger journey evidence:']
    for _, row in evidence.iterrows():
        lines.append(f"- [{row.source}] {row.text}")
    return {'answer': '\n'.join(lines), 'evidence': evidence.to_dict(orient='records')}
