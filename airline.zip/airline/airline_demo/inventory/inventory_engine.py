from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import pandas as pd

from airline_demo.config.settings import DATA_DIR

INVENTORY_REQUIREMENTS = {
    'UPGRADE': {'upgrade_capacity': 1},
    'SEAT_LEG': {'extra_legroom_capacity': 1},
    'MEAL': {'premium_meal_capacity': 1},
    'LOUNGE': {'lounge_capacity': 1},
    'PRIORITY': {'priority_capacity': 1},
    'BAG': {'cargo_bag_capacity': 1},
    'WIFI': {'wifi_available': True},
    'SEAT_STD': {},
    'INSURANCE': {},
}


def load_inventory() -> pd.DataFrame:
    raw = DATA_DIR / 'inventory_snapshots_raw.csv'
    curated = DATA_DIR / 'inventory' / 'inventory_snapshots.csv'
    return pd.read_csv(curated if curated.exists() else raw)


def required_resources(offer_ids: Iterable[str]) -> dict:
    req = {}
    for oid in offer_ids:
        for resource, amount in INVENTORY_REQUIREMENTS.get(oid, {}).items():
            if isinstance(amount, bool):
                req[resource] = amount
            else:
                req[resource] = req.get(resource, 0) + amount
    return req


def inventory_check(inventory_row: pd.Series | dict, offer_ids: Iterable[str]) -> tuple[bool, str, dict]:
    row = dict(inventory_row)
    req = required_resources(offer_ids)
    reasons = []
    for resource, amount in req.items():
        available = row.get(resource, 0)
        if isinstance(amount, bool):
            if bool(available) != amount:
                reasons.append(f'{resource}=False')
        elif float(available) < float(amount):
            reasons.append(f'{resource} insufficient ({available} < {amount})')
    return (len(reasons) == 0, '; '.join(reasons) if reasons else 'inventory_available', req)


def initialize_inventory_snapshots() -> None:
    inv = pd.read_csv(DATA_DIR / 'inventory_snapshots_raw.csv')
    inv.to_csv(DATA_DIR / 'inventory' / 'inventory_snapshots.csv', index=False)
    pd.DataFrame(columns=['event_id', 'flight_id', 'candidate_id', 'offer_ids', 'resource', 'before', 'after', 'event_type']).to_csv(DATA_DIR / 'inventory' / 'inventory_audit.csv', index=False)


def consume_inventory(flight_id: str, candidate_id: str, offer_ids: Iterable[str], event_type: str = 'accepted') -> pd.DataFrame:
    inv_path = DATA_DIR / 'inventory' / 'inventory_snapshots.csv'
    audit_path = DATA_DIR / 'inventory' / 'inventory_audit.csv'
    inv = pd.read_csv(inv_path)
    idxs = inv.index[inv.flight_id == flight_id].tolist()
    if not idxs:
        raise ValueError(f'Unknown flight_id {flight_id}')
    idx = idxs[0]
    ok, reason, req = inventory_check(inv.loc[idx], offer_ids)
    if not ok:
        raise ValueError(f'Cannot consume inventory: {reason}')
    audit_rows = []
    for resource, amount in req.items():
        if isinstance(amount, bool):
            continue
        before = float(inv.loc[idx, resource])
        after = before - float(amount)
        inv.loc[idx, resource] = after
        audit_rows.append({'event_id': f'INV{len(audit_rows)+1:06d}', 'flight_id': flight_id, 'candidate_id': candidate_id, 'offer_ids': '|'.join(offer_ids), 'resource': resource, 'before': before, 'after': after, 'event_type': event_type})
    inv.loc[idx, 'last_updated_event'] = f'{event_type}:{candidate_id}'
    inv.to_csv(inv_path, index=False)
    audit = pd.read_csv(audit_path) if audit_path.exists() else pd.DataFrame()
    pd.concat([audit, pd.DataFrame(audit_rows)], ignore_index=True).to_csv(audit_path, index=False)
    return inv


def apply_inventory_allocation() -> None:
    candidates = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    inv = load_inventory()
    allocation_rows = []
    remaining = inv.set_index('flight_id').to_dict(orient='index')
    for _, r in candidates.sort_values(['session_id', 'final_rank_score'], ascending=[True, False]).iterrows():
        offer_ids = str(r['products']).split('|') if r.get('candidate_type') == 'bundle' else [r['offer_id']]
        flight_id = r['flight_id']
        ok, reason, req = inventory_check(remaining.get(flight_id, {}), offer_ids)
        allocated = False
        if ok:
            allocated = True
            for resource, amount in req.items():
                if not isinstance(amount, bool):
                    remaining[flight_id][resource] = remaining[flight_id][resource] - amount
        allocation_rows.append({
            'session_id': r['session_id'], 'booking_id': r['booking_id'], 'flight_id': flight_id,
            'candidate_id': r['candidate_id'], 'candidate_type': r['candidate_type'], 'offer_ids': '|'.join(offer_ids),
            'allocated': allocated, 'allocation_reason': 'allocated' if allocated else reason,
            'expected_revenue': r['expected_revenue'], 'final_rank_score': r['final_rank_score'],
        })
    pd.DataFrame(allocation_rows).to_csv(DATA_DIR / 'inventory' / 'flight_inventory_allocation.csv', index=False)
