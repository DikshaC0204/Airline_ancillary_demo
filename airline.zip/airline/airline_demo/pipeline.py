from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone

from airline_demo.config.settings import DEFAULT_PASSENGERS, ROOT_DIR
from airline_demo.utils import ensure_dirs, require_preferred_dependencies

PIPELINE_STEPS = [
    'generate_data',
    'build_event_journeys',
    'materialize_point_in_time_features',
    'build_features',
    'train_hdbscan_cohorts',
    'build_embeddings_and_faiss',
    'train_propensity_models',
    'train_collaborative_filtering',
    'mine_association_rules',
    'train_causal_journey_transformer',
    'initialize_inventory',
    'generate_candidate_fusion',
    'enrich_candidates_with_event_and_sequence_features',
    'generate_dynamic_bundles',
    'train_lambdamart_ranker',
    'train_contextual_bandit',
    'generate_shap_explanations',
    'apply_inventory_optimization',
    'build_journey_replays',
    'build_decision_traces',
    'build_business_metrics',
    'build_rag_index',
]


def run_pipeline(n_passengers: int | None = None) -> dict:
    """Run every stage in an isolated Python process.

    Isolation keeps native ML libraries and large intermediate DataFrames from
    accumulating memory across the long end-to-end pipeline. All stitching is
    artifact-based and validated between stages.
    """
    ensure_dirs()
    n_passengers = int(n_passengers or DEFAULT_PASSENGERS)
    started = datetime.now(timezone.utc).isoformat()
    status = []
    require_preferred_dependencies(include_streamlit=False)
    status.append({'step': 'dependency_check', 'status': 'completed', 'elapsed_seconds': 0.0})
    env = os.environ.copy()
    env['AIRLINE_DEMO_PASSENGERS'] = str(n_passengers)
    root = str(ROOT_DIR)
    env['PYTHONPATH'] = root + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')

    for step in PIPELINE_STEPS:
        print(f'[pipeline] {step}...', flush=True)
        step_start = datetime.now(timezone.utc)
        completed = subprocess.run(
            [sys.executable, '-m', 'airline_demo.pipeline_worker', step],
            cwd=root, env=env, text=True, capture_output=True,
        )
        elapsed = (datetime.now(timezone.utc) - step_start).total_seconds()
        if completed.stdout.strip():
            print(completed.stdout.strip(), flush=True)
        if completed.returncode != 0:
            if completed.stderr.strip():
                print(completed.stderr.strip(), file=sys.stderr, flush=True)
            status.append({'step': step, 'status': 'failed', 'elapsed_seconds': round(elapsed, 3), 'error': completed.stderr[-4000:]})
            result = {
                'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
                'n_passengers': n_passengers, 'pipeline_steps': status, 'strict_showcase_mode': True,
            }
            (ROOT_DIR / 'validation_log.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
            raise RuntimeError(f'Pipeline step failed: {step}\n{completed.stderr}')
        status.append({'step': step, 'status': 'completed', 'elapsed_seconds': round(elapsed, 3)})
        print(f'[pipeline] {step} completed in {elapsed:.2f}s', flush=True)

    result = {
        'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
        'n_passengers': n_passengers, 'pipeline_steps': status, 'strict_showcase_mode': True,
        'advanced_components': [
            'point_in_time_features', 'feature_availability_registry', 'causal_journey_transformer',
            'multi_task_next_event_response_bundle_time_heads', 'contextual_bandit', 'no_offer_action',
            'inverse_propensity_scoring', 'doubly_robust_evaluation', 'event_driven_replay',
            'dynamic_single_vs_bundle_actions', 'inventory_constraints', 'local_trained_sentence_transformer_rag',
        ],
    }
    (ROOT_DIR / 'validation_log.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result
