from __future__ import annotations

import json
import pandas as pd

from airline_demo.config.settings import DATA_DIR

# Deliberately simple static merchandising policy used as the comparison arm.
# It shows one generic ancillary by stage and does not personalize by cohort,
# interaction sequence, event context, bundle affinity, or contextual-bandit value.
STATIC_STAGE_OFFER = {
    'seat_selection': 'SEAT_STD',
    'payment': 'BAG',
    'confirmation': 'INSURANCE',
    'checkin': 'PRIORITY',
    'airport': 'LOUNGE',
    'boarding': 'PRIORITY',
    'in_flight': 'WIFI',
}


def _static_baseline(ranked: pd.DataFrame) -> pd.DataFrame:
    singles = ranked[(ranked.candidate_type == 'single') & (ranked.eligible == True) & (ranked.inventory_eligible == True)].copy()
    singles['static_offer_id'] = singles.touchpoint_stage.map(STATIC_STAGE_OFFER)
    preferred = singles[singles.offer_id == singles.static_offer_id].copy()
    # Preserve one row per session; sessions without the generic static product
    # correctly contribute zero expected revenue rather than choosing a personalized substitute.
    sessions = ranked[['session_id', 'touchpoint_stage']].drop_duplicates()
    preferred = preferred.sort_values(['session_id', 'expected_revenue'], ascending=[True, False]).groupby('session_id').head(1)
    base = sessions.merge(preferred[['session_id', 'offer_name', 'expected_revenue', 'propensity_score']], on='session_id', how='left')
    base[['expected_revenue', 'propensity_score']] = base[['expected_revenue', 'propensity_score']].fillna(0.0)
    base['offer_name'] = base.offer_name.fillna('No eligible static stage offer')
    return base


def build_business_metrics() -> None:
    ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    bandit = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv')
    rank_top = ranked[ranked.rank_position == 1].copy()
    policy_top = bandit[bandit.bandit_selected == 1].copy()
    baseline = _static_baseline(ranked)

    ai_rev = float(policy_top.expected_revenue.sum())
    ranker_rev = float(rank_top.expected_revenue.sum())
    baseline_rev = float(baseline.expected_revenue.sum())
    accepted_revenue = float(replay.loc[replay.outcome == 'accepted', 'price'].sum())
    no_offer_rate = float((policy_top.offer_id == 'NO_OFFER').mean()) if len(policy_top) else 0
    bundle_rate = float((policy_top.candidate_type == 'bundle').mean()) if len(policy_top) else 0
    bandit_metrics = json.loads((DATA_DIR / 'bandits' / 'bandit_metrics.json').read_text())

    summary = pd.DataFrame([
        {'metric': 'Personalized bandit expected revenue', 'value': round(ai_rev, 2)},
        {'metric': 'LambdaMART-only expected revenue', 'value': round(ranker_rev, 2)},
        {'metric': 'Generic static-stage expected revenue', 'value': round(baseline_rev, 2)},
        {'metric': 'Expected uplift vs generic static pct', 'value': round((ai_rev - baseline_rev) / max(1, baseline_rev) * 100, 2)},
        {'metric': 'Simulated accepted revenue', 'value': round(accepted_revenue, 2)},
        {'metric': 'Bundle selection rate pct', 'value': round(bundle_rate * 100, 2)},
        {'metric': 'No-offer preservation rate pct', 'value': round(no_offer_rate * 100, 2)},
        {'metric': 'Doubly robust policy value', 'value': round(float(bandit_metrics['doubly_robust_estimated_policy_value']), 4)},
        {'metric': 'Effective sample size', 'value': round(float(bandit_metrics['effective_sample_size']), 1)},
        {'metric': 'Recommendation coverage sessions', 'value': int(policy_top.session_id.nunique())},
    ])

    by_stage = policy_top.groupby('touchpoint_stage').agg(
        expected_revenue=('expected_revenue', 'sum'), avg_propensity=('propensity_score', 'mean'),
        sessions=('session_id', 'nunique'), no_offer_rate=('offer_id', lambda x: float((x == 'NO_OFFER').mean())),
        bundle_rate=('candidate_type', lambda x: float((x == 'bundle').mean())),
        exploration_bonus=('exploration_bonus', 'mean'),
    ).reset_index()
    static_stage = baseline.groupby('touchpoint_stage').agg(static_expected_revenue=('expected_revenue', 'sum')).reset_index()
    by_stage = by_stage.merge(static_stage, on='touchpoint_stage', how='left')
    by_stage['expected_uplift_pct'] = (
        (by_stage.expected_revenue - by_stage.static_expected_revenue)
        / by_stage.static_expected_revenue.clip(lower=1.0) * 100
    )

    twins = pd.read_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv')[['passenger_id', 'cohort_label']]
    by_cohort = policy_top.merge(twins, on='passenger_id', how='left').groupby('cohort_label').agg(
        expected_revenue=('expected_revenue', 'sum'), avg_propensity=('propensity_score', 'mean'),
        sessions=('session_id', 'nunique'), bundle_rate=('candidate_type', lambda x: float((x == 'bundle').mean())),
        no_offer_rate=('offer_id', lambda x: float((x == 'NO_OFFER').mean())),
    ).reset_index()

    blocked = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv')
    blocked = blocked[blocked.inventory_eligible == False].groupby('inventory_reason').size().reset_index(name='blocked_count')
    outcomes = replay.groupby(['journey_stage', 'outcome']).size().reset_index(name='count')

    summary.to_csv(DATA_DIR / 'business_metrics' / 'business_value_summary.csv', index=False)
    by_stage.to_csv(DATA_DIR / 'business_metrics' / 'offer_performance_by_stage.csv', index=False)
    by_cohort.to_csv(DATA_DIR / 'business_metrics' / 'offer_performance_by_cohort.csv', index=False)
    baseline.to_csv(DATA_DIR / 'business_metrics' / 'static_baseline_decisions.csv', index=False)
    blocked.to_csv(DATA_DIR / 'business_metrics' / 'blocked_offers_by_inventory_reason.csv', index=False)
    outcomes.to_csv(DATA_DIR / 'business_metrics' / 'journey_outcomes_by_stage.csv', index=False)
