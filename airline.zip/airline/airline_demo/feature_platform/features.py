from __future__ import annotations

import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

from airline_demo.config.settings import DATA_DIR, DIGITAL_TWIN_DIMS
from airline_demo.utils import ensure_dirs

LOYALTY_SCORE = {'None': 0.0, 'Silver': 0.35, 'Gold': 0.70, 'Platinum': 1.0}
FARE_SCORE = {'Basic Economy': 0.05, 'Economy': 0.25, 'Economy Flex': 0.45, 'Premium Economy': 0.75, 'Business': 1.0}


def _safe_div(a, b):
    return np.where(b == 0, 0, a / b)


def build_features() -> None:
    ensure_dirs()
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv')
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    offers = pd.read_csv(DATA_DIR / 'offer_history.csv')
    purchases = pd.read_csv(DATA_DIR / 'purchases.csv') if (DATA_DIR / 'purchases.csv').exists() else pd.DataFrame()

    booking_agg = bookings.groupby('passenger_id').agg(
        total_bookings=('booking_id', 'nunique'),
        avg_lead_time=('lead_time_days', 'mean'),
        avg_distance=('distance_miles', 'mean'),
        avg_duration=('duration_minutes', 'mean'),
        family_booking_rate=('children', lambda s: float((s > 0).mean())),
        premium_cabin_rate=('cabin', lambda s: float(s.isin(['Premium Economy', 'Business']).mean())),
        business_route_avg=('business_route_score', 'mean'),
        leisure_route_avg=('leisure_route_score', 'mean'),
        avg_party_size=('party_size', 'mean'),
        international_rate=('international', 'mean'),
    ).reset_index()

    offer_agg = offers.groupby('passenger_id').agg(
        offer_impressions=('offer_event_id', 'count'),
        offer_clicks=('clicked', 'sum'),
        offer_accepts=('accepted', 'sum'),
        offer_rejections=('rejected', 'sum'),
        avg_offered_price=('price', 'mean'),
    ).reset_index()
    offer_agg['offer_acceptance_rate'] = _safe_div(offer_agg['offer_accepts'], offer_agg['offer_impressions'])
    offer_agg['click_rate'] = _safe_div(offer_agg['offer_clicks'], offer_agg['offer_impressions'])
    offer_agg['rejection_rate'] = _safe_div(offer_agg['offer_rejections'], offer_agg['offer_impressions'])

    if purchases.empty:
        purchase_agg = pd.DataFrame({'passenger_id': passengers.passenger_id})
        purchase_agg['total_ancillary_spend'] = 0.0
        purchase_agg['purchased_offer_count'] = 0
        purchase_agg['unique_offer_count'] = 0
    else:
        purchase_agg = purchases.groupby('passenger_id').agg(
            total_ancillary_spend=('purchase_amount', 'sum'),
            purchased_offer_count=('purchase_id', 'count'),
            unique_offer_count=('offer_id', 'nunique'),
        ).reset_index()

    features = passengers.merge(booking_agg, on='passenger_id', how='left').merge(offer_agg, on='passenger_id', how='left').merge(purchase_agg, on='passenger_id', how='left')
    features = features.fillna(0)
    features['loyalty_score'] = features['loyalty_tier'].map(LOYALTY_SCORE).fillna(0)
    features['corporate_flag_int'] = features['corporate_flag'].astype(int)
    features['spend_per_trip'] = _safe_div(features['total_ancillary_spend'], features['total_bookings'])
    features['bundle_acceptance_rate'] = np.minimum(1, features['purchased_offer_count'] / np.maximum(1, features['total_bookings'] * 3))

    # Digital-twin dimensions. These are engineered behavioral embeddings, not a random vector.
    features['emb_business'] = np.clip(0.45 * features['corporate_flag_int'] + 0.25 * features['business_route_avg'] + 0.20 * features['annual_trips'] / 50 + 0.10 * features['loyalty_score'], 0, 1)
    features['emb_family'] = np.clip(0.65 * features['family_booking_rate'] + 0.25 * features['avg_party_size'] / 5 + 0.10 * (features['persona'] == 'Family').astype(int), 0, 1)
    features['emb_budget'] = np.clip(0.70 * features['price_sensitivity'] + 0.20 * (features['persona'].isin(['Budget', 'Student'])).astype(int) + 0.10 * (features['loyalty_score'] < 0.35).astype(int), 0, 1)
    features['emb_premium'] = np.clip(0.35 * features['loyalty_score'] + 0.25 * features['premium_cabin_rate'] + 0.25 * features['spend_per_trip'] / 250 + 0.15 * (features['persona'] == 'Premium').astype(int), 0, 1)
    features['emb_comfort'] = np.clip(0.30 * features['emb_premium'] + 0.30 * (1 - features['price_sensitivity']) + 0.20 * features['offer_acceptance_rate'] + 0.20 * features['avg_distance'] / 2600, 0, 1)
    features['emb_digital'] = np.clip(0.55 * features['digital_engagement_score'] + 0.25 * features['click_rate'] + 0.20 * features['annual_trips'] / 50, 0, 1)
    features['emb_convenience'] = np.clip(0.35 * features['emb_business'] + 0.25 * features['emb_family'] + 0.20 * features['click_rate'] + 0.20 * features['loyalty_score'], 0, 1)
    features['emb_airport'] = np.clip(0.45 * features['emb_business'] + 0.35 * features['emb_premium'] + 0.20 * features['loyalty_score'], 0, 1)
    features['emb_inflight'] = np.clip(0.35 * features['emb_business'] + 0.25 * features['avg_duration'] / 370 + 0.20 * features['emb_digital'] + 0.20 * features['emb_comfort'], 0, 1)

    numeric_cols = [
        'age', 'price_sensitivity', 'annual_trips', 'historical_ancillary_spend', 'total_bookings',
        'avg_lead_time', 'avg_distance', 'avg_duration', 'family_booking_rate', 'premium_cabin_rate',
        'business_route_avg', 'leisure_route_avg', 'avg_party_size', 'international_rate', 'offer_impressions',
        'offer_clicks', 'offer_accepts', 'offer_rejections', 'offer_acceptance_rate', 'click_rate',
        'rejection_rate', 'total_ancillary_spend', 'purchased_offer_count', 'unique_offer_count',
        'loyalty_score', 'corporate_flag_int', 'spend_per_trip', 'bundle_acceptance_rate'
    ] + DIGITAL_TWIN_DIMS

    # Keep original columns plus engineered fields.
    features.to_csv(DATA_DIR / 'feature_store' / 'passenger_features.csv', index=False)

    twins = features[['passenger_id', 'persona', 'archetype_seed', 'loyalty_tier', 'corporate_flag', 'price_sensitivity', 'annual_trips', 'historical_ancillary_spend'] + DIGITAL_TWIN_DIMS].copy()
    twins['dominant_orientation'] = twins[DIGITAL_TWIN_DIMS].idxmax(axis=1).str.replace('emb_', '', regex=False)
    twins['digital_twin_summary'] = twins.apply(lambda r: f"{r['archetype_seed']} with strongest {r['dominant_orientation']} orientation", axis=1)
    twins.to_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv', index=False)

    registry = {
        'passenger_profile_features': ['age', 'loyalty_tier', 'corporate_flag', 'annual_trips', 'historical_ancillary_spend', 'price_sensitivity'],
        'booking_behavior_features': ['total_bookings', 'avg_lead_time', 'avg_distance', 'family_booking_rate', 'premium_cabin_rate', 'business_route_avg'],
        'offer_behavior_features': ['offer_acceptance_rate', 'click_rate', 'rejection_rate', 'total_ancillary_spend', 'purchased_offer_count'],
        'digital_twin_dimensions': DIGITAL_TWIN_DIMS,
        'model_numeric_features': numeric_cols,
    }
    (DATA_DIR / 'feature_store' / 'feature_registry.json').write_text(json.dumps(registry, indent=2), encoding='utf-8')
