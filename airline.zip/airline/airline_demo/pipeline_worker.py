from __future__ import annotations

import os
import sys

from airline_demo.analytics.business_value import build_business_metrics
from airline_demo.bandits.contextual_policy import train_contextual_bandit
from airline_demo.decision_engine.trace import build_decision_traces
from airline_demo.embeddings.vector_index import build_passenger_offer_embeddings_and_faiss
from airline_demo.event_platform.dynamic_features import enrich_candidate_fusion_with_event_and_sequence_features
from airline_demo.event_platform.feature_materializer import materialize_point_in_time_features
from airline_demo.event_platform.journey_events import build_event_journeys
from airline_demo.explainability.shap_explainer import generate_shap_explanations
from airline_demo.feature_platform.features import build_features
from airline_demo.inventory.inventory_engine import apply_inventory_allocation, initialize_inventory_snapshots
from airline_demo.ml_platform.hybrid import mine_association_rules, train_collaborative_filtering
from airline_demo.ml_platform.propensity import train_propensity_models
from airline_demo.passenger_intelligence.cohorts import train_hdbscan_cohorts
from airline_demo.rag.rag_index import build_rag_index
from airline_demo.ranking.lambdamart import train_lambdamart_ranker
from airline_demo.recommendation.bundles import generate_dynamic_bundles
from airline_demo.recommendation.candidate_fusion import generate_candidate_fusion
from airline_demo.sequence_models.journey_transformer import train_journey_transformer
from airline_demo.simulation.journey_replay import build_journey_replays
from airline_demo.simulator.data_generator import generate_data
from airline_demo.utils import ensure_dirs


STEP_FUNCTIONS = {
    'generate_data': lambda: generate_data(n_passengers=int(os.getenv('AIRLINE_DEMO_PASSENGERS', '1000'))),
    'build_event_journeys': build_event_journeys,
    'materialize_point_in_time_features': materialize_point_in_time_features,
    'build_features': build_features,
    'train_hdbscan_cohorts': train_hdbscan_cohorts,
    'build_embeddings_and_faiss': build_passenger_offer_embeddings_and_faiss,
    'train_propensity_models': train_propensity_models,
    'train_collaborative_filtering': train_collaborative_filtering,
    'mine_association_rules': mine_association_rules,
    'train_causal_journey_transformer': train_journey_transformer,
    'initialize_inventory': initialize_inventory_snapshots,
    'generate_candidate_fusion': generate_candidate_fusion,
    'enrich_candidates_with_event_and_sequence_features': enrich_candidate_fusion_with_event_and_sequence_features,
    'generate_dynamic_bundles': generate_dynamic_bundles,
    'train_lambdamart_ranker': train_lambdamart_ranker,
    'train_contextual_bandit': train_contextual_bandit,
    'generate_shap_explanations': generate_shap_explanations,
    'apply_inventory_optimization': apply_inventory_allocation,
    'build_journey_replays': build_journey_replays,
    'build_decision_traces': build_decision_traces,
    'build_business_metrics': build_business_metrics,
    'build_rag_index': build_rag_index,
}


def execute_step(step: str) -> None:
    ensure_dirs()
    if step not in STEP_FUNCTIONS:
        raise KeyError(f'Unknown pipeline step: {step}')
    STEP_FUNCTIONS[step]()


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python -m airline_demo.pipeline_worker <step>')
    execute_step(sys.argv[1])
