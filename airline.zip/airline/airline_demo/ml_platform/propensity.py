from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
from sklearn.model_selection import train_test_split

from airline_demo.config.settings import ANCILLARIES, DATA_DIR, MODEL_DIR, RANDOM_SEED

NUMERIC_BOOKING_FEATURES = [
    'distance_miles', 'duration_minutes', 'business_route_score', 'leisure_route_score', 'lead_time_days',
    'trip_duration_days', 'adults', 'children', 'party_size', 'upgrade_inventory',
]
NUMERIC_PASSENGER_FEATURES = [
    'age', 'price_sensitivity', 'annual_trips', 'historical_ancillary_spend', 'total_bookings', 'avg_lead_time',
    'avg_distance', 'avg_duration', 'family_booking_rate', 'premium_cabin_rate', 'business_route_avg',
    'leisure_route_avg', 'avg_party_size', 'international_rate', 'offer_acceptance_rate', 'click_rate',
    'rejection_rate', 'total_ancillary_spend', 'purchased_offer_count', 'unique_offer_count', 'loyalty_score',
    'corporate_flag_int', 'spend_per_trip', 'bundle_acceptance_rate', 'emb_comfort', 'emb_business',
    'emb_family', 'emb_budget', 'emb_premium', 'emb_digital', 'emb_convenience', 'emb_airport', 'emb_inflight',
]
CATEGORICAL_FEATURES = ['persona', 'loyalty_tier', 'fare_family', 'cabin', 'origin', 'destination', 'journey_stage']


class IsotonicCalibratedLightGBM:
    """Serializable LightGBM classifier with a held-out isotonic calibrator."""

    def __init__(self, base_model: LGBMClassifier, calibrator: IsotonicRegression):
        self.base_model = base_model
        self.calibrator = calibrator

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        raw = self.base_model.predict_proba(X)[:, 1]
        calibrated = np.clip(self.calibrator.predict(raw), 0, 1)
        return np.column_stack([1 - calibrated, calibrated])


def _training_frame() -> pd.DataFrame:
    offers = pd.read_csv(DATA_DIR / 'offer_history.csv')
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    features = pd.read_csv(DATA_DIR / 'feature_store' / 'passenger_features.csv')
    df = offers.merge(bookings.drop(columns=['journey_stage'], errors='ignore'), on=['booking_id', 'session_id', 'flight_id', 'passenger_id'], how='left')
    return df.merge(features, on='passenger_id', how='left', suffixes=('', '_passenger')).fillna(0)


def _candidate_frame_all_bookings() -> pd.DataFrame:
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    features = pd.read_csv(DATA_DIR / 'feature_store' / 'passenger_features.csv')
    rows = []
    for _, b in bookings.iterrows():
        for anc in ANCILLARIES:
            row = b.to_dict()
            row.update({'offer_id': anc['offer_id'], 'offer_name': anc['name'], 'price': anc['price']})
            rows.append(row)
    return pd.DataFrame(rows).merge(features, on='passenger_id', how='left', suffixes=('', '_passenger')).fillna(0)


def _encode(X: pd.DataFrame, feature_columns: list[str] | None = None) -> pd.DataFrame:
    cols = [c for c in NUMERIC_PASSENGER_FEATURES + NUMERIC_BOOKING_FEATURES if c in X.columns] + [c for c in CATEGORICAL_FEATURES if c in X.columns]
    encoded = pd.get_dummies(X[cols], columns=[c for c in CATEGORICAL_FEATURES if c in X.columns], dummy_na=True)
    encoded = encoded.replace([np.inf, -np.inf], 0).fillna(0)
    return encoded.reindex(columns=feature_columns, fill_value=0) if feature_columns is not None else encoded


def _model() -> LGBMClassifier:
    return LGBMClassifier(
        n_estimators=90, learning_rate=.055, num_leaves=25, min_child_samples=18,
        subsample=.90, colsample_bytree=.90, random_state=RANDOM_SEED,
        n_jobs=1, verbosity=-1, deterministic=True, force_col_wise=True,
    )


def train_propensity_models() -> None:
    df = _training_frame()
    all_bookings = _candidate_frame_all_bookings()
    registry, calibration_rows, scores = [], [], []

    for anc in ANCILLARIES:
        offer_id = anc['offer_id']
        sub = df[df.offer_id == offer_id].copy()
        y = sub.accepted.astype(int)
        if y.nunique() < 2 or y.sum() < 8 or (len(y) - y.sum()) < 8:
            raise RuntimeError(f'Insufficient positive/negative training samples for {offer_id}. Increase AIRLINE_DEMO_PASSENGERS.')
        X = _encode(sub)
        X_dev, X_test, y_dev, y_test = train_test_split(X, y, test_size=.22, random_state=RANDOM_SEED, stratify=y)
        X_train, X_cal, y_train, y_cal = train_test_split(X_dev, y_dev, test_size=.25, random_state=RANDOM_SEED + 1, stratify=y_dev)
        base = _model()
        base.fit(X_train, y_train)
        cal_raw = base.predict_proba(X_cal)[:, 1]
        calibrator = IsotonicRegression(out_of_bounds='clip', y_min=0.001, y_max=.999)
        calibrator.fit(cal_raw, y_cal)
        model = IsotonicCalibratedLightGBM(base, calibrator)
        p = model.predict_proba(X_test)[:, 1]
        auc = float(roc_auc_score(y_test, p)) if y_test.nunique() > 1 else float('nan')
        brier = float(brier_score_loss(y_test, p))
        artifact = {'calibrated_model': model, 'base_model': base, 'isotonic_calibrator': calibrator, 'feature_columns': list(X.columns), 'offer_id': offer_id}
        joblib.dump(artifact, MODEL_DIR / 'propensity' / f'{offer_id}_model.joblib')
        registry.append({
            'offer_id': offer_id, 'offer_name': anc['name'], 'algorithm': 'LightGBMClassifier + held-out isotonic calibration',
            'training_rows': len(sub), 'train_rows': len(X_train), 'calibration_rows': len(X_cal), 'test_rows': len(X_test),
            'positive_rate': float(y.mean()), 'auc': auc, 'brier_score': brier,
            'artifact_path': f'model_artifacts/propensity/{offer_id}_model.joblib',
        })
        calibration_rows.append({
            'offer_id': offer_id, 'mean_predicted_probability': float(p.mean()), 'observed_rate': float(y_test.mean()),
            'brier_score': brier, 'calibration_method': 'isotonic_held_out',
        })
        scoring = all_bookings[all_bookings.offer_id == offer_id].copy()
        scoring['propensity_score'] = model.predict_proba(_encode(scoring, list(X.columns)))[:, 1]
        scores.append(scoring[['booking_id', 'session_id', 'flight_id', 'passenger_id', 'journey_stage', 'offer_id', 'offer_name', 'price', 'propensity_score']])

    pd.DataFrame(registry).to_csv(DATA_DIR / 'model_reports' / 'propensity_model_registry.csv', index=False)
    pd.DataFrame(calibration_rows).to_csv(DATA_DIR / 'model_reports' / 'calibration_report.csv', index=False)
    pd.concat(scores, ignore_index=True).to_csv(DATA_DIR / 'model_reports' / 'propensity_scores.csv', index=False)
