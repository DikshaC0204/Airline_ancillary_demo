from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from airline_demo.config.settings import DATA_DIR, ANCILLARIES


def train_collaborative_filtering() -> None:
    purchases = pd.read_csv(DATA_DIR / 'purchases.csv')
    passenger_item = pd.crosstab(purchases['passenger_id'], purchases['offer_id']).clip(upper=1)
    all_offers = [a['offer_id'] for a in ANCILLARIES]
    passenger_item = passenger_item.reindex(columns=all_offers, fill_value=0)
    sim = cosine_similarity(passenger_item.T)
    item_sim = pd.DataFrame(sim, index=all_offers, columns=all_offers).reset_index().rename(columns={'index': 'offer_id'})
    rows = []
    for pid, row in passenger_item.iterrows():
        bought = row.values.astype(float)
        raw_scores = sim.dot(bought)
        for offer_id, score, already in zip(all_offers, raw_scores, bought):
            rows.append({'passenger_id': pid, 'offer_id': offer_id, 'cf_score': float(0 if already > 0 else score / max(1, bought.sum()))})
    item_sim.to_csv(DATA_DIR / 'hybrid_recommender' / 'item_item_similarity.csv', index=False)
    pd.DataFrame(rows).to_csv(DATA_DIR / 'hybrid_recommender' / 'passenger_cf_scores.csv', index=False)


def mine_association_rules() -> None:
    from mlxtend.frequent_patterns import association_rules, fpgrowth
    from mlxtend.preprocessing import TransactionEncoder

    purchases = pd.read_csv(DATA_DIR / 'purchases.csv')
    baskets = purchases.groupby('booking_id')['offer_id'].apply(lambda s: sorted(set(s))).tolist()
    baskets = [b for b in baskets if len(b) > 0]
    if len(baskets) < 20:
        raise RuntimeError('Not enough purchase baskets for FP-Growth. Increase AIRLINE_DEMO_PASSENGERS.')
    te = TransactionEncoder()
    arr = te.fit(baskets).transform(baskets)
    basket_df = pd.DataFrame(arr, columns=te.columns_)
    itemsets = fpgrowth(basket_df, min_support=0.015, use_colnames=True)
    if itemsets.empty:
        itemsets = fpgrowth(basket_df, min_support=0.005, use_colnames=True)
    rules = association_rules(itemsets, metric='confidence', min_threshold=0.08) if not itemsets.empty else pd.DataFrame()
    def fs_to_str(x):
        return '|'.join(sorted(list(x)))
    itemsets = itemsets.copy()
    if not itemsets.empty:
        itemsets['itemsets'] = itemsets['itemsets'].apply(fs_to_str)
    if not rules.empty:
        rules = rules.copy()
        rules['antecedents'] = rules['antecedents'].apply(fs_to_str)
        rules['consequents'] = rules['consequents'].apply(fs_to_str)
    itemsets.to_csv(DATA_DIR / 'hybrid_recommender' / 'frequent_itemsets.csv', index=False)
    rules.to_csv(DATA_DIR / 'hybrid_recommender' / 'association_rules.csv', index=False)
