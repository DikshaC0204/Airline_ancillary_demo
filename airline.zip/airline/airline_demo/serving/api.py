from __future__ import annotations

from typing import Any

import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from airline_demo.config.settings import DATA_DIR
from airline_demo.journey_orchestrator.scenario import get_session_story
from airline_demo.rag.rag_index import answer_question
from airline_demo.simulation.journey_replay import score_live_scenario

app = FastAPI(
    title='Airline AI Journey Decision Intelligence API',
    version='2.0.0',
    description='Artifact-backed recommendation, event redecision, journey replay and grounded explanation API.',
)


class RecommendationRequest(BaseModel):
    booking_id: str
    touchpoint_stage: str


class LiveDecisionRequest(BaseModel):
    booking_id: str
    touchpoint_stage: str
    delay_minutes: float = Field(0, ge=0, le=1440)
    lounge_occupancy: float | None = Field(None, ge=0, le=1)
    fatigue_score: float | None = Field(None, ge=0, le=1)
    gate_distance_minutes: float | None = Field(None, ge=0, le=180)
    security_wait_minutes: float | None = Field(None, ge=0, le=240)
    airport_congestion_score: float | None = Field(None, ge=0, le=1)
    upgrade_inventory_remaining: float | None = Field(None, ge=0)
    inventory_state: dict[str, Any] | None = None
    purchased_products: list[str] = Field(default_factory=list)
    rejected_products: list[str] = Field(default_factory=list)
    top_k: int = Field(5, ge=1, le=20)


class CopilotRequest(BaseModel):
    question: str
    passenger_id: str | None = None


@app.get('/health')
def health():
    core = [
        DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv',
        DATA_DIR / 'simulation' / 'journey_replay.csv',
        DATA_DIR / 'rag' / 'evidence_index.csv',
    ]
    return {'status': 'ok' if all(p.exists() for p in core) else 'artifacts_missing'}


@app.post('/recommendations')
def recommendations(req: RecommendationRequest):
    try:
        story = get_session_story(req.booking_id, req.touchpoint_stage)
    except (IndexError, KeyError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    recs = story['recommendations'].head(10).to_dict(orient='records')
    return {
        'booking_id': req.booking_id,
        'touchpoint_stage': req.touchpoint_stage,
        'session_id': story['session_id'],
        'passenger': story['passenger'],
        'digital_twin': story['digital_twin'],
        'recommendations': recs,
    }


@app.post('/live-decision')
def live_decision(req: LiveDecisionRequest):
    scored = score_live_scenario(
        req.booking_id,
        req.touchpoint_stage,
        delay_minutes=req.delay_minutes,
        lounge_occupancy=req.lounge_occupancy,
        fatigue_score=req.fatigue_score,
        gate_distance_minutes=req.gate_distance_minutes,
        security_wait_minutes=req.security_wait_minutes,
        airport_congestion_score=req.airport_congestion_score,
        upgrade_inventory_remaining=req.upgrade_inventory_remaining,
        inventory_state=req.inventory_state,
        purchased_products=set(req.purchased_products),
        rejected_products=set(req.rejected_products),
    )
    if scored.empty:
        raise HTTPException(status_code=404, detail='No candidate session found for this booking and touchpoint.')
    fields = [
        'live_rank', 'candidate_id', 'offer_id', 'offer_name', 'candidate_type', 'products', 'price',
        'propensity_score', 'expected_revenue', 'operational_utility', 'event_utility_adjustment', 'live_policy_value',
        'live_expected_reward', 'live_uncertainty', 'live_policy_probability', 'suppression_reason',
    ]
    return {
        'booking_id': req.booking_id,
        'touchpoint_stage': req.touchpoint_stage,
        'event_context': req.model_dump(exclude={'purchased_products', 'rejected_products', 'top_k'}),
        'selected_action': scored.iloc[0][fields].to_dict(),
        'ranked_actions': scored.head(req.top_k)[fields].to_dict(orient='records'),
    }


@app.get('/journey-replay/{booking_id}')
def journey_replay(booking_id: str):
    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv')
    rows = replay[replay.booking_id == booking_id].sort_values('stage_order')
    if rows.empty:
        raise HTTPException(status_code=404, detail='Unknown booking or replay not built.')
    return {'booking_id': booking_id, 'journey': rows.to_dict(orient='records')}


@app.post('/copilot')
def copilot(req: CopilotRequest):
    return answer_question(req.question, passenger_id=req.passenger_id)
