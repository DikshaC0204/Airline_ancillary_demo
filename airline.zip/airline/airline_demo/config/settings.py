from __future__ import annotations

import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT_DIR / 'data' / 'generated'
MODEL_DIR = ROOT_DIR / 'model_artifacts'
RANDOM_SEED = 42
DEFAULT_PASSENGERS = int(os.getenv('AIRLINE_DEMO_PASSENGERS', '1000'))
SHOWCASE_STRICT = os.getenv('AIRLINE_SHOWCASE_STRICT', '1') == '1'

JOURNEY_STAGES = [
    'search', 'flight_selection', 'seat_selection', 'payment', 'confirmation',
    'checkin', 'airport', 'boarding', 'in_flight', 'arrival'
]

ANCILLARIES = [
    {'offer_id': 'SEAT_STD', 'name': 'Standard Seat', 'category': 'Seat', 'price': 20, 'start': 'seat_selection', 'end': 'checkin', 'business_priority': 0.55},
    {'offer_id': 'SEAT_LEG', 'name': 'Extra Legroom Seat', 'category': 'Seat', 'price': 45, 'start': 'seat_selection', 'end': 'boarding', 'business_priority': 0.75},
    {'offer_id': 'BAG', 'name': 'Checked Bag', 'category': 'Baggage', 'price': 35, 'start': 'payment', 'end': 'checkin', 'business_priority': 0.65},
    {'offer_id': 'MEAL', 'name': 'Premium Meal', 'category': 'Meal', 'price': 18, 'start': 'payment', 'end': 'boarding', 'business_priority': 0.50},
    {'offer_id': 'LOUNGE', 'name': 'Airport Lounge', 'category': 'Airport', 'price': 55, 'start': 'checkin', 'end': 'airport', 'business_priority': 0.82},
    {'offer_id': 'PRIORITY', 'name': 'Priority Boarding', 'category': 'Airport', 'price': 25, 'start': 'checkin', 'end': 'boarding', 'business_priority': 0.62},
    {'offer_id': 'WIFI', 'name': 'Wi-Fi', 'category': 'In Flight', 'price': 12, 'start': 'boarding', 'end': 'in_flight', 'business_priority': 0.60},
    {'offer_id': 'INSURANCE', 'name': 'Travel Insurance', 'category': 'Protection', 'price': 30, 'start': 'payment', 'end': 'confirmation', 'business_priority': 0.58},
    {'offer_id': 'UPGRADE', 'name': 'Cabin Upgrade', 'category': 'Upgrade', 'price': 120, 'start': 'payment', 'end': 'checkin', 'business_priority': 0.95},
]

OFFER_LOOKUP = {x['offer_id']: x for x in ANCILLARIES}

STATIC_BUNDLES = [
    {'template_id': 'BUSINESS_CORE', 'name': 'Business Bundle', 'products': ['SEAT_LEG', 'LOUNGE', 'WIFI'], 'discount': 0.15},
    {'template_id': 'FAMILY_HELPER', 'name': 'Family Bundle', 'products': ['SEAT_STD', 'BAG', 'MEAL'], 'discount': 0.17},
    {'template_id': 'COMFORT_PLUS', 'name': 'Comfort Bundle', 'products': ['SEAT_LEG', 'MEAL'], 'discount': 0.12},
    {'template_id': 'PREMIUM_AIRPORT', 'name': 'Premium Airport Bundle', 'products': ['LOUNGE', 'PRIORITY', 'WIFI'], 'discount': 0.16},
]

REQUIRED_DEPENDENCIES = {
    'hdbscan': 'hdbscan',
    'lightgbm': 'lightgbm',
    'faiss-cpu': 'faiss',
    'sentence-transformers': 'sentence_transformers',
    'shap': 'shap',
    'mlxtend': 'mlxtend',
    'streamlit': 'streamlit',
    'torch': 'torch',
}

DIGITAL_TWIN_DIMS = [
    'emb_comfort', 'emb_business', 'emb_family', 'emb_budget', 'emb_premium',
    'emb_digital', 'emb_convenience', 'emb_airport', 'emb_inflight'
]
