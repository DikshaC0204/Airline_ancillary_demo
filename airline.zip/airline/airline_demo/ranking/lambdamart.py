from __future__ import annotations

import json
import joblib
import numpy as np
import pandas as pd
from lightgbm import LGBMRanker
from sklearn.metrics import ndcg_score

from airline_demo.config.settings import DATA_DIR, MODEL_DIR, RANDOM_SEED

RANK_FEATURES = [
    'propensity_score', 'expected_revenue', 'embedding_similarity', 'cf_score', 'association_rule_score',
    'content_similarity', 'journey_relevance', 'business_priority', 'inventory_score', 'candidate_fusion_score',
    'price', 'bundle_savings', 'bundle_affinity', 'is_bundle',
    'delay_minutes', 'connection_risk_score', 'airport_dwell_minutes', 'offer_fatigue_score',
    'sequence_accept_probability', 'sequence_reject_probability', 'sequence_bundle_preference',
    'sequence_candidate_score', 'operational_utility', 'fatigue_penalty',
    'lounge_occupancy', 'gate_distance_minutes', 'security_wait_minutes',
    'airport_congestion_score', 'minutes_to_departure', 'upgrade_inventory_remaining',
    'offer_seen_count', 'offer_rejected_count', 'minutes_since_last_offer'
]


def _single_relevance(row: pd.Series, outcomes: dict) -> int:
    r = outcomes.get((row['booking_id'], row['offer_id']))
    if not r:
        return 0
    if r.get('accepted', 0) > 0:
        return 3
    if r.get('clicked', 0) > 0:
        return 1
    return 0


def _bundle_relevance(row: pd.Series, purchased_by_booking: dict) -> int:
    purchased = purchased_by_booking.get(row['booking_id'], set())
    products = set(str(row['products']).split('|'))
    hits = len(products.intersection(purchased))
    if hits == len(products) and hits > 0:
        return 3
    if hits > 0:
        return 1
    return 0


def train_lambdamart_ranker() -> None:
    singles = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv')
    bundles_path = DATA_DIR / 'bundles' / 'dynamic_bundles.csv'
    bundles = pd.read_csv(bundles_path) if bundles_path.exists() else pd.DataFrame()
    singles = singles[singles['eligible'] == True].copy()
    singles['standalone_value'] = singles['price']
    singles['savings'] = 0.0
    singles['bundle_affinity'] = 0.0
    singles['why_generated'] = 'Single ancillary candidate'
    singles['is_bundle'] = 0
    singles['bundle_savings'] = 0.0
    if not bundles.empty:
        bundles['is_bundle'] = 1
        bundles['bundle_savings'] = bundles['savings']
    common_cols = sorted(set(singles.columns).union(set(bundles.columns if not bundles.empty else [])))
    all_candidates = pd.concat([singles.reindex(columns=common_cols), bundles.reindex(columns=common_cols)], ignore_index=True)
    all_candidates = all_candidates.fillna({'bundle_savings': 0, 'bundle_affinity': 0, 'is_bundle': 0})
    all_candidates = all_candidates.replace([np.inf, -np.inf], 0).fillna(0)
    for feature in RANK_FEATURES:
        if feature not in all_candidates.columns:
            all_candidates[feature] = 0.0

    outcomes_df = pd.read_csv(DATA_DIR / 'offer_history.csv')
    outcomes = outcomes_df.groupby(['booking_id', 'offer_id']).agg(clicked=('clicked', 'max'), accepted=('accepted', 'max')).reset_index()
    outcome_map = {(r.booking_id, r.offer_id): {'clicked': int(r.clicked), 'accepted': int(r.accepted)} for r in outcomes.itertuples()}
    purchases = pd.read_csv(DATA_DIR / 'purchases.csv')
    purchased_map = purchases.groupby('booking_id')['offer_id'].apply(lambda s: set(s)).to_dict()

    labels = []
    for _, r in all_candidates.iterrows():
        if r['candidate_type'] == 'bundle':
            labels.append(_bundle_relevance(r, purchased_map))
        else:
            labels.append(_single_relevance(r, outcome_map))
    all_candidates['relevance'] = labels
    all_candidates = all_candidates.sort_values('session_id').reset_index(drop=True)
    X = all_candidates[RANK_FEATURES].astype(float).replace([np.inf, -np.inf], 0).fillna(0)
    y = all_candidates['relevance'].astype(int)
    group = all_candidates.groupby('session_id', sort=False).size().tolist()
    if len(group) < 20 or y.nunique() < 2:
        raise RuntimeError('Insufficient query groups/relevance labels for LambdaMART ranker. Increase AIRLINE_DEMO_PASSENGERS.')
    ranker = LGBMRanker(
        objective='lambdarank', metric='ndcg', n_estimators=70, learning_rate=0.065,
        num_leaves=19, min_child_samples=20, random_state=RANDOM_SEED, verbose=-1, n_jobs=1,
        deterministic=True, force_col_wise=True,
    )
    ranker.fit(X, y, group=group)
    all_candidates['final_rank_score'] = ranker.predict(X)
    all_candidates['rank_position'] = all_candidates.groupby('session_id')['final_rank_score'].rank(ascending=False, method='first').astype(int)

    metrics = {}
    for k in [3, 5, 10]:
        vals = []
        for _, g in all_candidates.groupby('session_id'):
            if len(g) >= 2 and g['relevance'].sum() > 0:
                vals.append(ndcg_score([g['relevance'].values], [g['final_rank_score'].values], k=min(k, len(g))))
        metrics[f'ndcg@{k}'] = float(np.mean(vals)) if vals else 0.0
    metrics['training_rows'] = int(len(all_candidates))
    metrics['query_groups'] = int(len(group))

    importance = pd.DataFrame({'feature': RANK_FEATURES, 'importance': ranker.feature_importances_}).sort_values('importance', ascending=False)
    all_candidates.to_csv(DATA_DIR / 'ranking' / 'ltr_training_data.csv', index=False)
    all_candidates.sort_values(['session_id', 'rank_position']).to_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv', index=False)
    importance.to_csv(DATA_DIR / 'ranking' / 'ltr_feature_importance.csv', index=False)
    (DATA_DIR / 'ranking' / 'ltr_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    joblib.dump({'ranker': ranker, 'features': RANK_FEATURES}, MODEL_DIR / 'ranking' / 'lambdamart_ranker.joblib')
