PREMIUM_CSS = """
<style>
.stApp { background: radial-gradient(circle at top left, #102040 0%, #070B16 38%, #04060D 100%); color: #F5F7FF; }
.block-container { padding-top: 1.5rem; max-width: 1500px; }
.metric-card { background: rgba(20, 34, 64, 0.78); border: 1px solid rgba(77, 208, 225, 0.25); border-radius: 18px; padding: 18px; box-shadow: 0 10px 30px rgba(0,0,0,.25); }
.flow-card { background: rgba(12, 18, 36, .88); border: 1px solid rgba(167, 139, 250, .25); border-radius: 16px; padding: 14px; margin: 8px 0; }
.offer-card { background: linear-gradient(135deg, rgba(18, 34, 62, .94), rgba(42, 28, 70, .80)); border: 1px solid rgba(68, 231, 231, .35); border-radius: 20px; padding: 18px; margin-bottom: 12px; }
.badge { display: inline-block; border-radius: 999px; padding: 4px 10px; margin: 3px; background: rgba(80, 230, 220, .12); border: 1px solid rgba(80, 230, 220, .32); color: #9FF9F3; font-size: 12px; }
.gold { color: #FFD166; } .cyan { color: #55E6F6; } .purple { color: #B79CFF; }
.timeline { display: flex; flex-wrap: wrap; gap: 8px; margin: 8px 0 18px 0; }
.timeline span { padding: 7px 11px; border-radius: 999px; background: rgba(255,255,255,.07); border: 1px solid rgba(255,255,255,.13); font-size: 12px; }
</style>
"""
