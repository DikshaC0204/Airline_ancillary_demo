from __future__ import annotations

import numpy as np
import pandas as pd

from airline_demo.config.settings import ANCILLARIES, DATA_DIR, JOURNEY_STAGES
from airline_demo.inventory.inventory_engine import inventory_check, load_inventory
from airline_demo.recommendation.eligibility import offer_stage_eligible, stage_state


def _association_map(passenger_history: dict[str, set[str]], rules: pd.DataFrame) -> dict[tuple[str, str], float]:
    if rules.empty:
        return {}
    parsed = []
    for r in rules.itertuples():
        ants = set(str(r.antecedents).split('|')) if str(r.antecedents) else set()
        cons = set(str(r.consequents).split('|')) if str(r.consequents) else set()
        parsed.append((ants, cons, float(getattr(r, 'confidence', 0)), float(getattr(r, 'lift', 1))))
    result = {}
    for passenger_id, history in passenger_history.items():
        for ants, cons, confidence, lift in parsed:
            if ants and ants.issubset(history):
                score = min(1.0, confidence * lift / 3.0)
                for offer_id in cons:
                    key = (passenger_id, offer_id)
                    result[key] = max(result.get(key, 0.0), score)
    return result


def generate_candidate_fusion() -> None:
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    scores = pd.read_csv(DATA_DIR / 'model_reports' / 'propensity_scores.csv')[['booking_id', 'offer_id', 'propensity_score']]
    retrieval = pd.read_csv(DATA_DIR / 'retrieval' / 'passenger_offer_retrieval.csv')[['passenger_id', 'offer_id', 'embedding_similarity']]
    cf = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'passenger_cf_scores.csv')[['passenger_id', 'offer_id', 'cf_score']]
    rules_path = DATA_DIR / 'hybrid_recommender' / 'association_rules.csv'
    rules = pd.read_csv(rules_path) if rules_path.exists() else pd.DataFrame()
    purchases = pd.read_csv(DATA_DIR / 'purchases.csv')
    inventory = load_inventory()

    passenger_history = purchases.groupby('passenger_id')['offer_id'].apply(set).to_dict() if not purchases.empty else {}
    assoc_map = _association_map(passenger_history, rules)
    purchased_pairs = purchases[['passenger_id', 'offer_id']].drop_duplicates().assign(already_purchased=True) if not purchases.empty else pd.DataFrame(columns=['passenger_id', 'offer_id', 'already_purchased'])

    offers = pd.DataFrame(ANCILLARIES).rename(columns={'name': 'offer_name'})
    stages = pd.DataFrame({'touchpoint_stage': JOURNEY_STAGES})
    base = bookings.assign(_k=1).merge(stages.assign(_k=1), on='_k').drop(columns='_k')
    base = base.assign(_k=1).merge(offers.assign(_k=1), on='_k').drop(columns='_k')
    base['session_id'] = base.booking_id.astype(str) + '__' + base.touchpoint_stage.astype(str)
    base['candidate_id'] = base.session_id + '__' + base.offer_id
    base['candidate_type'] = 'single'
    base['products'] = base.offer_id

    eligibility_rows = []
    for stage in JOURNEY_STAGES:
        for anc in ANCILLARIES:
            oid = anc['offer_id']
            eligibility_rows.append({
                'touchpoint_stage': stage, 'offer_id': oid,
                'stage_eligible': offer_stage_eligible(oid, stage), 'stage_state': stage_state(oid, stage),
            })
    eligibility = pd.DataFrame(eligibility_rows)

    inv_rows = []
    for inv in inventory.to_dict(orient='records'):
        for anc in ANCILLARIES:
            ok, reason, _ = inventory_check(inv, [anc['offer_id']])
            inv_rows.append({'flight_id': inv['flight_id'], 'offer_id': anc['offer_id'], 'inventory_eligible': ok, 'inventory_reason': reason, 'inventory_score': float(ok)})
    inv_df = pd.DataFrame(inv_rows)

    out = base.merge(scores, on=['booking_id', 'offer_id'], how='left')
    out = out.merge(retrieval, on=['passenger_id', 'offer_id'], how='left')
    out = out.merge(cf, on=['passenger_id', 'offer_id'], how='left')
    out = out.merge(eligibility, on=['touchpoint_stage', 'offer_id'], how='left')
    out = out.merge(inv_df, on=['flight_id', 'offer_id'], how='left')
    out = out.merge(purchased_pairs, on=['passenger_id', 'offer_id'], how='left')
    out['already_purchased'] = out.already_purchased.fillna(False).astype(bool)
    out['association_rule_score'] = [assoc_map.get((p, o), 0.0) for p, o in zip(out.passenger_id, out.offer_id)]
    out[['propensity_score', 'embedding_similarity', 'cf_score', 'inventory_score']] = out[['propensity_score', 'embedding_similarity', 'cf_score', 'inventory_score']].fillna(0.0)
    out['stage_eligible'] = out.stage_eligible.fillna(False).astype(bool)
    out['inventory_eligible'] = out.inventory_eligible.fillna(False).astype(bool)
    out['eligible'] = out.stage_eligible & out.inventory_eligible & ~out.already_purchased
    out['journey_relevance'] = np.where(out.stage_eligible, 1.0, np.where(out.stage_state == 'not_yet_eligible', .20, 0.0))
    out['content_similarity'] = .50 * out.embedding_similarity + .25 * out.cf_score + .25 * out.association_rule_score
    out['expected_revenue'] = out.price * out.propensity_score * out.journey_relevance * out.inventory_score * (~out.already_purchased).astype(int)
    out['candidate_fusion_score'] = (
        .34 * out.propensity_score + .17 * out.embedding_similarity + .14 * out.cf_score +
        .11 * out.association_rule_score + .10 * out.journey_relevance + .08 * out.business_priority + .06 * out.inventory_score
    )
    columns = [
        'session_id', 'booking_id', 'passenger_id', 'flight_id', 'touchpoint_stage', 'candidate_id', 'candidate_type',
        'offer_id', 'offer_name', 'products', 'price', 'stage_state', 'stage_eligible', 'inventory_eligible',
        'inventory_reason', 'already_purchased', 'eligible', 'propensity_score', 'embedding_similarity', 'cf_score',
        'association_rule_score', 'content_similarity', 'journey_relevance', 'business_priority', 'inventory_score',
        'expected_revenue', 'candidate_fusion_score',
    ]
    out[columns].to_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv', index=False)
