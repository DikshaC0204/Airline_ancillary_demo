from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd

from airline_demo.config.settings import DATA_DIR, STATIC_BUNDLES
from airline_demo.inventory.inventory_engine import inventory_check, load_inventory


def _bundle_name(products: list[str]) -> str:
    p = set(products)
    if {'SEAT_LEG', 'LOUNGE', 'WIFI'}.issubset(p):
        return 'Business Bundle'
    if {'SEAT_STD', 'BAG', 'MEAL'}.issubset(p):
        return 'Family Bundle'
    if 'UPGRADE' in p:
        return 'Premium Upgrade Bundle'
    if {'LOUNGE', 'PRIORITY'}.issubset(p):
        return 'Airport Comfort Bundle'
    return 'Dynamic Smart Bundle'


def generate_dynamic_bundles(max_bundles_per_session: int = 4) -> None:
    candidates = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv')
    inv_map = load_inventory().set_index('flight_id').to_dict(orient='index')
    rows = []
    bundle_counter = 0

    eligible = candidates[(candidates.eligible == True) & (candidates.candidate_type == 'single')].copy()
    eligible = eligible.sort_values(['session_id', 'candidate_fusion_score'], ascending=[True, False])
    for session_id, group in eligible.groupby('session_id', sort=False):
        records = group.head(6).to_dict(orient='records')
        if len(records) < 2:
            continue
        by_offer = {r['offer_id']: r for r in records}
        combos: list[tuple[str, ...]] = []
        top_ids = list(by_offer)
        combos.extend(combinations(top_ids[:5], 2))
        combos.extend(combinations(top_ids[:5], 3))
        for template in STATIC_BUNDLES:
            if set(template['products']).issubset(by_offer):
                combos.append(tuple(template['products']))
        first = records[0]
        seen = set(); kept = 0
        for combo in combos:
            products = tuple(sorted(set(combo)))
            if len(products) < 2 or products in seen:
                continue
            seen.add(products)
            sub = [by_offer[x] for x in products if x in by_offer]
            if len(sub) != len(products):
                continue
            ok, reason, _ = inventory_check(inv_map.get(first['flight_id'], {}), products)
            if not ok:
                continue
            def mean(name: str, default: float = 0.0) -> float:
                return float(np.mean([float(r.get(name, default) or default) for r in sub]))
            def maximum(name: str, default: float = 0.0) -> float:
                return float(np.max([float(r.get(name, default) or default) for r in sub]))
            standalone = float(sum(float(r['price']) for r in sub))
            discount = .14 + min(.08, .02 * len(products))
            price = round(standalone * (1 - discount), 2)
            bundle_pref = mean('sequence_bundle_preference', .30)
            bundle_propensity = float(np.clip(mean('propensity_score') * (1 + .08 * (len(products) - 1)) + .10 * (bundle_pref - .5), .005, .98))
            affinity = float(np.clip(.4 * maximum('association_rule_score') + .3 * mean('cf_score') + .3 * mean('embedding_similarity'), 0, 1))
            expected_revenue = price * bundle_propensity
            bundle_counter += 1
            fusion = float(.37 * bundle_propensity + .16 * affinity + .18 * mean('candidate_fusion_score') + .15 * min(1, expected_revenue / 120) + .14 * bundle_pref)
            rows.append({
                'session_id': session_id, 'booking_id': first['booking_id'], 'passenger_id': first['passenger_id'], 'flight_id': first['flight_id'],
                'touchpoint_stage': first['touchpoint_stage'], 'candidate_id': f'{session_id}__BND_{bundle_counter:07d}',
                'candidate_type': 'bundle', 'offer_id': 'BUNDLE', 'offer_name': _bundle_name(list(products)),
                'products': '|'.join(products), 'price': price, 'standalone_value': standalone,
                'savings': round(standalone - price, 2), 'savings_pct': round((standalone - price) / standalone, 4),
                'bundle_propensity': bundle_propensity, 'bundle_affinity': affinity, 'propensity_score': bundle_propensity,
                'embedding_similarity': mean('embedding_similarity'), 'cf_score': mean('cf_score'),
                'association_rule_score': maximum('association_rule_score'), 'content_similarity': mean('content_similarity'),
                'journey_relevance': min(1.35, mean('journey_relevance')), 'business_priority': mean('business_priority'),
                'inventory_score': 1.0, 'inventory_eligible': True, 'inventory_reason': reason, 'eligible': True,
                'expected_revenue': expected_revenue, 'candidate_fusion_score': fusion,
                'delay_minutes': maximum('delay_minutes'), 'connection_risk_score': maximum('connection_risk_score'),
                'airport_dwell_minutes': maximum('airport_dwell_minutes'), 'offer_fatigue_score': maximum('offer_fatigue_score'),
                'sequence_accept_probability': mean('sequence_accept_probability', .15),
                'sequence_reject_probability': mean('sequence_reject_probability', .15),
                'sequence_bundle_preference': bundle_pref, 'sequence_candidate_score': mean('sequence_candidate_score', .20),
                'operational_utility': mean('operational_utility'), 'fatigue_penalty': maximum('fatigue_penalty'),
                'why_generated': 'Top compatible products from propensity, sequence state, FAISS, CF, association rules, event context and inventory',
            })
            kept += 1
            if kept >= max_bundles_per_session:
                break
    pd.DataFrame(rows).to_csv(DATA_DIR / 'bundles' / 'dynamic_bundles.csv', index=False)
