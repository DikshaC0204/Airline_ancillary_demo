from __future__ import annotations

from airline_demo.config.settings import JOURNEY_STAGES, OFFER_LOOKUP


def stage_index(stage: str) -> int:
    return JOURNEY_STAGES.index(stage)


def offer_stage_eligible(offer_id: str, stage: str) -> bool:
    offer = OFFER_LOOKUP[offer_id]
    return stage_index(offer['start']) <= stage_index(stage) <= stage_index(offer['end'])


def stage_state(offer_id: str, stage: str) -> str:
    offer = OFFER_LOOKUP[offer_id]
    if stage_index(stage) < stage_index(offer['start']):
        return 'not_yet_eligible'
    if stage_index(stage) > stage_index(offer['end']):
        return 'expired'
    return 'eligible'
