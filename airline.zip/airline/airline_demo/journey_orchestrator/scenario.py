from __future__ import annotations

import pandas as pd

from airline_demo.config.settings import DATA_DIR, JOURNEY_STAGES


def list_passenger_sessions() -> pd.DataFrame:
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv')
    return bookings.merge(passengers[['passenger_id', 'persona', 'loyalty_tier']], on='passenger_id', how='left')


def get_session_story(booking_id: str, touchpoint_stage: str) -> dict:
    session_id = f'{booking_id}__{touchpoint_stage}'
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv')
    twins = pd.read_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv')
    ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    fusion = pd.read_csv(DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv')
    traces = pd.read_csv(DATA_DIR / 'decision_trace' / 'decision_trace_steps.csv') if (DATA_DIR / 'decision_trace' / 'decision_trace_steps.csv').exists() else pd.DataFrame()
    b = bookings[bookings.booking_id == booking_id].iloc[0]
    p = passengers[passengers.passenger_id == b.passenger_id].iloc[0]
    t = twins[twins.passenger_id == b.passenger_id].iloc[0]
    recs = ranked[ranked.session_id == session_id].sort_values('rank_position').head(10)
    f = fusion[fusion.session_id == session_id]
    trace = pd.DataFrame()
    if not traces.empty and not recs.empty:
        trace = traces[traces.candidate_id == recs.iloc[0].candidate_id]
    return {
        'booking': b.to_dict(), 'passenger': p.to_dict(), 'digital_twin': t.to_dict(),
        'recommendations': recs, 'fusion_candidates': f, 'decision_trace': trace,
        'session_id': session_id, 'touchpoint_stage': touchpoint_stage,
    }


def journey_stage_delta(booking_id: str) -> pd.DataFrame:
    ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    rows = []
    for stage in JOURNEY_STAGES:
        session_id = f'{booking_id}__{stage}'
        g = ranked[ranked.session_id == session_id].sort_values('rank_position').head(1)
        if not g.empty:
            r = g.iloc[0]
            rows.append({'touchpoint_stage': stage, 'top_offer': r.offer_name, 'products': r.products, 'expected_revenue': r.expected_revenue, 'propensity_score': r.propensity_score, 'candidate_type': r.candidate_type})
    return pd.DataFrame(rows)
