from __future__ import annotations

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import normalize

from airline_demo.config.settings import ANCILLARIES, DATA_DIR, DIGITAL_TWIN_DIMS, JOURNEY_STAGES, MODEL_DIR

OFFER_VECTOR_DIMS = [
    'comfort', 'business', 'family', 'budget', 'premium', 'digital', 'convenience', 'airport', 'inflight', 'price_level', 'urgency'
]

OFFER_TAGS = {
    'SEAT_STD': [0.45, 0.10, 0.65, 0.55, 0.15, 0.05, 0.45, 0.05, 0.10, 0.25, 0.35],
    'SEAT_LEG': [0.85, 0.60, 0.25, 0.15, 0.55, 0.10, 0.65, 0.05, 0.20, 0.45, 0.50],
    'BAG': [0.25, 0.10, 0.80, 0.55, 0.10, 0.05, 0.70, 0.10, 0.05, 0.35, 0.45],
    'MEAL': [0.50, 0.20, 0.55, 0.30, 0.25, 0.05, 0.35, 0.05, 0.70, 0.20, 0.40],
    'LOUNGE': [0.75, 0.85, 0.15, 0.05, 0.85, 0.20, 0.70, 0.95, 0.05, 0.55, 0.70],
    'PRIORITY': [0.35, 0.75, 0.30, 0.15, 0.55, 0.15, 0.85, 0.85, 0.05, 0.30, 0.75],
    'WIFI': [0.35, 0.80, 0.15, 0.25, 0.35, 0.95, 0.40, 0.05, 0.95, 0.15, 0.55],
    'INSURANCE': [0.20, 0.25, 0.55, 0.35, 0.20, 0.20, 0.45, 0.05, 0.05, 0.30, 0.40],
    'UPGRADE': [0.95, 0.90, 0.10, 0.02, 0.98, 0.20, 0.75, 0.50, 0.40, 0.95, 0.80],
}


def _stage_midpoint(offer: dict) -> float:
    idx = {s: i for i, s in enumerate(JOURNEY_STAGES)}
    return (idx[offer['start']] + idx[offer['end']]) / (2 * max(1, len(JOURNEY_STAGES)-1))


def build_passenger_offer_embeddings_and_faiss(k: int = 6) -> None:
    import faiss

    twins = pd.read_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv')
    passenger_vectors = twins[DIGITAL_TWIN_DIMS].fillna(0).to_numpy(dtype='float32')
    passenger_vectors = normalize(passenger_vectors, norm='l2').astype('float32')
    p_index = twins[['passenger_id', 'persona', 'cohort_label']].copy() if 'cohort_label' in twins.columns else twins[['passenger_id', 'persona']].copy()
    np.save(DATA_DIR / 'embeddings' / 'passenger_embeddings.npy', passenger_vectors)
    p_index.to_csv(DATA_DIR / 'embeddings' / 'passenger_embedding_index.csv', index=False)

    offer_rows, offer_vectors = [], []
    for offer in ANCILLARIES:
        vec = np.array(OFFER_TAGS[offer['offer_id']], dtype='float32')
        # Align offer semantic dimensions to the 9 digital-twin dimensions plus commercial dimensions.
        offer_vectors.append(vec)
        offer_rows.append({
            'offer_id': offer['offer_id'], 'offer_name': offer['name'], 'category': offer['category'], 'price': offer['price'],
            'stage_midpoint': _stage_midpoint(offer), **{d: float(v) for d, v in zip(OFFER_VECTOR_DIMS, vec)}
        })
    offer_vectors = normalize(np.vstack(offer_vectors), norm='l2').astype('float32')
    offer_index = pd.DataFrame(offer_rows)
    np.save(DATA_DIR / 'embeddings' / 'offer_embeddings.npy', offer_vectors)
    offer_index.to_csv(DATA_DIR / 'embeddings' / 'offer_embedding_index.csv', index=False)

    # Project passenger vector to offer vector dimensions by expanding with interpretable commercial dimensions.
    p_ext = np.column_stack([
        twins['emb_comfort'], twins['emb_business'], twins['emb_family'], twins['emb_budget'], twins['emb_premium'],
        twins['emb_digital'], twins['emb_convenience'], twins['emb_airport'], twins['emb_inflight'],
        1 - twins['price_sensitivity'], twins['offer_acceptance_rate'] if 'offer_acceptance_rate' in twins.columns else np.repeat(0.5, len(twins))
    ]).astype('float32')
    p_ext = normalize(p_ext, norm='l2').astype('float32')

    index = faiss.IndexFlatIP(offer_vectors.shape[1])
    index.add(offer_vectors)
    scores, idxs = index.search(p_ext, min(k, len(offer_vectors)))
    retrieval = []
    for i, passenger_id in enumerate(twins['passenger_id']):
        for rank, (score, oidx) in enumerate(zip(scores[i], idxs[i]), start=1):
            retrieval.append({
                'passenger_id': passenger_id, 'retrieval_rank': rank, 'offer_id': offer_index.iloc[int(oidx)].offer_id,
                'offer_name': offer_index.iloc[int(oidx)].offer_name, 'embedding_similarity': float(score),
                'retrieval_reason': 'Nearest offer in Digital Twin to offer semantic embedding space',
            })
    pd.DataFrame(retrieval).to_csv(DATA_DIR / 'retrieval' / 'passenger_offer_retrieval.csv', index=False)
    faiss.write_index(index, str(MODEL_DIR / 'embeddings' / 'faiss_offer_index.bin'))
    joblib.dump({'offer_vector_dims': OFFER_VECTOR_DIMS, 'digital_twin_dims': DIGITAL_TWIN_DIMS}, MODEL_DIR / 'embeddings' / 'embedding_metadata.joblib')
