from __future__ import annotations

import json
from typing import Any

import joblib
import numpy as np
import pandas as pd

from airline_demo.bandits.contextual_policy import BANDIT_FEATURES, _feature_frame, _softmax
from airline_demo.config.settings import DATA_DIR, JOURNEY_STAGES, MODEL_DIR, OFFER_LOOKUP, RANDOM_SEED
from airline_demo.inventory.inventory_engine import inventory_check


def _products(row: pd.Series) -> set[str]:
    text = str(row.get('products', '') or '')
    return {x for x in text.split('|') if x}


def _outcome(row: pd.Series, fatigue: float, rng: np.random.Generator) -> tuple[str, float]:
    if row.offer_id == 'NO_OFFER':
        return 'no_offer', .24 if fatigue >= .48 else (.06 if fatigue >= .38 else -.30)
    p = (
        .68 * float(row.get('propensity_score', .1))
        + .14 * float(row.get('sequence_accept_probability', .15))
        + .10 * max(0.0, float(row.get('operational_utility', 0)))
        + .08 * float(row.get('candidate_fusion_score', 0))
    )
    if str(row.get('candidate_type')) == 'bundle':
        p += .12 * (float(row.get('sequence_bundle_preference', .3)) - .35)
    p -= .15 * fatigue
    p = float(np.clip(p, .025, .88))
    u = rng.random()
    if u < p:
        return 'accepted', 1.05 + min(1.6, float(row.get('price', 0)) * .52 / 90)
    if u < p + .18:
        return 'clicked', .24
    if u < p + .34:
        return 'rejected', -.32
    return 'ignored', -.035


def build_journey_replays(max_bookings: int | None = None) -> None:
    decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    stage_snap = pd.read_csv(DATA_DIR / 'event_platform' / 'stage_feature_snapshots.csv')
    events = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_event_stream.csv')
    bookings = pd.read_csv(DATA_DIR / 'bookings.csv')
    passengers = pd.read_csv(DATA_DIR / 'passengers.csv')
    booking_order = bookings.booking_id.tolist()[:max_bookings] if max_bookings else bookings.booking_id.tolist()
    stage_idx = {stage: i for i, stage in enumerate(JOURNEY_STAGES)}
    rng = np.random.default_rng(RANDOM_SEED + 1129)
    rows: list[dict[str, Any]] = []

    passenger_map = passengers.set_index('passenger_id').to_dict(orient='index')
    booking_map = bookings.set_index('booking_id').to_dict(orient='index')
    decision_groups = {key: group.sort_values('bandit_rank') for key, group in decisions.groupby('session_id', sort=False)}
    snap_map = {(r.booking_id, r.journey_stage): r._asdict() for r in stage_snap.itertuples(index=False)}
    event_groups = {(key[0], key[1]): group.sort_values('event_timestamp') for key, group in events.groupby(['booking_id', 'journey_stage'], sort=False)}

    for booking_id in booking_order:
        b = booking_map[booking_id]
        p = passenger_map[b['passenger_id']]
        purchased: set[str] = set()
        rejected: set[str] = set()
        fatigue = 0.0
        previous_offer = ''
        previous_revenue = 0.0
        for stage in JOURNEY_STAGES:
            session_id = f'{booking_id}__{stage}'
            g = decision_groups.get(session_id)
            if g is None or g.empty:
                continue
            snap_row = snap_map.get((booking_id, stage), {})
            event_g = event_groups.get((booking_id, stage), pd.DataFrame())
            if not event_g.empty:
                operational = event_g[event_g.event_type.isin(['flight_delayed', 'gate_changed'])]
                trigger = str(operational.iloc[-1].event_type) if not operational.empty else str(event_g.iloc[0].event_type)
            else:
                trigger = 'touchpoint_entered'

            selected = None
            suppression_reasons = []
            for cand in g.itertuples(index=False):
                cand_series = pd.Series(cand._asdict())
                products = _products(cand_series)
                if products & purchased:
                    suppression_reasons.append({'offer': cand_series.offer_name, 'reason': 'already_purchased'})
                    continue
                if products & rejected:
                    suppression_reasons.append({'offer': cand_series.offer_name, 'reason': 'recently_rejected'})
                    continue
                selected = cand_series
                break
            if selected is None:
                no_offer = g[g.offer_id == 'NO_OFFER']
                selected = no_offer.iloc[0] if not no_offer.empty else g.iloc[0]

            fatigue_before = fatigue
            outcome, reward = _outcome(selected, fatigue, rng)
            products = _products(selected)
            if outcome == 'accepted':
                purchased |= products; fatigue = max(0.0, fatigue - .18)
            elif outcome == 'rejected':
                rejected |= products; fatigue = min(1.0, fatigue + .22)
            elif outcome == 'ignored':
                fatigue = min(1.0, fatigue + .10)
            elif outcome == 'clicked':
                fatigue = min(1.0, fatigue + .04)
            else:
                fatigue = max(0.0, fatigue - .08)

            top3 = g.head(3)[['offer_name', 'candidate_type', 'bandit_rank', 'bandit_policy_value', 'target_policy_probability', 'expected_revenue']].to_dict(orient='records')
            delay_value = snap_row.get('delay_minutes', 0)
            delay = float(delay_value) if pd.notna(delay_value) else 0.0
            risk_value = snap_row.get('connection_risk_score', 0)
            risk = float(risk_value) if pd.notna(risk_value) else 0.0
            feature_changes = {
                'journey_stage': stage, 'delay_minutes': delay, 'connection_risk_score': risk,
                'offer_fatigue_score_before_decision': round(fatigue_before, 3),
                'sequence_accept_probability': float(selected.get('sequence_accept_probability', 0)),
                'sequence_bundle_preference': float(selected.get('sequence_bundle_preference', 0)),
            }
            reason_parts = [
                f"bandit policy value {float(selected.get('bandit_policy_value', 0)):.3f}",
                f"LambdaMART score {float(selected.get('final_rank_score', 0)):.3f}",
                f"propensity {float(selected.get('propensity_score', 0)):.1%}",
            ]
            if delay > 0:
                reason_parts.append(f'{int(delay)} minute delay changed operational utility')
            if selected.offer_id == 'NO_OFFER':
                reason_parts.append('fatigue and negative-response risk favored preserving experience')
            rows.append({
                'replay_id': f'REPLAY_{booking_id}_{stage}', 'booking_id': booking_id, 'passenger_id': b['passenger_id'],
                'persona': p['persona'], 'flight_id': b['flight_id'], 'journey_stage': stage, 'stage_order': stage_idx[stage],
                'trigger_event': trigger, 'selected_candidate_id': selected.candidate_id, 'selected_offer': selected.offer_name,
                'selected_products': selected.products, 'candidate_type': selected.candidate_type, 'price': float(selected.price),
                'expected_revenue': float(selected.expected_revenue), 'bandit_policy_value': float(selected.bandit_policy_value),
                'bandit_probability': float(selected.target_policy_probability), 'exploration_bonus': float(selected.exploration_bonus),
                'outcome': outcome, 'reward': reward, 'fatigue_after': fatigue,
                'purchased_products_after': '|'.join(sorted(purchased)), 'rejected_products_after': '|'.join(sorted(rejected)),
                'previous_top_offer': previous_offer, 'offer_changed': int(previous_offer != '' and previous_offer != selected.offer_name),
                'expected_revenue_delta': float(selected.expected_revenue - previous_revenue),
                'features_new_or_changed': json.dumps(feature_changes), 'suppressed_candidates': json.dumps(suppression_reasons[:8]),
                'top_three_actions': json.dumps(top3), 'decision_explanation': '; '.join(reason_parts),
            })
            previous_offer = str(selected.offer_name)
            previous_revenue = float(selected.expected_revenue)

    replay = pd.DataFrame(rows).sort_values(['booking_id', 'stage_order'])
    replay.to_csv(DATA_DIR / 'simulation' / 'journey_replay.csv', index=False)
    replay[['booking_id', 'passenger_id', 'journey_stage', 'selected_offer', 'candidate_type', 'outcome', 'offer_changed', 'expected_revenue', 'expected_revenue_delta', 'trigger_event']].to_csv(
        DATA_DIR / 'simulation' / 'journey_offer_changes.csv', index=False
    )


def score_live_scenario(
    booking_id: str,
    journey_stage: str,
    delay_minutes: float = 0.0,
    lounge_occupancy: float | None = None,
    fatigue_score: float | None = None,
    gate_distance_minutes: float | None = None,
    security_wait_minutes: float | None = None,
    airport_congestion_score: float | None = None,
    upgrade_inventory_remaining: float | None = None,
    inventory_state: dict | None = None,
    purchased_products: set[str] | None = None,
    rejected_products: set[str] | None = None,
) -> pd.DataFrame:
    """Re-score a saved candidate set after a live event or passenger interaction."""
    purchased_products = purchased_products or set()
    rejected_products = rejected_products or set()
    decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    session_id = f'{booking_id}__{journey_stage}'
    g = decisions[decisions.session_id == session_id].copy()
    if g.empty:
        return g
    # Keep action payload columns deterministic across pandas/Arrow backends.
    # NO_OFFER rows have no products and otherwise arrive as NaN.
    g['products'] = g['products'].fillna('').astype('object')
    g['offer_name'] = g['offer_name'].fillna('No Offer').astype('object')
    g['delay_minutes'] = float(delay_minutes)
    if lounge_occupancy is not None:
        g['lounge_occupancy'] = float(lounge_occupancy)
    if fatigue_score is not None:
        g['offer_fatigue_score'] = float(fatigue_score)
    if gate_distance_minutes is not None:
        g['gate_distance_minutes'] = float(gate_distance_minutes)
    if security_wait_minutes is not None:
        g['security_wait_minutes'] = float(security_wait_minutes)
    if airport_congestion_score is not None:
        g['airport_congestion_score'] = float(airport_congestion_score)
    if upgrade_inventory_remaining is not None:
        g['upgrade_inventory_remaining'] = float(upgrade_inventory_remaining)
    delay_scale = np.clip(float(delay_minutes) / 180, 0, 1.5)
    congestion = float(g.get('airport_congestion_score', pd.Series([0])).max())
    security = float(g.get('security_wait_minutes', pd.Series([0])).max()) / 60
    gate = float(g.get('gate_distance_minutes', pd.Series([0])).max()) / 35
    space = 1 - float(g.get('lounge_occupancy', pd.Series([0])).max())
    upgrade_space = np.clip(float(g.get('upgrade_inventory_remaining', pd.Series([0])).max()) / 8, 0, 1)

    # Operational events affect both individual products and any bundle that
    # contains them.  Bundle utility is the mean utility of its components,
    # which keeps a three-product bundle from receiving an artificial size bias.
    component_utility = {
        'LOUNGE': .42 * delay_scale + .12 * congestion + .10 * space - .08 * gate,
        'MEAL': .24 * delay_scale,
        'WIFI': .20 * delay_scale,
        'PRIORITY': -.18 * delay_scale + .10 * security + .08 * gate,
        'UPGRADE': .08 * upgrade_space,
        'SEAT_LEG': 0.0,
        'SEAT_STD': 0.0,
        'BAG': 0.0,
        'INSURANCE': 0.0,
    }

    def action_operational_utility(row: pd.Series) -> float:
        products = _products(row)
        if not products or row.get('offer_id') == 'NO_OFFER':
            return 0.0
        return float(np.mean([component_utility.get(product, 0.0) for product in products]))

    g['operational_utility'] = g.apply(action_operational_utility, axis=1)
    g['propensity_score'] = np.clip(g.propensity_score + .12 * g.operational_utility - .08 * g.offer_fatigue_score, .01, .98)
    g['expected_revenue'] = g.price * g.propensity_score * np.clip(g.journey_relevance + g.operational_utility, 0, 1.4) * g.inventory_score
    g['no_offer_action'] = (g.offer_id == 'NO_OFFER').astype(float)
    g.loc[g.offer_id == 'NO_OFFER', 'candidate_fusion_score'] = .08 + .55 * g.loc[g.offer_id == 'NO_OFFER', 'offer_fatigue_score']
    g.loc[g.offer_id == 'NO_OFFER', 'final_rank_score'] = -.2 + 2.2 * g.loc[g.offer_id == 'NO_OFFER', 'offer_fatigue_score']
    artifact = joblib.load(MODEL_DIR / 'bandits' / 'linucb_policy.joblib')
    policy = artifact['policy']
    x = _feature_frame(g).to_numpy(float)
    ucb, mean, uncertainty = policy.score(x)
    # LinUCB supplies the learned exploit/explore value.  A constrained
    # event-utility overlay makes newly arrived operational facts actionable
    # immediately, even before the next offline bandit retraining cycle.
    g['event_utility_adjustment'] = .55 * g['operational_utility']
    g['live_policy_value'] = ucb + g['event_utility_adjustment']
    g['live_expected_reward'] = mean
    g['live_uncertainty'] = uncertainty
    g['suppression_reason'] = ''
    # Apply the same customer-experience no-offer guardrail used in training.
    non_no = g[g.offer_id != 'NO_OFFER']
    max_propensity = float(non_no.propensity_score.max()) if not non_no.empty else 0.0
    max_revenue = float(non_no.expected_revenue.max()) if not non_no.empty else 0.0
    current_fatigue = float(g.offer_fatigue_score.max()) if len(g) else 0.0
    no_offer_allowed = current_fatigue >= .45 or max_propensity < .075 or max_revenue < .65
    no_idx = g.index[g.offer_id == 'NO_OFFER']
    if not no_offer_allowed:
        g.loc[no_idx, 'suppression_reason'] = 'no_offer_guardrail_not_triggered'
        g.loc[no_idx, 'live_policy_value'] = -999
    else:
        experience_value = -.12 + .55 * current_fatigue - .35 * max_propensity - .01 * max_revenue
        g.loc[no_idx, 'live_policy_value'] = np.maximum(g.loc[no_idx, 'live_policy_value'], experience_value)

    bundle_mask = g.candidate_type == 'bundle'
    bundle_adjustment = -.045 + .08 * (g.sequence_bundle_preference.fillna(.3) - .50) + .02 * np.clip(g.bundle_savings.fillna(0) / 50.0, 0, 1)
    g.loc[bundle_mask, 'live_policy_value'] += bundle_adjustment[bundle_mask]
    for idx, row in g.iterrows():
        products = _products(row)
        if inventory_state is not None and row.offer_id != 'NO_OFFER':
            ok, reason, _ = inventory_check(inventory_state, products)
            if not ok:
                g.at[idx, 'suppression_reason'] = f'inventory: {reason}'
                g.at[idx, 'live_policy_value'] = -999
                continue
        if products & purchased_products:
            g.at[idx, 'suppression_reason'] = 'already_purchased'
            g.at[idx, 'live_policy_value'] = -999
        elif products & rejected_products:
            g.at[idx, 'suppression_reason'] = 'recently_rejected'
            g.at[idx, 'live_policy_value'] = -999
    g['live_rank'] = g.live_policy_value.rank(ascending=False, method='first').astype(int)
    probs = _softmax(g.live_policy_value.to_numpy(float), .30)
    g['live_policy_probability'] = probs
    return g.sort_values('live_rank')
