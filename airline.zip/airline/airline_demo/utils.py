from __future__ import annotations

import importlib
import json
from pathlib import Path
from typing import Iterable

import pandas as pd

from airline_demo.config.settings import DATA_DIR, MODEL_DIR, REQUIRED_DEPENDENCIES


def ensure_dirs() -> None:
    for path in [DATA_DIR, MODEL_DIR]:
        path.mkdir(parents=True, exist_ok=True)
    for sub in [
        'feature_store', 'passenger_intelligence', 'embeddings', 'retrieval',
        'model_reports', 'hybrid_recommender', 'bundles', 'inventory', 'ranking',
        'explainability', 'decision_trace', 'rag', 'business_metrics', 'monitoring',
        'event_platform', 'sequence_models', 'bandits', 'simulation'
    ]:
        (DATA_DIR / sub).mkdir(parents=True, exist_ok=True)
    for sub in ['propensity', 'ranking', 'rag', 'cohorts', 'embeddings', 'sequence_models', 'bandits']:
        (MODEL_DIR / sub).mkdir(parents=True, exist_ok=True)


def require_preferred_dependencies(include_streamlit: bool = False) -> None:
    missing = []
    for package, import_name in REQUIRED_DEPENDENCIES.items():
        if package == 'streamlit' and not include_streamlit:
            continue
        try:
            importlib.import_module(import_name)
        except Exception as exc:
            missing.append((package, import_name, str(exc)))
    if missing:
        lines = ['Missing preferred showcase dependencies. No silent fallback is used.']
        for package, import_name, err in missing:
            lines.append(f'- {package} ({import_name}): {err}')
        lines.append('Install with: pip install -r requirements.txt')
        raise RuntimeError('\n'.join(lines))


def read_csv(name: str) -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / name)


def write_csv(df: pd.DataFrame, rel: str) -> Path:
    path = DATA_DIR / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path


def write_json(obj, rel: str) -> Path:
    path = DATA_DIR / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=str), encoding='utf-8')
    return path


def assert_files_exist(paths: Iterable[Path]) -> list[str]:
    missing = [str(p) for p in paths if not p.exists()]
    return missing
