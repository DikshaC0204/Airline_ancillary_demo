from __future__ import annotations

import json
import os
from dataclasses import dataclass

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from airline_demo.config.settings import DATA_DIR, MODEL_DIR, RANDOM_SEED

BANDIT_FEATURES = [
    'propensity_score', 'expected_revenue_scaled', 'embedding_similarity', 'cf_score',
    'association_rule_score', 'journey_relevance', 'business_priority', 'inventory_score',
    'candidate_fusion_score', 'ranker_score_scaled', 'price_scaled', 'is_bundle',
    'bundle_savings_scaled', 'sequence_accept_probability', 'sequence_reject_probability',
    'sequence_bundle_preference', 'operational_utility', 'offer_fatigue_score',
    'delay_scaled', 'connection_risk_score', 'lounge_space', 'gate_distance_scaled',
    'security_wait_scaled', 'airport_congestion_score', 'minutes_to_departure_scaled',
    'upgrade_inventory_scaled', 'offer_seen_scaled', 'offer_rejected_scaled',
    'minutes_since_last_offer_scaled', 'no_offer_action',
]


def _softmax(values: np.ndarray, temperature: float = .55) -> np.ndarray:
    z = (values - np.max(values)) / max(temperature, 1e-4)
    exp = np.exp(np.clip(z, -30, 30))
    return exp / exp.sum()


def _series(g: pd.DataFrame, name: str, default: float = 0.0) -> pd.Series:
    if name in g.columns:
        return pd.to_numeric(g[name], errors='coerce').fillna(default)
    return pd.Series(default, index=g.index, dtype=float)


def _feature_frame(g: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=g.index)
    out['propensity_score'] = _series(g, 'propensity_score')
    out['expected_revenue_scaled'] = np.clip(_series(g, 'expected_revenue') / 120, 0, 2)
    out['embedding_similarity'] = _series(g, 'embedding_similarity')
    out['cf_score'] = _series(g, 'cf_score')
    out['association_rule_score'] = _series(g, 'association_rule_score')
    out['journey_relevance'] = np.clip(_series(g, 'journey_relevance'), 0, 1.5)
    out['business_priority'] = _series(g, 'business_priority')
    out['inventory_score'] = _series(g, 'inventory_score')
    out['candidate_fusion_score'] = np.clip(_series(g, 'candidate_fusion_score'), 0, 1.5)
    out['ranker_score_scaled'] = np.tanh(_series(g, 'final_rank_score') / 3)
    out['price_scaled'] = np.clip(_series(g, 'price') / 180, 0, 2)
    out['is_bundle'] = _series(g, 'is_bundle')
    out['bundle_savings_scaled'] = np.clip(_series(g, 'bundle_savings') / 50, 0, 2)
    out['sequence_accept_probability'] = _series(g, 'sequence_accept_probability', .15)
    out['sequence_reject_probability'] = _series(g, 'sequence_reject_probability', .15)
    out['sequence_bundle_preference'] = _series(g, 'sequence_bundle_preference', .3)
    out['operational_utility'] = _series(g, 'operational_utility')
    out['offer_fatigue_score'] = _series(g, 'offer_fatigue_score')
    out['delay_scaled'] = np.clip(_series(g, 'delay_minutes') / 180, 0, 2)
    out['connection_risk_score'] = _series(g, 'connection_risk_score')
    out['lounge_space'] = 1 - np.clip(_series(g, 'lounge_occupancy'), 0, 1)
    out['gate_distance_scaled'] = np.clip(_series(g, 'gate_distance_minutes') / 35, 0, 2)
    out['security_wait_scaled'] = np.clip(_series(g, 'security_wait_minutes') / 60, 0, 2)
    out['airport_congestion_score'] = np.clip(_series(g, 'airport_congestion_score'), 0, 1)
    out['minutes_to_departure_scaled'] = np.clip(_series(g, 'minutes_to_departure') / 10080, -2, 2)
    out['upgrade_inventory_scaled'] = np.clip(_series(g, 'upgrade_inventory_remaining') / 12, 0, 2)
    out['offer_seen_scaled'] = np.clip(_series(g, 'offer_seen_count') / 12, 0, 2)
    out['offer_rejected_scaled'] = np.clip(_series(g, 'offer_rejected_count') / 8, 0, 2)
    out['minutes_since_last_offer_scaled'] = np.clip(_series(g, 'minutes_since_last_offer') / 10080, 0, 2)
    out['no_offer_action'] = _series(g, 'no_offer_action')
    return out[BANDIT_FEATURES].fillna(0)


@dataclass
class SharedLinUCB:
    alpha: float = .65
    ridge: float = 1.0

    def fit(self, x: np.ndarray, rewards: np.ndarray) -> 'SharedLinUCB':
        d = x.shape[1]
        self.a = self.ridge * np.eye(d) + x.T @ x
        self.b = x.T @ rewards
        self.a_inv = np.linalg.inv(self.a)
        self.theta = self.a_inv @ self.b
        return self

    def score(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        mean = x @ self.theta
        uncertainty = np.sqrt(np.maximum(0, np.einsum('ij,jk,ik->i', x, self.a_inv, x)))
        return mean + self.alpha * uncertainty, mean, uncertainty


def _simulated_outcome(row: pd.Series, rng: np.random.Generator) -> tuple[str, float]:
    """Generate logged feedback for the synthetic policy environment.

    The simulator rewards commercial value and customer relevance while retaining
    rejection/fatigue costs. NO_OFFER is beneficial only when fatigue is genuinely
    high; otherwise it carries an opportunity-cost penalty.
    """
    fatigue = float(row.get('offer_fatigue_score', 0))
    if row.offer_id == 'NO_OFFER':
        if fatigue >= .48:
            return 'no_offer', .24
        if fatigue >= .38:
            return 'no_offer', .06
        return 'no_offer', -.30
    p = (
        .68 * float(row.get('propensity_score', .1))
        + .14 * float(row.get('sequence_accept_probability', .15))
        + .10 * max(0.0, float(row.get('operational_utility', 0)))
        + .08 * float(row.get('candidate_fusion_score', 0))
    )
    if int(row.get('is_bundle', 0)):
        p += .12 * (float(row.get('sequence_bundle_preference', .3)) - .35)
    p -= .15 * fatigue
    p = float(np.clip(p, .025, .88))
    u = rng.random()
    if u < p:
        margin = float(row.get('price', 0)) * (.58 if int(row.get('is_bundle', 0)) else .50)
        return 'accepted', 1.05 + min(1.6, margin / 90)
    if u < p + .18:
        return 'clicked', .24
    if u < p + .34:
        return 'rejected', -.32
    return 'ignored', -.035


def _add_no_offer_rows(actions: pd.DataFrame) -> pd.DataFrame:
    no_offer = actions.sort_values(['session_id', 'final_rank_score'], ascending=[True, False]).groupby('session_id', sort=False).head(1).copy()
    numeric_zero = [
        'propensity_score', 'expected_revenue', 'embedding_similarity', 'cf_score', 'association_rule_score',
        'content_similarity', 'price', 'bundle_savings', 'bundle_affinity', 'is_bundle', 'sequence_accept_probability',
        'operational_utility',
    ]
    for c in numeric_zero:
        no_offer[c] = 0.0
    no_offer['candidate_id'] = no_offer.session_id.astype(str) + '__NO_OFFER'
    no_offer['candidate_type'] = 'no_offer'; no_offer['offer_id'] = 'NO_OFFER'
    no_offer['offer_name'] = 'No Offer / Preserve Experience'; no_offer['products'] = ''
    no_offer['eligible'] = True; no_offer['inventory_eligible'] = True; no_offer['inventory_reason'] = 'no_inventory_required'
    no_offer['no_offer_action'] = 1.0
    no_offer['journey_relevance'] = np.minimum(1.0, .15 + _series(no_offer, 'offer_fatigue_score'))
    no_offer['business_priority'] = .20
    no_offer['candidate_fusion_score'] = .08 + .55 * _series(no_offer, 'offer_fatigue_score')
    no_offer['final_rank_score'] = -.2 + 2.2 * _series(no_offer, 'offer_fatigue_score')
    no_offer['rank_position'] = actions.groupby('session_id').rank_position.transform('max').reindex(no_offer.index).fillna(8).astype(int) + 1
    return pd.concat([actions, no_offer], ignore_index=True)


def train_contextual_bandit() -> None:
    ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
    ranked = ranked[(ranked.eligible == True) & (ranked.inventory_eligible == True)].copy()
    ranked = ranked.sort_values(['session_id', 'final_rank_score'], ascending=[True, False]).groupby('session_id', sort=False).head(8).copy()
    ranked['no_offer_action'] = 0.0
    actions = _add_no_offer_rows(ranked).reset_index(drop=True)
    feature_cols = [f'bandit_feature__{f}' for f in BANDIT_FEATURES]
    features = _feature_frame(actions)
    for f in BANDIT_FEATURES:
        actions[f'bandit_feature__{f}'] = features[f].to_numpy()

    # Exploratory logging policy: softmax baseline plus uniform support.
    baseline = actions.final_rank_score.to_numpy(float)
    group_max = actions.groupby('session_id').final_rank_score.transform('max').to_numpy(float)
    exp = np.exp(np.clip((baseline - group_max) / .72, -30, 30))
    group_sum = pd.Series(exp).groupby(actions.session_id).transform('sum').to_numpy(float)
    sizes = actions.groupby('session_id').session_id.transform('size').to_numpy(float)
    actions['logging_probability'] = .82 * exp / group_sum + .18 / sizes
    actions['logged_chosen'] = 0; actions['logged_outcome'] = ''; actions['logged_reward'] = np.nan

    rng = np.random.default_rng(RANDOM_SEED + 811)
    chosen_indices = []
    for _, idx in actions.groupby('session_id', sort=False).indices.items():
        idx = np.asarray(idx, dtype=int)
        probs = actions.loc[idx, 'logging_probability'].to_numpy(float)
        probs = probs / probs.sum()
        chosen_indices.append(int(rng.choice(idx, p=probs)))
    actions.loc[chosen_indices, 'logged_chosen'] = 1
    for idx in chosen_indices:
        outcome, reward = _simulated_outcome(actions.loc[idx], rng)
        actions.at[idx, 'logged_outcome'] = outcome
        actions.at[idx, 'logged_reward'] = reward

    chosen = actions.loc[chosen_indices].copy()
    X = chosen[feature_cols].to_numpy(float); y = chosen.logged_reward.to_numpy(float)
    if len(chosen) < 100:
        raise RuntimeError('Insufficient contextual-bandit decisions. Increase AIRLINE_DEMO_PASSENGERS.')
    policy = SharedLinUCB(alpha=float(os.getenv('AIRLINE_BANDIT_ALPHA', '.65')), ridge=1.5).fit(X, y)

    x_all = actions[feature_cols].to_numpy(float)
    ucb, mean, uncertainty = policy.score(x_all)
    actions['bandit_policy_value'] = ucb; actions['bandit_expected_reward'] = mean
    actions['bandit_uncertainty'] = uncertainty; actions['exploration_bonus'] = policy.alpha * uncertainty

    # Customer-experience guardrail: NO_OFFER remains a learned action, but is
    # admissible only for high fatigue or weak feasible commercial actions.
    non_no = actions[actions.offer_id != 'NO_OFFER']
    max_propensity = non_no.groupby('session_id').propensity_score.max()
    max_revenue = non_no.groupby('session_id').expected_revenue.max()
    no_mask = actions.offer_id == 'NO_OFFER'
    fatigue = actions.offer_fatigue_score.fillna(0)
    actions['guardrail_eligible'] = True
    no_allowed = (
        (fatigue >= .45)
        | (actions.session_id.map(max_propensity).fillna(0) < .075)
        | (actions.session_id.map(max_revenue).fillna(0) < .65)
    )
    actions.loc[no_mask & ~no_allowed, 'guardrail_eligible'] = False
    actions.loc[no_mask & ~no_allowed, 'bandit_policy_value'] = -3.0
    actions.loc[no_mask & ~no_allowed, 'bandit_expected_reward'] = np.minimum(
        actions.loc[no_mask & ~no_allowed, 'bandit_expected_reward'], -.25
    )

    # Calibrate action complexity: bundles must beat a modest cognitive/price
    # complexity cost, while still winning when sequence preference and savings
    # support them. This keeps the policy genuinely single-versus-bundle.
    bundle_mask = actions.candidate_type == 'bundle'
    bundle_adjustment = (
        -.045
        + .08 * (actions.sequence_bundle_preference.fillna(.3) - .50)
        + .02 * np.clip(actions.bundle_savings.fillna(0) / 50.0, 0, 1)
    )
    actions.loc[bundle_mask, 'bandit_policy_value'] += bundle_adjustment[bundle_mask]
    actions['policy_complexity_adjustment'] = np.where(bundle_mask, bundle_adjustment, 0.0)

    # Give the no-offer action an explicit experience-preservation value using
    # current fatigue and the strength of the best commercial alternative.
    no_offer_experience_value = (
        -.12 + .55 * fatigue
        - .35 * actions.session_id.map(max_propensity).fillna(0)
        - .01 * actions.session_id.map(max_revenue).fillna(0)
    )
    actions.loc[no_mask & no_allowed, 'bandit_policy_value'] = np.maximum(
        actions.loc[no_mask & no_allowed, 'bandit_policy_value'],
        no_offer_experience_value[no_mask & no_allowed],
    )
    actions['no_offer_experience_value'] = np.where(no_mask, no_offer_experience_value, 0.0)
    ucb = actions.bandit_policy_value.to_numpy(float)
    group_max = actions.groupby('session_id').bandit_policy_value.transform('max').to_numpy(float)
    target_exp = np.exp(np.clip((ucb - group_max) / .30, -30, 30))
    target_sum = pd.Series(target_exp).groupby(actions.session_id).transform('sum').to_numpy(float)
    actions['target_policy_probability'] = .97 * target_exp / target_sum + .03 / sizes
    actions['bandit_rank'] = actions.groupby('session_id').bandit_policy_value.rank(ascending=False, method='first').astype(int)
    actions['bandit_selected'] = (actions.bandit_rank == 1).astype(int)

    reward_model = Ridge(alpha=2.0).fit(X, y)
    actions['reward_model_prediction'] = reward_model.predict(x_all)
    actions['target_q_component'] = actions.target_policy_probability * actions.reward_model_prediction
    target_q = actions.groupby('session_id').target_q_component.sum()
    logged = actions[actions.logged_chosen == 1].copy()
    logged['importance_weight'] = logged.target_policy_probability / logged.logging_probability.clip(lower=1e-5)
    logged['ips_term'] = logged.importance_weight * logged.logged_reward
    logged['dr_term'] = logged.session_id.map(target_q) + logged.importance_weight * (logged.logged_reward - logged.reward_model_prediction)
    selected = actions[actions.bandit_selected == 1]
    weights = logged.importance_weight.to_numpy(float)
    metrics = {
        'policy': 'shared_linucb_action_dependent_features', 'training_decisions': int(len(chosen)),
        'action_rows': int(len(actions)), 'alpha': policy.alpha,
        'logging_policy_mean_reward': float(chosen.logged_reward.mean()),
        'ips_estimated_policy_value': float(logged.ips_term.mean()),
        'doubly_robust_estimated_policy_value': float(logged.dr_term.mean()),
        'effective_sample_size': float(weights.sum() ** 2 / max(np.square(weights).sum(), 1e-9)),
        'no_offer_selection_rate': float((selected.offer_id == 'NO_OFFER').mean()),
        'no_offer_guardrail_eligible_rate': float(actions.loc[actions.offer_id == 'NO_OFFER', 'guardrail_eligible'].mean()),
        'bundle_selection_rate': float((selected.candidate_type == 'bundle').mean()),
        'mean_exploration_bonus': float(selected.exploration_bonus.mean()),
    }
    actions.to_csv(DATA_DIR / 'bandits' / 'bandit_training_log.csv', index=False)
    actions.sort_values(['session_id', 'bandit_rank']).to_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv', index=False)
    (DATA_DIR / 'bandits' / 'bandit_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
    pd.DataFrame({'feature': BANDIT_FEATURES, 'coefficient': policy.theta}).sort_values('coefficient', key=lambda s: s.abs(), ascending=False).to_csv(DATA_DIR / 'bandits' / 'bandit_feature_weights.csv', index=False)
    joblib.dump({'policy': policy, 'features': BANDIT_FEATURES, 'reward_model': reward_model}, MODEL_DIR / 'bandits' / 'linucb_policy.joblib')
