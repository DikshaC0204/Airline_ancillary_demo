from __future__ import annotations

import json
import pandas as pd

from airline_demo.config.settings import DATA_DIR

TRACE_STEPS = [
    'passenger_loaded', 'point_in_time_features_materialized', 'digital_twin_created', 'cohort_assigned',
    'journey_sequence_encoded', 'next_behavior_predicted', 'touchpoint_and_event_context_applied',
    'eligible_actions_generated', 'inventory_checked', 'propensity_models_scored', 'faiss_retrieval_added',
    'collaborative_filtering_added', 'association_rules_applied', 'dynamic_bundles_generated',
    'lambdamart_baseline_ranked', 'contextual_bandit_policy_scored', 'guardrails_and_suppression_applied',
    'final_action_selected', 'outcome_and_reward_logged', 'explanation_generated',
]


def build_decision_traces() -> None:
    policy = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    selected = policy[policy.bandit_selected == 1].copy()
    twins = pd.read_csv(DATA_DIR / 'feature_store' / 'digital_twins.csv')
    seq = pd.read_csv(DATA_DIR / 'sequence_models' / 'sequence_state_features.csv')
    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv') if (DATA_DIR / 'simulation' / 'journey_replay.csv').exists() else pd.DataFrame()
    shap_df = pd.read_csv(DATA_DIR / 'explainability' / 'top_attributions.csv') if (DATA_DIR / 'explainability' / 'top_attributions.csv').exists() else pd.DataFrame()
    twin_map = twins.set_index('passenger_id').to_dict(orient='index')
    seq_map = {(r.booking_id, r.touchpoint_stage): r._asdict() for r in seq.itertuples()}
    replay_map = {(r.booking_id, r.journey_stage): r._asdict() for r in replay.itertuples()} if not replay.empty else {}
    traces, payloads = [], {}

    for _, r in selected.iterrows():
        trace_id = f"TRACE_{r['session_id']}"
        twin = twin_map.get(r.passenger_id, {})
        s = seq_map.get((r.booking_id, r.touchpoint_stage), {})
        rp = replay_map.get((r.booking_id, r.touchpoint_stage), {})
        shap_features = shap_df[shap_df.candidate_id == r.candidate_id].head(6).to_dict(orient='records') if not shap_df.empty else []
        step_payload = {
            'passenger_loaded': {'passenger_id': r.passenger_id, 'booking_id': r.booking_id, 'flight_id': r.flight_id},
            'point_in_time_features_materialized': {
                'delay_minutes': float(r.get('delay_minutes', 0)), 'connection_risk_score': float(r.get('connection_risk_score', 0)),
                'offer_fatigue_score': float(r.get('offer_fatigue_score', 0)), 'touchpoint': r.touchpoint_stage,
            },
            'digital_twin_created': {'dominant_orientation': twin.get('dominant_orientation'), 'summary': twin.get('digital_twin_summary')},
            'cohort_assigned': {'cohort_label': twin.get('cohort_label'), 'cluster_probability': twin.get('cluster_probability')},
            'journey_sequence_encoded': {'state_norm': s.get('sequence_state_norm'), 'state_event_id': s.get('state_event_id')},
            'next_behavior_predicted': {
                'predicted_next_event': s.get('predicted_next_event'), 'next_event_probability': s.get('predicted_next_event_probability'),
                'accept_probability': s.get('sequence_accept_probability'), 'reject_probability': s.get('sequence_reject_probability'),
                'bundle_preference': s.get('sequence_bundle_preference'), 'minutes_to_next_event': s.get('predicted_minutes_to_next_event'),
            },
            'touchpoint_and_event_context_applied': {'touchpoint': r.touchpoint_stage, 'operational_utility': float(r.get('operational_utility', 0)), 'trigger_event': rp.get('trigger_event')},
            'eligible_actions_generated': {'candidate_type': r.candidate_type, 'products': r.products, 'eligible': bool(r.eligible)},
            'inventory_checked': {'inventory_eligible': bool(r.inventory_eligible), 'inventory_reason': r.get('inventory_reason', '')},
            'propensity_models_scored': {'propensity_score': float(r.propensity_score)},
            'faiss_retrieval_added': {'embedding_similarity': float(r.embedding_similarity)},
            'collaborative_filtering_added': {'cf_score': float(r.cf_score)},
            'association_rules_applied': {'association_rule_score': float(r.association_rule_score)},
            'dynamic_bundles_generated': {'candidate_type': r.candidate_type, 'bundle_savings': float(r.get('bundle_savings', 0)), 'bundle_preference': float(r.get('sequence_bundle_preference', 0))},
            'lambdamart_baseline_ranked': {'rank_position': int(r.rank_position), 'final_rank_score': float(r.final_rank_score)},
            'contextual_bandit_policy_scored': {
                'policy_value': float(r.bandit_policy_value), 'expected_reward': float(r.bandit_expected_reward),
                'uncertainty': float(r.bandit_uncertainty), 'exploration_bonus': float(r.exploration_bonus),
                'action_probability': float(r.target_policy_probability),
            },
            'guardrails_and_suppression_applied': {'no_offer_action': bool(r.offer_id == 'NO_OFFER'), 'inventory_guardrail': bool(r.inventory_eligible)},
            'final_action_selected': {'offer_name': r.offer_name, 'products': r.products, 'price': float(r.price), 'candidate_type': r.candidate_type},
            'outcome_and_reward_logged': {'outcome': rp.get('outcome'), 'reward': rp.get('reward'), 'purchased_after': rp.get('purchased_products_after'), 'rejected_after': rp.get('rejected_products_after')},
            'explanation_generated': {'top_shap_drivers': shap_features, 'decision_explanation': rp.get('decision_explanation')},
        }
        payloads[trace_id] = step_payload
        for i, step in enumerate(TRACE_STEPS, start=1):
            traces.append({
                'trace_id': trace_id, 'candidate_id': r.candidate_id, 'session_id': r.session_id,
                'step_number': i, 'step_name': step, 'step_status': 'completed',
                'evidence': json.dumps(step_payload.get(step, {}), default=str),
            })
    pd.DataFrame(traces).to_csv(DATA_DIR / 'decision_trace' / 'decision_trace_steps.csv', index=False)
    (DATA_DIR / 'decision_trace' / 'decision_trace_payloads.json').write_text(json.dumps(payloads, indent=2, default=str), encoding='utf-8')
