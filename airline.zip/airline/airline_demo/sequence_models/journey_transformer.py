from __future__ import annotations

import json
import math
import os
from dataclasses import dataclass

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from airline_demo.config.settings import DATA_DIR, JOURNEY_STAGES, MODEL_DIR, RANDOM_SEED

PAD = '<PAD>'
UNK = '<UNK>'
RESPONSE_CLASSES = ['none', 'accepted', 'rejected', 'ignored', 'clicked']
NUMERIC_FEATURES = [
    'time_gap_minutes', 'minutes_to_departure', 'delay_minutes', 'connection_risk_score',
    'offer_fatigue_score', 'offer_seen_count', 'offer_rejected_count', 'offer_accepted_count',
    'gate_distance_minutes', 'lounge_occupancy', 'search_repetition_count',
    'schedule_sensitivity', 'seat_map_dwell_seconds', 'seats_viewed_count',
    'security_wait_minutes', 'airport_congestion_score', 'upgrade_inventory_remaining',
    'minutes_since_last_offer',
]


def _token_frame(df: pd.DataFrame) -> pd.Series:
    offer = df['offer_id'].fillna('').astype(str)
    outcome = df['outcome'].fillna('').astype(str)
    suffix = np.where(offer.ne(''), ':' + offer, '')
    suffix = suffix + np.where(outcome.ne(''), ':' + outcome, '')
    return df['event_type'].astype(str) + suffix


def _numeric_matrix(g: pd.DataFrame) -> np.ndarray:
    ts = pd.to_datetime(g.event_timestamp)
    gap = ts.diff().dt.total_seconds().div(60).fillna(0).clip(lower=0)
    def col(name: str, default: float = 0.0) -> pd.Series:
        if name not in g.columns:
            return pd.Series(default, index=g.index, dtype=float)
        return pd.to_numeric(g[name], errors='coerce').fillna(default)
    return np.column_stack([
        np.log1p(gap.to_numpy(float)) / 8.0,
        np.clip(col('minutes_to_departure').to_numpy(float) / 50000, -1, 1),
        col('delay_minutes').to_numpy(float) / 240,
        col('connection_risk_score').to_numpy(float),
        col('offer_fatigue_score').to_numpy(float),
        np.minimum(col('offer_seen_count').to_numpy(float), 12) / 12,
        np.minimum(col('offer_rejected_count').to_numpy(float), 8) / 8,
        np.minimum(col('offer_accepted_count').to_numpy(float), 8) / 8,
        col('gate_distance_minutes').to_numpy(float) / 35,
        col('lounge_occupancy').to_numpy(float),
        np.minimum(col('search_repetition_count').to_numpy(float), 8) / 8,
        col('schedule_sensitivity').to_numpy(float),
        np.minimum(col('seat_map_dwell_seconds').to_numpy(float), 600) / 600,
        np.minimum(col('seats_viewed_count').to_numpy(float), 20) / 20,
        np.minimum(col('security_wait_minutes').to_numpy(float), 60) / 60,
        col('airport_congestion_score').to_numpy(float),
        np.minimum(col('upgrade_inventory_remaining').to_numpy(float), 12) / 12,
        np.minimum(col('minutes_since_last_offer').to_numpy(float), 10080) / 10080,
    ]).astype('float32')


@dataclass
class Example:
    tokens: np.ndarray
    stages: np.ndarray
    numeric: np.ndarray
    target_token: int = 0
    target_response: int = 0
    target_log_minutes: float = 0.0
    bundle_target: float = 0.0
    booking_id: str = ''
    metadata: dict | None = None


class JourneyDataset(Dataset):
    def __init__(self, examples: list[Example], max_len: int):
        self.examples = examples
        self.max_len = max_len

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, idx):
        ex = self.examples[idx]
        tokens = ex.tokens[-self.max_len:]
        stages = ex.stages[-self.max_len:]
        numeric = ex.numeric[-self.max_len:]
        n = len(tokens)
        pad = self.max_len - n
        return {
            'token_ids': torch.tensor(np.pad(tokens, (pad, 0)), dtype=torch.long),
            'stage_ids': torch.tensor(np.pad(stages, (pad, 0)), dtype=torch.long),
            'numeric': torch.tensor(np.pad(numeric, ((pad, 0), (0, 0))), dtype=torch.float32),
            'attention_mask': torch.tensor(np.array([0] * pad + [1] * n), dtype=torch.bool),
            'target_token': torch.tensor(ex.target_token, dtype=torch.long),
            'target_response': torch.tensor(ex.target_response, dtype=torch.long),
            'target_log_minutes': torch.tensor(ex.target_log_minutes, dtype=torch.float32),
            'bundle_target': torch.tensor(ex.bundle_target, dtype=torch.float32),
        }


class CausalJourneyTransformer(nn.Module):
    def __init__(self, vocab_size: int, n_stages: int, numeric_dim: int, d_model: int = 40, n_heads: int = 4, n_layers: int = 1, state_dim: int = 20):
        super().__init__()
        self.token_embedding = nn.Embedding(vocab_size, d_model, padding_idx=0)
        self.stage_embedding = nn.Embedding(n_stages + 1, d_model, padding_idx=0)
        self.numeric_projection = nn.Sequential(nn.Linear(numeric_dim, d_model), nn.GELU())
        self.position_embedding = nn.Embedding(96, d_model)
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=n_heads, dim_feedforward=d_model * 2, dropout=.08, batch_first=True)
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers, enable_nested_tensor=False)
        self.state_projection = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, state_dim), nn.Tanh())
        self.next_event_head = nn.Linear(state_dim, vocab_size)
        self.response_head = nn.Linear(state_dim, len(RESPONSE_CLASSES))
        self.time_head = nn.Linear(state_dim, 1)
        self.bundle_head = nn.Linear(state_dim, 1)

    def forward(self, token_ids, stage_ids, numeric, attention_mask):
        b, length = token_ids.shape
        pos = torch.arange(length, device=token_ids.device).unsqueeze(0).expand(b, -1)
        x = self.token_embedding(token_ids) + self.stage_embedding(stage_ids) + self.numeric_projection(numeric) + self.position_embedding(pos)
        causal = torch.triu(torch.ones(length, length, device=token_ids.device, dtype=torch.bool), diagonal=1)
        encoded = self.encoder(x, mask=causal, src_key_padding_mask=~attention_mask)
        final_idx = attention_mask.long().sum(1).clamp(min=1) - 1 + (length - attention_mask.long().sum(1))
        state = encoded[torch.arange(b, device=token_ids.device), final_idx]
        state = self.state_projection(state)
        return {
            'state': state,
            'next_event_logits': self.next_event_head(state),
            'response_logits': self.response_head(state),
            'time_log_minutes': self.time_head(state).squeeze(-1),
            'bundle_logit': self.bundle_head(state).squeeze(-1),
        }


def _build_examples(max_len: int, max_examples: int):
    df = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv')
    df['event_timestamp'] = pd.to_datetime(df.event_timestamp)
    df['token'] = _token_frame(df)
    vocab = {PAD: 0, UNK: 1}
    for token in sorted(df.token.unique()):
        vocab[token] = len(vocab)
    stage_map = {s: i + 1 for i, s in enumerate(JOURNEY_STAGES)}
    groups = list(df.sort_values(['booking_id', 'event_timestamp']).groupby('booking_id', sort=False))
    per_booking = max(4, min(16, max_examples // max(1, len(groups))))
    examples: list[Example] = []
    state_examples: list[Example] = []

    for booking_id, g in groups:
        g = g.reset_index(drop=True)
        token_ids = g.token.map(vocab).to_numpy(np.int64)
        stage_ids = g.journey_stage.map(stage_map).fillna(0).to_numpy(np.int64)
        numeric = _numeric_matrix(g)
        ts = g.event_timestamp.to_numpy()
        candidate_targets = np.arange(1, len(g))
        if len(candidate_targets) > per_booking:
            candidate_targets = np.unique(np.linspace(1, len(g) - 1, per_booking).round().astype(int))
        persona = str(g.iloc[0].get('persona', ''))
        for target_idx in candidate_targets:
            start = max(0, target_idx - max_len)
            target = g.iloc[target_idx]
            outcome = str(target.get('outcome', '') or '')
            response = RESPONSE_CLASSES.index(outcome) if outcome in RESPONSE_CLASSES else 0
            delta = max(0.0, (g.iloc[target_idx].event_timestamp - g.iloc[target_idx - 1].event_timestamp).total_seconds() / 60)
            bundle_target = float(persona in ['Business', 'Family', 'Premium'] and float(target.get('offer_seen_count', 0)) >= 2)
            examples.append(Example(
                token_ids[start:target_idx], stage_ids[start:target_idx], numeric[start:target_idx],
                vocab[str(target.token)], response, math.log1p(delta), bundle_target, booking_id,
            ))
        for stage in JOURNEY_STAGES:
            positions = np.flatnonzero(g.journey_stage.to_numpy() == stage)
            if len(positions):
                end = int(positions[-1]) + 1
                start = max(0, end - max_len)
                last = g.iloc[end - 1]
                state_examples.append(Example(
                    token_ids[start:end], stage_ids[start:end], numeric[start:end], booking_id=booking_id,
                    metadata={
                        'booking_id': booking_id, 'passenger_id': last.passenger_id, 'flight_id': last.flight_id,
                        'touchpoint_stage': stage, 'state_event_id': last.event_id,
                        'state_timestamp': last.event_timestamp.isoformat(),
                    },
                ))
    return examples[:max_examples], state_examples, vocab


def train_journey_transformer() -> None:
    torch.manual_seed(RANDOM_SEED)
    torch.set_num_threads(max(1, int(os.getenv('AIRLINE_TORCH_THREADS', '2'))))
    max_len = int(os.getenv('AIRLINE_SEQUENCE_MAX_LEN', '36'))
    max_examples = int(os.getenv('AIRLINE_SEQUENCE_MAX_EXAMPLES', '14000'))
    epochs = int(os.getenv('AIRLINE_SEQUENCE_EPOCHS', '3'))
    batch_size = int(os.getenv('AIRLINE_SEQUENCE_BATCH_SIZE', '256'))
    examples, state_examples, vocab = _build_examples(max_len, max_examples)
    if len(examples) < 100:
        raise RuntimeError('Insufficient event sequence examples for the journey Transformer.')

    booking_ids = np.array(sorted({e.booking_id for e in examples}))
    rng = np.random.default_rng(RANDOM_SEED)
    rng.shuffle(booking_ids)
    split = max(1, int(.82 * len(booking_ids)))
    train_ids = set(booking_ids[:split])
    train = [e for e in examples if e.booking_id in train_ids]
    test = [e for e in examples if e.booking_id not in train_ids]
    if not test:
        test = train[-max(20, len(train) // 10):]
        train = train[:-len(test)]

    model = CausalJourneyTransformer(len(vocab), len(JOURNEY_STAGES), len(NUMERIC_FEATURES))
    optimizer = torch.optim.AdamW(model.parameters(), lr=2.4e-3, weight_decay=1e-4)
    ce, bce, smooth = nn.CrossEntropyLoss(), nn.BCEWithLogitsLoss(), nn.SmoothL1Loss()
    train_loader = DataLoader(JourneyDataset(train, max_len), batch_size=batch_size, shuffle=True, num_workers=0)
    history = []
    for epoch in range(epochs):
        model.train(); losses = []
        for batch in train_loader:
            out = model(batch['token_ids'], batch['stage_ids'], batch['numeric'], batch['attention_mask'])
            loss = ce(out['next_event_logits'], batch['target_token']) + .55 * ce(out['response_logits'], batch['target_response']) + .18 * smooth(out['time_log_minutes'], batch['target_log_minutes']) + .28 * bce(out['bundle_logit'], batch['bundle_target'])
            optimizer.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 2.0); optimizer.step()
            losses.append(float(loss.detach()))
        history.append({'epoch': epoch + 1, 'train_loss': float(np.mean(losses))})

    model.eval(); total = event_ok = response_ok = bundle_ok = 0; time_errors = []
    test_loader = DataLoader(JourneyDataset(test, max_len), batch_size=batch_size, shuffle=False, num_workers=0)
    with torch.no_grad():
        for batch in test_loader:
            out = model(batch['token_ids'], batch['stage_ids'], batch['numeric'], batch['attention_mask'])
            event_ok += int((out['next_event_logits'].argmax(1) == batch['target_token']).sum())
            response_ok += int((out['response_logits'].argmax(1) == batch['target_response']).sum())
            bundle_ok += int(((torch.sigmoid(out['bundle_logit']) >= .5).float() == batch['bundle_target']).sum())
            pred = torch.expm1(out['time_log_minutes'].clamp(0, 12)); true = torch.expm1(batch['target_log_minutes'])
            time_errors.extend(torch.abs(pred - true).tolist()); total += len(batch['target_token'])

    torch.save({
        'model_state_dict': model.state_dict(), 'vocab': vocab, 'max_len': max_len,
        'numeric_features': NUMERIC_FEATURES, 'journey_stages': JOURNEY_STAGES,
        'model_config': {'vocab_size': len(vocab), 'n_stages': len(JOURNEY_STAGES), 'numeric_dim': len(NUMERIC_FEATURES)},
    }, MODEL_DIR / 'sequence_models' / 'causal_journey_transformer.pt')
    (DATA_DIR / 'sequence_models' / 'event_vocabulary.json').write_text(json.dumps(vocab, indent=2), encoding='utf-8')
    metrics = {
        'architecture': 'causal_transformer_multitask', 'train_examples': len(train), 'test_examples': len(test),
        'vocabulary_size': len(vocab), 'epochs': epochs, 'next_event_accuracy': event_ok / max(total, 1),
        'next_response_accuracy': response_ok / max(total, 1), 'bundle_preference_accuracy': bundle_ok / max(total, 1),
        'time_to_next_event_mae_minutes': float(np.mean(time_errors)) if time_errors else 0.0, 'training_history': history,
    }
    (DATA_DIR / 'sequence_models' / 'sequence_model_metrics.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')

    inv_vocab = {v: k for k, v in vocab.items()}
    state_loader = DataLoader(JourneyDataset(state_examples, max_len), batch_size=batch_size, shuffle=False, num_workers=0)
    state_rows = []; offset = 0
    with torch.no_grad():
        for batch in state_loader:
            out = model(batch['token_ids'], batch['stage_ids'], batch['numeric'], batch['attention_mask'])
            ep = torch.softmax(out['next_event_logits'], 1).cpu().numpy()
            rp = torch.softmax(out['response_logits'], 1).cpu().numpy()
            states = out['state'].cpu().numpy(); bundle = torch.sigmoid(out['bundle_logit']).cpu().numpy()
            minutes = torch.expm1(out['time_log_minutes'].clamp(0, 12)).cpu().numpy()
            for j in range(len(states)):
                ex = state_examples[offset + j]; top = int(ep[j].argmax()); row = dict(ex.metadata or {})
                row.update({
                    'predicted_next_event': inv_vocab.get(top, UNK), 'predicted_next_event_probability': float(ep[j, top]),
                    'sequence_accept_probability': float(rp[j, RESPONSE_CLASSES.index('accepted')]),
                    'sequence_reject_probability': float(rp[j, RESPONSE_CLASSES.index('rejected')]),
                    'sequence_ignore_probability': float(rp[j, RESPONSE_CLASSES.index('ignored')]),
                    'sequence_bundle_preference': float(bundle[j]), 'predicted_minutes_to_next_event': float(minutes[j]),
                    'sequence_state_norm': float(np.linalg.norm(states[j])),
                })
                for i, value in enumerate(states[j]): row[f'seq_state_{i:02d}'] = float(value)
                state_rows.append(row)
            offset += len(states)
    pd.DataFrame(state_rows).to_csv(DATA_DIR / 'sequence_models' / 'sequence_state_features.csv', index=False)
