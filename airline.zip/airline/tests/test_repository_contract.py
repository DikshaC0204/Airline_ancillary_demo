from pathlib import Path

from airline_demo.config.settings import ANCILLARIES, JOURNEY_STAGES, ROOT_DIR


def test_offer_catalog_contract():
    assert len(ANCILLARIES) == 9
    assert 'payment' in JOURNEY_STAGES


def test_required_scripts_exist():
    for rel in ['scripts/run_pipeline.py', 'scripts/healthcheck.py', 'airline_demo/app.py']:
        assert (ROOT_DIR / rel).exists()
