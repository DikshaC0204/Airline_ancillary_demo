from __future__ import annotations

import json

import pandas as pd

from airline_demo.config.settings import DATA_DIR, MODEL_DIR


def test_all_advanced_model_artifacts_exist():
    paths = [
        MODEL_DIR / 'cohorts' / 'hdbscan_cohort_model.joblib',
        MODEL_DIR / 'embeddings' / 'faiss_offer_index.bin',
        MODEL_DIR / 'sequence_models' / 'causal_journey_transformer.pt',
        MODEL_DIR / 'ranking' / 'lambdamart_ranker.joblib',
        MODEL_DIR / 'bandits' / 'linucb_policy.joblib',
        MODEL_DIR / 'rag' / 'faiss_rag_index.bin',
    ]
    paths += list((MODEL_DIR / 'propensity').glob('*_model.joblib'))
    assert all(p.exists() and p.stat().st_size > 0 for p in paths)
    assert len(list((MODEL_DIR / 'propensity').glob('*_model.joblib'))) == 9


def test_model_metrics_are_real_and_nonempty():
    sequence = json.loads((DATA_DIR / 'sequence_models' / 'sequence_model_metrics.json').read_text())
    ranker = json.loads((DATA_DIR / 'ranking' / 'ltr_metrics.json').read_text())
    bandit = json.loads((DATA_DIR / 'bandits' / 'bandit_metrics.json').read_text())
    assert sequence['architecture'] == 'causal_transformer_multitask'
    assert sequence['train_examples'] > 100
    assert 0 <= sequence['next_response_accuracy'] <= 1
    assert ranker['query_groups'] > 0
    assert 0 < ranker['ndcg@3'] <= 1
    assert bandit['training_decisions'] > 100
    assert bandit['effective_sample_size'] > 0
    assert 0 <= bandit['no_offer_selection_rate'] <= .65


def test_dynamic_bundles_and_single_actions_enter_policy():
    decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    assert {'single', 'bundle', 'no_offer'}.issubset(set(decisions.candidate_type.unique()))
    assert decisions.groupby('session_id').bandit_selected.sum().eq(1).all()
