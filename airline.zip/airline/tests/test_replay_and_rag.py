from __future__ import annotations

import pandas as pd

from airline_demo.config.settings import DATA_DIR
from airline_demo.rag.rag_index import answer_question


def test_journey_replay_has_interactions_and_changes():
    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv')
    assert replay.booking_id.nunique() > 0
    assert replay.journey_stage.nunique() >= 6
    assert replay.outcome.isin(['accepted', 'rejected', 'ignored', 'clicked', 'no_offer']).all()
    assert replay.offer_changed.sum() > 0


def test_grounded_rag_returns_evidence():
    passenger_id = pd.read_csv(DATA_DIR / 'passengers.csv').iloc[0].passenger_id
    result = answer_question('Why did the recommendation change after an operational event?', passenger_id=passenger_id)
    assert result['evidence']
    assert 'Grounded answer' in result['answer']
