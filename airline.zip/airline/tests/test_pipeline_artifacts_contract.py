from pathlib import Path

from airline_demo.config.settings import DATA_DIR, MODEL_DIR


def test_artifact_paths_declared():
    expected = [
        DATA_DIR / 'feature_store' / 'passenger_features.csv',
        DATA_DIR / 'model_reports' / 'propensity_model_registry.csv',
        DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv',
        MODEL_DIR / 'ranking' / 'lambdamart_ranker.joblib',
    ]
    # These are created by scripts/run_pipeline.py. The test documents the contract without forcing training during import.
    assert all(str(p).endswith(('.csv', '.joblib')) for p in expected)
