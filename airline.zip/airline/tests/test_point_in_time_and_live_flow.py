from __future__ import annotations

import pandas as pd

from airline_demo.config.settings import DATA_DIR
from airline_demo.simulation.journey_replay import score_live_scenario


def test_delay_is_not_visible_before_delay_event():
    events = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_event_stream.csv', parse_dates=['event_timestamp'])
    snapshots = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv', parse_dates=['event_timestamp'])
    delayed = events[events.event_type == 'flight_delayed']
    assert not delayed.empty
    event = delayed.iloc[0]
    before = snapshots[(snapshots.booking_id == event.booking_id) & (snapshots.event_timestamp < event.event_timestamp)]
    after = snapshots[(snapshots.booking_id == event.booking_id) & (snapshots.event_timestamp >= event.event_timestamp)]
    assert not before.empty and not after.empty
    latest_before = before.sort_values('event_timestamp').iloc[-1]
    first_after = after.sort_values('event_timestamp').iloc[0]
    assert int(latest_before.delay_minutes_available) == 0
    assert int(first_after.delay_minutes_available) == 1
    assert float(first_after.delay_minutes) > 0


def test_live_delay_rescores_operational_actions():
    decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    airport = decisions[(decisions.touchpoint_stage == 'airport') & (decisions.offer_id == 'LOUNGE')]
    assert not airport.empty
    booking_id = airport.iloc[0].booking_id
    before = score_live_scenario(booking_id, 'airport', delay_minutes=0, fatigue_score=.2)
    after = score_live_scenario(booking_id, 'airport', delay_minutes=120, fatigue_score=.2)
    assert not before.empty and not after.empty
    before_lounge = before[before.offer_id == 'LOUNGE'].iloc[0]
    after_lounge = after[after.offer_id == 'LOUNGE'].iloc[0]
    assert after_lounge.operational_utility > before_lounge.operational_utility
    assert after_lounge.expected_revenue >= before_lounge.expected_revenue


def test_accept_reject_suppression_changes_action_set():
    decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
    row = decisions[(decisions.touchpoint_stage == 'airport') & (decisions.offer_id != 'NO_OFFER')].iloc[0]
    products = {x for x in str(row.products).split('|') if x}
    scored = score_live_scenario(row.booking_id, 'airport', purchased_products=products, fatigue_score=.2)
    suppressed = scored[scored.products.astype(str).apply(lambda text: bool({x for x in text.split('|') if x} & products))]
    assert not suppressed.empty
    assert (suppressed.suppression_reason == 'already_purchased').all()
