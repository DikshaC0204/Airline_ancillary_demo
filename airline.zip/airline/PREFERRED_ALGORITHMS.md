# Preferred Algorithms Contract

The default showcase pipeline requires and actually uses:

- HDBSCAN for behavioral cohorts;
- LightGBM classifiers for nine ancillary propensity models;
- held-out isotonic calibration;
- behavioral passenger and offer embeddings;
- FAISS for offer and RAG retrieval;
- item-item collaborative filtering;
- mlxtend FP-Growth and association rules;
- a causal multi-task PyTorch Journey Transformer;
- dynamic single and bundle action generation;
- LightGBM `LGBMRanker` with the LambdaRank objective;
- a constrained shared LinUCB contextual bandit;
- logged-action probabilities, IPS and doubly robust evaluation;
- SHAP for propensity and ranking attribution;
- a locally initialized and contrastively trained BERT SentenceTransformer for RAG;
- deterministic journey, offer, fare and inventory guardrails.

Each listed component trains or builds artifacts in `scripts/run_pipeline.py`, enters the decision flow, appears in the UI, and is checked by healthcheck/tests. Missing preferred dependencies cause a clear failure; there is no silent algorithm downgrade.
