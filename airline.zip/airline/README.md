# Airline AI Journey Decision Intelligence Platform — Advanced End-to-End Demo

This repository is a fully stitched airline ancillary sequencing and bundling showcase. It follows one passenger from search through arrival and continuously decides whether to present a **single ancillary, a dynamic bundle, or no offer**.

The platform combines point-in-time feature materialization, a Passenger Digital Twin, HDBSCAN cohorts, calibrated LightGBM propensity models, passenger/offer embeddings, FAISS retrieval, collaborative filtering, FP-Growth association rules, a multi-task causal Journey Transformer, dynamic bundle generation, inventory constraints, LambdaMART ranking, a safe contextual bandit, SHAP explanations, event-by-event journey replay, decision traces, and grounded RAG.

Use this repository as the definitive advanced demo. The Python package remains `airline_demo`.

## What is actually trained or built

Running `python scripts/run_pipeline.py` executes every stage and writes its artifacts:

1. Synthetic passengers, bookings, offers, purchases, flights and inventory.
2. Chronological journey and offer-interaction events.
3. Point-in-time feature snapshots and availability indicators.
4. Passenger features and Digital Twins.
5. HDBSCAN behavioral cohort model.
6. Passenger and offer embeddings plus FAISS retrieval index.
7. Nine LightGBM ancillary propensity models with isotonic calibration.
8. Item-item collaborative filtering.
9. FP-Growth frequent itemsets and association rules.
10. Multi-task causal PyTorch Journey Transformer.
11. Candidate fusion across all model signals.
12. Dynamic single-versus-bundle action generation.
13. Inventory-aware eligibility.
14. LightGBM LambdaMART ranker.
15. Shared LinUCB contextual bandit with a no-offer action and guardrails.
16. IPS and doubly robust off-policy evaluation.
17. SHAP explanations.
18. Journey replay with accept, reject, ignore, suppress and redecision behavior.
19. Auditable decision trace.
20. Grounded SentenceTransformer/FAISS RAG evidence index.
21. Business and customer-experience metrics.

No preferred model is silently replaced with a fallback.

## Quick start

Python 3.10 or 3.11 is recommended for the broadest native-wheel compatibility.

### Windows PowerShell

```powershell
cd airline_ai_decision_platform_advanced
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/run_pipeline.py
python scripts/healthcheck.py
streamlit run airline_demo/app.py
```

### macOS/Linux

```bash
cd airline_ai_decision_platform_advanced
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/run_pipeline.py
python scripts/healthcheck.py
streamlit run airline_demo/app.py
```

The ZIP contains validation artifacts so the UI can be opened immediately after installing dependencies. Run the pipeline to retrain every model from scratch.

## Configure scale and training

```powershell
$env:AIRLINE_DEMO_PASSENGERS = "1000"
$env:AIRLINE_SEQUENCE_EPOCHS = "3"
$env:AIRLINE_RAG_EPOCHS = "2"
python scripts/run_pipeline.py
```

Useful environment variables:

| Variable | Default | Purpose |
|---|---:|---|
| `AIRLINE_DEMO_PASSENGERS` | `1000` | Number of synthetic passengers |
| `AIRLINE_SEQUENCE_EPOCHS` | `2` | Journey Transformer epochs |
| `AIRLINE_SEQUENCE_MAX_EXAMPLES` | `16000` | Sequence training examples |
| `AIRLINE_BANDIT_ALPHA` | `0.65` | LinUCB exploration strength |
| `AIRLINE_RAG_EPOCHS` | `2` | RAG encoder contrastive epochs |
| `AIRLINE_RAG_TRAIN_PAIRS` | `1600` | Positive/negative RAG pairs |
| `AIRLINE_RAG_EMBEDDING_MODEL` | unset | Optional local/pretrained SentenceTransformer path |

## UI storyline

The workbench is organized in the order the decision is made:

1. **Journey Command Center** — see the changing offer and response at each touchpoint.
2. **Live Event & Interaction Lab** — inject a delay, change fatigue, accept/reject/ignore, and rerank immediately.
3. **Feature Evolution** — inspect only the features known at each event timestamp.
4. **Sequence Intelligence** — show causal Transformer state and next-event/response predictions.
5. **Contextual Bandit** — show exploit/explore/no-offer values and policy uncertainty.
6. **Digital Twin & Cohorts** — explain who the passenger is.
7. **Propensity, Embeddings & Retrieval** — show purchase probability and candidate retrieval.
8. **Hybrid Candidates & Bundles** — compare singles and dynamically created bundles.
9. **Inventory Intelligence** — show capacity checks and blocked actions.
10. **LambdaMART & SHAP** — show baseline ranking and local feature contributions.
11. **Decision Trace** — audit every step.
12. **Grounded RAG Copilot** — answer “why did it change?” from saved evidence.
13. **Business Value** — compare the personalized policy with a generic static-stage policy.
14. **Architecture & Model Registry** — explain how everything is stitched together.

## Central decision flow

```text
Chronological events and current inventory
  → point-in-time feature snapshot
  → Digital Twin and HDBSCAN cohort
  → causal Journey Transformer state
  → calibrated ancillary propensities
  → FAISS + CF + association-rule candidates
  → single and dynamic bundle actions
  → stage, fare, purchase, rejection and inventory constraints
  → LambdaMART baseline rank
  → safe contextual-bandit policy
  → accept / reject / ignore / no-offer outcome
  → reward, suppression and next-touchpoint redecision
  → SHAP, trace, RAG and value reporting
```

## Important modeling boundary

The contextual bandit is trained from a **synthetic randomized logged-policy environment**, because this standalone demo has no real airline exploration log. The code records action probabilities and performs IPS and doubly robust evaluation exactly as a production bandit pipeline requires. Real deployment must replace the simulated reward log with consented airline decision and outcome telemetry.

See `docs/DEMO_STORY.md`, `docs/EVENT_DRIVEN_ARCHITECTURE.md`, `docs/SEQUENCE_MODELS.md`, `docs/CONTEXTUAL_BANDITS.md`, and `docs/DATABRICKS_MIGRATION.md`.
