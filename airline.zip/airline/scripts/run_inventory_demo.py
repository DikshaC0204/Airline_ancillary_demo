import pandas as pd
from airline_demo.config.settings import DATA_DIR
from airline_demo.inventory.inventory_engine import consume_inventory

ranked = pd.read_csv(DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv')
top = ranked[(ranked.rank_position == 1) & (ranked.inventory_eligible == True)].iloc[0]
offers = str(top.products).split('|') if top.candidate_type == 'bundle' else [top.offer_id]
print('Consuming inventory for:', top.flight_id, top.candidate_id, offers)
updated = consume_inventory(top.flight_id, top.candidate_id, offers)
print(updated[updated.flight_id == top.flight_id].to_string(index=False))
