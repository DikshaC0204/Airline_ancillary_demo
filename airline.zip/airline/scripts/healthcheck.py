from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from airline_demo.config.settings import DATA_DIR, MODEL_DIR

REQUIRED_FILES = [
    DATA_DIR / 'passengers.csv',
    DATA_DIR / 'bookings.csv',
    DATA_DIR / 'event_platform' / 'journey_event_stream.csv',
    DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv',
    DATA_DIR / 'event_platform' / 'stage_feature_snapshots.csv',
    DATA_DIR / 'event_platform' / 'feature_availability_registry.csv',
    DATA_DIR / 'feature_store' / 'passenger_features.csv',
    DATA_DIR / 'feature_store' / 'digital_twins.csv',
    MODEL_DIR / 'cohorts' / 'hdbscan_cohort_model.joblib',
    DATA_DIR / 'passenger_intelligence' / 'ml_behavioral_cohorts.csv',
    DATA_DIR / 'embeddings' / 'passenger_embeddings.npy',
    DATA_DIR / 'embeddings' / 'offer_embeddings.npy',
    MODEL_DIR / 'embeddings' / 'faiss_offer_index.bin',
    DATA_DIR / 'retrieval' / 'passenger_offer_retrieval.csv',
    DATA_DIR / 'model_reports' / 'propensity_model_registry.csv',
    DATA_DIR / 'model_reports' / 'calibration_report.csv',
    DATA_DIR / 'hybrid_recommender' / 'item_item_similarity.csv',
    DATA_DIR / 'hybrid_recommender' / 'association_rules.csv',
    DATA_DIR / 'hybrid_recommender' / 'fusion_candidates.csv',
    MODEL_DIR / 'sequence_models' / 'causal_journey_transformer.pt',
    DATA_DIR / 'sequence_models' / 'sequence_state_features.csv',
    DATA_DIR / 'sequence_models' / 'sequence_model_metrics.json',
    DATA_DIR / 'bundles' / 'dynamic_bundles.csv',
    MODEL_DIR / 'ranking' / 'lambdamart_ranker.joblib',
    DATA_DIR / 'ranking' / 'ltr_ranked_candidates.csv',
    DATA_DIR / 'ranking' / 'ltr_metrics.json',
    MODEL_DIR / 'bandits' / 'linucb_policy.joblib',
    DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv',
    DATA_DIR / 'bandits' / 'bandit_metrics.json',
    DATA_DIR / 'explainability' / 'top_attributions.csv',
    DATA_DIR / 'inventory' / 'inventory_snapshots.csv',
    DATA_DIR / 'inventory' / 'flight_inventory_allocation.csv',
    DATA_DIR / 'simulation' / 'journey_replay.csv',
    DATA_DIR / 'simulation' / 'journey_offer_changes.csv',
    DATA_DIR / 'decision_trace' / 'decision_trace_steps.csv',
    MODEL_DIR / 'rag' / 'faiss_rag_index.bin',
    MODEL_DIR / 'rag' / 'local_sentence_transformer' / 'modules.json',
    DATA_DIR / 'rag' / 'evidence_documents.jsonl',
    DATA_DIR / 'rag' / 'embedding_model_metrics.json',
    DATA_DIR / 'business_metrics' / 'business_value_summary.csv',
]

PROPENSITY_MODELS = [
    MODEL_DIR / 'propensity' / f'{offer}_model.joblib'
    for offer in ['SEAT_STD', 'SEAT_LEG', 'BAG', 'MEAL', 'LOUNGE', 'PRIORITY', 'WIFI', 'INSURANCE', 'UPGRADE']
]


def fail(message: str) -> None:
    raise SystemExit(message)


def main() -> None:
    missing = [str(p.relative_to(ROOT)) for p in REQUIRED_FILES + PROPENSITY_MODELS if not p.exists() or p.stat().st_size == 0]
    if missing:
        fail('Missing or empty required artifacts:\n' + '\n'.join(missing) + '\nRun: python scripts/run_pipeline.py')

    registry = pd.read_csv(DATA_DIR / 'model_reports' / 'propensity_model_registry.csv')
    if len(registry) != 9:
        fail(f'Expected nine propensity models, found {len(registry)}.')

    sequence_metrics = json.loads((DATA_DIR / 'sequence_models' / 'sequence_model_metrics.json').read_text())
    if sequence_metrics.get('architecture') != 'causal_transformer_multitask' or sequence_metrics.get('train_examples', 0) < 100:
        fail('Journey Transformer metrics are invalid.')

    rank_metrics = json.loads((DATA_DIR / 'ranking' / 'ltr_metrics.json').read_text())
    if rank_metrics.get('query_groups', 0) <= 0 or rank_metrics.get('ndcg@3', 0) <= 0:
        fail('LambdaMART metrics are invalid.')

    bandit_metrics = json.loads((DATA_DIR / 'bandits' / 'bandit_metrics.json').read_text())
    for field in ['training_decisions', 'ips_estimated_policy_value', 'doubly_robust_estimated_policy_value', 'effective_sample_size']:
        if field not in bandit_metrics:
            fail(f'Contextual-bandit metric missing: {field}')
    no_offer_rate = float(bandit_metrics.get('no_offer_selection_rate', 1.0))
    if not 0.0 <= no_offer_rate <= 0.65:
        fail(f'No-offer selection rate is outside the demonstration guardrail: {no_offer_rate:.3f}')

    replay = pd.read_csv(DATA_DIR / 'simulation' / 'journey_replay.csv')
    if replay.booking_id.nunique() == 0 or replay.journey_stage.nunique() < 6:
        fail('Journey replay does not cover enough passengers or touchpoints.')

    snapshots = pd.read_csv(DATA_DIR / 'event_platform' / 'journey_feature_snapshots.csv')
    if 'delay_minutes_available' not in snapshots.columns or 'offer_fatigue_score' not in snapshots.columns:
        fail('Point-in-time feature availability fields are missing.')

    validation_path = ROOT / 'validation_log.json'
    if not validation_path.exists():
        fail('validation_log.json is missing.')
    validation = json.loads(validation_path.read_text())
    failed_steps = [s for s in validation.get('pipeline_steps', []) if s.get('status') != 'completed']
    if failed_steps:
        fail(f'Pipeline validation contains failed steps: {failed_steps}')

    print('Advanced airline AI healthcheck passed.')
    print(f"- passengers: {pd.read_csv(DATA_DIR / 'passengers.csv').passenger_id.nunique()}")
    print(f"- bookings: {pd.read_csv(DATA_DIR / 'bookings.csv').booking_id.nunique()}")
    print('- trained propensity models: 9')
    print(f"- sequence training examples: {sequence_metrics['train_examples']}")
    print(f"- LambdaMART NDCG@3: {rank_metrics['ndcg@3']:.4f}")
    print(f"- bandit training decisions: {bandit_metrics['training_decisions']}")
    print(f"- no-offer selection rate: {no_offer_rate:.2%}")
    print(f"- replay rows: {len(replay)}")


if __name__ == '__main__':
    main()
