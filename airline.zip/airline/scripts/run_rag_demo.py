from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from airline_demo.config.settings import DATA_DIR
from airline_demo.rag.rag_index import answer_question

p = pd.read_csv(DATA_DIR / 'passengers.csv').iloc[0].passenger_id
ans = answer_question('Why was the recommendation made and what evidence supports it?', passenger_id=p)
print(ans['answer'])
print('\nRetrieved evidence:')
for item in ans.get('evidence', [])[:5]:
    print(f"- {item.get('document_type', 'evidence')}: {item.get('text', '')[:220]}")
