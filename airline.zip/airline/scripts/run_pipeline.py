from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from airline_demo.pipeline import run_pipeline

if __name__ == '__main__':
    result = run_pipeline()
    print('Pipeline completed successfully.')
    for step in result['pipeline_steps']:
        print(f"- {step['step']}: {step['status']} ({step.get('elapsed_seconds', 0):.2f}s)")
