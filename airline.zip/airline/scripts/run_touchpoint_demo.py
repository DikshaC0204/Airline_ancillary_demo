from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from airline_demo.config.settings import DATA_DIR
from airline_demo.simulation.journey_replay import score_live_scenario

decisions = pd.read_csv(DATA_DIR / 'bandits' / 'bandit_policy_decisions.csv')
airport = decisions[(decisions.touchpoint_stage == 'airport') & decisions.products.fillna('').str.contains('LOUNGE')]
booking_id = str(airport.iloc[0].booking_id) if not airport.empty else str(decisions.iloc[0].booking_id)
print(f'Booking: {booking_id}')

outputs = {}
for delay in [0, 105]:
    scored = score_live_scenario(
        booking_id, 'airport', delay_minutes=delay, lounge_occupancy=.45,
        fatigue_score=.25, gate_distance_minutes=12, security_wait_minutes=18,
        airport_congestion_score=.55,
    )
    outputs[delay] = scored
    print(f'\nAirport decision with delay={delay} minutes')
    print(scored.head(7)[['live_rank', 'offer_name', 'candidate_type', 'products', 'expected_revenue', 'operational_utility', 'live_policy_value']].to_string(index=False))

before = outputs[0].set_index('candidate_id')
after = outputs[105].set_index('candidate_id')
common = before.index.intersection(after.index)
movement = pd.DataFrame({
    'offer_name': after.loc[common, 'offer_name'],
    'products': after.loc[common, 'products'],
    'rank_before': before.loc[common, 'live_rank'],
    'rank_after': after.loc[common, 'live_rank'],
    'operational_utility_delta': after.loc[common, 'operational_utility'] - before.loc[common, 'operational_utility'],
    'expected_revenue_delta': after.loc[common, 'expected_revenue'] - before.loc[common, 'expected_revenue'],
}).reset_index(drop=True)
movement['rank_improvement'] = movement.rank_before - movement.rank_after
print('\nLargest event-driven movements')
print(movement.sort_values(['rank_improvement', 'operational_utility_delta'], ascending=False).head(8).to_string(index=False))
