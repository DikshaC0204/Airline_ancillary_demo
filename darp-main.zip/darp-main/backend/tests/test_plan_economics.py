"""What a plan claims it will earn, checked against arithmetic that does not need a solver.

Covers the three ways the reported economics used to flatter the optimiser:
sales counted once per leg against the same stock, a manual baseline provisioned
for one leg of a rotation, and a cost charged by the objective but left out of
the reported net.
"""

from __future__ import annotations

import pytest

from app.optim.baseline import plan_manual_loads, rotation_demand
from app.optim.selection import PinSpec, _poisson_tail, solve_selection
from tests.conftest import make_forecast, make_inputs, make_sku


def _expected_capped(total_lam: float, qty: int) -> float:
    """E[min(D, qty)] for Poisson demand — the exact value the plan may book."""
    return _poisson_tail(total_lam, qty)[0][qty]


@pytest.mark.parametrize("legs", [1, 2, 3])
def test_rotation_sales_match_the_closed_form(legs):
    # One range is loaded at the origin and depletes across the legs, so the
    # rotation can only ever sell min(total demand, load).
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=1, min_pack_size=1)
    leg_forecasts = [{1: make_forecast(1, 1.0)} for _ in range(legs)]
    inp = make_inputs([sku], leg_forecasts, pins=[PinSpec(1, "set_qty", 2)])

    decision = solve_selection(inp).decisions[0]

    assert decision.expected_sold == pytest.approx(_expected_capped(float(legs), 2), abs=1e-6)
    assert sum(decision.leg_sales.values()) == pytest.approx(decision.expected_sold, abs=1e-9)
    assert decision.expected_sold <= decision.loaded_qty


def test_a_unit_is_not_sold_twice_on_a_two_leg_rotation():
    # Two units against demand of one per leg: valuing each leg against the full
    # load books 1.78 units of sales, when only 1.46 can be sold in total.
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=1, min_pack_size=1)
    forecast = {1: make_forecast(1, 1.0)}
    inp = make_inputs([sku], [forecast, forecast], pins=[PinSpec(1, "set_qty", 2)])

    decision = solve_selection(inp).decisions[0]
    per_leg_independent = 2 * _expected_capped(1.0, 2)

    assert decision.expected_sold < per_leg_independent - 0.2
    # Later legs sell less, because earlier legs already took the stock.
    assert decision.leg_sales[1] > decision.leg_sales[2] > 0


def test_the_manual_baseline_provisions_every_leg():
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=1, min_pack_size=1)
    forecast = {1: make_forecast(1, 5.0)}

    one_leg, _ = plan_manual_loads(make_inputs([sku], [forecast]))
    three_legs, _ = plan_manual_loads(make_inputs([sku], [forecast] * 3))

    assert rotation_demand(make_inputs([sku], [forecast] * 3)) == {1: 15.0}
    # 1.25x the demand it actually has to cover, not 1.25x the first leg's.
    assert one_leg[1] == 7
    assert three_legs[1] == 19


def test_net_contribution_includes_the_case_break_charge():
    # 13 units of a 12-unit case splits a case, which the objective charges for.
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=12, min_pack_size=1)
    inp = make_inputs([sku], [{1: make_forecast(1, 10.0)}], pins=[PinSpec(1, "set_qty", 13)])

    decision = solve_selection(inp).decisions[0]

    assert decision.case_break_cost == pytest.approx(inp.cost_params.case_break_penalty_gbp)
    recomputed = (
        decision.expected_margin
        - decision.return_cost
        - decision.spoilage_cost
        - decision.pick_pack_cost
        - decision.fuel_cost
        - decision.complexity_cost
        - decision.case_break_cost
    )
    assert decision.net_contribution == pytest.approx(recomputed, abs=1e-9)


def test_a_clean_case_multiple_is_not_charged_a_case_break():
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=12, min_pack_size=1)
    inp = make_inputs([sku], [{1: make_forecast(1, 10.0)}], pins=[PinSpec(1, "set_qty", 12)])

    assert solve_selection(inp).decisions[0].case_break_cost == 0.0
