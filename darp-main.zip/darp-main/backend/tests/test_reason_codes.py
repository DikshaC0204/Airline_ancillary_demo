"""Deterministic reason-code generation."""

from __future__ import annotations

from app.models import RegulatoryRule
from app.optim import explain
from app.optim.selection import SelectionParams, solve_selection
from tests.conftest import make_drawers, make_forecast, make_inputs, make_sku


def _analyse(skus, leg_forecasts, **kw):
    inp = make_inputs(skus, leg_forecasts, **kw)
    res = solve_selection(inp)
    return explain.analyse(inp, res), res


def test_regulatory_exclusion():
    sku = make_sku(id=1, category="Tobacco")
    rule = RegulatoryRule(id=1, route_id=None, sku_category="Tobacco", rule_type="disallow", parameters_json={})
    analysis, _ = _analyse([sku], [{1: make_forecast(1, 5.0)}], regulatory_rules=[rule])
    assert analysis["decisions"][1]["reason_code"] == explain.EXCLUDED_REGULATORY


def test_negative_net_exclusion():
    # Margin zero (cost ≥ retail) → loss-making after handling/fuel.
    sku = make_sku(id=1, retail_price=0.40, cost_price=0.40)
    other = make_sku(id=2, retail_price=2.0, cost_price=0.5)
    analysis, _ = _analyse([sku, other], [{1: make_forecast(1, 5.0), 2: make_forecast(2, 5.0)}])
    code = analysis["decisions"][1]["reason_code"]
    assert code in (explain.EXCLUDED_NEGATIVE_NET, explain.EXCLUDED_LOW_RETURN_PICKLINE)


def test_displaced_volume_with_substitute():
    # Tiny drawer; two SKUs differing only in density. The denser one wins; the
    # other is displaced on volume and points at its substitute.
    dense = make_sku(id=1, length_mm=40, width_mm=40, height_mm=40, retail_price=3.0, cost_price=0.4)
    bulky = make_sku(id=2, length_mm=120, width_mm=120, height_mm=120, retail_price=3.0, cost_price=0.4)
    drawers = make_drawers(1)
    fc = {1: make_forecast(1, 200.0, 200.0), 2: make_forecast(2, 200.0, 200.0)}
    analysis, res = _analyse([dense, bulky], [fc], drawers=drawers)
    d_bulky = next(d for d in res.decisions if d.sku_id == 2)
    info = analysis["decisions"][2]
    if d_bulky.loaded_qty == 0:
        assert info["reason_code"] in (
            explain.EXCLUDED_DISPLACED_VOLUME, explain.EXCLUDED_DISPLACED_WEIGHT,
        )
        assert info["substitute_sku_id"] == 1


def test_case_efficient_loaded():
    sku = make_sku(id=1, case_size=12, min_pack_size=1, retail_price=2.5, cost_price=0.4)
    other = make_sku(id=2, retail_price=2.0, cost_price=0.5)
    fc = {1: make_forecast(1, 24.0, 24.0), 2: make_forecast(2, 5.0)}
    analysis, res = _analyse([sku, other], [fc])
    d = next(d for d in res.decisions if d.sku_id == 1)
    if d.loaded_qty >= 12 and d.loaded_qty % 12 == 0:
        assert analysis["decisions"][1]["reason_code"] == explain.LOADED_CASE_EFFICIENT


def test_every_sku_gets_a_code():
    skus = [make_sku(id=i) for i in range(1, 8)]
    fc = {s.id: make_forecast(s.id, float(s.id)) for s in skus}
    analysis, _ = _analyse(skus, [fc])
    for s in skus:
        assert analysis["decisions"][s.id]["reason_code"]
        assert analysis["decisions"][s.id]["reason_text"]
