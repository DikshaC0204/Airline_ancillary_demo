"""What the plan says about itself has to match what it did.

An empty galley must not be described as full, and the service level has to
measure demand the plan expects to meet rather than stock it happens to hold.
"""

from __future__ import annotations

from datetime import datetime

import pytest
from sqlalchemy import select

from app.optim import explain
from app.optim.engine import run_optimisation
from app.optim.forecast_data import load_training_frame
from app.optim.forecast_evaluation import split_on_date
from app.optim.forecast_service import ForecastContext
from app.optim.selection import SelectionParams, solve_selection
from app.models import CostParams, Flight, OptimisationRun, Route
from tests.conftest import (
    build_engine_world,
    build_synthetic_history,
    make_cost_params,
    make_drawers,
    make_forecast,
    make_inputs,
    make_sku,
)


def test_an_empty_galley_is_not_described_as_full():
    # Nothing is loaded at all, so nothing can have been displaced by anything.
    sku = make_sku(id=1, retail_price=10.0, cost_price=1.0, case_size=1)
    inp = make_inputs(
        [sku], [{1: make_forecast(1, 5.0)}],
        cost_params=make_cost_params(complexity_penalty_per_new_pickline_gbp=100.0),
    )

    result = solve_selection(inp)
    reason = explain.analyse(inp, result)["decisions"][1]

    assert result.total_loaded_units == 0
    assert reason["reason_code"] == explain.EXCLUDED_NOT_WORTH_PICKLINE
    assert "galley had room" in reason["reason_text"]


def test_a_full_galley_still_reports_displacement():
    # Two lines of equal bulk with room for roughly one: the loser really was
    # crowded out, and must not be told the galley had room.
    winner = make_sku(id=1, retail_price=20.0, cost_price=1.0, case_size=1,
                      length_mm=100.0, width_mm=100.0, height_mm=100.0, volume_cm3=1000.0)
    loser = make_sku(id=2, retail_price=6.0, cost_price=1.0, case_size=1,
                     length_mm=100.0, width_mm=100.0, height_mm=100.0, volume_cm3=1000.0)
    forecasts = {1: make_forecast(1, 5.0), 2: make_forecast(2, 5.0)}
    inp = make_inputs([winner, loser], [forecasts], drawers=make_drawers(n_full=0, n_half=1))

    result = solve_selection(inp)
    reasons = explain.analyse(inp, result)["decisions"]

    assert result.total_loaded_units > 0
    assert reasons[2]["reason_code"] in (
        explain.EXCLUDED_DISPLACED_VOLUME,
        explain.EXCLUDED_DISPLACED_WEIGHT,
        explain.REDUCED_TO_FIT_VOLUME,
        explain.REDUCED_TO_FIT_WEIGHT,
    )


def test_service_level_measures_expected_sales_not_stock_held(memory_session):
    build_engine_world(memory_session, flights=10, skus_per_category=1)
    # This world has three lines; the default pickline threshold would reject all
    # of them and leave nothing to measure.
    cost_params = memory_session.execute(select(CostParams)).scalars().one()
    cost_params.pickline_min_expected_margin_gbp = 0.5
    cost_params.complexity_penalty_per_new_pickline_gbp = 0.2
    memory_session.commit()

    run_id = run_optimisation(
        memory_session,
        flight_id=10,
        params=SelectionParams(solver_time_limit_s=3),
        forecast_context=ForecastContext(
            requested_method="empirical",
            effective_method="empirical",
            as_of=datetime(2025, 1, 11),
        ),
    )

    run = memory_session.get(OptimisationRun, run_id)
    assert run.status == "done"
    assert run.total_units > 0
    # Demand is Poisson, so no finite load can expect to meet all of it.
    assert 0.0 < run.service_level_achieved < 1.0


def test_folds_split_on_when_sales_became_known(memory_session):
    build_synthetic_history(memory_session, flights=40)
    # An overnight flight departs before the boundary but lands after it.
    route = memory_session.get(Route, 1)
    route.flight_duration_min = 240
    flight = memory_session.get(Flight, 1)
    flight.scheduled_dt = datetime(2025, 6, 1, 23, 0)
    memory_session.commit()

    boundary = datetime(2025, 6, 2)
    frame = load_training_frame(memory_session, as_of=datetime(2026, 1, 1))
    before, after = split_on_date(frame, boundary)
    eligible = load_training_frame(memory_session, as_of=boundary)

    assert flight.id not in set(before.flight_ids.tolist())
    assert flight.id in set(after.flight_ids.tolist())
    # The learned models now train on exactly what the empirical one can see.
    assert len(before) == len(eligible)
