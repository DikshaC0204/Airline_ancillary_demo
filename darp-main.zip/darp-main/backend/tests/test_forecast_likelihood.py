"""The censored count likelihood: derivatives, edge cases, and solver agreement."""

from __future__ import annotations

import math

import numpy as np
import pytest

from app.optim import forecast_likelihood as fl
from app.optim.selection import _poisson_tail


def _nll(raw, y, loaded, exposure, censored):
    mu = fl.rate_from_raw(np.array([raw]), np.array([exposure]))
    return -fl.log_likelihood(mu, np.array([y]), np.array([loaded]), np.array([censored]))[0]


# ---------------------------------------------------------------------------
# Uncensored rows must stay ordinary Poisson
# ---------------------------------------------------------------------------

def test_uncensored_rows_reduce_to_the_textbook_poisson_pair():
    exposure = np.array([100.0, 180.0])
    raw = np.log(np.array([0.02, 0.005]))
    y = np.array([3.0, 1.0])
    loaded = np.array([10.0, 9.0])
    censored = np.array([False, False])

    grad, hess = fl.grad_hess(raw, y, loaded, exposure, censored)
    mu = fl.rate_from_raw(raw, exposure)

    assert np.allclose(grad, mu - y)
    assert np.allclose(hess, mu)


def test_uncensored_likelihood_matches_the_poisson_formula():
    mu = np.array([2.5])
    ll = fl.log_likelihood(mu, np.array([3.0]), np.array([9.0]), np.array([False]))[0]
    expected = 3 * math.log(2.5) - 2.5 - math.log(math.factorial(3))
    assert ll == pytest.approx(expected, rel=1e-10)


# ---------------------------------------------------------------------------
# Censored rows
# ---------------------------------------------------------------------------

def test_selling_out_scores_the_survival_probability_not_the_pmf():
    mu = np.array([2.0])
    ll = fl.log_likelihood(mu, np.array([1.0]), np.array([1.0]), np.array([True]))[0]
    # P(D >= 1) = 1 - e^-mu
    assert ll == pytest.approx(math.log(1 - math.exp(-2.0)), rel=1e-10)


def test_a_sold_out_row_is_more_likely_than_an_exact_count():
    """P(D >= k) >= P(D = k), so censoring can only raise the score."""
    mu = np.array([3.0])
    censored = fl.log_likelihood(mu, np.array([4.0]), np.array([4.0]), np.array([True]))[0]
    exact = fl.log_likelihood(mu, np.array([4.0]), np.array([4.0]), np.array([False]))[0]
    assert censored > exact


@pytest.mark.parametrize("rate", [0.001, 0.01, 0.05, 0.3])
@pytest.mark.parametrize("loaded", [1.0, 2.0, 6.0, 40.0])
def test_censored_gradient_matches_finite_differences(rate, loaded):
    exposure, step = 150.0, 1e-6
    raw = math.log(rate)

    grad, _ = fl.grad_hess(
        np.array([raw]), np.array([loaded]), np.array([loaded]),
        np.array([exposure]), np.array([True]),
    )
    numeric = (
        _nll(raw + step, loaded, loaded, exposure, True)
        - _nll(raw - step, loaded, loaded, exposure, True)
    ) / (2 * step)

    assert grad[0] == pytest.approx(numeric, rel=1e-4, abs=1e-6)


@pytest.mark.parametrize("rate", [0.005, 0.02, 0.2])
@pytest.mark.parametrize("loaded", [1.0, 3.0, 12.0])
def test_censored_hessian_matches_finite_differences(rate, loaded):
    exposure, step = 150.0, 1e-4
    raw = math.log(rate)

    _, hess = fl.grad_hess(
        np.array([raw]), np.array([loaded]), np.array([loaded]),
        np.array([exposure]), np.array([True]),
    )
    numeric = (
        _nll(raw + step, loaded, loaded, exposure, True)
        - 2 * _nll(raw, loaded, loaded, exposure, True)
        + _nll(raw - step, loaded, loaded, exposure, True)
    ) / (step ** 2)

    if hess[0] > fl.MIN_HESSIAN * 10:  # the floor deliberately overrides small values
        assert hess[0] == pytest.approx(numeric, rel=5e-3, abs=1e-5)


def test_hessian_is_always_usable_by_a_boosting_step():
    rng = np.random.default_rng(42)
    n = 500
    raw = rng.uniform(-12.0, 1.0, n)
    loaded = rng.integers(1, 40, n).astype(float)
    exposure = rng.uniform(60.0, 190.0, n)
    censored = rng.random(n) < 0.5
    y = np.where(censored, loaded, rng.integers(0, 5, n).astype(float))

    grad, hess = fl.grad_hess(raw, y, loaded, exposure, censored)
    assert np.all(np.isfinite(grad))
    assert np.all(hess >= fl.MIN_HESSIAN)


def test_extreme_raw_scores_stay_finite():
    for raw in (-200.0, 200.0):
        grad, hess = fl.grad_hess(
            np.array([raw]), np.array([2.0]), np.array([2.0]),
            np.array([180.0]), np.array([True]),
        )
        assert np.isfinite(grad[0]) and np.isfinite(hess[0])


def test_fitting_censored_data_recovers_a_higher_rate_than_naive_poisson():
    """The whole point: sold-out rows must not drag the estimate down."""
    rng = np.random.default_rng(7)
    exposure = np.full(4000, 180.0)
    true_rate = 0.05
    demand = rng.poisson(exposure * true_rate)
    cap = 8.0
    sold = np.minimum(demand, cap).astype(float)
    loaded = np.full_like(sold, cap)
    censored = sold >= loaded

    def fit(use_censoring: bool) -> float:
        raw = math.log(max(sold.mean(), 0.5) / 180.0)
        flags = censored if use_censoring else np.zeros_like(censored, dtype=bool)
        for _ in range(60):
            g, h = fl.grad_hess(np.full_like(sold, raw), sold, loaded, exposure, flags)
            raw -= g.sum() / max(h.sum(), 1e-9)
        return math.exp(raw)

    naive, corrected = fit(False), fit(True)
    assert naive < true_rate * 0.95           # censoring biases it down
    assert corrected == pytest.approx(true_rate, rel=0.06)
    assert corrected > naive


# ---------------------------------------------------------------------------
# Expected capped sales
# ---------------------------------------------------------------------------

def test_expected_capped_sales_matches_the_solver_curve():
    for mu in (0.3, 2.0, 7.5):
        g, _ = _poisson_tail(mu, 12)
        for cap in range(13):
            ours = fl.expected_capped_sales(np.array([mu]), np.array([float(cap)]))[0]
            assert ours == pytest.approx(g[cap], rel=1e-9, abs=1e-12)


def test_expected_capped_sales_never_exceeds_demand_or_the_load():
    mu = np.array([0.05, 1.0, 25.0])
    cap = np.array([3.0, 1.0, 10.0])
    out = fl.expected_capped_sales(mu, cap)
    assert np.all(out <= mu + 1e-12)
    assert np.all(out <= cap + 1e-12)


def test_expected_capped_sales_is_zero_without_stock():
    out = fl.expected_capped_sales(np.array([5.0]), np.array([0.0]))
    assert out[0] == 0.0


def test_expected_capped_sales_saturates_at_the_mean():
    out = fl.expected_capped_sales(np.array([2.0]), np.array([400.0]))
    assert out[0] == pytest.approx(2.0, rel=1e-9)


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------

def test_deviance_prefers_the_rate_that_generated_the_data():
    rng = np.random.default_rng(3)
    y = rng.poisson(2.0, 2000).astype(float)
    loaded = np.full_like(y, 99.0)
    censored = np.zeros_like(y, dtype=bool)

    good = fl.deviance(np.full_like(y, 2.0), y, loaded, censored)
    bad = fl.deviance(np.full_like(y, 6.0), y, loaded, censored)
    assert good < bad


def test_deviance_of_an_empty_slice_is_not_a_number():
    empty = np.array([])
    assert math.isnan(fl.deviance(empty, empty, empty, empty.astype(bool)))
