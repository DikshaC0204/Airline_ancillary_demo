"""Override + approval API integration (runs against the seeded dev DB)."""

from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

from app.db import session_scope
from app.main import create_app
from app.models import Flight, Sku


@pytest.fixture(scope="module")
def client():
    return TestClient(create_app())


def _seeded() -> bool:
    with session_scope() as s:
        return s.query(Flight).first() is not None


def _wait_done(client, run_id, timeout=60):
    for _ in range(timeout * 2):
        d = client.get(f"/api/runs/{run_id}").json()
        if d["run"]["status"] in ("done", "failed"):
            return d
        time.sleep(0.5)
    raise AssertionError("run did not finish")


@pytest.mark.skipif(not _seeded(), reason="seeded dev DB required")
def test_override_run_lifecycle(client):
    flight = client.get("/api/flights?limit=1").json()["items"][0]
    run = client.post("/api/runs", json={"flight_id": flight["id"]}).json()
    detail = _wait_done(client, run["id"])
    assert detail["run"]["status"] == "done"
    assert all(d["reason_code"] for d in detail["decisions"])

    loaded = next(d for d in detail["decisions"] if d["loaded_qty"] > 0)
    ov = client.post(f"/api/runs/{run['id']}/override",
                     json={"overrides": [{"sku_id": loaded["sku_id"], "kind": "force_exclude", "note": "t"}]})
    assert ov.status_code == 200
    ov_run = ov.json()
    assert ov_run["run_kind"] == "override"
    assert ov_run["parent_run_id"] == run["id"]
    ov_detail = _wait_done(client, ov_run["id"])
    pinned = next(d for d in ov_detail["decisions"] if d["sku_id"] == loaded["sku_id"])
    assert pinned["loaded_qty"] == 0
    assert pinned["is_overridden"] is True
    assert len(ov_detail["overrides"]) == 1


@pytest.mark.skipif(not _seeded(), reason="seeded dev DB required")
def test_approval_single_plan_invariant(client):
    flight = client.get("/api/flights?limit=1").json()["items"][0]
    r1 = client.post("/api/runs", json={"flight_id": flight["id"]}).json()
    _wait_done(client, r1["id"])
    r2 = client.post("/api/runs", json={"flight_id": flight["id"]}).json()
    _wait_done(client, r2["id"])

    a1 = client.post(f"/api/runs/{r1['id']}/approve", json={"approved_by": "A"})
    assert a1.json()["approval_status"] == "approved"
    a2 = client.post(f"/api/runs/{r2['id']}/approve", json={"approved_by": "B"})
    assert a2.json()["approval_status"] == "approved"
    # Approving r2 must have reverted r1 to draft.
    assert client.get(f"/api/runs/{r1['id']}").json()["run"]["approval_status"] == "draft"


@pytest.mark.skipif(not _seeded(), reason="seeded dev DB required")
def test_override_pins_exceed_capacity_returns_422(client):
    flight = client.get("/api/flights?limit=1").json()["items"][0]
    run = client.post("/api/runs", json={"flight_id": flight["id"]}).json()
    _wait_done(client, run["id"])
    # Pin an absurd quantity of a bulky SKU.
    skus = client.get("/api/skus?limit=2000").json()
    items = skus["items"] if isinstance(skus, dict) else skus
    bulky = max(items, key=lambda s: s["volume_cm3"])
    ov = client.post(f"/api/runs/{run['id']}/override",
                     json={"overrides": [{"sku_id": bulky["id"], "kind": "set_qty", "qty": 100000}]})
    assert ov.status_code == 422
    assert ov.json()["detail"]["reason"] == "pins_exceed_capacity"
