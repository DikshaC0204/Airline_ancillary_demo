"""Case-multiple preference."""

from __future__ import annotations

from app.optim.selection import SelectionParams, solve_selection
from tests.conftest import make_cost_params, make_forecast, make_inputs, make_sku


def _load_qty(case_break_penalty: float) -> int:
    # Single SKU, demand 13, case size 12. With a strong case-break penalty the
    # solver should snap to a clean case multiple (12 or 24); with none it may sit at 13.
    sku = make_sku(id=1, case_size=12, min_pack_size=1, retail_price=2.0, cost_price=0.4,
                   unit_weight_g=50.0)
    cp = make_cost_params(case_break_penalty_gbp=case_break_penalty)
    inp = make_inputs([sku], [{1: make_forecast(1, 13.0, 13.0)}], cost_params=cp)
    res = solve_selection(inp)
    return next(d for d in res.decisions if d.sku_id == 1).loaded_qty


def test_strong_penalty_snaps_to_case_multiple():
    qty = _load_qty(case_break_penalty=5.0)
    assert qty % 12 == 0


def test_no_penalty_allows_case_break():
    qty = _load_qty(case_break_penalty=0.0)
    # Without a penalty the solver is free to load a non-multiple (it will load to
    # demand 13, or thereabouts). Just assert it is not forced onto a 12-multiple.
    assert qty >= 12
