"""Test fixtures and factories.

Solver tests build `SelectionInputs` from *unsaved* ORM instances — `solve_selection`
never touches the database, so no session is needed. API tests use a tmp-file
SQLite database (worker threads create their own sessions via the global engine).
"""

from __future__ import annotations

import math
from datetime import datetime

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db import Base
from app.models import (
    Aircraft,
    BrandRule,
    Cart,
    CostParams,
    Drawer,
    Flight,
    GalleyLayout,
    RegulatoryRule,
    Route,
    Sale,
    Sku,
    SupplierCommitment,
)
from app.optim.forecast import ForecastResult
from app.optim.selection import LegInput, SelectionInputs, SelectionParams


@pytest.fixture
def memory_session():
    """A throwaway in-memory database.

    Forecast tests must never touch the seeded development database — the demo
    data lives there, and `test_override_api` already mutates it.

    StaticPool matters: an in-memory SQLite database belongs to its connection,
    and the default pool hands each thread a different one. TestClient runs
    endpoints on a worker thread, which would otherwise find an empty schema.
    """
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    session = sessionmaker(bind=engine, future=True)()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


# Demand per passenger by category, for the synthetic history below. Forecast
# tests assert against these, so the generating process is known exactly.
TRUE_RATES = {"Fast": 0.040, "Mid": 0.010, "Slow": 0.001}


def build_synthetic_history(
    session,
    *,
    flights: int = 260,
    skus_per_category: int = 4,
    start: datetime = datetime(2025, 1, 1, 9, 0),
    overload: float = 1.1,
    seed: int = 11,
):
    """A route, a catalogue, and Poisson demand capped by what was loaded.

    `overload` decides how often lines sell out: at 1.1 the load sits just above
    average demand, so censoring is common enough to matter.
    """
    import numpy as np
    from datetime import timedelta

    rng = np.random.default_rng(seed)
    session.add(Route(
        id=1, origin_iata="LTN", dest_iata="IBZ", distance_km=1450.0,
        flight_duration_min=145, haul_class="short", duty_free_allowed=False,
        alcohol_allowed=True, tobacco_allowed=False, seasonality_profile_json={},
    ))

    sku_rate: dict[int, float] = {}
    sku_id = 1
    for category, rate in TRUE_RATES.items():
        for j in range(skus_per_category):
            session.add(Sku(
                id=sku_id, code=f"S{sku_id}", name=f"Sku {sku_id}", category=category,
                sub_category=f"{category}-sub", brand=f"Brand{j}", unit_weight_g=80.0,
                length_mm=60.0, width_mm=60.0, height_mm=100.0, volume_cm3=360.0,
                packaging_type="box", shelf_life_days=180, warehouse_zone="ambient-standard",
                cost_price=0.4, retail_price=1.5, margin_pct=0.7, supplier_id=1,
                min_pack_size=1, case_size=12,
            ))
            sku_rate[sku_id] = rate
            sku_id += 1
    session.flush()

    for i in range(flights):
        pax = int(rng.integers(90, 190))
        session.add(Flight(
            id=i + 1, route_id=1, flight_no=f"U2{i}", scheduled_dt=start + timedelta(days=i),
            aircraft_id=1, expected_pax=pax, expected_load_factor=round(pax / 186, 3),
            pax_mix_json={"leisure": 0.7, "business": 0.3}, cabin_config_json={},
        ))
        for sid, rate in sku_rate.items():
            demand = int(rng.poisson(pax * rate))
            loaded = max(1, int(math.ceil(pax * rate * overload)))
            sold = min(demand, loaded)
            session.add(Sale(
                flight_id=i + 1, sku_id=sid, units_sold=sold, revenue=sold * 1.5,
                unsold_units=loaded - sold, returned_units=0,
            ))
    session.commit()
    return sku_rate


_DRAWER_DIMS = {
    "ATLAS_full": (400.0, 300.0, 280.0, 18.0),
    "ATLAS_half": (400.0, 300.0, 140.0, 9.0),
}


def build_engine_world(session, **kw):
    """Synthetic history plus the aircraft, galley and costs the engine needs.

    Enough of a world to run the full pipeline in memory, so provenance can be
    tested without going near the seeded development database.
    """
    rates = build_synthetic_history(session, **kw)

    session.add(GalleyLayout(id=1, aircraft_type="A320", num_retail_carts=1, schematic_json={}))
    session.add(Cart(id=1, galley_layout_id=1, position_code="G1", cart_type="full"))
    for i in range(4):
        session.add(Drawer(
            id=i + 1, cart_id=1, slot_index=i, type="ATLAS_full",
            internal_l_mm=400.0, internal_w_mm=300.0, internal_h_mm=280.0,
            max_weight_kg=18.0, accessibility_score=1 + i // 2,
        ))
    session.add(Aircraft(
        id=1, registration="G-TEST", type="A320", retail_galley_layout_id=1,
        empty_weight_kg=42600.0, max_payload_kg=17500.0,
        fuel_burn_coeff_short=0.030, fuel_burn_coeff_medium=0.040, fuel_burn_coeff_long=0.055,
    ))
    session.add(make_cost_params())
    session.commit()
    return rates


def make_cost_params(**kw) -> CostParams:
    defaults = dict(
        id=1,
        valid_from=datetime(2025, 1, 1),
        fuel_price_per_kg_gbp=0.82,
        pick_cost_per_unit_gbp=0.08,
        pack_cost_per_drawer_gbp=1.20,
        cart_assembly_cost_gbp=4.50,
        return_handling_cost_per_unit_gbp=0.15,
        complexity_penalty_per_new_pickline_gbp=2.00,
        pick_zone_multipliers_json={
            "ambient-fast": 0.8, "ambient-standard": 1.0, "chilled": 1.5,
            "bonded": 1.8, "secure-high-value": 2.2,
        },
        bonded_access_surcharge_gbp=1.50,
        authorised_pick_surcharge_per_unit_gbp=0.12,
        pickline_min_expected_margin_gbp=6.00,
        case_break_penalty_gbp=0.40,
        spoilage_reuse_cycle_days=3.0,
    )
    defaults.update(kw)
    return CostParams(**defaults)


_SKU_COUNTER = [1000]


def make_sku(**kw) -> Sku:
    _SKU_COUNTER[0] += 1
    sid = kw.pop("id", _SKU_COUNTER[0])
    length = kw.pop("length_mm", 60.0)
    width = kw.pop("width_mm", 60.0)
    height = kw.pop("height_mm", 100.0)
    defaults = dict(
        id=sid,
        code=f"TST-{sid}",
        name=f"Test SKU {sid}",
        category="Snacks (savoury)",
        sub_category="Crisps",
        brand="TestBrand",
        unit_weight_g=80.0,
        length_mm=length,
        width_mm=width,
        height_mm=height,
        volume_cm3=(length * width * height) / 1000.0,
        packaging_type="box",
        stackable=True,
        max_stack_height=6,
        fragility_score=1,
        orientation_constraint="any",
        shelf_life_days=180,
        hazard_class="none",
        warehouse_zone="ambient-standard",
        cost_price=0.40,
        retail_price=1.50,
        margin_pct=0.73,
        supplier_id=1,
        min_pack_size=1,
        case_size=12,
        bonded=False,
        requires_authorised_pick=False,
        image_url=None,
    )
    defaults.update(kw)
    return Sku(**defaults)


def make_drawers(n_full: int = 4, n_half: int = 0) -> list[Drawer]:
    drawers: list[Drawer] = []
    did = 1
    for i in range(n_full):
        l, w, h, mw = _DRAWER_DIMS["ATLAS_full"]
        drawers.append(Drawer(
            id=did, cart_id=1, slot_index=i, type="ATLAS_full",
            internal_l_mm=l, internal_w_mm=w, internal_h_mm=h,
            max_weight_kg=mw, accessibility_score=1 + i // 2,
        ))
        did += 1
    for i in range(n_half):
        l, w, h, mw = _DRAWER_DIMS["ATLAS_half"]
        drawers.append(Drawer(
            id=did, cart_id=2, slot_index=i, type="ATLAS_half",
            internal_l_mm=l, internal_w_mm=w, internal_h_mm=h,
            max_weight_kg=mw, accessibility_score=1 + i // 2,
        ))
        did += 1
    return drawers


def make_aircraft(**kw) -> Aircraft:
    defaults = dict(
        id=1, registration="G-TEST", type="A320", retail_galley_layout_id=1,
        empty_weight_kg=42600.0, max_payload_kg=17500.0,
        fuel_burn_coeff_short=0.030, fuel_burn_coeff_medium=0.040, fuel_burn_coeff_long=0.055,
    )
    defaults.update(kw)
    return Aircraft(**defaults)


def make_route(**kw) -> Route:
    defaults = dict(
        id=1, origin_iata="LTN", dest_iata="IBZ", distance_km=1450.0,
        flight_duration_min=145, haul_class="short", duty_free_allowed=False,
        alcohol_allowed=True, tobacco_allowed=False, seasonality_profile_json={},
    )
    defaults.update(kw)
    return Route(**defaults)


def make_flight(route: Route, **kw) -> Flight:
    defaults = dict(
        id=1, route_id=route.id, flight_no="U2TEST", scheduled_dt=datetime(2025, 7, 4, 10, 0),
        aircraft_id=1, expected_pax=180, expected_load_factor=0.9,
        pax_mix_json={"leisure": 1.0}, cabin_config_json={},
    )
    defaults.update(kw)
    f = Flight(**defaults)
    f.route = route
    return f


def make_forecast(sku_id: int, expected: float, p90: float | None = None) -> ForecastResult:
    p90 = p90 if p90 is not None else expected * 1.3
    return ForecastResult(
        sku_id=sku_id, expected_units=expected, p10_units=max(0.0, expected * 0.7),
        p50_units=expected, p90_units=p90, history_rows=50,
    )


def make_inputs(
    skus: list[Sku],
    leg_forecasts: list[dict[int, ForecastResult]],
    *,
    drawers: list[Drawer] | None = None,
    cost_params: CostParams | None = None,
    params: SelectionParams | None = None,
    brand_rules: list[BrandRule] | None = None,
    supplier_commitments: list[SupplierCommitment] | None = None,
    regulatory_rules: list[RegulatoryRule] | None = None,
    routes: list[Route] | None = None,
    pins=None,
    aircraft: Aircraft | None = None,
) -> SelectionInputs:
    drawers = drawers if drawers is not None else make_drawers(4)
    cost_params = cost_params or make_cost_params()
    params = params or SelectionParams()
    aircraft = aircraft or make_aircraft()
    routes = routes or [make_route(id=i + 1) for i in range(len(leg_forecasts))]
    legs: list[LegInput] = []
    for k, fcs in enumerate(leg_forecasts):
        route = routes[k] if k < len(routes) else routes[0]
        flight = make_flight(route, id=k + 1, flight_no=f"U2L{k+1}")
        legs.append(LegInput(
            flight=flight, route=route,
            burn_coeff=(route.fuel_burn_coeff_short if hasattr(route, "fuel_burn_coeff_short")
                        else aircraft.fuel_burn_coeff_short),
            forecasts=fcs,
        ))
    origin_route = legs[0].route
    return SelectionInputs(
        flight=legs[0].flight,
        route=origin_route,
        aircraft=aircraft,
        galley=GalleyLayout(id=1, aircraft_type="A320", num_retail_carts=1, schematic_json={}),
        drawers=drawers,
        skus=skus,
        forecasts=leg_forecasts[0],
        cost_params=cost_params,
        regulatory_rules=regulatory_rules or [],
        brand_rules=brand_rules or [],
        supplier_commitments=supplier_commitments or [],
        params=params,
        legs=legs,
        pins=pins or [],
    )
