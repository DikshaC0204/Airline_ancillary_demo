"""A plan is only a plan if it fits in the drawers and nobody else owns the flight.

These lock in three ways a run could previously be presented as usable when it
was not: units with no drawer position, approval of a plan the current aircraft
cannot take, and two approved plans covering the same flight.
"""

from __future__ import annotations

from datetime import datetime

import pytest
from fastapi import HTTPException

from app.api.runs import ApproveBody, approve_run
from app.models import DrawerAssignment, Flight, OptimisationRun, Rotation, Route, Sku
from app.optim.engine import run_optimisation
from app.optim.forecast_service import ForecastContext
from app.optim.selection import PinSpec, SelectionParams
from tests.conftest import build_engine_world, make_forecast


def _snapshot(sku_ids, expected=1.0):
    return {"1": {str(sid): make_forecast(sid, expected).to_dict() for sid in sku_ids}}


def test_a_run_whose_units_do_not_fit_never_completes(memory_session):
    build_engine_world(memory_session, flights=10, skus_per_category=1)

    # Longer than the drawer, so no orientation can place it however low eta goes.
    oversized = memory_session.get(Sku, 1)
    oversized.length_mm, oversized.width_mm, oversized.height_mm = 500.0, 20.0, 20.0
    oversized.volume_cm3 = 200.0
    memory_session.commit()

    sku_ids = [1, 2, 3]
    run_id = run_optimisation(
        memory_session,
        flight_id=10,
        params=SelectionParams(solver_time_limit_s=2),
        pins=[PinSpec(sid, "set_qty", 2 if sid == 1 else 0) for sid in sku_ids],
        forecast_context=ForecastContext(
            requested_method="empirical",
            effective_method="empirical",
            as_of=datetime(2025, 1, 10),
        ),
        forecast_snapshot=_snapshot(sku_ids),
    )

    run = memory_session.get(OptimisationRun, run_id)
    assert run.status == "failed"
    failure = (run.parameters_json or {}).get("packing_failure")
    assert failure["unplaced_units"] == 2
    assert failure["by_sku"][0]["sku_id"] == 1


def test_a_plan_with_unplaced_units_cannot_be_approved(memory_session):
    memory_session.add(Route(
        id=1, origin_iata="LTN", dest_iata="IBZ", distance_km=1450.0,
        flight_duration_min=145, haul_class="short", duty_free_allowed=False,
        alcohol_allowed=True, tobacco_allowed=False, seasonality_profile_json={},
    ))
    memory_session.add(Flight(
        id=1, route_id=1, flight_no="U2TEST", scheduled_dt=datetime(2025, 7, 4, 10, 0),
        aircraft_id=1, expected_pax=180, expected_load_factor=0.9,
        pax_mix_json={}, cabin_config_json={},
    ))
    memory_session.add(OptimisationRun(
        id=1, flight_id=1, status="done", parameters_json={}, total_units=10,
    ))
    memory_session.add(DrawerAssignment(
        optimisation_run_id=1, drawer_id=1, sku_id=1, units=4, position_xyz_json={},
    ))
    memory_session.commit()

    with pytest.raises(HTTPException) as excinfo:
        approve_run(1, ApproveBody(approved_by="planner"), memory_session)

    assert excinfo.value.status_code == 409
    assert excinfo.value.detail["reason"] == "plan_not_fully_packed"
    assert memory_session.get(OptimisationRun, 1).approval_status == "draft"


def test_a_plan_the_current_aircraft_cannot_take_cannot_be_approved(memory_session):
    memory_session.add(OptimisationRun(
        id=1, flight_id=1, status="done", parameters_json={}, total_units=0,
        revalidation_json={"verdict": "capacity_violated", "unplaced_units": 7},
    ))
    memory_session.commit()

    with pytest.raises(HTTPException) as excinfo:
        approve_run(1, ApproveBody(approved_by="planner"), memory_session)

    assert excinfo.value.status_code == 409
    assert excinfo.value.detail["reason"] == "capacity_violated"


def test_approving_a_rotation_stands_down_a_plan_for_one_of_its_legs(memory_session):
    memory_session.add(Route(
        id=1, origin_iata="LTN", dest_iata="IBZ", distance_km=1450.0,
        flight_duration_min=145, haul_class="short", duty_free_allowed=False,
        alcohol_allowed=True, tobacco_allowed=False, seasonality_profile_json={},
    ))
    memory_session.add(Rotation(id=1, code="ROT-TEST", description="two legs"))
    for fid, leg in ((1, 1), (2, 2)):
        memory_session.add(Flight(
            id=fid, route_id=1, flight_no=f"U2L{leg}", scheduled_dt=datetime(2025, 7, 4, 10, 0),
            aircraft_id=1, expected_pax=180, expected_load_factor=0.9,
            pax_mix_json={}, cabin_config_json={}, rotation_id=1, leg_index=leg,
        ))
    # A single-leg plan for leg 1, and a rotation plan that also covers leg 1.
    leg_run = OptimisationRun(id=1, flight_id=1, status="done", parameters_json={}, total_units=0)
    rotation_run = OptimisationRun(
        id=2, flight_id=1, rotation_id=1, status="done", parameters_json={}, total_units=0,
    )
    memory_session.add_all([leg_run, rotation_run])
    memory_session.commit()

    approve_run(1, ApproveBody(approved_by="planner"), memory_session)
    assert leg_run.approval_status == "approved"

    approve_run(2, ApproveBody(approved_by="planner"), memory_session)
    assert rotation_run.approval_status == "approved"
    assert leg_run.approval_status == "draft"
