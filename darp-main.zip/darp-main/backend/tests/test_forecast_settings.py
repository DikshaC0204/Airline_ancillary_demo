"""Forecast settings, training jobs, and the provenance a run carries."""

from __future__ import annotations

from datetime import datetime, timedelta

import pytest
from fastapi.testclient import TestClient

from app.api.settings import router as settings_router
from app.db import get_session
from app.models import ApplicationSettings, Flight, ForecastTrainingJob, OptimisationRun, Sale
from app.optim import forecast_service as svc
from app.optim.engine import run_optimisation
from app.optim.forecast import EMPIRICAL, LIGHTGBM
from tests.conftest import build_engine_world, build_synthetic_history


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

def test_settings_default_to_the_method_that_needs_no_model(memory_session):
    row = svc.get_settings(memory_session)
    assert row.forecast_method == EMPIRICAL
    assert row.active_model_id is None


def test_settings_row_is_created_once(memory_session):
    first = svc.get_settings(memory_session)
    first.revision = 7
    memory_session.commit()
    assert svc.get_settings(memory_session).revision == 7


def test_an_unknown_method_is_rejected(memory_session):
    with pytest.raises(ValueError, match="unknown forecast method"):
        svc.set_method(memory_session, "prophet")


def test_lightgbm_cannot_be_selected_without_a_trained_model(memory_session):
    with pytest.raises(svc.SettingsConflict, match="missing"):
        svc.set_method(memory_session, LIGHTGBM)
    # The failed attempt must not have changed anything.
    assert svc.get_settings(memory_session).forecast_method == EMPIRICAL


def test_selecting_empirical_always_works(memory_session):
    row = svc.set_method(memory_session, EMPIRICAL)
    assert row.forecast_method == EMPIRICAL
    assert row.revision == 1


def test_model_status_is_missing_without_an_artifact(memory_session):
    assert svc.model_status(memory_session, None)["state"] == svc.MISSING
    assert svc.model_status(memory_session, "nope")["state"] == svc.MISSING


def test_available_methods_always_offers_the_default(memory_session):
    build_synthetic_history(memory_session, flights=5)
    methods = {m["method"]: m for m in svc.available_methods(memory_session)}
    assert methods[EMPIRICAL]["available"] is True
    assert LIGHTGBM in methods
    # Nothing is trained yet, so the optional method is offered but not usable.
    assert methods[LIGHTGBM]["available"] is False


# ---------------------------------------------------------------------------
# Training jobs
# ---------------------------------------------------------------------------

def test_training_needs_history(memory_session):
    with pytest.raises(svc.SettingsConflict, match="no flight history"):
        svc.start_training(memory_session, spawn=False)


def test_a_queued_job_blocks_a_second_one(memory_session):
    build_synthetic_history(memory_session, flights=120)
    svc.start_training(memory_session, spawn=False)
    with pytest.raises(svc.TrainingConflict, match="already running"):
        svc.start_training(memory_session, spawn=False)


def test_a_job_records_the_cutoff_it_was_asked_for(memory_session):
    build_synthetic_history(memory_session, flights=120)
    cutoff = datetime(2025, 4, 1)
    job = svc.start_training(memory_session, cutoff=cutoff, spawn=False)
    assert job.requested_cutoff == cutoff
    assert job.state == svc.QUEUED
    assert job.model_id


def test_jobs_stuck_by_a_restart_are_marked_interrupted(memory_session):
    build_synthetic_history(memory_session, flights=120)
    job = svc.start_training(memory_session, spawn=False)

    assert svc.recover_interrupted_jobs(memory_session) == 1
    memory_session.refresh(job)
    assert job.state == svc.INTERRUPTED
    assert job.is_terminal
    # And a new job may now start.
    svc.start_training(memory_session, spawn=False)


def test_a_finished_job_does_not_activate_itself(memory_session):
    build_synthetic_history(memory_session, flights=120)
    job = svc.start_training(memory_session, spawn=False)
    job.state = svc.SUCCEEDED
    memory_session.commit()

    assert svc.get_settings(memory_session).forecast_method == EMPIRICAL
    assert svc.get_settings(memory_session).active_model_id is None


# ---------------------------------------------------------------------------
# Resolving a method for a run
# ---------------------------------------------------------------------------

def test_context_roundtrips_through_json():
    ctx = svc.ForecastContext(
        requested_method=LIGHTGBM, effective_method=EMPIRICAL,
        as_of=datetime(2026, 1, 1), model_id="abc",
        information_cutoff=datetime(2025, 12, 1),
        fallback_reason=svc.FALLBACK_STALE, exclude_flight_ids=(3, 4),
    )
    again = svc.ForecastContext.from_dict(ctx.to_dict())
    assert again == ctx
    assert again.did_fall_back


def test_empirical_is_resolved_without_a_fallback(memory_session):
    build_synthetic_history(memory_session, flights=30)
    ctx = svc.resolve_context(memory_session, target_departure=datetime(2025, 6, 1))
    assert ctx.effective_method == EMPIRICAL
    assert ctx.fallback_reason is None


def test_asking_for_lightgbm_without_a_model_falls_back_and_says_why(memory_session):
    build_synthetic_history(memory_session, flights=30)
    svc.get_settings(memory_session).forecast_method = LIGHTGBM
    memory_session.commit()

    ctx = svc.resolve_context(memory_session, target_departure=datetime(2025, 6, 1))
    assert ctx.requested_method == LIGHTGBM
    assert ctx.effective_method == EMPIRICAL
    assert ctx.fallback_reason in (svc.FALLBACK_NO_MODEL, svc.FALLBACK_LIBRARY_MISSING)


def test_the_cutoff_never_reaches_past_the_target_departure(memory_session):
    build_synthetic_history(memory_session, flights=30)
    departure = datetime(2025, 1, 10, 9, 0)
    ctx = svc.resolve_context(memory_session, target_departure=departure)
    assert ctx.as_of <= departure


def test_rotation_legs_are_excluded_from_their_own_forecast(memory_session):
    build_synthetic_history(memory_session, flights=30)
    ctx = svc.resolve_context(
        memory_session, target_departure=datetime(2025, 6, 1), exclude_flight_ids=[4, 5, 6]
    )
    assert ctx.exclude_flight_ids == (4, 5, 6)


def test_build_forecaster_returns_the_empirical_model_for_the_default(memory_session):
    build_synthetic_history(memory_session, flights=30)
    ctx = svc.resolve_context(memory_session, target_departure=datetime(2025, 6, 1))
    forecaster, resolved = svc.build_forecaster(memory_session, ctx)
    assert forecaster.method == EMPIRICAL
    assert resolved.effective_method == EMPIRICAL


def test_a_broken_artifact_degrades_instead_of_raising(memory_session):
    build_synthetic_history(memory_session, flights=30)
    ctx = svc.ForecastContext(
        requested_method=LIGHTGBM, effective_method=LIGHTGBM,
        as_of=datetime(2025, 6, 1), model_id="does-not-exist",
    )
    forecaster, resolved = svc.build_forecaster(memory_session, ctx)
    assert forecaster.method == EMPIRICAL
    assert resolved.fallback_reason == svc.FALLBACK_LOAD_FAILED


# ---------------------------------------------------------------------------
# What a run records
# ---------------------------------------------------------------------------

def test_a_run_records_the_method_and_its_forecasts(memory_session):
    build_engine_world(memory_session, flights=120)
    target = memory_session.get(Flight, 100)

    run_id = run_optimisation(memory_session, target.id)
    run = memory_session.get(OptimisationRun, run_id)
    params = run.parameters_json

    assert params["forecasting"]["effective_method"] == EMPIRICAL
    assert params["forecasting"]["fallback_reason"] is None
    # The forecast the plan was actually built on is kept, per leg.
    snapshot = params["forecast_snapshot"]["1"]
    assert len(snapshot) > 0
    assert all("expected_units" in v for v in snapshot.values())


def test_a_run_never_forecasts_from_its_own_flight(memory_session):
    build_engine_world(memory_session, flights=120)
    target = memory_session.get(Flight, 100)

    run_id = run_optimisation(memory_session, target.id)
    params = memory_session.get(OptimisationRun, run_id).parameters_json

    assert datetime.fromisoformat(params["forecasting"]["as_of"]) <= target.scheduled_dt
    assert target.id in params["forecasting"]["excluded_flight_ids"]


def test_an_inherited_snapshot_is_replayed_exactly(memory_session):
    build_engine_world(memory_session, flights=120)
    target = memory_session.get(Flight, 100)

    first = memory_session.get(OptimisationRun, run_optimisation(memory_session, target.id))
    snapshot = first.parameters_json["forecast_snapshot"]

    second = memory_session.get(OptimisationRun, run_optimisation(
        memory_session, target.id, forecast_snapshot=snapshot
    ))
    assert second.parameters_json["forecast_snapshot"] == snapshot
    assert second.parameters_json["forecasting"]["inherited_snapshot"] is True
    assert second.expected_net_contribution == pytest.approx(first.expected_net_contribution)


def test_replaying_a_snapshot_that_misses_a_leg_is_refused(memory_session):
    build_engine_world(memory_session, flights=120)
    target = memory_session.get(Flight, 100)
    with pytest.raises(ValueError, match="does not cover every leg"):
        run_optimisation(memory_session, target.id, forecast_snapshot={"1": {}})


# ---------------------------------------------------------------------------
# Selecting a trained model
# ---------------------------------------------------------------------------

@pytest.fixture
def trained_model(memory_session, tmp_path, monkeypatch):
    """A succeeded job with an artifact on disk, without running a real fit."""
    from app.optim.forecast_data import dataset_fingerprint

    monkeypatch.setattr(svc.app_settings, "arp_model_dir", tmp_path / "models")
    build_synthetic_history(memory_session, flights=120)

    model_id = "testmodel01"
    directory = svc.artifact_dir(model_id)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "meta.json").write_text("{}", encoding="utf-8")

    job = ForecastTrainingJob(
        model_id=model_id,
        state=svc.SUCCEEDED,
        data_fingerprint=dataset_fingerprint(memory_session),
        information_cutoff=datetime(2025, 4, 1),
        requested_cutoff=datetime(2025, 4, 1),
        report_json={"rows": {"total": 999}},
        finished_at=datetime(2025, 4, 2),
    )
    memory_session.add(job)
    memory_session.commit()
    return job


def test_a_trained_model_becomes_the_candidate_to_select(memory_session, trained_model):
    assert svc.candidate_model_id(memory_session) == trained_model.model_id
    assert svc.model_status(memory_session, trained_model.model_id)["state"] == svc.READY


def test_choosing_lightgbm_adopts_the_model_that_was_trained(memory_session, trained_model):
    row = svc.set_method(memory_session, LIGHTGBM)
    assert row.forecast_method == LIGHTGBM
    assert row.active_model_id == trained_model.model_id


def test_changing_the_history_makes_the_model_stale(memory_session, trained_model):
    svc.set_method(memory_session, LIGHTGBM)

    sale = memory_session.query(Sale).first()
    sale.units_sold += 5
    memory_session.commit()

    assert svc.model_status(memory_session, trained_model.model_id)["state"] == svc.STALE
    ctx = svc.resolve_context(memory_session, target_departure=datetime(2026, 1, 1))
    assert ctx.effective_method == EMPIRICAL
    assert ctx.fallback_reason == svc.FALLBACK_STALE


def test_a_model_cannot_forecast_a_flight_it_already_learned_from(memory_session, trained_model):
    svc.set_method(memory_session, LIGHTGBM)

    # The model saw everything up to April 2025, so a January flight is history
    # to it, not a forecast.
    ctx = svc.resolve_context(memory_session, target_departure=datetime(2025, 1, 20))
    assert ctx.effective_method == EMPIRICAL
    assert ctx.fallback_reason == svc.FALLBACK_NOT_ELIGIBLE

    later = svc.resolve_context(memory_session, target_departure=datetime(2025, 9, 1))
    assert later.effective_method == LIGHTGBM
    assert later.fallback_reason is None


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

@pytest.fixture
def client(memory_session):
    from fastapi import FastAPI

    app = FastAPI()
    app.include_router(settings_router, prefix="/api/settings")
    from app.api.forecasting import router as forecasting_router

    app.include_router(forecasting_router, prefix="/api/forecasting")
    app.dependency_overrides[get_session] = lambda: memory_session
    return TestClient(app)


def test_settings_endpoint_reports_methods_and_data(client, memory_session):
    build_synthetic_history(memory_session, flights=120)
    body = client.get("/api/settings").json()

    assert body["forecast_method"] == EMPIRICAL
    assert {m["method"] for m in body["methods"]} == {EMPIRICAL, LIGHTGBM}
    assert body["dataset"]["recommended_cutoff"] is not None


def test_settings_rejects_an_invalid_method(client):
    assert client.patch("/api/settings", json={"forecast_method": "magic"}).status_code == 422


def test_settings_returns_conflict_for_an_unusable_model(client, memory_session):
    build_synthetic_history(memory_session, flights=30)
    response = client.patch("/api/settings", json={"forecast_method": LIGHTGBM})
    assert response.status_code == 409
    assert "lightgbm" in response.json()["detail"].lower() or "model" in response.json()["detail"].lower()


def test_settings_can_be_saved_back_to_the_default(client, memory_session):
    build_synthetic_history(memory_session, flights=30)
    body = client.patch("/api/settings", json={"forecast_method": EMPIRICAL}).json()
    assert body["forecast_method"] == EMPIRICAL
    assert body["revision"] >= 1


def test_a_missing_training_job_is_a_404(client):
    assert client.get("/api/forecasting/jobs/999").status_code == 404


def test_latest_evaluation_is_empty_before_any_training(client):
    assert client.get("/api/forecasting/evaluations/latest").json()["report"] is None


def test_training_without_history_is_a_conflict(client):
    assert client.post("/api/forecasting/train-evaluate", json={}).status_code == 409
