"""Pinning / override-run solver behaviour."""

from __future__ import annotations

from app.optim.selection import PinSpec, SelectionParams, solve_selection, validate_pins_capacity
from tests.conftest import make_aircraft, make_drawers, make_forecast, make_inputs, make_sku


def _solve(skus, forecasts, **kw):
    inp = make_inputs(skus, [forecasts], **kw)
    return solve_selection(inp), inp


def test_set_qty_forces_quantity():
    skus = [make_sku(id=1, retail_price=1.5, cost_price=0.4),
            make_sku(id=2, retail_price=2.0, cost_price=0.5)]
    fc = {1: make_forecast(1, 5.0), 2: make_forecast(2, 5.0)}
    res, _ = _solve(skus, fc, params=SelectionParams(soft_constraints=True),
                    pins=[PinSpec(sku_id=1, kind="set_qty", qty=7)])
    d1 = next(d for d in res.decisions if d.sku_id == 1)
    assert d1.loaded_qty == 7
    assert d1.pinned is True


def test_force_exclude_removes_sku():
    skus = [make_sku(id=1, retail_price=3.0, cost_price=0.4),  # strong contributor
            make_sku(id=2, retail_price=2.0, cost_price=0.5)]
    fc = {1: make_forecast(1, 20.0), 2: make_forecast(2, 10.0)}
    base, _ = _solve(skus, fc)
    pinned, _ = _solve(skus, fc, params=SelectionParams(soft_constraints=True),
                       pins=[PinSpec(sku_id=1, kind="force_exclude")])
    d1 = next(d for d in pinned.decisions if d.sku_id == 1)
    assert d1.loaded_qty == 0
    # Excluding the top contributor cannot improve the objective.
    assert pinned.objective_value_gbp <= base.objective_value_gbp + 1e-6


def test_force_include_loads_uneconomic_sku():
    skus = [make_sku(id=1, retail_price=0.45, cost_price=0.40, shelf_life_days=200),
            make_sku(id=2, retail_price=2.0, cost_price=0.5)]
    fc = {1: make_forecast(1, 1.0), 2: make_forecast(2, 10.0)}
    base, _ = _solve(skus, fc)
    d1_base = next(d for d in base.decisions if d.sku_id == 1)
    assert d1_base.loaded_qty == 0  # not worth loading on its own
    pinned, _ = _solve(skus, fc, params=SelectionParams(soft_constraints=True),
                       pins=[PinSpec(sku_id=1, kind="force_include")])
    d1 = next(d for d in pinned.decisions if d.sku_id == 1)
    assert d1.loaded_qty > 0


def test_validate_pins_capacity_flags_volume():
    # One tiny drawer; pin a huge quantity that cannot fit.
    big = make_sku(id=1, length_mm=200, width_mm=200, height_mm=200)  # 8000 cm3 each
    drawers = make_drawers(1)  # 1 full ATLAS ~33600 cm3 * 0.65 ≈ 21840
    err = validate_pins_capacity(
        drawers, make_aircraft(), [big],
        [PinSpec(sku_id=1, kind="set_qty", qty=50)],
        SelectionParams(),
    )
    assert err is not None
    assert err["reason"] == "pins_exceed_capacity"
    assert err["constraint"] == "volume"


def test_determinism():
    skus = [make_sku(id=i, retail_price=1.0 + i * 0.1) for i in range(1, 11)]
    fc = {s.id: make_forecast(s.id, 5.0 + s.id) for s in skus}
    r1, _ = _solve(skus, fc)
    r2, _ = _solve(skus, fc)
    assert {d.sku_id: d.loaded_qty for d in r1.decisions} == {d.sku_id: d.loaded_qty for d in r2.decisions}
