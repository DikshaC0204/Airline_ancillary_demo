"""Temporal splitting, scoring, and the method comparison."""

from __future__ import annotations

from datetime import datetime, timedelta

import numpy as np
import pytest

from app.models import Flight, Sale, Sku
from app.optim import forecast_evaluation as fe
from app.optim import forecast_lightgbm as lgbm
from app.optim.forecast import EMPIRICAL
from app.optim.forecast_data import load_training_frame
from tests.conftest import TRUE_RATES, build_synthetic_history

CUTOFF = datetime(2026, 1, 1)


def _frame(session):
    return load_training_frame(session, as_of=CUTOFF)


# ---------------------------------------------------------------------------
# Splitting
# ---------------------------------------------------------------------------

def test_a_split_never_cuts_a_date_in_half(memory_session):
    build_synthetic_history(memory_session, flights=120)
    frame = _frame(memory_session)

    boundary = fe.split_date_at(frame, 0.8)
    before, after = fe.split_on_date(frame, boundary)

    assert set(before.dates).isdisjoint(set(after.dates))
    assert max(before.dates) < boundary <= min(after.dates)
    assert len(before) + len(after) == len(frame)


def test_every_leg_of_a_rotation_lands_on_one_side(memory_session):
    build_synthetic_history(memory_session, flights=120)
    # Two legs of one rotation on the same calendar date.
    memory_session.add(Flight(
        id=5000, route_id=1, flight_no="ROT-1", scheduled_dt=datetime(2025, 3, 1, 7, 0),
        aircraft_id=1, expected_pax=150, expected_load_factor=0.8,
        pax_mix_json={"leisure": 1.0}, cabin_config_json={}, rotation_id=3, leg_index=1,
    ))
    memory_session.add(Flight(
        id=5001, route_id=1, flight_no="ROT-2", scheduled_dt=datetime(2025, 3, 1, 19, 0),
        aircraft_id=1, expected_pax=150, expected_load_factor=0.8,
        pax_mix_json={"leisure": 1.0}, cabin_config_json={}, rotation_id=3, leg_index=2,
    ))
    for fid in (5000, 5001):
        memory_session.add(Sale(flight_id=fid, sku_id=1, units_sold=2, revenue=3.0, unsold_units=3))
    memory_session.commit()

    frame = _frame(memory_session)
    before, after = fe.split_on_date(frame, datetime(2025, 3, 1))
    legs_before = {int(f) for f in before.flight_ids} & {5000, 5001}
    legs_after = {int(f) for f in after.flight_ids} & {5000, 5001}
    assert not (legs_before and legs_after)


def test_a_single_date_cannot_be_split(memory_session):
    build_synthetic_history(memory_session, flights=1)
    assert fe.split_date_at(_frame(memory_session), 0.8) is None


def test_thin_history_is_refused_rather_than_trained_on(memory_session):
    build_synthetic_history(memory_session, flights=20)
    with pytest.raises(fe.InsufficientData):
        fe.check_sufficient(_frame(memory_session))


def test_sufficient_history_passes_the_check(memory_session):
    build_synthetic_history(memory_session, flights=200)
    fe.check_sufficient(_frame(memory_session))  # must not raise


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

def test_metrics_are_empty_for_an_empty_slice():
    empty = fe.MetricSet()
    assert empty.rows == 0
    assert empty.to_dict()["censored_nll"] is None


def test_a_perfect_forecast_scores_near_zero_error(memory_session):
    build_synthetic_history(memory_session, flights=150, overload=99.0)  # nothing sells out
    frame = _frame(memory_session)
    metrics = fe.evaluate_predictions(frame.units_sold.copy(), frame)

    assert metrics.capped_mae < 0.35
    assert metrics.sellout_rows == 0
    assert metrics.uncensored_rows == len(frame)


def test_over_forecasting_shows_a_positive_bias(memory_session):
    build_synthetic_history(memory_session, flights=150, overload=99.0)
    frame = _frame(memory_session)

    high = fe.evaluate_predictions(frame.units_sold + 1.0, frame)
    low = fe.evaluate_predictions(np.maximum(frame.units_sold - 1.0, 0.0), frame)
    assert high.capped_bias > 0
    assert low.capped_bias < 0


def test_wape_is_none_when_nothing_sold(memory_session):
    build_synthetic_history(memory_session, flights=150)
    frame = _frame(memory_session)
    frame.units_sold[:] = 0.0
    assert fe.evaluate_predictions(np.zeros(len(frame)), frame).capped_wape is None


def test_slices_partition_every_row(memory_session):
    build_synthetic_history(memory_session, flights=150)
    frame = _frame(memory_session)
    mu = np.full(len(frame), 0.5)

    by_category = fe.slice_metrics(mu, frame, "category")
    assert set(by_category) == set(TRUE_RATES)
    assert sum(s["rows"] for s in by_category.values()) == len(frame)


def test_an_unknown_slice_feature_is_rejected(memory_session):
    build_synthetic_history(memory_session, flights=120)
    frame = _frame(memory_session)
    with pytest.raises(ValueError, match="not a categorical feature"):
        fe.slice_metrics(np.zeros(len(frame)), frame, "expected_pax")


# ---------------------------------------------------------------------------
# Poisson GLM
# ---------------------------------------------------------------------------

def test_glm_recovers_the_generating_rates(memory_session):
    build_synthetic_history(memory_session, flights=200)
    frame = _frame(memory_session)
    glm = fe.PoissonGlm().fit(frame)

    mu = glm.predict_rows(frame)
    rates = mu / frame.exposure
    categories = np.array([row[fe.CATEGORICAL_FEATURES.index("category")] for row in frame.categorical_rows])

    for category, true_rate in TRUE_RATES.items():
        got = float(np.mean(rates[categories == category]))
        assert got == pytest.approx(true_rate, rel=0.5), f"{category}: {got}"


def test_glm_refuses_an_empty_frame(memory_session):
    with pytest.raises(ValueError, match="empty"):
        fe.PoissonGlm().fit(_frame(memory_session))


def test_glm_predictions_are_finite_for_unseen_categories(memory_session):
    build_synthetic_history(memory_session, flights=150)
    frame = _frame(memory_session)
    glm = fe.PoissonGlm().fit(frame)

    frame.categorical_rows[0][fe.CATEGORICAL_FEATURES.index("brand")] = "BrandNeverSeen"
    assert np.all(np.isfinite(glm.predict_rows(frame)))


# ---------------------------------------------------------------------------
# End-to-end comparison
# ---------------------------------------------------------------------------

@pytest.mark.skipif(not lgbm.is_available(), reason="lightgbm not installed")
def test_comparison_scores_every_method_on_the_same_held_out_dates(memory_session):
    build_synthetic_history(memory_session, flights=240)
    model, report = fe.train_and_evaluate(
        memory_session,
        cutoff=CUTOFF,
        params=lgbm.LightGbmParams(num_boost_round=60, min_data_in_leaf=50),
    )

    methods = {m["method"]: m for m in report["methods"]}
    assert set(methods) == {EMPIRICAL, fe.GLM, lgbm.LIGHTGBM if hasattr(lgbm, "LIGHTGBM") else "lightgbm"}
    assert report["rows"]["train"] > 0 and report["rows"]["test"] > 0
    assert report["validation_from"] > report["dataset"]["train_start"]
    assert report["data_is_synthetic"] is True
    assert report["caveats"]

    for name, entry in methods.items():
        assert entry["metrics"]["rows"] == report["rows"]["test"], name
        assert entry["metrics"]["censored_nll"] is not None, name

    # The deployment artifact is refit on everything up to the cutoff.
    assert model.training_rows > report["rows"]["train"]


@pytest.mark.skipif(not lgbm.is_available(), reason="lightgbm not installed")
def test_comparison_refuses_when_history_is_too_thin(memory_session):
    build_synthetic_history(memory_session, flights=30)
    with pytest.raises(fe.InsufficientData):
        fe.train_and_evaluate(memory_session, cutoff=CUTOFF)


def test_comparison_needs_flights_at_all(memory_session):
    with pytest.raises(fe.InsufficientData, match="no flights"):
        fe.train_and_evaluate(memory_session)
