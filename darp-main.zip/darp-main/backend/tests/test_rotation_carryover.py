"""Multi-leg rotation carry-over fuel behaviour."""

from __future__ import annotations

from app.optim.selection import SelectionParams, solve_selection
from tests.conftest import make_forecast, make_inputs, make_sku


def test_sales_allocated_to_earlier_leg_first():
    # One heavy SKU, two legs with equal demand caps. Selling early reduces
    # carried weight on the later leg, so the optimiser prefers leg-1 sales.
    sku = make_sku(id=1, unit_weight_g=2000.0, retail_price=5.0, cost_price=1.0,
                   case_size=1, min_pack_size=1)
    leg1 = {1: make_forecast(1, 5.0, 5.0)}
    leg2 = {1: make_forecast(1, 5.0, 5.0)}
    inp = make_inputs([sku], [leg1, leg2])
    res = solve_selection(inp)
    d = next(d for d in res.decisions if d.sku_id == 1)
    assert d.loaded_qty > 0
    # leg_sales keyed by 1-based leg index.
    assert d.leg_sales.get(1, 0) >= d.leg_sales.get(2, 0)
    # Cannot sell more than loaded.
    assert sum(d.leg_sales.values()) <= d.loaded_qty + 1e-6


def test_carryover_fuel_higher_than_single_leg():
    # The same SKU carried across two legs costs more fuel than one leg.
    sku = make_sku(id=1, unit_weight_g=1800.0, retail_price=6.0, cost_price=1.0,
                   case_size=1, min_pack_size=1)
    single = solve_selection(make_inputs([sku], [{1: make_forecast(1, 3.0, 3.0)}]))
    twoleg = solve_selection(make_inputs([sku], [{1: make_forecast(1, 3.0, 3.0)},
                                                 {1: make_forecast(1, 3.0, 3.0)}]))
    d_single = next(d for d in single.decisions if d.sku_id == 1)
    d_two = next(d for d in twoleg.decisions if d.sku_id == 1)
    if d_single.loaded_qty > 0 and d_two.loaded_qty > 0:
        # Per-unit fuel is at least as high across two legs (some units carried twice).
        assert d_two.fuel_cost >= d_single.fuel_cost - 1e-6
