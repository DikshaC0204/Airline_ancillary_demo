"""A scenario prices its own run and nobody else's.

Fuel price used to be written into the shared CostParams row for the duration of
a scenario run, so overlapping scenarios compounded each other's multipliers and
could leave the stored price wrong once they finished.
"""

from __future__ import annotations

from datetime import datetime

import pytest
from sqlalchemy import select

from app.models import CostParams, OptimisationRun, Sku
from app.optim.engine import _repriced_fuel, run_optimisation
from app.optim.forecast_service import ForecastContext
from app.optim.selection import SelectionParams
from tests.conftest import build_engine_world, make_cost_params


def test_repricing_fuel_does_not_touch_the_shared_row(memory_session):
    memory_session.add(make_cost_params(fuel_price_per_kg_gbp=1.0))
    memory_session.commit()

    stored = memory_session.execute(select(CostParams)).scalars().one()
    repriced = _repriced_fuel(stored, 1.5)
    memory_session.commit()

    assert repriced.fuel_price_per_kg_gbp == pytest.approx(1.5)
    assert repriced is not stored
    # Other cost levers survive the copy.
    assert repriced.pick_cost_per_unit_gbp == stored.pick_cost_per_unit_gbp
    assert memory_session.execute(
        select(CostParams.fuel_price_per_kg_gbp)
    ).scalar_one() == pytest.approx(1.0)


def test_a_scenario_run_leaves_the_stored_fuel_price_alone(memory_session):
    build_engine_world(memory_session, flights=8, skus_per_category=1)
    before = memory_session.execute(select(CostParams.fuel_price_per_kg_gbp)).scalar_one()

    run_id = run_optimisation(
        memory_session,
        flight_id=8,
        params=SelectionParams(solver_time_limit_s=2),
        forecast_context=ForecastContext(
            requested_method="empirical",
            effective_method="empirical",
            as_of=datetime(2025, 1, 9),
        ),
        fuel_price_multiplier=2.5,
    )

    run = memory_session.get(OptimisationRun, run_id)
    after = memory_session.execute(select(CostParams.fuel_price_per_kg_gbp)).scalar_one()

    assert after == pytest.approx(before)
    # The run still reports the price it was actually costed at.
    assert run.parameters_json["fuel_price_per_kg_gbp_used"] == pytest.approx(before * 2.5)


def test_a_dearer_scenario_costs_more_fuel(memory_session):
    build_engine_world(memory_session, flights=8, skus_per_category=1)
    for sku in memory_session.execute(select(Sku)).scalars():
        sku.unit_weight_g = 400.0
    memory_session.commit()

    context = ForecastContext(
        requested_method="empirical",
        effective_method="empirical",
        as_of=datetime(2025, 1, 9),
    )
    cheap = run_optimisation(
        memory_session, flight_id=8, params=SelectionParams(solver_time_limit_s=2),
        forecast_context=context,
    )
    dear = run_optimisation(
        memory_session, flight_id=8, params=SelectionParams(solver_time_limit_s=2),
        forecast_context=context, fuel_price_multiplier=4.0,
    )

    cheap_run = memory_session.get(OptimisationRun, cheap)
    dear_run = memory_session.get(OptimisationRun, dear)
    assert dear_run.expected_net_contribution < cheap_run.expected_net_contribution
