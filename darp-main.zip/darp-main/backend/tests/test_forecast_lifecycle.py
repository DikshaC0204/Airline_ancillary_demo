"""Retraining after the data moves has to lead somewhere.

Two things used to make it a dead end: an edit the staleness check could not see,
and a pinned model that kept its claim on the LightGBM slot after going stale, so
the freshly trained replacement could never be selected.
"""

from __future__ import annotations

from datetime import datetime

import pytest

from app.models import ForecastTrainingJob, Sku
from app.optim import forecast_service as svc
from app.optim.forecast import LIGHTGBM
from app.optim.forecast_data import dataset_fingerprint
from tests.conftest import build_synthetic_history


@pytest.fixture
def model_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(svc.app_settings, "arp_model_dir", tmp_path / "models")
    return tmp_path / "models"


def _publish(model_id: str, session, *, fingerprint=None) -> ForecastTrainingJob:
    directory = svc.artifact_dir(model_id)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "meta.json").write_text("{}", encoding="utf-8")
    job = ForecastTrainingJob(
        model_id=model_id,
        state=svc.SUCCEEDED,
        data_fingerprint=fingerprint or dataset_fingerprint(session),
        information_cutoff=datetime(2025, 4, 1),
        requested_cutoff=datetime(2025, 4, 1),
        finished_at=datetime(2025, 4, 2),
    )
    session.add(job)
    session.commit()
    return job


def test_editing_the_catalogue_makes_a_model_stale(memory_session, model_dir):
    build_synthetic_history(memory_session, flights=120)
    _publish("model-a", memory_session)
    svc.set_method(memory_session, LIGHTGBM)
    assert svc.model_status(memory_session, "model-a")["state"] == svc.READY

    # Brand is a model feature, so this changes what a fit would learn even
    # though every row count and sum is untouched.
    memory_session.get(Sku, 1).brand = "Renamed"
    memory_session.commit()

    assert svc.model_status(memory_session, "model-a")["state"] == svc.STALE


def test_a_replacement_model_can_be_selected_once_the_pinned_one_is_stale(
    memory_session, model_dir
):
    build_synthetic_history(memory_session, flights=120)
    _publish("model-a", memory_session)
    svc.set_method(memory_session, LIGHTGBM)

    memory_session.get(Sku, 1).brand = "Renamed"
    memory_session.commit()
    _publish("model-b", memory_session)

    assert svc.candidate_model_id(memory_session) == "model-b"
    row = svc.set_method(memory_session, LIGHTGBM)
    assert row.active_model_id == "model-b"

    context = svc.resolve_context(memory_session, target_departure=datetime(2026, 1, 1))
    assert context.effective_method == LIGHTGBM
    assert context.model_id == "model-b"


def test_a_usable_pinned_model_is_not_replaced_by_a_newer_one(memory_session, model_dir):
    build_synthetic_history(memory_session, flights=120)
    _publish("model-a", memory_session)
    svc.set_method(memory_session, LIGHTGBM)
    _publish("model-b", memory_session)

    # Both are current, so the operator's choice stands until they change it.
    assert svc.candidate_model_id(memory_session) == "model-a"
