"""Shelf-life / spoilage cost behaviour."""

from __future__ import annotations

from app.optim.selection import solve_selection
from tests.conftest import make_forecast, make_inputs, make_sku


def test_spoilage_cost_only_on_perishables():
    perishable = make_sku(id=1, shelf_life_days=2, retail_price=4.0, cost_price=2.0,
                          warehouse_zone="chilled", category="Sandwiches & wraps")
    durable = make_sku(id=2, shelf_life_days=1825, retail_price=4.0, cost_price=2.0)
    fc = {1: make_forecast(1, 8.0, 14.0), 2: make_forecast(2, 8.0, 14.0)}
    res = solve_selection(make_inputs([perishable, durable], [fc]))
    d_per = next(d for d in res.decisions if d.sku_id == 1)
    d_dur = next(d for d in res.decisions if d.sku_id == 2)
    # Durable: essentially no spoilage. Perishable: spoilage applies to any unsold stock.
    assert d_dur.spoilage_cost <= 1e-6
    if d_per.loaded_qty > d_per.expected_sold:
        assert d_per.spoilage_cost > 0.0


def test_perishable_loaded_no_more_than_durable_equivalent():
    # Same economics except shelf life: the perishable should not be over-loaded
    # relative to the durable (spoilage discourages overstock).
    perishable = make_sku(id=1, shelf_life_days=2, retail_price=4.0, cost_price=2.0)
    durable = make_sku(id=2, shelf_life_days=1825, retail_price=4.0, cost_price=2.0)
    fc = {1: make_forecast(1, 10.0, 18.0), 2: make_forecast(2, 10.0, 18.0)}
    res = solve_selection(make_inputs([perishable, durable], [fc]))
    d_per = next(d for d in res.decisions if d.sku_id == 1)
    d_dur = next(d for d in res.decisions if d.sku_id == 2)
    assert d_per.loaded_qty <= d_dur.loaded_qty
