"""Time eligibility and stock-exposure rules for forecast training data."""

from __future__ import annotations

from datetime import datetime

import pytest

from app.models import Flight, Route, Sale, Sku
from app.optim import forecast_data as fd
from app.optim.forecast_data import (
    CENSORED,
    DatasetIntegrityError,
    FeatureEncoder,
    STOCKED,
    dataset_fingerprint,
    default_training_cutoff,
    load_training_frame,
)


ROUTE_KEY = "LTN-IBZ"


def _route(session, **kw) -> Route:
    defaults = dict(
        id=1, origin_iata="LTN", dest_iata="IBZ", distance_km=1450.0,
        flight_duration_min=145, haul_class="short", duty_free_allowed=False,
        alcohol_allowed=True, tobacco_allowed=False, seasonality_profile_json={},
    )
    defaults.update(kw)
    r = Route(**defaults)
    session.add(r)
    return r


def _sku(session, sku_id: int = 100, **kw) -> Sku:
    defaults = dict(
        id=sku_id, code=f"SKU-{sku_id}", name=f"Sku {sku_id}", category="Snacks (savoury)",
        sub_category="Crisps", brand="TestBrand", unit_weight_g=80.0,
        length_mm=60.0, width_mm=60.0, height_mm=100.0, volume_cm3=360.0,
        packaging_type="box", shelf_life_days=180, warehouse_zone="ambient-standard",
        cost_price=0.40, retail_price=1.50, margin_pct=0.73, supplier_id=1,
        min_pack_size=1, case_size=12,
    )
    defaults.update(kw)
    s = Sku(**defaults)
    session.add(s)
    return s


def _flight(session, flight_id: int, dt: datetime, *, pax: int = 180, route_id: int = 1, **kw) -> Flight:
    defaults = dict(
        id=flight_id, route_id=route_id, flight_no=f"U2{flight_id}", scheduled_dt=dt,
        aircraft_id=1, expected_pax=pax, expected_load_factor=0.9,
        pax_mix_json={"leisure": 0.8, "business": 0.2}, cabin_config_json={},
    )
    defaults.update(kw)
    f = Flight(**defaults)
    session.add(f)
    return f


def _sale(session, flight_id: int, sku_id: int, sold: int, unsold: int, returned: int = 0) -> Sale:
    s = Sale(
        flight_id=flight_id, sku_id=sku_id, units_sold=sold, revenue=sold * 1.5,
        unsold_units=unsold, returned_units=returned,
    )
    session.add(s)
    return s


def _basic(session):
    _route(session)
    _sku(session)
    session.flush()


# ---------------------------------------------------------------------------
# Time eligibility
# ---------------------------------------------------------------------------

def test_flight_is_eligible_only_after_it_has_landed(memory_session):
    _basic(memory_session)
    # Departs 10:00, 145-minute route, so its sales exist from 12:25.
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=3, unsold=2)
    memory_session.commit()

    landed = datetime(2025, 6, 1, 12, 25)
    assert len(load_training_frame(memory_session, as_of=landed)) == 0
    assert len(load_training_frame(memory_session, as_of=datetime(2025, 6, 1, 12, 26))) == 1


def test_future_flights_are_counted_as_excluded_not_silently_dropped(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _flight(memory_session, 2, datetime(2025, 9, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=3, unsold=2)
    _sale(memory_session, 2, 100, sold=4, unsold=1)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert len(frame) == 1
    assert frame.audit.future_rows_excluded == 1


def test_target_flight_and_every_rotation_leg_are_excluded(memory_session):
    _basic(memory_session)
    for fid in (1, 2, 3):
        _flight(memory_session, fid, datetime(2025, 6, fid, 10, 0), rotation_id=7 if fid > 1 else None)
        _sale(memory_session, fid, 100, sold=3, unsold=2)
    memory_session.commit()

    legs = fd.rotation_flight_ids(memory_session, 7)
    assert sorted(legs) == [2, 3]

    frame = load_training_frame(
        memory_session, as_of=datetime(2025, 7, 1), exclude_flight_ids=legs
    )
    assert len(frame) == 1
    assert frame.flight_ids.tolist() == [1]
    assert frame.audit.target_rows_excluded == 2


def test_default_cutoff_leaves_the_latest_month_for_out_of_time_targets(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _flight(memory_session, 2, datetime(2026, 4, 20, 10, 0))
    memory_session.commit()

    assert default_training_cutoff(memory_session) == datetime(2026, 4, 1)


def test_default_cutoff_is_none_without_flights(memory_session):
    assert default_training_cutoff(memory_session) is None


# ---------------------------------------------------------------------------
# Stock exposure
# ---------------------------------------------------------------------------

def test_never_stocked_rows_are_not_zero_demand_observations(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=0, unsold=0)  # never loaded
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert len(frame) == 0
    assert frame.audit.unstocked_rows == 1
    assert frame.audit.eligible_rows == 1


def test_stocked_zero_sales_are_kept_as_real_observations(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=0, unsold=4)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert len(frame) == 1
    assert frame.units_sold.tolist() == [0.0]
    assert frame.censored.tolist() == [False]
    assert frame.audit.stocked_rows == 1


def test_selling_the_whole_load_is_censored_not_exact_demand(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=5, unsold=0)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert frame.censored.tolist() == [True]
    assert frame.loaded_units.tolist() == [5.0]
    assert frame.audit.censored_rows == 1


def test_loaded_units_are_reconstructed_from_sold_plus_unsold(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=3, unsold=2, returned=2)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert frame.loaded_units.tolist() == [5.0]
    assert frame.exposure.tolist() == [180.0]


def test_zero_pax_flights_carry_no_exposure_to_scale_a_rate_by(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0), pax=0)
    _sale(memory_session, 1, 100, sold=0, unsold=3)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert len(frame) == 0
    assert frame.audit.zero_pax_rows_skipped == 1


# ---------------------------------------------------------------------------
# Integrity
# ---------------------------------------------------------------------------

def test_duplicate_flight_sku_rows_fail_rather_than_being_summed(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=1, unsold=1)
    _sale(memory_session, 1, 100, sold=2, unsold=1)
    memory_session.commit()

    with pytest.raises(DatasetIntegrityError, match="duplicate"):
        load_training_frame(memory_session, as_of=datetime(2025, 7, 1))


def test_returns_cannot_exceed_unsold_stock(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=1, unsold=1, returned=5)
    memory_session.commit()

    with pytest.raises(DatasetIntegrityError, match="returned exceeds unsold"):
        load_training_frame(memory_session, as_of=datetime(2025, 7, 1))


def test_negative_units_are_rejected(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=-1, unsold=1)
    memory_session.commit()

    with pytest.raises(DatasetIntegrityError, match="negative units"):
        load_training_frame(memory_session, as_of=datetime(2025, 7, 1))


def test_sales_for_unknown_flights_are_audited(memory_session):
    _basic(memory_session)
    _sale(memory_session, 999, 100, sold=1, unsold=1)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    assert frame.audit.unknown_flight_rows == 1


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------

def test_features_exclude_every_outcome_field():
    banned = {"units_sold", "revenue", "unsold", "returned", "sold_at_minute", "demand"}
    assert not banned & set(fd.FEATURE_NAMES)


def test_feature_row_uses_only_preflight_inputs(memory_session):
    _basic(memory_session)
    flight = _flight(memory_session, 1, datetime(2025, 6, 6, 19, 0))
    memory_session.commit()

    ctx = fd.flight_context(flight, memory_session.get(Route, 1))
    cats, nums = fd.feature_values(ctx, memory_session.get(Sku, 100))
    named = dict(zip(fd.CATEGORICAL_FEATURES, cats)) | dict(zip(fd.NUMERIC_FEATURES, nums))

    assert named["route_key"] == ROUTE_KEY
    assert named["season_slot"] == "peak"       # June on a summer-leisure route
    assert named["time_of_day"] == "evening"
    assert named["dow_bucket"] == "friday"
    assert named["expected_pax"] == 180.0
    assert named["pax_leisure"] == 0.8
    assert named["pax_diaspora"] == 0.0         # absent segment, not missing


def test_encoder_is_deterministic_and_maps_unseen_categories_to_missing():
    def row(route: str) -> list[str]:
        return [route] + ["x"] * (len(fd.CATEGORICAL_FEATURES) - 1)

    enc = FeatureEncoder.fit([row("b"), row("a")])
    assert enc.vocabularies["route_key"] == {"a": 0, "b": 1}  # sorted, not insertion order

    codes = enc.encode([row("b"), row("a")])
    assert codes[0][0] == 1.0 and codes[1][0] == 0.0
    assert enc.encode([row("never-seen")])[0][0] == -1.0

    roundtrip = FeatureEncoder.from_dict(enc.to_dict())
    assert roundtrip.vocabularies == enc.vocabularies


def test_encoder_rejects_a_row_of_the_wrong_width():
    enc = FeatureEncoder(vocabularies={})
    with pytest.raises(DatasetIntegrityError, match="categorical values"):
        enc.encode([["only-one"]])


def test_encoder_rejects_a_mismatched_schema_version():
    with pytest.raises(DatasetIntegrityError, match="feature schema"):
        FeatureEncoder.from_dict({"schema_version": 999, "vocabularies": {}})


def test_encoder_fits_vocabulary_only_on_rows_it_is_given(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=2, unsold=2)
    memory_session.commit()

    frame = load_training_frame(memory_session, as_of=datetime(2025, 7, 1))
    enc = FeatureEncoder.fit(frame.categorical_rows)
    assert enc.vocabularies["route_key"] == {ROUTE_KEY: 0}

    matrix = enc.matrix(frame.categorical_rows, frame.numeric_rows)
    assert matrix.shape == (1, len(fd.FEATURE_NAMES))


# ---------------------------------------------------------------------------
# Fingerprint
# ---------------------------------------------------------------------------

def test_fingerprint_detects_an_edit_in_place(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    sale = _sale(memory_session, 1, 100, sold=2, unsold=2)
    memory_session.commit()
    before = dataset_fingerprint(memory_session)

    sale.units_sold = 3
    memory_session.commit()

    assert dataset_fingerprint(memory_session) != before


def test_fingerprint_is_stable_across_reads(memory_session):
    _basic(memory_session)
    _flight(memory_session, 1, datetime(2025, 6, 1, 10, 0))
    _sale(memory_session, 1, 100, sold=2, unsold=2)
    memory_session.commit()

    assert dataset_fingerprint(memory_session) == dataset_fingerprint(memory_session)


def test_observation_status_constants_are_distinct():
    assert len({STOCKED, CENSORED, fd.UNSTOCKED}) == 3
