"""The optional LightGBM provider: what it learns, persists, and refuses to guess."""

from __future__ import annotations

import math
from datetime import datetime, timedelta

import numpy as np
import pytest

from app.models import Flight, Route, Sale, Sku
from app.optim.forecast import DemandForecaster, LIGHTGBM
from app.optim.forecast_data import load_training_frame
from app.optim import forecast_lightgbm as lgbm
from tests.conftest import TRUE_RATES, build_synthetic_history

pytestmark = pytest.mark.skipif(not lgbm.is_available(), reason="lightgbm not installed")


CUTOFF = datetime(2026, 1, 1)


def _seed_history(session, **kw) -> None:
    build_synthetic_history(session, **kw)


def _fit(session, **kw):
    frame = load_training_frame(session, as_of=CUTOFF)
    params = lgbm.LightGbmParams(num_boost_round=80, min_data_in_leaf=50, **kw)
    return frame, lgbm.train_model(frame, params=params)


def _rate_for(model, session, sku_id: int, pax: int = 180) -> float:
    from app.optim.forecast_data import feature_values, flight_context

    flight = session.get(Flight, 1)
    ctx = flight_context(flight)
    cats, nums = feature_values(ctx, session.get(Sku, sku_id))
    return float(model.predict_rate([cats], [nums])[0])


# ---------------------------------------------------------------------------
# Learning
# ---------------------------------------------------------------------------

def test_model_recovers_the_demand_rate_of_each_category(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)

    by_cat = {}
    for sku in memory_session.query(Sku).all():
        by_cat.setdefault(sku.category, []).append(_rate_for(model, memory_session, sku.id))

    for category, true_rate in TRUE_RATES.items():
        got = float(np.mean(by_cat[category]))
        assert got == pytest.approx(true_rate, rel=0.45), f"{category}: {got} vs {true_rate}"

    assert np.mean(by_cat["Fast"]) > np.mean(by_cat["Mid"]) > np.mean(by_cat["Slow"])


def test_predicted_rates_are_finite_and_non_negative(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    rates = [_rate_for(model, memory_session, s.id) for s in memory_session.query(Sku).all()]
    assert all(math.isfinite(r) and r >= 0 for r in rates)


def test_training_is_reproducible_for_the_same_data_and_seed(memory_session):
    _seed_history(memory_session)
    _, first = _fit(memory_session)
    _, second = _fit(memory_session)
    ids = [s.id for s in memory_session.query(Sku).all()]
    a = [_rate_for(first, memory_session, i) for i in ids]
    b = [_rate_for(second, memory_session, i) for i in ids]
    assert a == pytest.approx(b, rel=1e-12)


def test_empty_training_data_is_refused(memory_session):
    frame = load_training_frame(memory_session, as_of=CUTOFF)
    with pytest.raises(ValueError, match="empty"):
        lgbm.train_model(frame)


def test_early_stopping_uses_the_validation_frame(memory_session):
    _seed_history(memory_session)
    frame = load_training_frame(memory_session, as_of=CUTOFF)
    split = np.array([d < datetime(2025, 7, 1) for d in frame.dates])
    train, valid = frame.subset(split), frame.subset(~split)

    model = lgbm.train_model(
        train,
        valid_frame=valid,
        params=lgbm.LightGbmParams(num_boost_round=200, early_stopping_rounds=10, min_data_in_leaf=50),
    )
    assert 0 < model.best_iteration <= 200


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def test_saved_model_predicts_identically_after_reload(memory_session, tmp_path):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    model.save(tmp_path / "artifact")

    reloaded = lgbm.TrainedModel.load(tmp_path / "artifact")
    ids = [s.id for s in memory_session.query(Sku).all()]
    before = [_rate_for(model, memory_session, i) for i in ids]
    after = [_rate_for(reloaded, memory_session, i) for i in ids]

    assert before == pytest.approx(after, rel=1e-12)
    assert reloaded.base_rate == model.base_rate
    assert reloaded.encoder.vocabularies == model.encoder.vocabularies


def test_a_model_built_on_other_features_is_rejected(memory_session, tmp_path):
    import json

    _seed_history(memory_session)
    _, model = _fit(memory_session)
    model.save(tmp_path / "artifact")

    meta_path = tmp_path / "artifact" / lgbm.META_FILE
    meta = json.loads(meta_path.read_text())
    meta["feature_names"] = ["something_else"]
    meta_path.write_text(json.dumps(meta))

    with pytest.raises(lgbm.LightGbmUnavailable, match="different feature set"):
        lgbm.TrainedModel.load(tmp_path / "artifact")


def test_a_stale_artifact_version_is_rejected(memory_session, tmp_path):
    import json

    _seed_history(memory_session)
    _, model = _fit(memory_session)
    model.save(tmp_path / "artifact")

    meta_path = tmp_path / "artifact" / lgbm.META_FILE
    meta = json.loads(meta_path.read_text())
    meta["artifact_version"] = 999
    meta_path.write_text(json.dumps(meta))

    with pytest.raises(lgbm.LightGbmUnavailable, match="artifact version"):
        lgbm.TrainedModel.load(tmp_path / "artifact")


# ---------------------------------------------------------------------------
# Serving and fallback
# ---------------------------------------------------------------------------

def test_forecaster_returns_one_result_per_sku_tagged_with_its_method(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)

    skus = memory_session.query(Sku).all()
    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)
    results = forecaster.predict_flight(memory_session.get(Flight, 1), skus)

    assert len(results) == len(skus)
    assert {r.sku_id for r in results} == {s.id for s in skus}
    assert all(r.method == LIGHTGBM for r in results)
    assert all(r.expected_units >= 0 for r in results)
    assert forecaster.fallbacks.total == 0


def test_expected_units_are_the_predicted_rate_times_passengers(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    sku = memory_session.query(Sku).first()
    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)

    flight = memory_session.get(Flight, 1)
    flight.expected_pax = 150
    result = forecaster.predict_flight(flight, [sku])[0]

    assert result.expected_units == pytest.approx(150 * _rate_for(model, memory_session, sku.id))


def test_a_busier_flight_is_forecast_to_sell_more(memory_session):
    """Pax drives the offset, but it is also a feature, so the rate may shift too."""
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    skus = memory_session.query(Sku).all()
    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)

    flight = memory_session.get(Flight, 1)
    flight.expected_pax = 100
    small = sum(r.expected_units for r in forecaster.predict_flight(flight, skus))
    flight.expected_pax = 200
    large = sum(r.expected_units for r in forecaster.predict_flight(flight, skus))

    assert large > small
    assert large == pytest.approx(2 * small, rel=0.25)


def test_an_empty_flight_forecasts_no_demand(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)

    flight = memory_session.get(Flight, 1)
    flight.expected_pax = 0
    results = forecaster.predict_flight(flight, memory_session.query(Sku).all())

    assert all(r.expected_units == 0.0 for r in results)


def test_quantiles_are_ordered_and_the_mean_is_not_the_median(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)
    results = forecaster.predict_flight(memory_session.get(Flight, 1), memory_session.query(Sku).all())

    for r in results:
        assert r.p10_units <= r.p50_units <= r.p90_units
    # A slow line's median demand is zero while its mean is a small fraction.
    slow = min(results, key=lambda r: r.expected_units)
    assert slow.p50_units == 0.0
    assert 0.0 < slow.expected_units < 1.0


def test_an_unknown_sku_falls_back_to_the_empirical_prior_and_is_counted(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)

    newcomer = Sku(
        id=9999, code="NEW-1", name="Brand new line", category="Fast",
        sub_category="Fast-sub", brand="Brand0", unit_weight_g=80.0,
        length_mm=60.0, width_mm=60.0, height_mm=100.0, volume_cm3=360.0,
        packaging_type="box", shelf_life_days=180, warehouse_zone="ambient-standard",
        cost_price=0.4, retail_price=1.5, margin_pct=0.7, supplier_id=1,
        min_pack_size=1, case_size=12,
    )
    memory_session.add(newcomer)
    memory_session.commit()

    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)
    results = forecaster.predict_flight(memory_session.get(Flight, 1), [newcomer])

    assert forecaster.fallbacks.unknown_sku == 1
    assert results[0].method.endswith("_fallback")
    assert results[0].expected_units > 0  # the category prior still has something to say


def test_explicit_cold_start_requests_bypass_the_model(memory_session):
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    skus = memory_session.query(Sku).all()[:2]

    forecaster = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)
    results = forecaster.predict_flight(
        memory_session.get(Flight, 1), skus, cold_start_skus={skus[0].id}
    )

    assert forecaster.fallbacks.requested_cold_start == 1
    by_id = {r.sku_id: r for r in results}
    assert by_id[skus[0].id].method.endswith("_fallback")
    assert by_id[skus[1].id].method == LIGHTGBM


def test_fallback_report_is_serialisable():
    report = lgbm.FallbackReport(unknown_sku=2, invalid_prediction=1)
    assert report.to_dict() == {
        "unknown_sku": 2, "invalid_prediction": 1, "requested_cold_start": 0, "total": 3,
    }


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------

def test_library_version_is_reported_when_available():
    assert lgbm.is_available()
    assert lgbm.library_version()


def test_the_model_beats_the_empirical_forecaster_on_a_sold_out_line(memory_session):
    """Censoring correction should show up where loads bind hardest."""
    _seed_history(memory_session)
    _, model = _fit(memory_session)
    flight = memory_session.get(Flight, 1)
    fast = memory_session.query(Sku).filter(Sku.category == "Fast").all()

    lgb_fc = lgbm.LightGbmForecaster(memory_session, model, as_of=CUTOFF)
    emp_fc = DemandForecaster(memory_session, as_of=CUTOFF)
    lgb_mean = np.mean([r.expected_units for r in lgb_fc.predict_flight(flight, fast)])
    emp_mean = np.mean([r.expected_units for r in emp_fc.predict_flight(flight, fast)])

    truth = flight.expected_pax * TRUE_RATES["Fast"]
    assert abs(lgb_mean - truth) < abs(emp_mean - truth)
