"""Warehouse-zone handling cost differentiation."""

from __future__ import annotations

from app.optim.selection import solve_selection
from tests.conftest import make_forecast, make_inputs, make_sku


def _handling_per_unit(zone: str, requires_auth: bool = False) -> float:
    sku = make_sku(id=1, warehouse_zone=zone, requires_authorised_pick=requires_auth,
                   retail_price=3.0, cost_price=0.4)
    inp = make_inputs([sku], [{1: make_forecast(1, 10.0, 10.0)}])
    res = solve_selection(inp)
    d = next(d for d in res.decisions if d.sku_id == 1)
    assert d.loaded_qty > 0
    return d.handling_cost / d.loaded_qty


def test_bonded_zone_costs_more_than_fast():
    fast = _handling_per_unit("ambient-fast")
    bonded = _handling_per_unit("bonded")
    assert bonded > fast


def test_authorised_pick_adds_surcharge():
    base = _handling_per_unit("ambient-standard", requires_auth=False)
    auth = _handling_per_unit("ambient-standard", requires_auth=True)
    assert auth > base
