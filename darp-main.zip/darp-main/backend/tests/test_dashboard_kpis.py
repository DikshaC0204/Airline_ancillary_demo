"""Baseline counterfactual and dashboard KPI derivation.

The dashboard's headline numbers are a claim made to a customer, so the
properties that make them defensible are asserted here: both sides of the
comparison are costed by the same objective, neither side books revenue it
cannot earn, and the derived percentages stay inside their own bounds.
"""

from __future__ import annotations

import math

from app.api.dashboard import _headline_kpis, _uplift_pct
from app.models import BrandRule, OptimisationRun, RegulatoryRule
from app.optim.baseline import (
    MANUAL_STOCK_BUFFER,
    MIN_TURNOVER_PER_FLIGHT_GBP,
    compute_baseline,
    plan_manual_loads,
)
from app.optim.selection import SelectionParams, effective_brand_minimums, solve_selection

from .conftest import make_drawers, make_forecast, make_inputs, make_route, make_sku


def _premium(**kw):
    """A slow-moving, high-value line — fragrance or sunglasses."""
    defaults = dict(cost_price=10.0, retail_price=48.0, category="Fragrance & cosmetics")
    defaults.update(kw)
    return make_sku(**defaults)


# --------------------------------------------------------------------------
# What the manual planner stocks
# --------------------------------------------------------------------------

def test_baseline_is_deterministic():
    skus = [make_sku(id=1), make_sku(id=2), make_sku(id=3)]
    fcs = {1: make_forecast(1, 10.0), 2: make_forecast(2, 4.0), 3: make_forecast(3, 2.0)}
    inp = make_inputs(skus, [fcs])

    assert plan_manual_loads(inp) == plan_manual_loads(inp)


def test_baseline_applies_the_stock_buffer():
    skus = [make_sku(id=1)]
    inp = make_inputs(skus, [{1: make_forecast(1, 10.0)}])

    loads, _ = plan_manual_loads(inp)

    # Stock MANUAL_STOCK_BUFFER x forecast demand — the "never sell out" heuristic.
    assert loads[1] == math.ceil(10.0 * MANUAL_STOCK_BUFFER)


def test_brand_minimums_cannot_exceed_the_demand_that_exists():
    # Uncapped, the seeded rules demanded 23 open lines on a flight with 20 units
    # of total demand, which is a guaranteed loss before any choice is made.
    cat = [make_sku(id=i, category="Spirits (mini)") for i in range(1, 9)]
    forecasts = {s.id: make_forecast(s.id, 0.025) for s in cat}  # 0.2 units total
    rule = BrandRule(id=1, category="Spirits (mini)", min_skus=4, min_units=6, max_share_pct=0.3)

    min_skus, min_units = effective_brand_minimums(rule, cat, forecasts)

    assert min_skus == 1
    assert min_units == 1


def test_brand_minimums_are_untouched_when_demand_supports_them():
    cat = [make_sku(id=i, category="Soft drinks") for i in range(1, 9)]
    forecasts = {s.id: make_forecast(s.id, 4.0) for s in cat}  # 32 units total
    rule = BrandRule(id=1, category="Soft drinks", min_skus=5, min_units=18, max_share_pct=0.4)

    assert effective_brand_minimums(rule, cat, forecasts) == (5, 18)


def test_baseline_drops_lines_that_barely_turn_over():
    slow = make_sku(id=2)  # 0.1 units x GBP 1.50 = GBP 0.15 a flight
    inp = make_inputs([make_sku(id=1), slow], [{1: make_forecast(1, 10.0), 2: make_forecast(2, 0.1)}])

    loads, _ = plan_manual_loads(inp)

    assert 0.1 * slow.retail_price < MIN_TURNOVER_PER_FLIGHT_GBP
    assert 2 not in loads
    assert 1 in loads


def test_baseline_stocks_slow_moving_high_value_lines():
    # Screening on demand volume would drop this; screening on turnover keeps it.
    # Without it the baseline cannot hold premium range and the uplift is a fiction.
    inp = make_inputs([_premium(id=1)], [{1: make_forecast(1, 0.2)}])

    loads, _ = plan_manual_loads(inp)

    assert loads[1] >= 1


def test_baseline_excludes_regulatory_banned_categories():
    route = make_route(id=1)
    skus = [make_sku(id=1, category="Tobacco", retail_price=60.0), make_sku(id=2)]
    fcs = {1: make_forecast(1, 5.0), 2: make_forecast(2, 5.0)}
    rules = [RegulatoryRule(id=1, route_id=1, sku_category="Tobacco", rule_type="disallow", parameters_json={})]
    inp = make_inputs(skus, [fcs], routes=[route], regulatory_rules=rules)

    loads, _ = plan_manual_loads(inp)

    assert 1 not in loads
    assert 2 in loads


def test_baseline_is_trimmed_to_the_galley_it_must_fit():
    # 60 bulky lines would need far more space than one drawer offers. A manual
    # plan that cannot be loaded is not a fair thing to measure uplift against.
    skus = [make_sku(id=i, length_mm=200, width_mm=200, height_mm=200) for i in range(1, 61)]
    fcs = {i: make_forecast(i, 5.0) for i in range(1, 61)}
    inp = make_inputs(skus, [fcs], drawers=make_drawers(1))

    loads, trimmed = plan_manual_loads(inp)

    assert trimmed > 0
    capacity = sum(
        d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in inp.drawers
    ) * inp.params.volume_efficiency_eta
    by_id = {s.id: s for s in skus}
    assert sum(by_id[i].volume_cm3 * q for i, q in loads.items()) <= capacity


# --------------------------------------------------------------------------
# Both sides costed the same way
# --------------------------------------------------------------------------

def test_baseline_is_costed_by_the_optimisers_own_objective():
    # Scoring the baseline with a separate cost function gave it cheaper costs
    # (no zone multipliers, no spoilage) and the "uplift" measured the gap
    # between two cost models rather than the quality of the plan.
    skus = [make_sku(id=1), _premium(id=2)]
    fcs = {1: make_forecast(1, 8.0), 2: make_forecast(2, 0.3)}
    inp = make_inputs(skus, [fcs])

    res = compute_baseline(inp)

    assert res.status in ("OPTIMAL", "FEASIBLE")
    assert res.total_units > 0


def test_baseline_never_books_more_sales_than_demand():
    skus = [make_sku(id=1)]
    inp = make_inputs(skus, [{1: make_forecast(1, 8.0)}])

    res = compute_baseline(inp)

    # It loads 1.4x demand but can only ever sell what passengers want, and
    # strictly less than the mean because stock cannot cover every outcome.
    assert res.expected_sold_units < 8.0
    assert res.unsold_units > 0


def test_optimiser_never_books_more_sales_than_demand():
    # The bug this guards: expected sales were capped at a demand *quantile* and
    # the objective drove them to that cap, so the plan booked revenue on its own
    # safety stock and overstated net contribution by ~167%.
    skus = [make_sku(id=i, retail_price=4.0, cost_price=0.5) for i in range(1, 11)]
    fcs = {i: make_forecast(i, 6.0) for i in range(1, 11)}

    res = solve_selection(make_inputs(skus, [fcs]))

    assert res.status in ("OPTIMAL", "FEASIBLE")
    for d in res.decisions:
        assert d.expected_sold <= 6.0 + 1e-6, f"sku {d.sku_id} books sales above mean demand"


def test_loading_more_yields_diminishing_expected_sales():
    """E[min(D, x)] is concave — the tenth unit of a line selling two is worthless."""
    skus = [make_sku(id=1, retail_price=4.0, cost_price=0.5)]
    fcs = {1: make_forecast(1, 5.0)}

    sold = []
    for qty in (2, 5, 10):
        from app.optim.selection import PinSpec
        inp = make_inputs(skus, [fcs], pins=[PinSpec(sku_id=1, kind="set_qty", qty=qty)])
        res = solve_selection(inp)
        sold.append(next(d.expected_sold for d in res.decisions if d.sku_id == 1))

    assert sold[0] < sold[1] < sold[2]
    assert (sold[2] - sold[1]) < (sold[1] - sold[0])


# --------------------------------------------------------------------------
# KPI aggregation
# --------------------------------------------------------------------------

def _run(net, base_net, waste, base_waste, service=0.9):
    return OptimisationRun(
        flight_id=1,
        status="done",
        expected_net_contribution=net,
        baseline_net_contribution=base_net,
        expected_waste_units=waste,
        baseline_waste_units=base_waste,
        service_level_achieved=service,
    )


def test_kpis_are_null_with_no_runs():
    kpis = _headline_kpis([])

    assert kpis["expected_uplift_pct"] is None
    assert kpis["waste_reduction_pct"] is None
    assert kpis["service_level_pct"] is None


def test_uplift_is_positive_when_the_optimiser_beats_the_baseline():
    kpis = _headline_kpis([_run(net=120.0, base_net=100.0, waste=10.0, base_waste=40.0)])

    assert kpis["expected_uplift_pct"] == 20.0
    assert kpis["net_uplift_gbp"] == 20.0
    assert kpis["waste_reduction_pct"] == 75.0
    assert kpis["waste_units_saved"] == 30.0


def test_uplift_is_negative_when_the_optimiser_loses():
    kpis = _headline_kpis([_run(net=80.0, base_net=100.0, waste=10.0, base_waste=40.0)])

    assert kpis["expected_uplift_pct"] == -20.0


def test_waste_reduction_cannot_exceed_one_hundred_percent():
    kpis = _headline_kpis([_run(net=120.0, base_net=100.0, waste=0.0, base_waste=40.0)])

    assert kpis["waste_reduction_pct"] == 100.0


def test_kpis_aggregate_on_totals_not_mean_of_percentages():
    # A tiny flight with a huge relative gain must not dominate a large one.
    small = _run(net=2.0, base_net=1.0, waste=0.0, base_waste=1.0)  # +100%
    large = _run(net=1000.0, base_net=1000.0, waste=100.0, base_waste=100.0)  # 0%

    kpis = _headline_kpis([small, large])

    # Mean of percentages would give 50%; totals give ~0.1%.
    assert kpis["expected_uplift_pct"] < 1.0


def test_uplift_percentage_is_withheld_against_a_loss_making_baseline():
    # On a thin flight the manual plan genuinely loses money. Dividing by that
    # produced figures like +239% that mean nothing; the money delta is used.
    assert _uplift_pct(9.82, -7.06) is None
    assert _uplift_pct(9.82, 0.0) is None
    assert _uplift_pct(120.0, 100.0) == 20.0


def test_kpis_fall_back_to_money_when_the_baseline_is_negative():
    kpis = _headline_kpis([_run(net=10.0, base_net=-7.0, waste=1.0, base_waste=2.0)])

    assert kpis["expected_uplift_pct"] is None
    assert kpis["net_uplift_gbp"] == 17.0


def test_a_profitable_baseline_cannot_carry_loss_making_ones_into_a_percentage():
    # The three approved runs behind "+164.8%": summing the baselines let two
    # loss-making flights cancel a profitable one down to £40.81, so a £67 gain
    # read as a triple-digit percentage.
    kpis = _headline_kpis([
        _run(net=72.11, base_net=49.85, waste=0.0, base_waste=0.0),
        _run(net=9.82, base_net=-7.06, waste=0.0, base_waste=0.0),
        _run(net=26.13, base_net=-1.98, waste=0.0, base_waste=0.0),
    ])

    assert kpis["expected_uplift_pct"] is None
    assert round(kpis["net_uplift_gbp"], 2) == 67.25
