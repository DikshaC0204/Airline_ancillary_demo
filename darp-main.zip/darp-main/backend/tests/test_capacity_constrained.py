"""Galley capacity as a real constraint, not a formality.

A single short-haul leg does not fill a retail galley, so on its own it never
forces the optimiser to choose between lines. A *rotation* does: one range is
loaded at the origin and has to serve every leg, so the same drawers must hold
several flights' demand. That is where "the most profitable range that
physically fits" stops being a slogan, and it is what these tests pin down — if
a future demand recalibration quietly un-binds it, the claim goes with it.
"""

from __future__ import annotations

from app.optim import explain
from app.optim.selection import SelectionParams, solve_selection
from tests.conftest import make_drawers, make_forecast, make_inputs, make_sku


def _catalogue(n: int = 14) -> list:
    """A mixed catalogue: a few dense high-margin lines, several bulky ones."""
    skus = []
    for i in range(1, n + 1):
        bulky = i % 2 == 0
        skus.append(make_sku(
            id=i,
            category=f"Cat{i % 4}",
            length_mm=110 if bulky else 55,
            width_mm=110 if bulky else 55,
            height_mm=110 if bulky else 55,
            retail_price=2.0 + (i % 5) * 0.8,
            cost_price=0.5,
            unit_weight_g=90.0,
        ))
    return skus


def _plan(skus, legs: int, demand: float = 3.0, drawers=3, **kw):
    """Sized from measurement: one leg fills ~81% of the galley, three fill it."""
    forecasts = [
        {s.id: make_forecast(s.id, demand, demand * 1.3) for s in skus} for _ in range(legs)
    ]
    inp = make_inputs(skus, forecasts, drawers=make_drawers(drawers), **kw)
    res = solve_selection(inp)
    return inp, res, explain.analyse(inp, res)


def _volume_cap(inp) -> float:
    total = sum(
        d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in inp.drawers
    )
    return total * inp.params.volume_efficiency_eta


def _utilisation(inp, res) -> float:
    return res.total_volume_cm3 / _volume_cap(inp)


# ---------------------------------------------------------------------------
# Capacity has to actually bind
# ---------------------------------------------------------------------------

def test_a_rotation_fills_a_galley_a_single_leg_does_not():
    skus = _catalogue()
    inp1, one_leg, analysis1 = _plan(skus, legs=1)
    inp3, three_legs, _ = _plan(skus, legs=3)

    assert _utilisation(inp1, one_leg) < 0.85
    assert _utilisation(inp3, three_legs) > 0.95

    # With room to spare, nothing has to be sacrificed.
    one_leg_codes = {info["reason_code"] for info in analysis1["decisions"].values()}
    assert not one_leg_codes & {
        explain.REDUCED_TO_FIT_VOLUME, explain.EXCLUDED_DISPLACED_VOLUME
    }


def test_the_plan_never_exceeds_the_galley_it_has_to_fit_in():
    inp, res, _ = _plan(_catalogue(), legs=3)
    assert res.total_volume_cm3 <= _volume_cap(inp) + 1e-6


def test_the_constraint_report_names_volume_as_the_limiting_factor():
    _, _, analysis = _plan(_catalogue(), legs=3)
    volume = next(c for c in analysis["constraints"] if c["kind"] == "volume")
    weight = next(c for c in analysis["constraints"] if c["kind"] == "weight")

    # Chunky items cannot always fill the final gap, so "binding" and "near" are
    # both honest here; what matters is that space is what ran out.
    assert volume["status"] in (explain.BINDING, explain.NEAR)
    assert volume["utilisation_pct"] >= 95.0
    # Weight is nowhere near its budget; claiming otherwise would be theatre.
    assert weight["status"] == explain.SLACK
    assert volume["utilisation_pct"] > weight["utilisation_pct"]


# ---------------------------------------------------------------------------
# What the planner is told about the trade-off
# ---------------------------------------------------------------------------

def test_scarcity_produces_trade_off_reasons():
    _, res, analysis = _plan(_catalogue(), legs=3)
    codes = {info["reason_code"] for info in analysis["decisions"].values()}

    # A full galley must show up as lines cut back, dropped, or both — otherwise
    # nothing was actually traded off.
    assert codes & {explain.REDUCED_TO_FIT_VOLUME, explain.EXCLUDED_DISPLACED_VOLUME}
    assert any(d.loaded_qty == 0 for d in res.decisions) or any(
        info["reason_code"] == explain.REDUCED_TO_FIT_VOLUME
        for info in analysis["decisions"].values()
    )


def test_a_displaced_line_is_told_why_it_lost():
    _, _, analysis = _plan(_catalogue(), legs=3)
    displaced = [
        info for info in analysis["decisions"].values()
        if info["reason_code"] == explain.EXCLUDED_DISPLACED_VOLUME
    ]
    assert displaced

    for info in displaced:
        detail = info["reason_detail"]
        # A line with nothing loaded has no realised density, so the explanation
        # has to value it at its forecast demand. Printing "£?" there hides
        # exactly the number the decision turned on.
        assert detail["net_per_cm3"] is not None
        assert "?" not in info["reason_text"]
        assert f"{detail['net_per_cm3']:.4f}" in info["reason_text"]


def test_a_slack_galley_does_not_get_blamed_for_a_trim():
    """A line cut back while the galley is two-thirds empty was not cut for space."""
    _, _, analysis = _plan(_catalogue(), legs=1, drawers=8)
    volume = next(c for c in analysis["constraints"] if c["kind"] == "volume")
    assert volume["status"] == explain.SLACK

    for info in analysis["decisions"].values():
        assert info["reason_code"] not in (
            explain.REDUCED_TO_FIT_VOLUME, explain.REDUCED_TO_FIT_WEIGHT,
        ), info["reason_text"]
        if info["reason_code"] == explain.REDUCED_MARGINAL_UNIT:
            assert "budget" not in info["reason_text"]


def test_trade_off_reasons_carry_the_numbers_they_turned_on():
    """Whichever way a line loses space, the planner is shown why."""
    _, _, analysis = _plan(_catalogue(), legs=3)
    affected = [
        info for info in analysis["decisions"].values()
        if info["reason_code"] in (explain.REDUCED_TO_FIT_VOLUME, explain.EXCLUDED_DISPLACED_VOLUME)
    ]
    assert affected

    for info in affected:
        detail = info["reason_detail"]
        assert "?" not in info["reason_text"]
        if info["reason_code"] == explain.REDUCED_TO_FIT_VOLUME:
            assert detail["loaded"] < detail["demand"]
        else:
            assert detail["net_per_cm3"] is not None


def test_every_line_still_gets_a_readable_reason_under_pressure():
    _, _, analysis = _plan(_catalogue(), legs=3)
    for info in analysis["decisions"].values():
        assert info["reason_code"]
        assert info["reason_text"]
        assert "?" not in info["reason_text"]


# ---------------------------------------------------------------------------
# The optimiser should spend scarce space on the better lines
# ---------------------------------------------------------------------------

def test_a_tighter_galley_keeps_the_denser_earners():
    """Halving the space should cost margin, but less than proportionally."""
    skus = _catalogue()
    roomy_inp, roomy, _ = _plan(skus, legs=3, drawers=2)
    tight_inp, tight, _ = _plan(skus, legs=3, drawers=1)

    assert tight.total_volume_cm3 < roomy.total_volume_cm3
    assert tight.expected_net_contribution <= roomy.expected_net_contribution
    # Value per cm³ must rise as space gets scarce, not stay flat.
    roomy_density = roomy.expected_net_contribution / max(roomy.total_volume_cm3, 1.0)
    tight_density = tight.expected_net_contribution / max(tight.total_volume_cm3, 1.0)
    assert tight_density >= roomy_density


def test_relaxing_the_volume_efficiency_lets_more_on_board():
    skus = _catalogue()
    _, tight, _ = _plan(skus, legs=3, params=SelectionParams(volume_efficiency_eta=0.5))
    _, loose, _ = _plan(skus, legs=3, params=SelectionParams(volume_efficiency_eta=0.8))

    assert loose.total_volume_cm3 > tight.total_volume_cm3
    assert loose.expected_net_contribution >= tight.expected_net_contribution
