"""Pydantic schemas for read-only API responses (P0)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


class _ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class SupplierOut(_ORM):
    id: int
    name: str
    min_commitment_units_per_month: int


class SkuOut(_ORM):
    id: int
    code: str
    name: str
    category: str
    sub_category: str
    brand: str
    unit_weight_g: float
    length_mm: float
    width_mm: float
    height_mm: float
    volume_cm3: float
    packaging_type: str
    stackable: bool
    max_stack_height: int
    fragility_score: int
    orientation_constraint: str
    shelf_life_days: int
    hazard_class: str
    warehouse_zone: str
    cost_price: float
    retail_price: float
    margin_pct: float
    supplier_id: int
    min_pack_size: int
    case_size: int
    bonded: bool
    requires_authorised_pick: bool
    image_url: Optional[str] = None


class SkuUpdate(BaseModel):
    name: Optional[str] = None
    retail_price: Optional[float] = None
    cost_price: Optional[float] = None
    case_size: Optional[int] = None
    min_pack_size: Optional[int] = None


class RouteOut(_ORM):
    id: int
    origin_iata: str
    dest_iata: str
    distance_km: float
    flight_duration_min: int
    haul_class: str
    duty_free_allowed: bool
    alcohol_allowed: bool
    tobacco_allowed: bool
    seasonality_profile_json: dict[str, Any]


class FlightOut(_ORM):
    id: int
    route_id: int
    flight_no: str
    scheduled_dt: datetime
    aircraft_id: int
    expected_pax: int
    expected_load_factor: float
    pax_mix_json: dict[str, float]
    cabin_config_json: dict[str, Any]
    rotation_id: Optional[int] = None
    leg_index: Optional[int] = None


class RotationLegOut(_ORM):
    flight_id: int
    leg_index: int
    flight_no: str
    origin_iata: str
    dest_iata: str
    scheduled_dt: datetime
    expected_pax: int


class RotationOut(BaseModel):
    id: int
    code: str
    description: Optional[str] = None
    legs: list[RotationLegOut] = []


class DrawerOut(_ORM):
    id: int
    cart_id: int
    slot_index: int
    type: str
    internal_l_mm: float
    internal_w_mm: float
    internal_h_mm: float
    max_weight_kg: float
    accessibility_score: int


class CartOut(_ORM):
    id: int
    galley_layout_id: int
    position_code: str
    cart_type: str
    drawers: list[DrawerOut] = []


class GalleyLayoutOut(_ORM):
    id: int
    aircraft_type: str
    num_retail_carts: int
    schematic_json: dict[str, Any]
    carts: list[CartOut] = []


class AircraftOut(_ORM):
    id: int
    registration: str
    type: str
    retail_galley_layout_id: int
    empty_weight_kg: float
    max_payload_kg: float
    fuel_burn_coeff_short: float
    fuel_burn_coeff_medium: float
    fuel_burn_coeff_long: float


class SaleOut(_ORM):
    id: int
    flight_id: int
    sku_id: int
    units_sold: int
    revenue: float
    unsold_units: int
    returned_units: int
    sold_at_minute_of_flight: Optional[int] = None


class CostParamsOut(_ORM):
    id: int
    valid_from: datetime
    fuel_price_per_kg_gbp: float
    pick_cost_per_unit_gbp: float
    pack_cost_per_drawer_gbp: float
    cart_assembly_cost_gbp: float
    return_handling_cost_per_unit_gbp: float
    complexity_penalty_per_new_pickline_gbp: float
    pick_zone_multipliers_json: dict[str, float] = {}
    bonded_access_surcharge_gbp: float = 1.50
    authorised_pick_surcharge_per_unit_gbp: float = 0.12
    pickline_min_expected_margin_gbp: float = 6.00
    case_break_penalty_gbp: float = 0.40
    spoilage_reuse_cycle_days: float = 3.0


class RegulatoryRuleOut(_ORM):
    id: int
    route_id: Optional[int] = None
    sku_category: str
    rule_type: str
    parameters_json: dict[str, Any]


class DashboardSummary(BaseModel):
    total_skus: int
    total_routes: int
    total_flights: int
    total_sales_rows: int
    # Null until at least one run has completed — the UI renders an empty state.
    expected_uplift_pct: Optional[float] = None
    waste_reduction_pct: Optional[float] = None
    service_level_pct: Optional[float] = None
    kpi_basis: str = "none"  # approved|latest|none
    runs_counted: int = 0
    routes: list[dict[str, Any]]


class Paginated(BaseModel):
    total: int
    items: list[Any]
