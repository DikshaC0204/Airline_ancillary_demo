"""SKU catalogue — ~140 SKUs across 15 categories.

Each SKU has realistic dimensions, weight, packaging, hazard class, margin,
supplier mapping, case size, etc. The list is hand-curated so it stays stable
across re-seeds.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class SkuSpec:
    code: str
    name: str
    category: str
    sub_category: str
    brand: str
    unit_weight_g: float
    length_mm: float
    width_mm: float
    height_mm: float
    packaging_type: str
    stackable: bool
    max_stack_height: int
    fragility_score: int
    orientation_constraint: str
    shelf_life_days: int
    hazard_class: str
    cost_price: float
    retail_price: float
    supplier_name: str
    min_pack_size: int
    case_size: int
    bonded: bool
    requires_authorised_pick: bool


def volume_cm3(s: SkuSpec) -> float:
    return (s.length_mm * s.width_mm * s.height_mm) / 1000.0


# Suppliers used across the catalogue.
SUPPLIERS: tuple[str, ...] = (
    "Diageo",
    "Pernod Ricard",
    "Heineken UK",
    "Coca-Cola Europe",
    "Britvic",
    "Nestlé",
    "Mondelez",
    "Mars Wrigley",
    "PepsiCo",
    "Lavazza",
    "Premier Foods",
    "easyJet Bistro",
    "L'Oréal Travel Retail",
    "LVMH Travel Retail",
    "Luxottica",
    "Generic Gifts Co",
    "Imperial Tobacco",
    "Kids Travel Co",
)


def _spirits_mini() -> list[SkuSpec]:
    items = [
        ("Gordon's London Dry", "Diageo", 65, 32, 32, 105),
        ("Tanqueray", "Diageo", 65, 32, 32, 105),
        ("Smirnoff Red", "Diageo", 65, 32, 32, 105),
        ("Bombay Sapphire", "Pernod Ricard", 68, 32, 32, 105),
        ("Jack Daniel's Old No.7", "Diageo", 70, 32, 32, 105),
        ("Jameson Irish Whiskey", "Pernod Ricard", 70, 32, 32, 105),
        ("Bacardi Carta Blanca", "Pernod Ricard", 65, 32, 32, 105),
        ("Captain Morgan Spiced", "Diageo", 70, 32, 32, 105),
        ("Absolut Vodka", "Pernod Ricard", 65, 32, 32, 105),
        ("Hendrick's Gin", "Pernod Ricard", 72, 36, 36, 105),
        ("Baileys Original", "Diageo", 78, 36, 36, 105),
        ("Glenfiddich 12yo", "Pernod Ricard", 75, 34, 34, 105),
    ]
    return [
        SkuSpec(
            code=f"SPM-{i+1:03d}",
            name=f"{name} 50ml",
            category="Spirits (mini)",
            sub_category="Mini",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="glass_bottle",
            stackable=False,
            max_stack_height=1,
            fragility_score=4,
            orientation_constraint="upright_only",
            shelf_life_days=1825,
            hazard_class="alcohol",
            cost_price=2.10,
            retail_price=5.50,
            supplier_name=sup,
            min_pack_size=1,
            case_size=24,
            bonded=True,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h) in enumerate(items)
    ]


def _spirits_full() -> list[SkuSpec]:
    items = [
        ("Johnnie Walker Black 1L", "Diageo", 1450, 90, 90, 270, 18.0, 32.0, 24),
        ("Glenfiddich 12yo 70cl", "Pernod Ricard", 1300, 85, 85, 265, 22.0, 38.0, 12),
        ("Tanqueray Gin 1L", "Diageo", 1400, 90, 90, 270, 16.5, 28.0, 12),
        ("Absolut Vodka 1L", "Pernod Ricard", 1400, 90, 90, 270, 14.0, 22.0, 12),
        ("Bacardi Rum 1L", "Pernod Ricard", 1400, 90, 90, 270, 14.5, 23.0, 12),
        ("Jack Daniel's 1L", "Diageo", 1500, 95, 95, 270, 19.5, 32.0, 12),
        ("Hendrick's Gin 70cl", "Pernod Ricard", 1250, 82, 82, 260, 26.0, 42.0, 12),
        ("Baileys 70cl", "Diageo", 1300, 82, 82, 260, 11.0, 17.5, 12),
    ]
    return [
        SkuSpec(
            code=f"SPF-{i+1:03d}",
            name=name,
            category="Spirits (full)",
            sub_category="Full size",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="glass_bottle",
            stackable=False,
            max_stack_height=1,
            fragility_score=5,
            orientation_constraint="upright_only",
            shelf_life_days=3650,
            hazard_class="alcohol",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=cs,
            bonded=True,
            requires_authorised_pick=True,
        )
        for i, (name, sup, w, l, ww, h, cp, rp, cs) in enumerate(items)
    ]


def _wine() -> list[SkuSpec]:
    items = [
        ("Prosecco Mini 187ml", "Pernod Ricard", 290, 55, 55, 200, 2.30, 6.00),
        ("Champagne Mini 200ml", "LVMH Travel Retail", 320, 60, 60, 215, 6.00, 14.00),
        ("Red Wine 187ml", "Pernod Ricard", 295, 55, 55, 200, 1.80, 5.50),
        ("White Wine 187ml", "Pernod Ricard", 295, 55, 55, 200, 1.80, 5.50),
        ("Rosé 187ml", "Pernod Ricard", 295, 55, 55, 200, 1.80, 5.50),
        ("Prosecco 75cl", "Pernod Ricard", 1300, 80, 80, 265, 7.50, 18.00),
        ("Bordeaux Red 75cl", "Pernod Ricard", 1250, 78, 78, 270, 9.00, 22.00),
        ("Sauvignon Blanc 75cl", "Pernod Ricard", 1250, 78, 78, 270, 8.00, 19.00),
    ]
    return [
        SkuSpec(
            code=f"WIN-{i+1:03d}",
            name=name,
            category="Wine",
            sub_category="Sparkling" if "Prosecco" in name or "Champagne" in name else "Still",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="glass_bottle",
            stackable=False,
            max_stack_height=1,
            fragility_score=4,
            orientation_constraint="upright_only",
            shelf_life_days=1095,
            hazard_class="alcohol",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=12,
            bonded=True,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _beer_cider() -> list[SkuSpec]:
    items = [
        ("Heineken 330ml", "Heineken UK", 350, 66, 66, 115, 0.85, 3.00),
        ("Amstel 330ml", "Heineken UK", 350, 66, 66, 115, 0.80, 2.80),
        ("Birra Moretti 330ml", "Heineken UK", 350, 66, 66, 115, 0.90, 3.20),
        ("Corona Extra 330ml", "Heineken UK", 360, 66, 66, 240, 1.10, 3.80),
        ("BrewDog Punk IPA 330ml", "Heineken UK", 350, 66, 66, 115, 1.20, 4.20),
        ("Carlsberg 330ml", "Heineken UK", 350, 66, 66, 115, 0.80, 2.80),
        ("Strongbow Cider 330ml", "Heineken UK", 360, 66, 66, 115, 0.85, 3.00),
        ("Kopparberg Mixed Fruit 330ml", "Heineken UK", 370, 66, 66, 240, 1.30, 4.20),
        ("Guinness Original 440ml", "Heineken UK", 470, 66, 66, 150, 1.30, 4.00),
        ("Peroni Nastro Azzurro 330ml", "Heineken UK", 360, 66, 66, 240, 1.20, 4.00),
    ]
    return [
        SkuSpec(
            code=f"BEE-{i+1:03d}",
            name=name,
            category="Beer & cider",
            sub_category="Cider" if "Cider" in name or "Kopparberg" in name else "Beer",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="can" if w < 380 and "Corona" not in name and "Kopparberg" not in name else "glass_bottle",
            stackable=True,
            max_stack_height=4,
            fragility_score=2,
            orientation_constraint="upright_only",
            shelf_life_days=270,
            hazard_class="alcohol",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=24,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _soft_drinks() -> list[SkuSpec]:
    items = [
        ("Coca-Cola 330ml", "Coca-Cola Europe", 350, 66, 66, 115, 0.30, 2.50, "can"),
        ("Diet Coke 330ml", "Coca-Cola Europe", 350, 66, 66, 115, 0.30, 2.50, "can"),
        ("Coke Zero 330ml", "Coca-Cola Europe", 350, 66, 66, 115, 0.30, 2.50, "can"),
        ("Sprite 330ml", "Coca-Cola Europe", 350, 66, 66, 115, 0.30, 2.30, "can"),
        ("Fanta Orange 330ml", "Coca-Cola Europe", 350, 66, 66, 115, 0.30, 2.30, "can"),
        ("Schweppes Tonic 200ml", "Britvic", 230, 50, 50, 110, 0.40, 2.20, "can"),
        ("Schweppes Soda 200ml", "Britvic", 230, 50, 50, 110, 0.40, 2.20, "can"),
        ("Red Bull 250ml", "Britvic", 280, 53, 53, 134, 1.10, 3.80, "can"),
        ("Monster Energy 500ml", "Britvic", 545, 66, 66, 168, 1.40, 4.20, "can"),
        ("Still Water 500ml", "Coca-Cola Europe", 520, 62, 62, 215, 0.20, 2.00, "plastic_bottle"),
        ("Sparkling Water 500ml", "Coca-Cola Europe", 525, 62, 62, 215, 0.20, 2.00, "plastic_bottle"),
        ("Tropicana Orange 250ml", "PepsiCo", 275, 50, 50, 130, 0.55, 2.80, "carton"),
        ("Tropicana Apple 250ml", "PepsiCo", 275, 50, 50, 130, 0.55, 2.80, "carton"),
        ("Innocent Smoothie 250ml", "Coca-Cola Europe", 280, 55, 55, 130, 1.10, 3.50, "plastic_bottle"),
    ]
    return [
        SkuSpec(
            code=f"SFT-{i+1:03d}",
            name=name,
            category="Soft drinks",
            sub_category="Energy" if "Red Bull" in name or "Monster" in name else "Water" if "Water" in name else "Juice" if "Tropicana" in name or "Innocent" in name else "Carbonated",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type=pkg,
            stackable=True,
            max_stack_height=4,
            fragility_score=1,
            orientation_constraint="upright_only" if pkg != "carton" else "any",
            shelf_life_days=120,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=24,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp, pkg) in enumerate(items)
    ]


def _hot_drinks() -> list[SkuSpec]:
    items = [
        ("Lavazza Espresso Pod", "Lavazza", 8, 38, 38, 30),
        ("Lavazza Cappuccino Pod", "Lavazza", 10, 38, 38, 30),
        ("Decaf Coffee Pod", "Lavazza", 8, 38, 38, 30),
        ("English Breakfast Tea Bag", "Premier Foods", 4, 60, 60, 8),
        ("Earl Grey Tea Bag", "Premier Foods", 4, 60, 60, 8),
        ("Green Tea Bag", "Premier Foods", 4, 60, 60, 8),
    ]
    return [
        SkuSpec(
            code=f"HOT-{i+1:03d}",
            name=name,
            category="Hot drinks",
            sub_category="Coffee" if "Coffee" in name or "Espresso" in name or "Cappuccino" in name or "Decaf" in name else "Tea",
            brand=sup,
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="pod" if "Pod" in name else "tea_bag",
            stackable=True,
            max_stack_height=10,
            fragility_score=1,
            orientation_constraint="any",
            shelf_life_days=540,
            hazard_class="none",
            cost_price=0.15,
            retail_price=2.50,
            supplier_name=sup,
            min_pack_size=1,
            case_size=100,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h) in enumerate(items)
    ]


def _savoury_snacks() -> list[SkuSpec]:
    items = [
        ("Pringles Original Mini", "Mondelez", 40, 50, 50, 110, 0.50, 2.20),
        ("Pringles Sour Cream Mini", "Mondelez", 40, 50, 50, 110, 0.50, 2.20),
        ("Pringles Salt & Vinegar Mini", "Mondelez", 40, 50, 50, 110, 0.50, 2.20),
        ("Walkers Ready Salted", "PepsiCo", 32, 200, 130, 40, 0.30, 1.80),
        ("Walkers Cheese & Onion", "PepsiCo", 32, 200, 130, 40, 0.30, 1.80),
        ("Walkers Salt & Vinegar", "PepsiCo", 32, 200, 130, 40, 0.30, 1.80),
        ("Doritos Cool Original", "PepsiCo", 40, 220, 140, 45, 0.40, 2.00),
        ("Cheddar Pretzels", "Mondelez", 80, 180, 120, 50, 0.80, 2.80),
        ("Mixed Nuts 60g", "Mondelez", 75, 140, 90, 30, 1.20, 3.50),
        ("Salted Cashews 60g", "Mondelez", 75, 140, 90, 30, 1.40, 3.80),
        ("Sea Salt Popcorn", "Mondelez", 35, 200, 150, 60, 0.50, 2.20),
        ("Sweet & Salt Popcorn", "Mondelez", 35, 200, 150, 60, 0.50, 2.20),
        ("Mini Cheddars", "Mondelez", 50, 160, 100, 40, 0.40, 1.80),
        ("Bombay Mix 50g", "Mondelez", 60, 140, 90, 30, 0.80, 2.50),
    ]
    return [
        SkuSpec(
            code=f"SNS-{i+1:03d}",
            name=name,
            category="Snacks (savoury)",
            sub_category="Crisps" if "Pringles" in name or "Walkers" in name or "Doritos" in name else "Nuts" if "Nuts" in name or "Cashews" in name else "Popcorn" if "Popcorn" in name else "Other",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="tube" if "Pringles" in name else "bag",
            stackable="Pringles" not in name,
            max_stack_height=3 if "Pringles" in name else 6,
            fragility_score=3 if "Pringles" not in name else 2,
            orientation_constraint="upright_only" if "Pringles" in name else "any",
            shelf_life_days=180,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=24,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _sweet_snacks() -> list[SkuSpec]:
    items = [
        ("Cadbury Dairy Milk 45g", "Mondelez", 50, 110, 55, 12, 0.40, 1.80),
        ("Cadbury Wispa", "Mondelez", 36, 130, 50, 10, 0.30, 1.50),
        ("Cadbury Twirl", "Mondelez", 43, 130, 50, 12, 0.30, 1.50),
        ("Mars Bar", "Mars Wrigley", 51, 110, 30, 18, 0.30, 1.50),
        ("Snickers", "Mars Wrigley", 48, 110, 30, 18, 0.30, 1.50),
        ("Twix", "Mars Wrigley", 50, 110, 30, 22, 0.30, 1.50),
        ("M&M's Peanut", "Mars Wrigley", 45, 130, 65, 15, 0.40, 1.80),
        ("Kit Kat 4-finger", "Nestlé", 41, 150, 50, 12, 0.35, 1.60),
        ("Toblerone 100g", "Mondelez", 105, 220, 65, 30, 1.20, 4.00),
        ("Haribo Starmix 100g", "Mondelez", 105, 160, 100, 25, 0.50, 2.00),
        ("Galaxy Caramel", "Mars Wrigley", 48, 110, 30, 18, 0.30, 1.50),
        ("Oreo Mini Pack", "Mondelez", 50, 110, 55, 25, 0.40, 1.80),
    ]
    return [
        SkuSpec(
            code=f"SNW-{i+1:03d}",
            name=name,
            category="Snacks (sweet)",
            sub_category="Chocolate" if any(k in name for k in ["Dairy", "Wispa", "Twirl", "Mars", "Snickers", "Twix", "Kit Kat", "Toblerone", "Galaxy", "M&M"]) else "Sweets",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="wrapper",
            stackable=True,
            max_stack_height=8,
            fragility_score=2,
            orientation_constraint="any",
            shelf_life_days=270,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=36,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _sandwiches() -> list[SkuSpec]:
    items = [
        ("Chicken Caesar Wrap", 220, 200, 80, 50, 1.80, 5.50),
        ("Ham & Cheese Baguette", 230, 220, 70, 60, 1.80, 5.50),
        ("BLT Sandwich", 200, 170, 100, 50, 1.60, 5.00),
        ("Tuna Mayo Sandwich", 200, 170, 100, 50, 1.60, 5.00),
        ("Chicken & Bacon Sandwich", 220, 170, 100, 50, 1.80, 5.50),
        ("Egg Mayo Sandwich", 200, 170, 100, 50, 1.40, 4.80),
        ("Cheese Ploughman's", 220, 170, 100, 50, 1.60, 5.20),
        ("Falafel Wrap (V)", 215, 200, 80, 50, 1.70, 5.20),
        ("Caesar Salad Bowl", 230, 150, 130, 50, 2.20, 6.50),
        ("Greek Salad Bowl", 230, 150, 130, 50, 2.20, 6.50),
    ]
    return [
        SkuSpec(
            code=f"SAN-{i+1:03d}",
            name=name,
            category="Sandwiches & wraps",
            sub_category="Wrap" if "Wrap" in name else "Sandwich" if "Sandwich" in name else "Baguette" if "Baguette" in name else "Salad",
            brand="easyJet Bistro",
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="chilled_pack",
            stackable=False,
            max_stack_height=2,
            fragility_score=3,
            orientation_constraint="any",
            shelf_life_days=2,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name="easyJet Bistro",
            min_pack_size=1,
            case_size=12,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _hot_meals() -> list[SkuSpec]:
    items = [
        ("Pasta Bolognese", 320, 180, 130, 45, 2.20, 7.50),
        ("Chicken Curry & Rice", 330, 180, 130, 45, 2.40, 7.80),
        ("Mac & Cheese", 300, 180, 130, 45, 2.00, 7.20),
        ("Vegetable Pasta (V)", 310, 180, 130, 45, 2.00, 7.20),
        ("English Breakfast Box", 280, 180, 130, 45, 2.30, 7.50),
        ("Beef Lasagne", 340, 180, 130, 45, 2.40, 8.00),
    ]
    return [
        SkuSpec(
            code=f"HOT-M{i+1:03d}",
            name=name,
            category="Hot meals",
            sub_category="Meal",
            brand="easyJet Bistro",
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="tray",
            stackable=True,
            max_stack_height=3,
            fragility_score=2,
            orientation_constraint="upright_only",
            shelf_life_days=4,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name="easyJet Bistro",
            min_pack_size=1,
            case_size=12,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _fragrance() -> list[SkuSpec]:
    items = [
        ("Chanel No.5 30ml Travel", "LVMH Travel Retail", 130, 50, 50, 100, 18.0, 55.0),
        ("Dior Sauvage 30ml Travel", "LVMH Travel Retail", 130, 50, 50, 100, 16.0, 50.0),
        ("Yves Saint Laurent Black Opium 30ml", "L'Oréal Travel Retail", 130, 50, 50, 100, 16.0, 50.0),
        ("Hugo Boss Bottled 30ml", "L'Oréal Travel Retail", 120, 48, 48, 95, 14.0, 42.0),
        ("Calvin Klein One 50ml", "L'Oréal Travel Retail", 180, 55, 55, 115, 14.0, 38.0),
        ("Marc Jacobs Daisy 30ml", "LVMH Travel Retail", 130, 50, 50, 100, 16.0, 48.0),
        ("Tom Ford Black Orchid 30ml", "LVMH Travel Retail", 140, 52, 52, 105, 22.0, 65.0),
        ("Jo Malone Lime Basil 30ml", "L'Oréal Travel Retail", 130, 50, 50, 100, 19.0, 55.0),
        ("MAC Lipstick Mini", "L'Oréal Travel Retail", 50, 25, 25, 80, 5.0, 16.0),
        ("Charlotte Tilbury Lipstick", "L'Oréal Travel Retail", 60, 25, 25, 90, 9.0, 28.0),
        ("Estée Lauder Double Wear Mini", "L'Oréal Travel Retail", 80, 30, 30, 80, 8.0, 22.0),
        ("Clinique Moisturiser 50ml", "L'Oréal Travel Retail", 110, 50, 50, 100, 10.0, 28.0),
        ("Travel-size Sunscreen SPF50", "L'Oréal Travel Retail", 120, 50, 50, 110, 4.0, 12.0),
        ("Aveda Hand Cream Mini", "L'Oréal Travel Retail", 90, 40, 40, 100, 4.0, 11.0),
    ]
    return [
        SkuSpec(
            code=f"FRA-{i+1:03d}",
            name=name,
            category="Fragrance & cosmetics",
            sub_category="Fragrance" if any(k in name for k in ["No.5", "Sauvage", "Opium", "Boss", "Calvin", "Daisy", "Black Orchid", "Lime Basil"]) else "Cosmetics",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="boxed_glass",
            stackable=False,
            max_stack_height=2,
            fragility_score=4,
            orientation_constraint="any",
            shelf_life_days=1825,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=12,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _sunglasses() -> list[SkuSpec]:
    items = [
        ("Ray-Ban Aviator Classic", "Luxottica", 30, 160, 65, 50, 45.0, 145.0),
        ("Ray-Ban Wayfarer", "Luxottica", 32, 155, 60, 50, 42.0, 135.0),
        ("Oakley Holbrook", "Luxottica", 28, 160, 65, 50, 48.0, 155.0),
        ("Persol PO0649", "Luxottica", 35, 160, 65, 50, 55.0, 175.0),
        ("Silk Scarf — easyJet edition", "Generic Gifts Co", 90, 200, 200, 30, 8.0, 28.0),
        ("Travel Hat Foldable", "Generic Gifts Co", 150, 250, 150, 60, 6.0, 22.0),
        ("Reading Glasses +2.0", "Luxottica", 35, 160, 60, 30, 6.0, 18.0),
        ("Beach Tote Bag", "Generic Gifts Co", 200, 300, 30, 250, 4.0, 14.0),
    ]
    return [
        SkuSpec(
            code=f"ACC-{i+1:03d}",
            name=name,
            category="Sunglasses & accessories",
            sub_category="Eyewear" if "Glasses" in name or any(k in name for k in ["Ray-Ban", "Oakley", "Persol"]) else "Accessories",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="case",
            stackable=True,
            max_stack_height=4,
            fragility_score=4,
            orientation_constraint="any",
            shelf_life_days=3650,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=6,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _gifts() -> list[SkuSpec]:
    items = [
        ("Lindt Gift Box 300g", "Mondelez", 380, 240, 170, 50, 6.0, 18.0),
        ("Cadbury Heroes Gift Tin", "Mondelez", 600, 200, 200, 90, 5.5, 16.0),
        ("Toblerone 360g Bar", "Mondelez", 380, 380, 75, 35, 5.0, 14.0),
        ("Travel Adapter Universal", "Generic Gifts Co", 180, 80, 60, 60, 6.0, 18.0),
        ("Power Bank 10000mAh", "Generic Gifts Co", 250, 140, 70, 18, 12.0, 35.0),
        ("Travel Neck Pillow Inflatable", "Generic Gifts Co", 150, 200, 150, 70, 4.0, 14.0),
        ("Eye Mask & Earplugs Set", "Generic Gifts Co", 70, 200, 110, 25, 2.5, 8.0),
        ("Compression Socks", "Generic Gifts Co", 90, 220, 110, 30, 4.0, 12.0),
        ("Bluetooth Earbuds Travel", "Generic Gifts Co", 120, 90, 60, 30, 18.0, 49.0),
        ("Premium Pen Set", "Generic Gifts Co", 200, 180, 80, 30, 8.0, 24.0),
    ]
    return [
        SkuSpec(
            code=f"GFT-{i+1:03d}",
            name=name,
            category="Gifts & travel essentials",
            sub_category="Gift" if "Gift" in name else "Travel",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="box",
            stackable=True,
            max_stack_height=3,
            fragility_score=3,
            orientation_constraint="any",
            shelf_life_days=3650,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name=sup,
            min_pack_size=1,
            case_size=8,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, sup, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _tobacco() -> list[SkuSpec]:
    items = [
        ("Marlboro Red 200s", 210, 90, 55, 90, 32.0, 60.0),
        ("Marlboro Gold 200s", 210, 90, 55, 90, 32.0, 60.0),
        ("Benson & Hedges 200s", 200, 90, 55, 90, 30.0, 58.0),
        ("Lambert & Butler 200s", 200, 90, 55, 90, 28.0, 55.0),
    ]
    return [
        SkuSpec(
            code=f"TOB-{i+1:03d}",
            name=name,
            category="Tobacco",
            sub_category="Cigarettes",
            brand=name.split()[0],
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="carton",
            stackable=True,
            max_stack_height=4,
            fragility_score=1,
            orientation_constraint="any",
            shelf_life_days=3650,
            hazard_class="tobacco",
            cost_price=cp,
            retail_price=rp,
            supplier_name="Imperial Tobacco",
            min_pack_size=1,
            case_size=10,
            bonded=True,
            requires_authorised_pick=True,
        )
        for i, (name, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def _kids() -> list[SkuSpec]:
    items = [
        ("Kids Activity Pack", 120, 220, 160, 15, 1.50, 5.50),
        ("Mini Lego Travel Set", 100, 150, 100, 30, 3.50, 9.00),
        ("Disney Sticker Book", 80, 220, 160, 8, 1.00, 4.00),
        ("Kids Snack Box", 150, 180, 130, 40, 1.80, 5.50),
    ]
    return [
        SkuSpec(
            code=f"KID-{i+1:03d}",
            name=name,
            category="Children",
            sub_category="Activity" if "Activity" in name or "Sticker" in name else "Toy" if "Lego" in name else "Food",
            brand="Kids Travel Co",
            unit_weight_g=w,
            length_mm=l,
            width_mm=ww,
            height_mm=h,
            packaging_type="box",
            stackable=True,
            max_stack_height=4,
            fragility_score=1,
            orientation_constraint="any",
            shelf_life_days=365 if "Snack" in name else 3650,
            hazard_class="none",
            cost_price=cp,
            retail_price=rp,
            supplier_name="Kids Travel Co",
            min_pack_size=1,
            case_size=12,
            bonded=False,
            requires_authorised_pick=False,
        )
        for i, (name, w, l, ww, h, cp, rp) in enumerate(items)
    ]


def all_skus() -> list[SkuSpec]:
    """Return the complete SKU catalogue (deterministic order)."""
    out: list[SkuSpec] = []
    for fn in (
        _spirits_mini,
        _spirits_full,
        _wine,
        _beer_cider,
        _soft_drinks,
        _hot_drinks,
        _savoury_snacks,
        _sweet_snacks,
        _sandwiches,
        _hot_meals,
        _fragrance,
        _sunglasses,
        _gifts,
        _tobacco,
        _kids,
    ):
        out.extend(fn())
    return out
