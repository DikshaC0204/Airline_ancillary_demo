"""Seed orchestrator.

Usage:
  python -m app.seed.run            # seed (idempotent — only if DB empty)
  python -m app.seed.run --reset    # drop all data and re-seed
"""

from __future__ import annotations

import argparse
import random
import time
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import delete, select

from ..config import settings
from ..db import Base, SessionLocal, engine, session_scope
from ..models import (
    Aircraft,
    BrandRule,
    Cart,
    CostParams,
    CrewFeedback,
    Drawer,
    Flight,
    GalleyLayout,
    OptimisationRun,
    RangeDecision,
    DrawerAssignment,
    RegulatoryRule,
    Rotation,
    RunOverride,
    Route,
    Sale,
    Scenario,
    Sku,
    Supplier,
    SupplierCommitment,
)
from . import aircraft as ac_seed
from . import crew_feedback as cf_seed
from . import routes as rt_seed
from . import sales_history as sh_seed
from . import skus as sku_seed


def _seed_suppliers(session) -> dict[str, int]:
    out: dict[str, int] = {}
    for name in sku_seed.SUPPLIERS:
        sup = Supplier(name=name, min_commitment_units_per_month=0)
        session.add(sup)
    session.flush()
    for sup in session.scalars(select(Supplier)).all():
        out[sup.name] = sup.id
    return out


def _warehouse_zone_for(spec) -> str:
    """Derive a warehouse pick zone from SKU attributes (brief §pick-zones)."""
    if spec.bonded:
        return "bonded"
    if spec.requires_authorised_pick or spec.category in (
        "Fragrance & cosmetics",
        "Sunglasses & accessories",
    ):
        return "secure-high-value"
    if spec.category in ("Sandwiches & wraps", "Hot meals"):
        return "chilled"
    if spec.category in ("Soft drinks", "Snacks (savoury)", "Snacks (sweet)", "Hot drinks"):
        return "ambient-fast"
    return "ambient-standard"


def _seed_skus(session, supplier_id_by_name: dict[str, int]) -> int:
    specs = sku_seed.all_skus()
    for spec in specs:
        session.add(
            Sku(
                code=spec.code,
                name=spec.name,
                category=spec.category,
                sub_category=spec.sub_category,
                brand=spec.brand,
                unit_weight_g=spec.unit_weight_g,
                length_mm=spec.length_mm,
                width_mm=spec.width_mm,
                height_mm=spec.height_mm,
                volume_cm3=sku_seed.volume_cm3(spec),
                packaging_type=spec.packaging_type,
                stackable=spec.stackable,
                max_stack_height=spec.max_stack_height,
                fragility_score=spec.fragility_score,
                orientation_constraint=spec.orientation_constraint,
                shelf_life_days=spec.shelf_life_days,
                hazard_class=spec.hazard_class,
                warehouse_zone=_warehouse_zone_for(spec),
                cost_price=spec.cost_price,
                retail_price=spec.retail_price,
                margin_pct=(spec.retail_price - spec.cost_price) / spec.retail_price if spec.retail_price > 0 else 0.0,
                supplier_id=supplier_id_by_name[spec.supplier_name],
                min_pack_size=spec.min_pack_size,
                case_size=spec.case_size,
                bonded=spec.bonded,
                requires_authorised_pick=spec.requires_authorised_pick,
            )
        )
    session.flush()
    return len(specs)


def _seed_routes(session) -> dict[str, Route]:
    out: dict[str, Route] = {}
    for spec in rt_seed.ROUTES:
        r = Route(
            origin_iata=spec.origin_iata,
            dest_iata=spec.dest_iata,
            distance_km=spec.distance_km,
            flight_duration_min=spec.flight_duration_min,
            haul_class=spec.haul_class,
            duty_free_allowed=spec.duty_free_allowed,
            alcohol_allowed=spec.alcohol_allowed,
            tobacco_allowed=spec.tobacco_allowed,
            seasonality_profile_json=spec.seasonality_profile,
        )
        session.add(r)
        out[f"{spec.origin_iata}-{spec.dest_iata}"] = r
    session.flush()
    return out


def _seed_regulatory(session, route_map: dict[str, Route]) -> None:
    for rule in rt_seed.REGULATORY_RULES:
        route = route_map.get(rule["route_key"])
        session.add(
            RegulatoryRule(
                route_id=route.id if route else None,
                sku_category=rule["sku_category"],
                rule_type=rule["rule_type"],
                parameters_json=rule["params"],
            )
        )


def _seed_aircraft(session) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {}
    # Build the two galley layouts shared across aircraft of each type.
    layout_by_type: dict[str, GalleyLayout] = {}
    for ac_type in ("A320", "A320neo"):
        spec = ac_seed.galley_layout_spec(ac_type)
        layout = GalleyLayout(
            aircraft_type=ac_type,
            num_retail_carts=spec["num_retail_carts"],
            schematic_json={"carts": spec["carts"]},
        )
        session.add(layout)
        session.flush()
        for cart_spec in spec["carts"]:
            cart = Cart(
                galley_layout_id=layout.id,
                position_code=cart_spec["position_code"],
                cart_type=cart_spec["cart_type"],
            )
            session.add(cart)
            session.flush()
            for d in cart_spec["drawers"]:
                dims = ac_seed.DRAWER_SPECS[d["type"]]
                session.add(
                    Drawer(
                        cart_id=cart.id,
                        slot_index=d["slot_index"],
                        type=d["type"],
                        internal_l_mm=dims["l"],
                        internal_w_mm=dims["w"],
                        internal_h_mm=dims["h"],
                        max_weight_kg=dims["max_weight_kg"],
                        accessibility_score=d["accessibility"],
                    )
                )
        layout_by_type[ac_type] = layout

    # Aircraft using their layouts.
    for spec in ac_seed.AIRCRAFT:
        ac = Aircraft(
            registration=spec.registration,
            type=spec.type,
            retail_galley_layout_id=layout_by_type[spec.type].id,
            empty_weight_kg=spec.empty_weight_kg,
            max_payload_kg=spec.max_payload_kg,
            fuel_burn_coeff_short=spec.fuel_burn_coeff_short,
            fuel_burn_coeff_medium=spec.fuel_burn_coeff_medium,
            fuel_burn_coeff_long=spec.fuel_burn_coeff_long,
        )
        session.add(ac)
    session.flush()
    for ac in session.scalars(select(Aircraft)).all():
        out.setdefault(ac.type, []).append(ac.id)
    return out


def _seed_cost_params(session) -> None:
    # Per-pickline charges are scale-sensitive: they are compared against the
    # margin a single line earns on a single flight (~GBP 0.50-3.00 at realistic
    # demand). Set them too high and no line pays for itself, so the optimiser
    # posts a loss on a range the airline actually sells profitably.
    session.add(
        CostParams(
            valid_from=datetime(2025, 1, 1),
            fuel_price_per_kg_gbp=0.82,
            pick_cost_per_unit_gbp=0.08,
            pack_cost_per_drawer_gbp=1.20,
            cart_assembly_cost_gbp=4.50,
            return_handling_cost_per_unit_gbp=0.15,
            # Roughly a minute of warehouse labour to open and pick one line.
            complexity_penalty_per_new_pickline_gbp=0.35,
            pick_zone_multipliers_json={
                "ambient-fast": 0.8,
                "ambient-standard": 1.0,
                "chilled": 1.5,
                "bonded": 1.8,
                "secure-high-value": 2.2,
            },
            bonded_access_surcharge_gbp=0.75,
            authorised_pick_surcharge_per_unit_gbp=0.12,
            pickline_min_expected_margin_gbp=1.50,
            case_break_penalty_gbp=0.40,
            spoilage_reuse_cycle_days=3.0,
        )
    )


def _seed_brand_rules(session) -> None:
    # Minimum units are a commercial range guarantee, so they only make sense
    # relative to demand — these track CATEGORY_BASE_DEMAND in sales_history.
    # Set above it and the model is infeasible before it starts.
    rules = [
        ("Spirits (mini)", 4, 6, 0.30),
        ("Wine", 2, 3, 0.20),
        ("Beer & cider", 3, 10, 0.30),
        ("Soft drinks", 5, 18, 0.40),
        ("Snacks (savoury)", 3, 6, 0.25),
        ("Snacks (sweet)", 3, 7, 0.25),
        ("Sandwiches & wraps", 3, 5, 0.30),
    ]
    for cat, min_skus, min_units, max_share in rules:
        session.add(BrandRule(category=cat, min_skus=min_skus, min_units=min_units, max_share_pct=max_share))


def _seed_flights_and_sales(
    session,
    rng: random.Random,
    aircraft_ids_by_type: dict[str, list[int]],
) -> tuple[int, int, int]:
    routes = session.scalars(select(Route)).all()
    start = datetime(2025, 5, 1, 0, 0)
    end = datetime(2026, 4, 30, 0, 0)

    flight_specs, rotation_descs = sh_seed.generate_flights(
        rng, routes, aircraft_ids_by_type, start, end
    )

    # Create rotation rows first so flights can reference their id.
    rotation_id_by_code: dict[str, int] = {}
    for code, desc in rotation_descs.items():
        rot = Rotation(code=code, description=desc)
        session.add(rot)
    session.flush()
    for rot in session.scalars(select(Rotation)).all():
        rotation_id_by_code[rot.code] = rot.id

    flight_objs: list[Flight] = []
    for fs in flight_specs:
        fs = dict(fs)
        rot_code = fs.pop("rotation_code", None)
        fs["rotation_id"] = rotation_id_by_code.get(rot_code) if rot_code else None
        flight_objs.append(Flight(**fs))
    session.add_all(flight_objs)
    session.flush()

    # Re-load with relationships needed by the sales generator.
    flights_by_route: dict[int, list[Flight]] = {}
    for f in flight_objs:
        flights_by_route.setdefault(f.route_id, []).append(f)

    skus = session.scalars(select(Sku)).all()
    sales = sh_seed.generate_sales(rng, skus, routes, flights_by_route)
    # Bulk insert for speed.
    session.bulk_save_objects(sales)
    return len(flight_objs), len(sales), len(rotation_id_by_code)


def _seed_crew_feedback(session, rng: random.Random) -> int:
    routes = session.scalars(select(Route)).all()
    by_key = {f"{r.origin_iata}-{r.dest_iata}": r for r in routes}
    flights_by_route_key: dict[str, list[Flight]] = {}
    for key, route in by_key.items():
        flights_by_route_key[key] = session.scalars(
            select(Flight).where(Flight.route_id == route.id).order_by(Flight.scheduled_dt.desc()).limit(60)
        ).all()
    count = 0
    for entry in cf_seed.CREW_COMMENTS:
        flights = flights_by_route_key.get(entry["flight_key"], [])
        flight_id = rng.choice(flights).id if flights else None
        session.add(CrewFeedback(flight_id=flight_id, sku_id=None, free_text=entry["text"], structured_json={}))
        count += 1
    return count


def run_seed(reset: bool = False) -> dict[str, Any]:
    """Idempotent seed. With reset=True, wipes everything first."""
    t0 = time.time()

    rng = random.Random(settings.arp_seed)

    if reset:
        # Drop rather than just delete rows: there are no migrations, so this is
        # the only thing that picks up model changes on an existing DB.
        Base.metadata.drop_all(bind=engine)
        Base.metadata.create_all(bind=engine)
    else:
        Base.metadata.create_all(bind=engine)
        with session_scope() as s:
            existing = s.scalar(select(Sku.id).limit(1))
            if existing:
                return {"skipped": True, "reason": "DB not empty; use --reset to re-seed"}

    stats: dict[str, Any] = {}
    with session_scope() as s:
        supplier_ids = _seed_suppliers(s)
        stats["suppliers"] = len(supplier_ids)
        stats["skus"] = _seed_skus(s, supplier_ids)
        route_map = _seed_routes(s)
        stats["routes"] = len(route_map)
        _seed_regulatory(s, route_map)
        aircraft_ids = _seed_aircraft(s)
        stats["aircraft"] = sum(len(v) for v in aircraft_ids.values())
        _seed_cost_params(s)
        _seed_brand_rules(s)
        flights_n, sales_n, rotations_n = _seed_flights_and_sales(s, rng, aircraft_ids)
        stats["flights"] = flights_n
        stats["rotations"] = rotations_n
        stats["sales"] = sales_n
        stats["crew_feedback"] = _seed_crew_feedback(s, rng)

    stats["elapsed_s"] = round(time.time() - t0, 2)
    return stats


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed the ARP synthetic database.")
    parser.add_argument("--reset", action="store_true", help="Drop all data and re-seed.")
    args = parser.parse_args()
    stats = run_seed(reset=args.reset)
    print("Seed complete:")
    for k, v in stats.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
