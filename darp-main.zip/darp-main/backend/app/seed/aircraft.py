"""Aircraft + galley layout seed.

ATLAS drawer dimensions per plan §5:
  Full ATLAS ~ 400 × 300 × 280 mm
  Half ATLAS ~ 400 × 300 × 140 mm
  ATLAS Box  ~ 405 × 301 × 273 mm
"""

from __future__ import annotations

from dataclasses import dataclass


# Drawer dimensions (internal, mm), max weight (kg)
DRAWER_SPECS = {
    "ATLAS_full": {"l": 400.0, "w": 300.0, "h": 280.0, "max_weight_kg": 18.0},
    "ATLAS_half": {"l": 400.0, "w": 300.0, "h": 140.0, "max_weight_kg": 9.0},
    "box": {"l": 405.0, "w": 301.0, "h": 273.0, "max_weight_kg": 16.0},
}


@dataclass(frozen=True)
class AircraftSpec:
    registration: str
    type: str
    empty_weight_kg: float
    max_payload_kg: float
    fuel_burn_coeff_short: float
    fuel_burn_coeff_medium: float
    fuel_burn_coeff_long: float


AIRCRAFT: tuple[AircraftSpec, ...] = (
    AircraftSpec(
        registration="G-EZAA",
        type="A320",
        empty_weight_kg=42600.0,
        max_payload_kg=17500.0,
        # Marginal kg-fuel burnt per extra kg of retail payload, by haul (rough proxies).
        fuel_burn_coeff_short=0.030,
        fuel_burn_coeff_medium=0.040,
        fuel_burn_coeff_long=0.055,
    ),
    AircraftSpec(
        registration="G-EZNB",
        type="A320neo",
        empty_weight_kg=44300.0,
        max_payload_kg=18200.0,
        fuel_burn_coeff_short=0.026,
        fuel_burn_coeff_medium=0.034,
        fuel_burn_coeff_long=0.046,
    ),
)


def galley_layout_spec(aircraft_type: str) -> dict:
    """Return galley schematic: 1 full retail trolley + 1 half trolley (4 half ATLAS).

    The A320neo cedes two full drawers to extra catering provisioning, so its
    retail cart holds only 6 full ATLAS drawers vs the A320's 8. This makes an
    A320 → A320neo aircraft swap capacity-meaningful (WP7 revalidation).
    """
    n_full = 6 if aircraft_type == "A320neo" else 8

    full_drawers = []
    for i in range(n_full):
        # accessibility 1 (best) at top, 5 (worst) at bottom-back.
        accessibility = 1 + (i // 2)
        full_drawers.append({"slot_index": i, "type": "ATLAS_full", "accessibility": min(5, accessibility)})

    half_drawers = []
    for i in range(4):
        accessibility = 1 + (i // 2)
        half_drawers.append({"slot_index": i, "type": "ATLAS_half", "accessibility": min(5, accessibility)})

    return {
        "aircraft_type": aircraft_type,
        "num_retail_carts": 2,
        "carts": [
            {"position_code": "R1", "cart_type": "full", "drawers": full_drawers},
            {"position_code": "R2", "cart_type": "half", "drawers": half_drawers},
        ],
    }
