"""Synthetic 12-month sales history generator.

Demand model (plan §5):
  units(flight, sku) = base × seasonality × dow_tod × pax_mix_sensitivity
                     × load_factor_sublinear × promo × noise
  Realised demand is then drawn from a Poisson and capped by what was loaded,
  so stockouts are genuine events rather than an assumption.

Calibration targets (European short-haul LCC onboard retail):
  ~0.40 units per passenger, ~GBP 2.00-2.75 spend per passenger.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass
from datetime import datetime, timedelta

from ..models import Flight, Route, Sale, Sku
from ..optim.baseline import manual_load_qty
from ..optim.cost_to_serve import is_perishable
from ..optim.season import season_slot as _season_slot


# Per-category base demand (units per typical 180-pax flight). Sums to ~64 units,
# i.e. ~0.43 per passenger after flight multipliers, matching observed short-haul
# onboard penetration. Boutique lines are sized to ~15-20% of revenue.
CATEGORY_BASE_DEMAND: dict[str, float] = {
    "Spirits (mini)": 3.0,
    "Spirits (full)": 0.4,
    "Wine": 2.0,
    "Beer & cider": 6.0,
    "Soft drinks": 18.0,
    "Hot drinks": 10.0,
    "Snacks (savoury)": 7.0,
    "Snacks (sweet)": 7.5,
    "Sandwiches & wraps": 5.5,
    "Hot meals": 2.2,
    # Boutique lines sell slowly but carry the margin; they must stay alive in the
    # history or the optimiser has no high-value range to discover.
    "Fragrance & cosmetics": 0.8,
    "Sunglasses & accessories": 0.18,
    "Gifts & travel essentials": 0.5,
    "Tobacco": 0.0,  # disallowed on both routes
    "Children": 0.5,
}

# What a planner loads relative to expected demand.
STOCK_BUFFER = 1.25


# Category × pax-segment affinity multiplier.
PAX_AFFINITY: dict[str, dict[str, float]] = {
    "business": {
        "Spirits (mini)": 0.7, "Spirits (full)": 0.4, "Wine": 1.1, "Beer & cider": 0.6,
        "Soft drinks": 1.1, "Hot drinks": 1.6, "Snacks (savoury)": 1.0, "Snacks (sweet)": 0.8,
        "Sandwiches & wraps": 1.4, "Hot meals": 1.2, "Fragrance & cosmetics": 0.6,
        "Sunglasses & accessories": 0.5, "Gifts & travel essentials": 0.9, "Children": 0.2,
    },
    "leisure": {
        "Spirits (mini)": 1.4, "Spirits (full)": 1.3, "Wine": 1.2, "Beer & cider": 1.4,
        "Soft drinks": 1.1, "Hot drinks": 0.7, "Snacks (savoury)": 1.2, "Snacks (sweet)": 1.3,
        "Sandwiches & wraps": 0.9, "Hot meals": 0.8, "Fragrance & cosmetics": 1.3,
        "Sunglasses & accessories": 1.6, "Gifts & travel essentials": 1.1, "Children": 1.3,
    },
    "diaspora": {
        "Spirits (mini)": 0.9, "Spirits (full)": 1.5, "Wine": 0.7, "Beer & cider": 1.0,
        "Soft drinks": 1.0, "Hot drinks": 1.0, "Snacks (savoury)": 0.9, "Snacks (sweet)": 1.0,
        "Sandwiches & wraps": 0.7, "Hot meals": 1.1, "Fragrance & cosmetics": 1.1,
        "Sunglasses & accessories": 0.7, "Gifts & travel essentials": 1.6, "Children": 1.4,
    },
    "other": {k: 1.0 for k in CATEGORY_BASE_DEMAND},
}


@dataclass
class GenStats:
    flights: int = 0
    sales_rows: int = 0


def _time_of_day_multiplier(hour: int, category: str) -> float:
    """Morning coffee/sandwich bump; evening alcohol bump."""
    if category == "Hot drinks":
        return 1.5 if hour < 11 else 0.7
    if category in ("Sandwiches & wraps", "Hot meals"):
        return 1.3 if 6 <= hour <= 13 else 0.9
    if category in ("Beer & cider", "Wine", "Spirits (mini)", "Spirits (full)"):
        return 0.6 if hour < 11 else 1.4
    return 1.0


def _dow_multiplier(dow: int, route_key: str) -> float:
    # 0=Mon
    from ..optim.season import route_profile
    if route_profile(route_key) == "leisure_summer":
        # Fri/Sat/Sun-heavy leisure
        return [0.85, 0.85, 0.90, 1.00, 1.20, 1.40, 1.20][dow]
    # ski_diaspora: more even, slight Friday/Sunday bumps
    return [1.00, 0.95, 0.95, 1.00, 1.20, 1.05, 1.15][dow]


def _poisson(rng: random.Random, lam: float) -> int:
    """Draw a unit count from Poisson(lam).

    Unit sales are counts, so Poisson is the natural draw. It also matters for
    slow movers: rounding a 0.06-unit expectation to the nearest integer yields
    zero on every single flight, which is what silently killed the boutique
    categories. A Poisson draw gives them their occasional genuine sale.
    """
    if lam <= 0.0:
        return 0
    if lam > 30.0:
        # Knuth's method degrades for large lam; normal approximation is fine here.
        return max(0, int(round(rng.gauss(lam, math.sqrt(lam)))))
    target = math.exp(-lam)
    k, p = 0, 1.0
    while True:
        p *= rng.random()
        if p <= target:
            return k
        k += 1


def generate_sales(
    rng: random.Random,
    skus: list[Sku],
    routes: list[Route],
    flights_by_route: dict[int, list[Flight]],
) -> list[Sale]:
    """Generate sale rows. Returns a list of unsaved Sale ORM objects."""
    sales: list[Sale] = []

    # Pre-index SKUs by category
    by_cat: dict[str, list[Sku]] = {}
    for sku in skus:
        by_cat.setdefault(sku.category, []).append(sku)

    # SKU-level multiplier inside its category (lognormal around 1.0).
    sku_multipliers: dict[int, float] = {
        sku.id: max(0.15, rng.lognormvariate(0.0, 0.45)) for sku in skus
    }

    for route in routes:
        route_key = f"{route.origin_iata}-{route.dest_iata}"
        flights = flights_by_route.get(route.id, [])
        for flight in flights:
            month = flight.scheduled_dt.month
            dow = flight.scheduled_dt.weekday()
            hour = flight.scheduled_dt.hour
            season = _season_slot(month, route_key)
            seasonality = route.seasonality_profile_json.get(str(month), 1.0)
            pax_mix = flight.pax_mix_json
            load_factor = flight.expected_load_factor
            pax = flight.expected_pax

            # Sub-linear load-factor effect.
            lf_effect = math.pow(load_factor / 0.75, 0.7)

            for category, base in CATEGORY_BASE_DEMAND.items():
                if base <= 0:
                    continue
                cat_skus = by_cat.get(category, [])
                if not cat_skus:
                    continue

                # Skip disallowed categories on certain routes.
                if category == "Tobacco" and not route.tobacco_allowed:
                    continue

                # Aggregate pax-affinity for this category.
                pax_aff = 0.0
                for segment, share in pax_mix.items():
                    pax_aff += share * PAX_AFFINITY.get(segment, {}).get(category, 1.0)

                tod = _time_of_day_multiplier(hour, category)
                dow_mult = _dow_multiplier(dow, route_key)

                # Total category demand on this flight.
                cat_units = (
                    base
                    * seasonality
                    * dow_mult
                    * tod
                    * pax_aff
                    * lf_effect
                    * (pax / 180.0)
                    * rng.lognormvariate(0.0, 0.18)
                )

                # Distribute across SKUs by their multipliers.
                weights = [sku_multipliers[s.id] for s in cat_skus]
                w_sum = sum(weights)
                if w_sum <= 0:
                    continue
                for sku, w in zip(cat_skus, weights):
                    share_units = cat_units * (w / w_sum)
                    # Promo uplift: 8% of (flight, sku) get +20-60%.
                    if rng.random() < 0.08:
                        share_units *= 1.0 + rng.uniform(0.2, 0.6)

                    # What the planner put on board, then what pax actually wanted.
                    # Uses the shared manual loading rule so the history is the
                    # output of the very plan the optimiser is measured against.
                    loaded = manual_load_qty(sku, share_units, buffer=STOCK_BUFFER)
                    demand = _poisson(rng, share_units)
                    sold = min(demand, loaded)
                    unsold = loaded - sold

                    # Unsold ambient stock comes off and goes back to the bond;
                    # only short-life lines are genuinely written off.
                    returned = 0 if is_perishable(sku) else unsold

                    revenue = sold * sku.retail_price
                    minute = rng.randint(0, max(15, flight.route.flight_duration_min - 15))
                    # Zero-sales rows are kept: the forecaster averages over the rows
                    # it finds, so dropping them biases demand upwards on exactly the
                    # marginal lines the optimiser has to judge.
                    sales.append(
                        Sale(
                            flight_id=flight.id,
                            sku_id=sku.id,
                            units_sold=sold,
                            revenue=round(revenue, 2),
                            unsold_units=unsold,
                            returned_units=returned,
                            sold_at_minute_of_flight=minute,
                        )
                    )
    return sales


# Multi-leg rotation templates — a range loaded once and carried across legs.
# (kind, [leg route keys], {days-of-week}, [departure hours], aircraft type)
ROTATION_TEMPLATES: tuple[dict, ...] = (
    {"code": "IBZ", "desc": "Luton–Ibiza same-day turn",
     "legs": ["LTN-IBZ", "IBZ-LTN"], "dows": {0, 4}, "hours": [7, 13], "ac_type": "A320"},
    {"code": "GVA", "desc": "Tirana–Geneva same-day turn",
     "legs": ["TIA-GVA", "GVA-TIA"], "dows": {1, 5}, "hours": [8, 14], "ac_type": "A320neo"},
    {"code": "CAN", "desc": "Luton–Malaga–Lanzarote–Luton triangle",
     "legs": ["LTN-AGP", "AGP-ACE", "ACE-LTN"], "dows": {2, 6}, "hours": [6, 11, 16], "ac_type": "A320"},
)

# Routes flown daily as standalone single legs (the simple demo path).
STANDALONE_ROUTES = {"LTN-IBZ": "A320", "TIA-GVA": "A320neo"}


def _flight_econ(route: Route, scheduled: datetime, rng: random.Random) -> tuple[int, float, dict]:
    """Return (pax, load_factor, pax_mix) for a flight on a route at a time."""
    month = scheduled.month
    route_key = f"{route.origin_iata}-{route.dest_iata}"
    seasonality = route.seasonality_profile_json.get(str(month), 1.0)
    load_factor = max(0.45, min(0.97, 0.72 * seasonality + rng.gauss(0, 0.05)))
    pax = int(round(180 * load_factor))
    from .routes import PAX_MIX  # local import to keep top clean
    pax_mix = PAX_MIX.get(route_key, {}).get(_season_slot(month, route_key), {"leisure": 1.0})
    return pax, round(load_factor, 3), pax_mix


def generate_flights(
    rng: random.Random,
    routes: list[Route],
    aircraft_ids_by_type: dict[str, list[int]],
    start: datetime,
    end: datetime,
) -> tuple[list[dict], dict[str, str]]:
    """Generate flight dicts (unsaved) plus a {rotation_code: description} map.

    Standalone routes fly daily; rotation templates fly on set weekdays with all
    legs sharing one aircraft and a `rotation_code`/`leg_index` tag.
    """
    routes_by_key = {f"{r.origin_iata}-{r.dest_iata}": r for r in routes}
    flights: list[dict] = []
    rotations: dict[str, str] = {}
    counter = 0
    rot_counter = 0

    def _next_aircraft(ac_type: str) -> int:
        nonlocal counter
        pool = aircraft_ids_by_type.get(ac_type) or aircraft_ids_by_type.get("A320", [])
        counter += 1
        return pool[counter % len(pool)]

    day = start
    while day <= end:
        # Standalone daily flights.
        for route_key, ac_type in STANDALONE_ROUTES.items():
            route = routes_by_key.get(route_key)
            if route is None:
                continue
            ac_id = _next_aircraft(ac_type)
            hour = rng.choice([7, 10, 14, 18])
            scheduled = day.replace(hour=hour, minute=rng.choice([0, 15, 30, 45]))
            pax, lf, pax_mix = _flight_econ(route, scheduled, rng)
            flights.append({
                "route_id": route.id,
                "flight_no": f"U2{1000 + counter % 9000}",
                "scheduled_dt": scheduled,
                "aircraft_id": ac_id,
                "expected_pax": pax,
                "expected_load_factor": lf,
                "pax_mix_json": pax_mix,
                "cabin_config_json": {"seats": 186, "config": "3-3"},
                "rotation_code": None,
                "leg_index": None,
            })

        # Rotation flights (all legs same aircraft, same day).
        for tmpl in ROTATION_TEMPLATES:
            if day.weekday() not in tmpl["dows"]:
                continue
            if any(routes_by_key.get(rk) is None for rk in tmpl["legs"]):
                continue
            ac_id = _next_aircraft(tmpl["ac_type"])
            rot_counter += 1
            rot_code = f"ROT-{tmpl['code']}-{day:%Y%m%d}"
            rotations[rot_code] = tmpl["desc"]
            for leg_idx, rk in enumerate(tmpl["legs"], start=1):
                route = routes_by_key[rk]
                hour = tmpl["hours"][leg_idx - 1]
                scheduled = day.replace(hour=hour, minute=0)
                pax, lf, pax_mix = _flight_econ(route, scheduled, rng)
                counter += 1
                flights.append({
                    "route_id": route.id,
                    "flight_no": f"U2{5000 + counter % 4000}",
                    "scheduled_dt": scheduled,
                    "aircraft_id": ac_id,
                    "expected_pax": pax,
                    "expected_load_factor": lf,
                    "pax_mix_json": pax_mix,
                    "cabin_config_json": {"seats": 186, "config": "3-3"},
                    "rotation_code": rot_code,
                    "leg_index": leg_idx,
                })
        day += timedelta(days=1)
    return flights, rotations
