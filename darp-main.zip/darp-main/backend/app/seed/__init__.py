"""Deterministic seed for the ARP prototype."""
