"""Route and regulatory rule seed."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RouteSpec:
    origin_iata: str
    dest_iata: str
    distance_km: float
    flight_duration_min: int
    haul_class: str
    duty_free_allowed: bool
    alcohol_allowed: bool
    tobacco_allowed: bool
    seasonality_profile: dict[str, float]  # month_index 1..12 → multiplier


# Seasonality profiles reused across routes that share demand shape.
_SUMMER_LEISURE = {
    "1": 0.45, "2": 0.50, "3": 0.65, "4": 0.85, "5": 1.10, "6": 1.45,
    "7": 1.80, "8": 1.85, "9": 1.40, "10": 0.95, "11": 0.55, "12": 0.55,
}
_SKI_DIASPORA = {
    "1": 1.10, "2": 1.15, "3": 0.95, "4": 0.85, "5": 0.85, "6": 0.95,
    "7": 1.15, "8": 1.25, "9": 1.00, "10": 0.90, "11": 0.85, "12": 1.20,
}
# Canary islands — winter-sun keeps the off-season floor higher.
_CANARY = {
    "1": 1.05, "2": 1.00, "3": 0.90, "4": 0.90, "5": 1.00, "6": 1.20,
    "7": 1.55, "8": 1.60, "9": 1.20, "10": 1.00, "11": 0.90, "12": 1.15,
}


ROUTES: tuple[RouteSpec, ...] = (
    RouteSpec(
        origin_iata="LTN",
        dest_iata="IBZ",
        distance_km=1450.0,
        flight_duration_min=145,
        haul_class="short",
        duty_free_allowed=False,  # intra-EU
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_SUMMER_LEISURE,
    ),
    # Return leg of the Ibiza turn — same-day rotation back to Luton.
    RouteSpec(
        origin_iata="IBZ",
        dest_iata="LTN",
        distance_km=1450.0,
        flight_duration_min=150,
        haul_class="short",
        duty_free_allowed=False,
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_SUMMER_LEISURE,
    ),
    RouteSpec(
        origin_iata="TIA",
        dest_iata="GVA",
        distance_km=1300.0,
        flight_duration_min=125,
        haul_class="short",
        duty_free_allowed=True,  # TIA is non-EU
        alcohol_allowed=True,
        tobacco_allowed=False,  # easyJet operational policy in this scenario
        seasonality_profile=_SKI_DIASPORA,
    ),
    RouteSpec(
        origin_iata="GVA",
        dest_iata="TIA",
        distance_km=1300.0,
        flight_duration_min=130,
        haul_class="short",
        duty_free_allowed=True,
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_SKI_DIASPORA,
    ),
    # Multi-leg Canary triangle (brief's "loaded LTN → unsold to Malaga →
    # carried to Lanzarote") — one loaded range carried across three legs.
    RouteSpec(
        origin_iata="LTN",
        dest_iata="AGP",
        distance_km=1680.0,
        flight_duration_min=170,
        haul_class="medium",
        duty_free_allowed=False,
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_SUMMER_LEISURE,
    ),
    RouteSpec(
        origin_iata="AGP",
        dest_iata="ACE",
        distance_km=1300.0,
        flight_duration_min=135,
        haul_class="short",
        duty_free_allowed=False,
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_CANARY,
    ),
    RouteSpec(
        origin_iata="ACE",
        dest_iata="LTN",
        distance_km=2840.0,
        flight_duration_min=255,
        haul_class="medium",
        duty_free_allowed=False,
        alcohol_allowed=True,
        tobacco_allowed=False,
        seasonality_profile=_CANARY,
    ),
)


# Pax-mix per route, by season slot ("peak"/"shoulder"/"off")
_LEISURE_MIX = {
    "peak": {"business": 0.05, "leisure": 0.90, "other": 0.05},
    "shoulder": {"business": 0.10, "leisure": 0.80, "other": 0.10},
    "off": {"business": 0.15, "leisure": 0.75, "other": 0.10},
}
_DIASPORA_MIX = {
    "peak": {"business": 0.20, "diaspora": 0.55, "leisure": 0.20, "other": 0.05},
    "shoulder": {"business": 0.25, "diaspora": 0.50, "leisure": 0.20, "other": 0.05},
    "off": {"business": 0.30, "diaspora": 0.50, "leisure": 0.15, "other": 0.05},
}
PAX_MIX: dict[str, dict[str, dict[str, float]]] = {
    "LTN-IBZ": _LEISURE_MIX,
    "IBZ-LTN": _LEISURE_MIX,
    "LTN-AGP": _LEISURE_MIX,
    "AGP-ACE": _LEISURE_MIX,
    "ACE-LTN": _LEISURE_MIX,
    "TIA-GVA": _DIASPORA_MIX,
    "GVA-TIA": _DIASPORA_MIX,
}


# Regulatory rules — by category, optionally scoped to a route key (origin-dest).
REGULATORY_RULES: tuple[dict, ...] = (
    # Global: tobacco not offered on any route in this scenario (easyJet policy / intra-EU duty-paid).
    {"route_key": None, "sku_category": "Tobacco", "rule_type": "disallow", "params": {"reason": "Tobacco not offered on these routes"}},
)
