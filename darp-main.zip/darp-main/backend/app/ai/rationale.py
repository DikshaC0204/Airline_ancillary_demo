"""Auto-rationale: 1-sentence "why" per range decision.

We do NOT rationalize every SKU (140+ would blow the call ceiling). Instead,
take the top-K most interesting decisions (load with high net contribution,
exclude/reduce with non-trivial expected_sales) and write a single batched
prompt that returns rationales for all of them in one JSON response.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import RangeDecision, Sku, OptimisationRun, Flight, Route
from .azure_openai import chat_json, AIUnavailable, is_configured


SYSTEM = (
    "You are a senior airline retail planner. Given a list of SKU decisions for a single "
    "flight, return a JSON object {\"rationales\": {\"<sku_code>\": \"<one short sentence>\"}}. "
    "Each item includes a deterministic `reason_code` and `reason_detail` already computed by the "
    "optimiser — your job is to render that reason as fluent prose, not to invent a different one. "
    "Reference at least one quantitative driver (margin, demand, weight, capacity). Be terse — "
    "under 22 words. No emoji."
)


def generate_rationales(
    session: Session,
    run_id: int,
    *,
    top_k: int = 12,
) -> int:
    """Backfill `rationale_text` on top-K decisions for a given run.

    Returns the number of decisions updated. Silently skips when AOAI is not
    configured.
    """
    if not is_configured():
        return 0

    run = session.get(OptimisationRun, run_id)
    if run is None:
        return 0
    flight = session.get(Flight, run.flight_id)
    if flight is None:
        return 0
    route = session.get(Route, flight.route_id) if flight else None
    route_label = f"{route.origin_iata}→{route.dest_iata}" if route else "?"

    decisions = (
        session.execute(
            select(RangeDecision, Sku)
            .join(Sku, Sku.id == RangeDecision.sku_id)
            .where(RangeDecision.optimisation_run_id == run_id)
        )
        .all()
    )
    if not decisions:
        return 0

    # Rank: prefer non-trivial loads + non-trivial exclusions/reductions.
    def score(d: RangeDecision) -> float:
        if d.decision in ("load", "increase"):
            return float(d.net_contribution or 0.0)
        if d.decision in ("reduce", "exclude"):
            return float(d.expected_sales or 0.0) * 5.0
        return 0.0

    ranked = sorted(decisions, key=lambda r: -score(r[0]))[: top_k]

    items: list[dict[str, Any]] = []
    for d, sku in ranked:
        items.append(
            {
                "sku_code": sku.code,
                "sku_name": sku.name,
                "category": sku.category,
                "decision": d.decision,
                "loaded_qty": d.loaded_qty,
                "expected_sales": round(d.expected_sales, 1),
                "expected_margin_gbp": round(d.expected_margin, 2),
                "fuel_cost_gbp": round(d.fuel_cost, 2),
                "net_contribution_gbp": round(d.net_contribution, 2),
                "unit_weight_g": round(sku.unit_weight_g, 1),
                "reason_code": d.reason_code,
                "reason_detail": d.reason_detail_json or {},
            }
        )

    user = (
        f"Flight {flight.flight_no} on route {route_label}, {flight.expected_pax} pax expected. "
        f"Total range: {run.total_skus} SKUs, {run.total_units} units, "
        f"{run.total_weight_kg:.0f} kg, expected net £{run.expected_net_contribution:.0f}.\n\n"
        f"Decisions to explain:\n{items}\n\n"
        f"Reply with JSON: {{\"rationales\": {{\"SKU_CODE\": \"sentence\", ...}}}}."
    )

    try:
        result = chat_json(
            [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user},
            ],
            run_key=f"run:{run_id}",
            max_tokens=600,
        )
    except AIUnavailable:
        return 0

    rationales = result.get("rationales") or {}
    if not isinstance(rationales, dict):
        return 0

    code_to_decision = {sku.code: d for d, sku in ranked}
    n_updated = 0
    for code, text in rationales.items():
        d = code_to_decision.get(code)
        if d is None or not isinstance(text, str):
            continue
        d.rationale_text = text.strip()
        n_updated += 1
    if n_updated:
        session.commit()
    return n_updated
