"""Crew free-text feedback → structured (sku_id, signal_type, severity)."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Sku, CrewFeedback
from .azure_openai import chat_json, AIUnavailable, is_configured


SIGNAL_TYPES = ["stockout", "waste", "quality", "presentation", "ops", "other"]

SYSTEM = (
    "You triage crew feedback for an airline retail planner. Given a free-text comment "
    "and the catalogue of available SKUs, return JSON: "
    "{\"sku_code\": \"<best matching SKU code or null>\", "
    "\"signal_type\": \"<one of: stockout, waste, quality, presentation, ops, other>\", "
    "\"severity\": <integer 1-5>, "
    "\"normalised\": \"<one-sentence rephrase under 18 words>\"}. "
    "Match leniently (brand or product noun) and pick the closest catalogue code."
)


def ingest_feedback(
    session: Session,
    raw_text: str,
    *,
    flight_id: int | None = None,
    crew_member: str | None = None,
) -> dict[str, Any]:
    """Parse + persist a single feedback row.

    Returns {"id": int, "structured": {...}} or {"error": str} if AI unavailable.
    """
    if not is_configured():
        return {"error": "AI not configured"}

    sku_rows = session.execute(select(Sku.code, Sku.name, Sku.category)).all()
    catalogue = "\n".join(f"  {c} | {n} | {cat}" for c, n, cat in sku_rows[:200])
    user = (
        f"Comment: {raw_text!r}\n\n"
        f"Catalogue (subset):\n{catalogue}\n\n"
        f"Reply with the JSON object."
    )
    try:
        result = chat_json(
            [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user},
            ],
            run_key="crew",
            max_tokens=200,
        )
    except AIUnavailable as e:
        return {"error": str(e)}

    code = result.get("sku_code")
    sku = (
        session.execute(select(Sku).where(Sku.code == code)).scalar_one_or_none()
        if isinstance(code, str)
        else None
    )
    signal_type = str(result.get("signal_type") or "other")
    if signal_type not in SIGNAL_TYPES:
        signal_type = "other"
    severity = result.get("severity") or 2
    try:
        severity = max(1, min(5, int(severity)))
    except (TypeError, ValueError):
        severity = 2

    fb = CrewFeedback(
        flight_id=flight_id,
        sku_id=sku.id if sku else None,
        free_text=raw_text,
        structured_json={
            "sku_code": sku.code if sku else None,
            "signal_type": signal_type,
            "severity": severity,
            "normalised": str(result.get("normalised") or "")[:280],
            "crew_member": crew_member,
        },
    )
    session.add(fb)
    session.commit()
    session.refresh(fb)
    return {
        "id": fb.id,
        "structured": {
            "sku_code": sku.code if sku else None,
            "sku_name": sku.name if sku else None,
            "signal_type": signal_type,
            "severity": severity,
            "normalised": fb.structured_json.get("normalised"),
        },
    }
