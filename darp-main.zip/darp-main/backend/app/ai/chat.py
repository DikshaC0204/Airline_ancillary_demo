"""Co-Planner chat: function-calling tools that the LLM can use to query the
running plan state without inventing data.

Tools:
- explain_sku(sku_code): structured info about a single SKU + its current decision
- compare_runs(run_id_a, run_id_b): KPI deltas
- list_top_skus(run_id, decision, limit): ranked decisions
- run_summary(run_id): KPIs + capacity
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import select, desc
from sqlalchemy.orm import Session

from ..models import (
    OptimisationRun,
    RangeDecision,
    Sku,
    Flight,
    Route,
    CostParams,
)
from .azure_openai import chat_with_tools, AIUnavailable, CallCeilingExceeded, is_configured, reset_run_counter


TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "run_summary",
            "description": "Get top-level KPIs for an optimisation run.",
            "parameters": {
                "type": "object",
                "properties": {"run_id": {"type": "integer"}},
                "required": ["run_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "explain_sku",
            "description": "Look up a SKU and how it was treated in the given run (load qty, demand, margin).",
            "parameters": {
                "type": "object",
                "properties": {
                    "run_id": {"type": "integer"},
                    "sku_code": {"type": "string"},
                },
                "required": ["run_id", "sku_code"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_top_skus",
            "description": "List the top-N SKUs for a run, ranked by net contribution.",
            "parameters": {
                "type": "object",
                "properties": {
                    "run_id": {"type": "integer"},
                    "decision": {
                        "type": "string",
                        "enum": ["load", "increase", "reduce", "exclude", "any"],
                        "default": "any",
                    },
                    "limit": {"type": "integer", "default": 10},
                },
                "required": ["run_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "compare_runs",
            "description": "Compute KPI deltas between two runs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "run_id_a": {"type": "integer"},
                    "run_id_b": {"type": "integer"},
                },
                "required": ["run_id_a", "run_id_b"],
            },
        },
    },
]


def _fmt_run(session: Session, run_id: int) -> dict[str, Any]:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        return {"error": f"run {run_id} not found"}
    flight = session.get(Flight, run.flight_id)
    route = session.get(Route, flight.route_id) if flight else None
    return {
        "run_id": run.id,
        "status": run.status,
        "flight_no": flight.flight_no if flight else None,
        "route": f"{route.origin_iata}->{route.dest_iata}" if route else None,
        "skus": run.total_skus,
        "units": run.total_units,
        "weight_kg": round(run.total_weight_kg or 0, 1),
        "revenue_gbp": round(run.expected_revenue or 0, 2),
        "net_gbp": round(run.expected_net_contribution or 0, 2),
        "scenario_label": run.scenario_label,
    }


def _execute_tool(session: Session, name: str, args: dict[str, Any]) -> Any:
    if name == "run_summary":
        return _fmt_run(session, int(args["run_id"]))

    if name == "explain_sku":
        run_id = int(args["run_id"])
        code = str(args["sku_code"]).strip().upper()
        sku = session.execute(select(Sku).where(Sku.code == code)).scalar_one_or_none()
        if sku is None:
            return {"error": f"SKU {code} not found"}
        d = session.execute(
            select(RangeDecision).where(
                RangeDecision.optimisation_run_id == run_id,
                RangeDecision.sku_id == sku.id,
            )
        ).scalar_one_or_none()
        return {
            "sku_code": sku.code,
            "sku_name": sku.name,
            "category": sku.category,
            "weight_g": sku.unit_weight_g,
            "retail_price_gbp": sku.retail_price,
            "margin_pct": round((sku.margin_pct or 0) * 100, 1),
            "decision": d.decision if d else "no_record",
            "loaded_qty": d.loaded_qty if d else 0,
            "expected_sales": round(d.expected_sales, 1) if d else 0,
            "net_contribution_gbp": round(d.net_contribution, 2) if d else 0,
            "rationale": d.rationale_text if d else None,
        }

    if name == "list_top_skus":
        run_id = int(args["run_id"])
        decision = str(args.get("decision", "any"))
        limit = int(args.get("limit", 10))
        stmt = (
            select(RangeDecision, Sku)
            .join(Sku, Sku.id == RangeDecision.sku_id)
            .where(RangeDecision.optimisation_run_id == run_id)
            .order_by(desc(RangeDecision.net_contribution))
            .limit(limit)
        )
        if decision != "any":
            stmt = stmt.where(RangeDecision.decision == decision)
        rows = session.execute(stmt).all()
        return [
            {
                "sku_code": sku.code,
                "name": sku.name,
                "decision": d.decision,
                "loaded_qty": d.loaded_qty,
                "net_gbp": round(d.net_contribution, 2),
            }
            for d, sku in rows
        ]

    if name == "compare_runs":
        a = _fmt_run(session, int(args["run_id_a"]))
        b = _fmt_run(session, int(args["run_id_b"]))
        if "error" in a or "error" in b:
            return {"error": "one or both runs not found"}
        delta = {
            k: round((b[k] or 0) - (a[k] or 0), 2)
            for k in ("skus", "units", "weight_kg", "revenue_gbp", "net_gbp")
        }
        return {"a": a, "b": b, "delta": delta}

    return {"error": f"unknown tool {name}"}


SYSTEM = (
    "You are the dnata Autonomous Range Planner co-planner. "
    "Answer planner questions about the live optimisation run using the supplied tools. "
    "Always use a tool to fetch real numbers — never invent data. "
    "Reply concisely (<=4 sentences) and cite specific figures with units (£, kg, units). "
    "When the planner asks 'why' something happened, look at the SKU's rationale and the "
    "constraints (weight budget, margin, demand) before answering."
)


def chat_turn(
    session: Session,
    history: list[dict[str, Any]],
    user_message: str,
    *,
    context_run_id: int | None = None,
    max_iterations: int = 3,
) -> dict[str, Any]:
    """Run one chat turn. Returns {"reply": str, "tool_trace": [...]}."""
    if not is_configured():
        return {
            "reply": "(AI co-planner not configured — set AZURE_OPENAI_API_KEY in .env)",
            "tool_trace": [],
        }

    sys_msg = SYSTEM
    if context_run_id is not None:
        sys_msg += f" The currently open run is run_id={context_run_id}."

    messages: list[dict[str, Any]] = [{"role": "system", "content": sys_msg}, *history,
                                       {"role": "user", "content": user_message}]
    tool_trace: list[dict[str, Any]] = []

    # Reset the per-turn call counter so the ceiling applies per chat turn,
    # not cumulatively across the process.
    reset_run_counter("chat")

    for _ in range(max_iterations):
        try:
            assistant = chat_with_tools(messages, TOOLS, run_key="chat", max_tokens=600)
        except CallCeilingExceeded:
            return {
                "reply": "(I hit the per-turn LLM call ceiling before finishing. Try a simpler question.)",
                "tool_trace": tool_trace,
            }
        except AIUnavailable as e:
            return {"reply": f"(AI error: {e})", "tool_trace": tool_trace}

        messages.append(
            {
                "role": "assistant",
                "content": assistant.get("content") or "",
                "tool_calls": assistant.get("tool_calls") or None,
            }
        )

        tool_calls = assistant.get("tool_calls") or []
        if not tool_calls:
            return {"reply": assistant.get("content") or "", "tool_trace": tool_trace}

        for tc in tool_calls:
            name = tc["function"]["name"]
            try:
                args = json.loads(tc["function"]["arguments"] or "{}")
            except json.JSONDecodeError:
                args = {}
            result = _execute_tool(session, name, args)
            tool_trace.append({"tool": name, "args": args, "result": result})
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc["id"],
                    "content": json.dumps(result, default=str),
                }
            )

    # Out of iterations: return whatever last text we have.
    last_assistant = next(
        (m for m in reversed(messages) if m.get("role") == "assistant" and m.get("content")), None
    )
    return {
        "reply": (last_assistant or {}).get("content") or "(no reply)",
        "tool_trace": tool_trace,
    }
