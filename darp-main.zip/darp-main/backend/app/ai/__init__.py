"""Azure OpenAI integration: cached client, rationale, narration, chat."""
