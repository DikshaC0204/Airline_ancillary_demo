"""Azure OpenAI client wrapper with SQLite cache and per-run call ceiling.

Design:
- Single shared `AzureOpenAI` client (lazy).
- Two helpers: `chat_json(...)` for structured JSON output (auto JSON-mode if the
  prompt mentions "JSON"), and `chat_with_tools(...)` for function-calling.
- Persistent cache in `data/aoai_cache.sqlite` keyed by sha256(prompt+model+tools).
- Per-process `_calls_in_run: dict[run_id, int]` ceiling (default 5).
- All network errors are caught and surfaced as `AIUnavailable` so callers can
  degrade gracefully (e.g. skip rationale, leave field blank).
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

from openai import AzureOpenAI, APIError
from openai.types.chat import ChatCompletion

from ..config import settings


CACHE_PATH = Path(settings.arp_db_path).parent / "aoai_cache.sqlite"


class AIUnavailable(RuntimeError):
    """Raised when AOAI is not configured or the API call failed."""


class CallCeilingExceeded(RuntimeError):
    pass


_lock = threading.Lock()
_client: Optional[AzureOpenAI] = None
_calls_in_run: dict[str, int] = {}


def _ensure_cache_table() -> sqlite3.Connection:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(CACHE_PATH, check_same_thread=False)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS aoai_cache (
            key TEXT PRIMARY KEY,
            response_json TEXT NOT NULL,
            created_at REAL NOT NULL
        )
        """
    )
    return conn


def _cache_get(key: str) -> Optional[dict]:
    with _lock:
        conn = _ensure_cache_table()
        row = conn.execute("SELECT response_json FROM aoai_cache WHERE key=?", (key,)).fetchone()
        conn.close()
    return json.loads(row[0]) if row else None


def _cache_put(key: str, response: dict) -> None:
    with _lock:
        conn = _ensure_cache_table()
        conn.execute(
            "INSERT OR REPLACE INTO aoai_cache(key, response_json, created_at) VALUES (?, ?, ?)",
            (key, json.dumps(response), time.time()),
        )
        conn.commit()
        conn.close()


def _hash_key(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


def _base_endpoint(raw: str) -> str:
    """Strip path/query so SDK can build deployment URL itself."""
    if not raw:
        return ""
    u = urlparse(raw)
    if not u.scheme or not u.netloc:
        return raw.rstrip("/")
    return f"{u.scheme}://{u.netloc}"


def _get_client() -> AzureOpenAI:
    global _client
    if _client is not None:
        return _client
    if not settings.azure_openai_api_key or not settings.azure_openai_endpoint:
        raise AIUnavailable("AZURE_OPENAI_API_KEY / ENDPOINT not configured")
    _client = AzureOpenAI(
        api_key=settings.azure_openai_api_key,
        api_version=settings.azure_openai_api_version,
        azure_endpoint=_base_endpoint(settings.azure_openai_endpoint),
    )
    return _client


def is_configured() -> bool:
    return bool(settings.azure_openai_api_key and settings.azure_openai_endpoint)


def reset_run_counter(run_key: str) -> None:
    _calls_in_run[run_key] = 0


def _bump_counter(run_key: Optional[str]) -> None:
    if run_key is None:
        return
    n = _calls_in_run.get(run_key, 0) + 1
    _calls_in_run[run_key] = n
    if n > settings.arp_llm_call_ceiling:
        raise CallCeilingExceeded(
            f"AOAI call ceiling ({settings.arp_llm_call_ceiling}) exceeded for run_key={run_key}"
        )


def chat_json(
    messages: list[dict],
    *,
    run_key: Optional[str] = None,
    temperature: float = 0.2,
    max_tokens: int = 400,
    use_cache: bool = True,
) -> dict:
    """Call chat completion expecting JSON back. Returns parsed dict.

    `messages` should include a system message instructing the model to reply with
    JSON only. We set `response_format={"type": "json_object"}` to enforce.
    """
    payload = {"messages": messages, "model": settings.azure_openai_deployment, "mode": "json"}
    key = _hash_key(payload)
    if use_cache:
        cached = _cache_get(key)
        if cached is not None:
            return cached

    _bump_counter(run_key)
    try:
        client = _get_client()
        resp: ChatCompletion = client.chat.completions.create(
            model=settings.azure_openai_deployment,
            messages=messages,  # type: ignore[arg-type]
            max_completion_tokens=max_tokens,
            response_format={"type": "json_object"},
        )
    except APIError as e:
        raise AIUnavailable(f"AOAI error: {e}") from e
    except Exception as e:
        raise AIUnavailable(f"AOAI call failed: {e}") from e

    text = resp.choices[0].message.content or "{}"
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        parsed = {"_raw": text}
    if use_cache:
        _cache_put(key, parsed)
    return parsed


def chat_text(
    messages: list[dict],
    *,
    run_key: Optional[str] = None,
    temperature: float = 0.3,
    max_tokens: int = 200,
    use_cache: bool = True,
) -> str:
    """Plain text reply."""
    payload = {"messages": messages, "model": settings.azure_openai_deployment, "mode": "text"}
    key = _hash_key(payload)
    if use_cache:
        cached = _cache_get(key)
        if cached is not None:
            return cached.get("text", "")

    _bump_counter(run_key)
    try:
        client = _get_client()
        resp: ChatCompletion = client.chat.completions.create(
            model=settings.azure_openai_deployment,
            messages=messages,  # type: ignore[arg-type]
            max_completion_tokens=max_tokens,
        )
    except APIError as e:
        raise AIUnavailable(f"AOAI error: {e}") from e
    except Exception as e:
        raise AIUnavailable(f"AOAI call failed: {e}") from e

    text = (resp.choices[0].message.content or "").strip()
    if use_cache:
        _cache_put(key, {"text": text})
    return text


def chat_with_tools(
    messages: list[dict],
    tools: list[dict],
    *,
    run_key: Optional[str] = None,
    temperature: float = 0.2,
    max_tokens: int = 600,
) -> dict[str, Any]:
    """Function-calling roundtrip. Returns the raw assistant message dict
    (including tool_calls if any).

    Not cached — chat is interactive.
    """
    _bump_counter(run_key)
    try:
        client = _get_client()
        resp: ChatCompletion = client.chat.completions.create(
            model=settings.azure_openai_deployment,
            messages=messages,  # type: ignore[arg-type]
            tools=tools,  # type: ignore[arg-type]
            tool_choice="auto",
            max_completion_tokens=max_tokens,
        )
    except APIError as e:
        raise AIUnavailable(f"AOAI error: {e}") from e
    except Exception as e:
        raise AIUnavailable(f"AOAI call failed: {e}") from e

    msg = resp.choices[0].message
    return {
        "role": "assistant",
        "content": msg.content or "",
        "tool_calls": [
            {
                "id": tc.id,
                "type": "function",
                "function": {"name": tc.function.name, "arguments": tc.function.arguments},
            }
            for tc in (msg.tool_calls or [])
        ],
    }
