"""Scenario narration: 3-bullet executive summary of base vs scenario."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import OptimisationRun, RangeDecision, Sku, Scenario
from .azure_openai import chat_json, AIUnavailable, is_configured


SYSTEM = (
    "You are an airline retail planner. Given two range plans (base and scenario) for the "
    "same flight, write a JSON object: {\"summary\": \"<one short headline sentence>\", "
    "\"bullets\": [\"<bullet 1>\", \"<bullet 2>\", \"<bullet 3>\"]}. Each bullet must "
    "include a number (£, kg, %, units). Avoid restating the parameter overlay verbatim. "
    "Focus on the commercial and operational consequences. Under 25 words per bullet. "
    "No emoji."
)


def _summarise_run(session: Session, run_id: int) -> dict[str, Any]:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        return {}
    rows = session.execute(
        select(RangeDecision, Sku)
        .join(Sku, Sku.id == RangeDecision.sku_id)
        .where(RangeDecision.optimisation_run_id == run_id)
    ).all()
    by_cat: dict[str, dict[str, float]] = {}
    for d, sku in rows:
        cat = by_cat.setdefault(sku.category, {"units": 0, "weight": 0.0, "net": 0.0, "skus": 0})
        cat["units"] += d.loaded_qty
        cat["weight"] += (sku.unit_weight_g or 0.0) * d.loaded_qty / 1000.0
        cat["net"] += d.net_contribution
        if d.loaded_qty > 0:
            cat["skus"] += 1
    return {
        "run_id": run.id,
        "skus": run.total_skus,
        "units": run.total_units,
        "weight_kg": round(run.total_weight_kg or 0.0, 1),
        "revenue_gbp": round(run.expected_revenue or 0.0, 2),
        "net_gbp": round(run.expected_net_contribution or 0.0, 2),
        "by_category": {
            k: {kk: (round(vv, 1) if isinstance(vv, float) else vv) for kk, vv in v.items()}
            for k, v in by_cat.items()
        },
    }


def narrate_scenario(
    session: Session,
    base_run_id: int,
    scenario_run_id: int,
    scenario: Scenario | None,
) -> dict[str, Any]:
    """Returns {"summary": str, "bullets": [str,...]} or {} if AI unavailable."""
    if not is_configured():
        return {}

    base = _summarise_run(session, base_run_id)
    sc = _summarise_run(session, scenario_run_id)
    if not base or not sc:
        return {}

    overlay = scenario.parameters_json if scenario is not None else {}
    user = (
        f"Scenario overlay: {overlay}\n\n"
        f"Base run #{base_run_id}: {base}\n\n"
        f"Scenario run #{scenario_run_id}: {sc}\n\n"
        f"Write JSON with summary + 3 bullets."
    )
    try:
        result = chat_json(
            [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user},
            ],
            run_key=f"narrate:{base_run_id}:{scenario_run_id}",
            max_tokens=350,
        )
    except AIUnavailable:
        return {}
    if not isinstance(result, dict) or "bullets" not in result:
        return {}
    return result
