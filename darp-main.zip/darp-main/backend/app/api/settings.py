"""Operator settings — currently the choice of forecasting method."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..db import get_session
from ..optim import forecast_service as svc
from ..optim.forecast_data import dataset_fingerprint

router = APIRouter()


class SettingsUpdate(BaseModel):
    forecast_method: str = Field(..., pattern="^(empirical|lightgbm)$")
    model_id: Optional[str] = None


class SettingsOut(BaseModel):
    forecast_method: str
    active_model_id: Optional[str] = None
    updated_at: Optional[datetime] = None
    revision: int = 0
    methods: list[dict[str, Any]] = []
    dataset: dict[str, Any] = {}
    latest_job: Optional[dict[str, Any]] = None


def job_payload(job) -> Optional[dict]:
    if job is None:
        return None
    return {
        "id": job.id,
        "model_id": job.model_id,
        "state": job.state,
        "progress_pct": job.progress_pct,
        "message": job.message,
        "requested_cutoff": job.requested_cutoff,
        "information_cutoff": job.information_cutoff,
        "error": job.error,
        "created_at": job.created_at,
        "started_at": job.started_at,
        "finished_at": job.finished_at,
        "is_terminal": job.is_terminal,
    }


def _settings_payload(session: Session) -> SettingsOut:
    row = svc.get_settings(session)
    fingerprint = dataset_fingerprint(session)
    return SettingsOut(
        forecast_method=row.forecast_method,
        active_model_id=row.active_model_id,
        updated_at=row.updated_at,
        revision=row.revision or 0,
        methods=svc.available_methods(session, fingerprint=fingerprint),
        dataset=svc.dataset_overview(session),
        latest_job=job_payload(svc.latest_job(session)),
    )


@router.get("", response_model=SettingsOut)
def read_settings(session: Session = Depends(get_session)) -> SettingsOut:
    return _settings_payload(session)


@router.patch("", response_model=SettingsOut)
def update_settings(body: SettingsUpdate, session: Session = Depends(get_session)) -> SettingsOut:
    try:
        svc.set_method(session, body.forecast_method, model_id=body.model_id)
    except svc.SettingsConflict as exc:
        # The method exists but cannot be served — a state problem, not bad input.
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _settings_payload(session)
