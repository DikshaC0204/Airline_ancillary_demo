"""Rotation endpoints — multi-leg flying that shares one loaded range."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from ..db import get_session
from ..models import Flight, Rotation, Route
from ..schemas import RotationLegOut, RotationOut

router = APIRouter()


def _to_out(session: Session, rot: Rotation) -> RotationOut:
    legs = session.execute(
        select(Flight).where(Flight.rotation_id == rot.id).order_by(Flight.leg_index)
        .options(selectinload(Flight.route))
    ).scalars().all()
    leg_outs = [
        RotationLegOut(
            flight_id=f.id,
            leg_index=f.leg_index or 0,
            flight_no=f.flight_no,
            origin_iata=f.route.origin_iata,
            dest_iata=f.route.dest_iata,
            scheduled_dt=f.scheduled_dt,
            expected_pax=f.expected_pax,
        )
        for f in legs
    ]
    return RotationOut(id=rot.id, code=rot.code, description=rot.description, legs=leg_outs)


@router.get("", response_model=list[RotationOut])
def list_rotations(limit: int = 100, session: Session = Depends(get_session)) -> list[RotationOut]:
    rots = session.execute(select(Rotation).order_by(Rotation.id).limit(limit)).scalars().all()
    return [_to_out(session, r) for r in rots]


@router.get("/{rotation_id}", response_model=RotationOut)
def get_rotation(rotation_id: int, session: Session = Depends(get_session)) -> RotationOut:
    rot = session.get(Rotation, rotation_id)
    if rot is None:
        raise HTTPException(404, "Rotation not found")
    return _to_out(session, rot)
