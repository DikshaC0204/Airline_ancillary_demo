"""Routes endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import Route
from ..schemas import RouteOut

router = APIRouter()


@router.get("", response_model=list[RouteOut])
def list_routes(session: Session = Depends(get_session)) -> list[RouteOut]:
    rows = session.scalars(select(Route).order_by(Route.origin_iata, Route.dest_iata)).all()
    return [RouteOut.model_validate(r) for r in rows]
