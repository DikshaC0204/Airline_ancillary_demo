"""API for optimisation runs."""

from __future__ import annotations

import asyncio
import json
import queue
import threading
from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload
from sse_starlette.sse import EventSourceResponse

from ..db import get_session, session_scope
from ..models import (
    Aircraft,
    Cart,
    CostParams,
    Drawer,
    DrawerAssignment,
    Flight,
    GalleyLayout,
    OptimisationRun,
    RangeDecision,
    Rotation,
    RunOverride,
    Sku,
)
from ..optim.engine import EngineProgressEvent, run_optimisation
from ..optim import forecast_service
from ..optim.selection import PinSpec, SelectionParams, validate_pins_capacity


router = APIRouter()


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------

class RunCreate(BaseModel):
    flight_id: Optional[int] = None
    rotation_id: Optional[int] = None
    service_level_p: float = Field(0.7, ge=0.5, le=0.95)
    volume_efficiency_eta: float = Field(0.65, ge=0.4, le=0.85)
    retail_weight_budget_kg: float = Field(280.0, ge=50.0, le=2000.0)
    complexity_penalty_scale: float = Field(1.0, ge=0.0, le=5.0)


class OverrideItem(BaseModel):
    sku_id: int
    kind: str  # force_include | force_exclude | set_qty
    qty: Optional[int] = None
    note: Optional[str] = None


class OverrideCreate(BaseModel):
    overrides: list[OverrideItem]


class ApproveBody(BaseModel):
    approved_by: str
    note: Optional[str] = None


class RunSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    flight_id: int
    created_at: datetime
    status: str
    objective_value: Optional[float] = None
    total_weight_kg: Optional[float] = None
    total_volume_cm3: Optional[float] = None
    total_skus: Optional[int] = None
    total_units: Optional[int] = None
    expected_revenue: Optional[float] = None
    expected_net_contribution: Optional[float] = None
    parameters_json: dict[str, Any] = {}
    run_kind: str = "autonomous"
    parent_run_id: Optional[int] = None
    rotation_id: Optional[int] = None
    approval_status: str = "draft"
    approved_by: Optional[str] = None
    approved_note: Optional[str] = None
    approved_at: Optional[datetime] = None

    @field_validator("parameters_json", mode="before")
    @classmethod
    def _hide_forecast_snapshot(cls, value):
        """The per-leg forecast snapshot is stored for override replay only.

        It runs to hundreds of rows per leg, which has no business being sent
        with every row of a run list.
        """
        if isinstance(value, dict) and "forecast_snapshot" in value:
            return {k: v for k, v in value.items() if k != "forecast_snapshot"}
        return value


class SubstituteOut(BaseModel):
    sku_id: int
    sku_code: str
    sku_name: str
    net_per_cm3: Optional[float] = None
    net_per_kg: Optional[float] = None


class RangeDecisionOut(BaseModel):
    sku_id: int
    sku_code: str
    sku_name: str
    category: str
    decision: str
    loaded_qty: int
    expected_sales: float
    expected_margin: float
    fuel_cost: float
    pick_pack_cost: float
    handling_cost: float = 0.0
    spoilage_cost: float = 0.0
    complexity_cost: float
    net_contribution: float
    net_per_kg: Optional[float] = None
    net_per_cm3: Optional[float] = None
    reason_code: Optional[str] = None
    reason_text: Optional[str] = None
    reason_detail: dict[str, Any] = {}
    substitute: Optional[SubstituteOut] = None
    leg_sales: dict[str, float] = {}
    is_overridden: bool = False
    rationale_text: Optional[str] = None
    weight_kg: float
    volume_cm3: float
    retail_price: float


class RunDetail(BaseModel):
    run: RunSummary
    decisions: list[RangeDecisionOut]
    capacity: dict[str, float]
    sustainability: dict[str, float]
    constraints: list[dict[str, Any]] = []
    rotation: Optional[dict[str, Any]] = None
    overrides: list[dict[str, Any]] = []


# ---------------------------------------------------------------------------
# Progress pubsub
# ---------------------------------------------------------------------------

_run_queues: dict[int, queue.Queue] = {}


def _queue_for(run_id: int) -> queue.Queue:
    q = _run_queues.get(run_id)
    if q is None:
        q = queue.Queue()
        _run_queues[run_id] = q
    return q


def _push_event(run_id: int, ev: EngineProgressEvent) -> None:
    _queue_for(run_id).put({
        "stage": ev.stage,
        "message": ev.message,
        "pct": ev.pct,
        "elapsed_s": round(ev.elapsed_s, 3),
        "extra": ev.extra or {},
    })


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

def _spawn_run_worker(
    run_id: int,
    *,
    flight_id: Optional[int],
    rotation_id: Optional[int],
    params: SelectionParams,
    pins: Optional[list[PinSpec]] = None,
    run_kind: str = "autonomous",
    parent_run_id: Optional[int] = None,
    forecast_context=None,
    forecast_snapshot: Optional[dict] = None,
) -> None:
    """Run the engine on a background thread, streaming progress over SSE."""

    def worker() -> None:
        try:
            with session_scope() as s:
                run_optimisation(
                    s,
                    flight_id,
                    rotation_id=rotation_id,
                    params=params,
                    pins=pins,
                    run_kind=run_kind,
                    parent_run_id=parent_run_id,
                    on_progress=lambda ev: _push_event(run_id, ev),
                    run_id=run_id,
                    forecast_context=forecast_context,
                    forecast_snapshot=forecast_snapshot,
                )
            try:
                from ..ai.rationale import generate_rationales
                with session_scope() as s:
                    generate_rationales(s, run_id, top_k=12)
            except Exception:  # noqa: BLE001
                pass
            _push_event(run_id, EngineProgressEvent("done", "Run complete", 100, 0.0, extra={"run_id": run_id}))
        except Exception as exc:  # noqa: BLE001
            try:
                with session_scope() as s:
                    r = s.get(OptimisationRun, run_id)
                    if r is not None:
                        r.status = "failed"
                        s.commit()
            except Exception:  # noqa: BLE001
                pass
            _push_event(run_id, EngineProgressEvent("failed", f"{type(exc).__name__}: {exc}", 100, 0.0))

    threading.Thread(target=worker, daemon=True).start()


@router.post("", response_model=RunSummary)
def start_run(body: RunCreate, session: Session = Depends(get_session)) -> RunSummary:
    if (body.flight_id is None) == (body.rotation_id is None):
        raise HTTPException(status_code=422, detail="provide exactly one of flight_id or rotation_id")

    origin_flight_id = body.flight_id
    leg_ids: list[int] = []
    if body.rotation_id is not None:
        leg_flights = session.execute(
            select(Flight).where(Flight.rotation_id == body.rotation_id).order_by(Flight.leg_index)
        ).scalars().all()
        if not leg_flights:
            raise HTTPException(status_code=404, detail="rotation has no flights")
        origin_flight = leg_flights[0]
        origin_flight_id = origin_flight.id
        leg_ids = [f.id for f in leg_flights]
    else:
        origin_flight = session.execute(
            select(Flight).where(Flight.id == body.flight_id)
        ).scalar_one_or_none()
        if origin_flight is None:
            raise HTTPException(status_code=404, detail="flight not found")
        leg_ids = [origin_flight.id]

    # Pin the forecasting decision now. A run queued under one method must not
    # change meaning because someone saved Settings while it waited.
    forecast_context = forecast_service.resolve_context(
        session,
        target_departure=origin_flight.scheduled_dt,
        exclude_flight_ids=leg_ids,
    )

    run = OptimisationRun(
        flight_id=origin_flight_id,
        rotation_id=body.rotation_id,
        status="pending",
        parameters_json={**body.model_dump(), "forecasting": forecast_context.to_dict()},
    )
    session.add(run)
    session.commit()
    session.refresh(run)
    run_id = run.id
    _queue_for(run_id)

    params = SelectionParams(
        service_level_p=body.service_level_p,
        volume_efficiency_eta=body.volume_efficiency_eta,
        retail_weight_budget_kg=body.retail_weight_budget_kg,
        complexity_penalty_scale=body.complexity_penalty_scale,
    )
    _spawn_run_worker(
        run_id,
        flight_id=body.flight_id,
        rotation_id=body.rotation_id,
        params=params,
        forecast_context=forecast_context,
    )
    return RunSummary.model_validate(run)


@router.post("/{run_id}/override", response_model=RunSummary)
def create_override_run(run_id: int, body: OverrideCreate, session: Session = Depends(get_session)) -> RunSummary:
    parent = session.get(OptimisationRun, run_id)
    if parent is None:
        raise HTTPException(status_code=404, detail="run not found")
    if not body.overrides:
        raise HTTPException(status_code=422, detail="no overrides supplied")

    pins = [PinSpec(sku_id=o.sku_id, kind=o.kind, qty=o.qty) for o in body.overrides]

    # Pre-validate pinned load against capacity before spawning the solve.
    origin_flight = session.execute(
        select(Flight).where(Flight.id == parent.flight_id)
        .options(
            selectinload(Flight.aircraft).selectinload(Aircraft.galley_layout)
            .selectinload(GalleyLayout.carts).selectinload(Cart.drawers)
        )
    ).scalar_one()
    aircraft = origin_flight.aircraft
    drawers = [d for c in aircraft.galley_layout.carts for d in c.drawers]
    skus = list(session.execute(select(Sku)).scalars())
    parent_params = parent.parameters_json or {}
    params = SelectionParams(
        service_level_p=float(parent_params.get("service_level_p", 0.7)),
        volume_efficiency_eta=float(parent_params.get("volume_efficiency_eta", 0.65)),
        retail_weight_budget_kg=float(parent_params.get("retail_weight_budget_kg", 280.0)),
        complexity_penalty_scale=float(parent_params.get("complexity_penalty_scale", 1.0)),
        soft_constraints=True,  # relax brand/supplier minima so pins never deadlock
    )
    err = validate_pins_capacity(drawers, aircraft, skus, pins, params)
    if err is not None:
        raise HTTPException(status_code=422, detail=err)

    # An override must re-solve the parent's plan against the parent's forecasts.
    # Re-forecasting would change the thing being compared, so if the catalogue
    # has moved on since, say so instead of quietly mixing the two.
    inherited_snapshot = parent_params.get("forecast_snapshot") or None
    if inherited_snapshot:
        snapshot_skus = {int(s) for s in (inherited_snapshot.get("1") or {})}
        missing = {s.id for s in skus} - snapshot_skus
        if missing:
            raise HTTPException(status_code=409, detail={
                "reason": "catalogue_changed_since_parent_run",
                "message": (
                    f"{len(missing)} SKUs have been added since run {run_id} was "
                    "forecast. Start a fresh run before overriding."
                ),
                "new_sku_ids": sorted(missing)[:20],
            })

    forecast_payload = parent_params.get("forecasting")
    inherited_context = (
        forecast_service.ForecastContext.from_dict(forecast_payload) if forecast_payload else None
    )

    # Snapshot original decisions for provenance.
    parent_decisions = {
        d.sku_id: d for d in session.execute(
            select(RangeDecision).where(RangeDecision.optimisation_run_id == run_id)
        ).scalars()
    }

    run = OptimisationRun(
        flight_id=parent.flight_id,
        rotation_id=parent.rotation_id,
        run_kind="override",
        parent_run_id=run_id,
        status="pending",
        parameters_json={
            **parent_params,
            "override_of": run_id,
            # Runs made before forecast provenance existed have nothing to
            # inherit, so they are recomputed and labelled rather than claimed
            # to reproduce the original.
            "forecast_inherited": bool(inherited_snapshot),
            "legacy_recomputed": not inherited_snapshot,
        },
    )
    session.add(run)
    session.commit()
    session.refresh(run)
    new_run_id = run.id

    for o in body.overrides:
        pd = parent_decisions.get(o.sku_id)
        session.add(RunOverride(
            run_id=new_run_id,
            source_run_id=run_id,
            sku_id=o.sku_id,
            kind=o.kind,
            qty=o.qty,
            original_decision=pd.decision if pd else "exclude",
            original_qty=pd.loaded_qty if pd else 0,
            note=o.note,
        ))
    session.commit()

    _queue_for(new_run_id)
    _spawn_run_worker(
        new_run_id,
        flight_id=parent.flight_id if parent.rotation_id is None else None,
        rotation_id=parent.rotation_id,
        params=params,
        pins=pins,
        run_kind="override",
        parent_run_id=run_id,
        forecast_context=inherited_context,
        forecast_snapshot=inherited_snapshot,
    )
    return RunSummary.model_validate(run)


def _covered_flight_ids(session: Session, run: OptimisationRun) -> set[int]:
    """Every flight a run plans for — all legs when it is a rotation."""
    if run.rotation_id is not None:
        return set(
            session.execute(
                select(Flight.id).where(Flight.rotation_id == run.rotation_id)
            ).scalars()
        )
    return {run.flight_id}


@router.post("/{run_id}/approve", response_model=RunSummary)
def approve_run(run_id: int, body: ApproveBody, session: Session = Depends(get_session)) -> RunSummary:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")
    if run.status != "done":
        raise HTTPException(status_code=409, detail="only completed runs can be approved")

    # Approving is the moment a plan becomes the one the warehouse builds, so it
    # has to still be loadable on the aircraft the flight is currently assigned.
    reval = run.revalidation_json or {}
    if reval.get("verdict") == "capacity_violated":
        raise HTTPException(status_code=409, detail={
            "reason": "capacity_violated",
            "message": (
                f"{reval.get('unplaced_units', 0)} units no longer fit the assigned aircraft; "
                "re-run the optimisation before approving"
            ),
        })

    packed_units = session.scalar(
        select(func.coalesce(func.sum(DrawerAssignment.units), 0)).where(
            DrawerAssignment.optimisation_run_id == run_id
        )
    ) or 0
    planned_units = run.total_units or 0
    if packed_units < planned_units:
        raise HTTPException(status_code=409, detail={
            "reason": "plan_not_fully_packed",
            "message": (
                f"only {packed_units} of {planned_units} planned units have a drawer position"
            ),
            "planned_units": planned_units,
            "packed_units": int(packed_units),
        })

    # Single "the plan" invariant. A rotation run and a single-leg run can cover
    # the same flight, so overlap is decided by the flights covered rather than
    # by matching ids.
    covered = _covered_flight_ids(session, run)
    siblings = session.execute(
        select(OptimisationRun).where(
            OptimisationRun.id != run_id,
            OptimisationRun.approval_status == "approved",
        )
    ).scalars().all()
    for sib in siblings:
        if _covered_flight_ids(session, sib) & covered:
            sib.approval_status = "draft"
            sib.approved_by = None
            sib.approved_note = None
            sib.approved_at = None

    run.approval_status = "approved"
    run.approved_by = body.approved_by
    run.approved_note = body.note
    run.approved_at = datetime.utcnow()
    session.commit()
    session.refresh(run)
    return RunSummary.model_validate(run)


@router.delete("/{run_id}/approve", response_model=RunSummary)
def revoke_approval(run_id: int, session: Session = Depends(get_session)) -> RunSummary:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")
    run.approval_status = "draft"
    run.approved_by = None
    run.approved_note = None
    run.approved_at = None
    session.commit()
    session.refresh(run)
    return RunSummary.model_validate(run)


@router.get("", response_model=list[RunSummary])
def list_runs(
    flight_id: Optional[int] = None,
    limit: int = 50,
    session: Session = Depends(get_session),
) -> list[RunSummary]:
    stmt = select(OptimisationRun).order_by(OptimisationRun.id.desc()).limit(limit)
    if flight_id is not None:
        stmt = stmt.where(OptimisationRun.flight_id == flight_id)
    runs = session.execute(stmt).scalars().all()
    return [RunSummary.model_validate(r) for r in runs]


@router.get("/by-flight/{flight_id}/latest", response_model=Optional[RunSummary])
def latest_run_for_flight(flight_id: int, session: Session = Depends(get_session)) -> Optional[RunSummary]:
    run = session.execute(
        select(OptimisationRun)
        .where(OptimisationRun.flight_id == flight_id)
        .order_by(OptimisationRun.id.desc())
    ).scalars().first()
    return RunSummary.model_validate(run) if run else None


@router.get("/by-flight/{flight_id}/approved", response_model=Optional[RunSummary])
def approved_run_for_flight(flight_id: int, session: Session = Depends(get_session)) -> Optional[RunSummary]:
    run = session.execute(
        select(OptimisationRun)
        .where(OptimisationRun.flight_id == flight_id, OptimisationRun.approval_status == "approved")
        .order_by(OptimisationRun.id.desc())
    ).scalars().first()
    return RunSummary.model_validate(run) if run else None


@router.get("/{run_id}", response_model=RunDetail)
def get_run(run_id: int, session: Session = Depends(get_session)) -> RunDetail:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")

    decisions = session.execute(
        select(RangeDecision)
        .where(RangeDecision.optimisation_run_id == run_id)
        .order_by(RangeDecision.net_contribution.desc())
    ).scalars().all()
    sku_ids = [d.sku_id for d in decisions]
    sku_map: dict[int, Sku] = {}
    if sku_ids:
        for s in session.execute(select(Sku).where(Sku.id.in_(sku_ids))).scalars():
            sku_map[s.id] = s

    # Resolve substitute SKU metadata.
    sub_ids = [d.substitute_sku_id for d in decisions if d.substitute_sku_id]
    sub_map: dict[int, Sku] = {}
    if sub_ids:
        for s in session.execute(select(Sku).where(Sku.id.in_(sub_ids))).scalars():
            sub_map[s.id] = s
    sub_decision: dict[int, RangeDecision] = {d.sku_id: d for d in decisions}

    out_decisions: list[RangeDecisionOut] = []
    for d in decisions:
        sku = sku_map.get(d.sku_id)
        if sku is None:
            continue
        w_kg = (sku.unit_weight_g / 1000.0) * d.loaded_qty
        v_cm3 = sku.volume_cm3 * d.loaded_qty
        substitute = None
        if d.substitute_sku_id and d.substitute_sku_id in sub_map:
            sub_sku = sub_map[d.substitute_sku_id]
            sub_dec = sub_decision.get(d.substitute_sku_id)
            substitute = SubstituteOut(
                sku_id=sub_sku.id,
                sku_code=sub_sku.code,
                sku_name=sub_sku.name,
                net_per_cm3=sub_dec.net_per_cm3 if sub_dec else None,
                net_per_kg=sub_dec.net_per_kg if sub_dec else None,
            )
        out_decisions.append(
            RangeDecisionOut(
                sku_id=d.sku_id,
                sku_code=sku.code,
                sku_name=sku.name,
                category=sku.category,
                decision=d.decision,
                loaded_qty=d.loaded_qty,
                expected_sales=d.expected_sales,
                expected_margin=d.expected_margin,
                fuel_cost=d.fuel_cost,
                pick_pack_cost=d.pick_pack_cost,
                handling_cost=d.handling_cost,
                spoilage_cost=d.spoilage_cost,
                complexity_cost=d.complexity_cost,
                net_contribution=d.net_contribution,
                net_per_kg=d.net_per_kg,
                net_per_cm3=d.net_per_cm3,
                reason_code=d.reason_code,
                reason_text=d.reason_text,
                reason_detail=d.reason_detail_json or {},
                substitute=substitute,
                leg_sales={str(k): float(v) for k, v in (d.leg_sales_json or {}).items()},
                is_overridden=bool(d.is_overridden),
                rationale_text=d.rationale_text,
                weight_kg=w_kg,
                volume_cm3=v_cm3,
                retail_price=sku.retail_price,
            )
        )

    flight = session.execute(
        select(Flight).where(Flight.id == run.flight_id).options(selectinload(Flight.aircraft))
    ).scalar_one()
    p = run.parameters_json or {}
    capacity = {
        "weight_budget_kg": float(p.get("retail_weight_budget_kg", 280.0)),
        "volume_efficiency_eta": float(p.get("volume_efficiency_eta", 0.65)),
        "service_level_p": float(p.get("service_level_p", 0.7)),
        "max_payload_kg": float(flight.aircraft.max_payload_kg),
    }

    # Sustainability: convert £fuel back into kg fuel using current price, then CO₂.
    cp = session.execute(select(CostParams).order_by(CostParams.valid_from.desc())).scalars().first()
    fuel_price = float((run.parameters_json or {}).get("fuel_price_per_kg_gbp_used") or (cp.fuel_price_per_kg_gbp if cp else 0.82))
    total_fuel_gbp = sum(d.fuel_cost for d in decisions)
    fuel_kg = total_fuel_gbp / fuel_price if fuel_price > 0 else 0.0
    co2_kg = fuel_kg * 3.15  # ICAO standard jet-A factor
    sustainability = {
        "fuel_price_per_kg_gbp": fuel_price,
        "fuel_cost_gbp": round(total_fuel_gbp, 2),
        "fuel_kg": round(fuel_kg, 2),
        "co2_kg": round(co2_kg, 2),
    }

    constraints = (run.constraint_report_json or {}).get("constraints", [])

    rotation = None
    if run.rotation_id is not None:
        rot = session.get(Rotation, run.rotation_id)
        rotation = {
            "id": run.rotation_id,
            "code": rot.code if rot else None,
            "description": rot.description if rot else None,
            "legs": (run.rotation_report_json or {}).get("legs", []),
        }

    overrides_out = [
        {
            "sku_id": o.sku_id,
            "kind": o.kind,
            "qty": o.qty,
            "original_decision": o.original_decision,
            "original_qty": o.original_qty,
            "note": o.note,
        }
        for o in session.execute(
            select(RunOverride).where(RunOverride.run_id == run_id)
        ).scalars()
    ]

    return RunDetail(
        run=RunSummary.model_validate(run),
        decisions=out_decisions,
        capacity=capacity,
        sustainability=sustainability,
        constraints=constraints,
        rotation=rotation,
        overrides=overrides_out,
    )


@router.get("/{run_id}/stream")
async def stream_run(run_id: int) -> EventSourceResponse:
    q = _queue_for(run_id)

    async def event_gen():
        loop = asyncio.get_event_loop()
        while True:
            try:
                ev = await loop.run_in_executor(None, lambda: q.get(timeout=30))
            except queue.Empty:
                yield {"event": "ping", "data": "{}"}
                continue
            yield {"event": "progress", "data": json.dumps(ev)}
            if ev.get("stage") in ("done", "failed"):
                break

    return EventSourceResponse(event_gen())


# ---------------------------------------------------------------------------
# Packing endpoint
# ---------------------------------------------------------------------------

class PackingOut(BaseModel):
    run_id: int
    cart_layout: list[dict[str, Any]]
    totals: dict[str, float]


@router.get("/{run_id}/packing", response_model=PackingOut)
def get_packing(run_id: int, session: Session = Depends(get_session)) -> PackingOut:
    run = session.get(OptimisationRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")

    flight = session.execute(
        select(Flight)
        .where(Flight.id == run.flight_id)
        .options(
            selectinload(Flight.aircraft)
            .selectinload(Aircraft.galley_layout)
            .selectinload(GalleyLayout.carts)
            .selectinload(Cart.drawers),
        )
    ).scalar_one()
    galley = flight.aircraft.galley_layout

    assignments = session.execute(
        select(DrawerAssignment).where(DrawerAssignment.optimisation_run_id == run_id)
    ).scalars().all()
    sku_ids = list({a.sku_id for a in assignments})
    sku_map: dict[int, Sku] = {}
    if sku_ids:
        for s in session.execute(select(Sku).where(Sku.id.in_(sku_ids))).scalars():
            sku_map[s.id] = s

    by_drawer: dict[int, list[DrawerAssignment]] = {}
    for a in assignments:
        by_drawer.setdefault(a.drawer_id, []).append(a)

    total_units = 0
    total_weight_kg = 0.0
    cart_layout: list[dict[str, Any]] = []
    for cart in galley.carts:
        cart_drawers: list[dict[str, Any]] = []
        for drawer in sorted(cart.drawers, key=lambda d: d.slot_index):
            drawer_assigns = by_drawer.get(drawer.id, [])
            placements_out: list[dict[str, Any]] = []
            d_units = 0
            d_weight_g = 0.0
            d_volume_cm3 = 0.0
            for a in drawer_assigns:
                sku = sku_map.get(a.sku_id)
                if sku is None:
                    continue
                positions = (a.position_xyz_json or {}).get("positions", [])
                placements_out.append({
                    "sku_id": sku.id,
                    "sku_code": sku.code,
                    "sku_name": sku.name,
                    "category": sku.category,
                    "units": a.units,
                    "positions": positions,
                })
                d_units += a.units
                d_weight_g += sku.unit_weight_g * a.units
                d_volume_cm3 += sku.volume_cm3 * a.units
            cart_drawers.append({
                "drawer_id": drawer.id,
                "cart_id": cart.id,
                "slot_index": drawer.slot_index,
                "drawer_type": drawer.type,
                "internal_l_mm": drawer.internal_l_mm,
                "internal_w_mm": drawer.internal_w_mm,
                "internal_h_mm": drawer.internal_h_mm,
                "max_weight_kg": drawer.max_weight_kg,
                "accessibility_score": drawer.accessibility_score,
                "placements": placements_out,
                "weight_kg": round(d_weight_g / 1000.0, 3),
                "weight_cap_kg": drawer.max_weight_kg,
                "volume_used_cm3": round(d_volume_cm3, 1),
                "volume_total_cm3": round(drawer.internal_l_mm * drawer.internal_w_mm * drawer.internal_h_mm / 1000.0, 1),
            })
            total_units += d_units
            total_weight_kg += d_weight_g / 1000.0
        cart_layout.append({
            "id": cart.id,
            "position_code": cart.position_code,
            "cart_type": cart.cart_type,
            "drawers": cart_drawers,
        })

    return PackingOut(
        run_id=run_id,
        cart_layout=cart_layout,
        totals={
            "total_units_packed": float(total_units),
            "total_weight_kg": round(total_weight_kg, 3),
        },
    )
