"""Training and evaluating the optional forecasting model."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import ForecastTrainingJob
from ..optim import forecast_service as svc
from .settings import job_payload

router = APIRouter()


class TrainRequest(BaseModel):
    # Everything up to this instant may be learned from; flights after it stay
    # available as honest out-of-time targets. Defaults to the start of the
    # latest month in the history.
    cutoff: Optional[datetime] = None


class JobOut(BaseModel):
    job: dict[str, Any]


@router.post("/train-evaluate", response_model=JobOut, status_code=202)
def train_evaluate(body: TrainRequest, session: Session = Depends(get_session)) -> JobOut:
    try:
        job = svc.start_training(session, cutoff=body.cutoff)
    except svc.TrainingConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except svc.SettingsConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return JobOut(job=job_payload(job))


@router.get("/jobs", response_model=list[dict])
def list_jobs(limit: int = 10, session: Session = Depends(get_session)) -> list[dict]:
    rows = session.execute(
        select(ForecastTrainingJob).order_by(ForecastTrainingJob.id.desc()).limit(min(limit, 50))
    ).scalars().all()
    return [job_payload(r) for r in rows]


@router.get("/jobs/{job_id}", response_model=dict)
def get_job(job_id: int, session: Session = Depends(get_session)) -> dict:
    job = session.get(ForecastTrainingJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="training job not found")
    payload = job_payload(job)
    payload["report"] = job.report_json
    return payload


@router.get("/evaluations/latest", response_model=dict)
def latest_evaluation(session: Session = Depends(get_session)) -> dict:
    job = session.execute(
        select(ForecastTrainingJob)
        .where(ForecastTrainingJob.state == svc.SUCCEEDED)
        .order_by(ForecastTrainingJob.id.desc())
    ).scalars().first()
    if job is None:
        return {"report": None, "job": None}
    return {"report": job.report_json, "job": job_payload(job)}
