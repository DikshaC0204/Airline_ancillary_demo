"""SKU endpoints."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import Sku
from ..schemas import SkuOut, SkuUpdate

router = APIRouter()


@router.get("", response_model=dict)
def list_skus(
    session: Session = Depends(get_session),
    q: Optional[str] = None,
    category: Optional[str] = None,
    limit: int = Query(500, le=2000),
    offset: int = 0,
) -> dict:
    stmt = select(Sku)
    if q:
        like = f"%{q}%"
        stmt = stmt.where((Sku.name.ilike(like)) | (Sku.code.ilike(like)) | (Sku.brand.ilike(like)))
    if category:
        stmt = stmt.where(Sku.category == category)

    total = session.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = session.scalars(stmt.order_by(Sku.category, Sku.name).offset(offset).limit(limit)).all()
    return {"total": total, "items": [SkuOut.model_validate(r).model_dump() for r in rows]}


@router.get("/categories", response_model=list[str])
def list_categories(session: Session = Depends(get_session)) -> list[str]:
    rows = session.execute(select(Sku.category).distinct().order_by(Sku.category)).all()
    return [r[0] for r in rows]


@router.get("/{sku_id}", response_model=SkuOut)
def get_sku(sku_id: int, session: Session = Depends(get_session)) -> SkuOut:
    sku = session.get(Sku, sku_id)
    if not sku:
        raise HTTPException(404, "SKU not found")
    return SkuOut.model_validate(sku)


@router.patch("/{sku_id}", response_model=SkuOut)
def update_sku(sku_id: int, patch: SkuUpdate, session: Session = Depends(get_session)) -> SkuOut:
    sku = session.get(Sku, sku_id)
    if not sku:
        raise HTTPException(404, "SKU not found")
    for field, value in patch.model_dump(exclude_unset=True).items():
        setattr(sku, field, value)
    if "retail_price" in patch.model_fields_set or "cost_price" in patch.model_fields_set:
        if sku.retail_price > 0:
            sku.margin_pct = (sku.retail_price - sku.cost_price) / sku.retail_price
    session.commit()
    session.refresh(sku)
    return SkuOut.model_validate(sku)
