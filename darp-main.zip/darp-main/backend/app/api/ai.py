"""AI endpoints: chat, narrate scenario, ingest crew feedback, regenerate rationales."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import OptimisationRun, Scenario, CrewFeedback, Sku, Flight
from ..ai import chat as chat_mod, narrate as narrate_mod, rationale as rationale_mod, crew as crew_mod
from ..ai.azure_openai import is_configured
from sqlalchemy import select, desc


router = APIRouter()


class ChatHistoryMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[ChatHistoryMessage] = []
    context_run_id: Optional[int] = None


class ChatResponse(BaseModel):
    reply: str
    tool_trace: list[dict[str, Any]]


@router.get("/health")
def ai_health() -> dict[str, Any]:
    return {"configured": is_configured()}


@router.post("/chat", response_model=ChatResponse)
def chat(body: ChatRequest, session: Session = Depends(get_session)) -> ChatResponse:
    history = [{"role": m.role, "content": m.content} for m in body.history]
    result = chat_mod.chat_turn(
        session,
        history,
        body.message,
        context_run_id=body.context_run_id,
    )
    return ChatResponse(reply=result["reply"], tool_trace=result["tool_trace"])


class NarrateRequest(BaseModel):
    base_run_id: int
    scenario_run_id: int
    scenario_id: Optional[int] = None


class NarrateResponse(BaseModel):
    summary: Optional[str] = None
    bullets: list[str] = []


@router.post("/narrate-scenario", response_model=NarrateResponse)
def narrate(body: NarrateRequest, session: Session = Depends(get_session)) -> NarrateResponse:
    sc = session.get(Scenario, body.scenario_id) if body.scenario_id else None
    out = narrate_mod.narrate_scenario(session, body.base_run_id, body.scenario_run_id, sc)
    return NarrateResponse(
        summary=out.get("summary"),
        bullets=[str(b) for b in (out.get("bullets") or [])],
    )


class RationaleRequest(BaseModel):
    run_id: int
    top_k: int = 12


@router.post("/rationales")
def generate_rationales(
    body: RationaleRequest, session: Session = Depends(get_session)
) -> dict[str, Any]:
    run = session.get(OptimisationRun, body.run_id)
    if run is None:
        raise HTTPException(404, "run not found")
    n = rationale_mod.generate_rationales(session, body.run_id, top_k=body.top_k)
    return {"run_id": body.run_id, "updated": n, "configured": is_configured()}


class CrewFeedbackRequest(BaseModel):
    text: str
    flight_id: Optional[int] = None
    crew_member: Optional[str] = None


@router.post("/crew-feedback")
def crew_feedback(
    body: CrewFeedbackRequest, session: Session = Depends(get_session)
) -> dict[str, Any]:
    if not body.text.strip():
        raise HTTPException(400, "empty text")
    return crew_mod.ingest_feedback(
        session, body.text.strip(), flight_id=body.flight_id, crew_member=body.crew_member
    )


@router.get("/crew-feedback")
def list_crew_feedback(
    session: Session = Depends(get_session), limit: int = 50
) -> list[dict[str, Any]]:
    rows = session.execute(
        select(CrewFeedback).order_by(desc(CrewFeedback.id)).limit(limit)
    ).scalars().all()
    out: list[dict[str, Any]] = []
    sku_codes: dict[int, tuple[str, str]] = {}
    flight_nos: dict[int, str] = {}
    for fb in rows:
        sku_label = None
        if fb.sku_id and fb.sku_id not in sku_codes:
            sku = session.get(Sku, fb.sku_id)
            if sku:
                sku_codes[fb.sku_id] = (sku.code, sku.name)
        if fb.sku_id and fb.sku_id in sku_codes:
            code, name = sku_codes[fb.sku_id]
            sku_label = f"{code} · {name}"
        flight_no = None
        if fb.flight_id and fb.flight_id not in flight_nos:
            fl = session.get(Flight, fb.flight_id)
            if fl:
                flight_nos[fb.flight_id] = fl.flight_no
        if fb.flight_id and fb.flight_id in flight_nos:
            flight_no = flight_nos[fb.flight_id]
        out.append(
            {
                "id": fb.id,
                "flight_id": fb.flight_id,
                "flight_no": flight_no,
                "sku_id": fb.sku_id,
                "sku_label": sku_label,
                "free_text": fb.free_text,
                "structured": fb.structured_json or {},
            }
        )
    return out
