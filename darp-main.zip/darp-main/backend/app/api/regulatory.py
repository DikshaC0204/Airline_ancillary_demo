"""Regulatory rule endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import RegulatoryRule
from ..schemas import RegulatoryRuleOut

router = APIRouter()


@router.get("", response_model=list[RegulatoryRuleOut])
def list_rules(session: Session = Depends(get_session)) -> list[RegulatoryRuleOut]:
    rows = session.scalars(select(RegulatoryRule).order_by(RegulatoryRule.id)).all()
    return [RegulatoryRuleOut.model_validate(r) for r in rows]
