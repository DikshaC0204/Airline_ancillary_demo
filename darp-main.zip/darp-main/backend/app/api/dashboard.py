"""Dashboard summary and activity endpoints.

Headline KPIs are derived from real optimisation runs compared against the
costed manual-plan baseline stored on each run (see optim/baseline.py). They
are never fabricated: if nothing has been planned yet the KPIs come back as
null and the UI says so rather than showing a zero.
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import Flight, OptimisationRun, Route, Sale, Sku

router = APIRouter()

# A percentage uplift is only meaningful against a positive baseline. On thin
# flights the manual plan can genuinely lose money, and dividing by that gives
# figures like +239% that say nothing. Below this the money delta is used instead.
MIN_BASELINE_FOR_PCT_GBP = 1.0


def _uplift_pct(net: float, baseline: float) -> Optional[float]:
    if baseline < MIN_BASELINE_FOR_PCT_GBP:
        return None
    return (net - baseline) / baseline * 100.0


def _headline_uplift_pct(net: float, baseline: float, baselines: list[float]) -> Optional[float]:
    """Aggregate uplift, or None when a ratio would mislead.

    Summing baselines lets a loss-making flight cancel a profitable one and
    shrink the denominator: three approved flights whose manual plans came to
    £49.85, -£7.06 and -£1.98 totalled £40.81 and reported +164.8% uplift on a
    £67 gain. "Improvement over a plan that loses money" is not a percentage
    anyone can act on, so the money figure carries it instead.
    """
    if any(b < 0 for b in baselines):
        return None
    return _uplift_pct(net, baseline)


# Origin / dest coordinates for the prototype routes — used by the Leaflet map.
# A route whose airports are missing here is silently dropped from the map, so
# this must cover every airport the seed creates.
AIRPORT_COORDS: dict[str, tuple[float, float]] = {
    "LTN": (51.8763, -0.3717),
    "IBZ": (38.8729, 1.3731),
    "TIA": (41.4147, 19.7206),
    "GVA": (46.2381, 6.1090),
    "AGP": (36.6749, -4.4991),
    "ACE": (28.9455, -13.6052),
}


def _kpi_runs(session: Session) -> tuple[list[OptimisationRun], str]:
    """Runs that back the headline KPIs.

    Approved plans are the truth if any exist; otherwise fall back to completed
    drafts so the dashboard is informative before anyone has hit approve. The
    caller surfaces which basis was used.
    """
    approved = list(
        session.scalars(
            select(OptimisationRun).where(
                OptimisationRun.status == "done",
                OptimisationRun.approval_status == "approved",
                OptimisationRun.baseline_net_contribution.is_not(None),
            )
        )
    )
    if approved:
        return approved, "approved"

    latest = list(
        session.scalars(
            select(OptimisationRun)
            .where(
                OptimisationRun.status == "done",
                OptimisationRun.baseline_net_contribution.is_not(None),
            )
            .order_by(OptimisationRun.id.desc())
            .limit(20)
        )
    )
    return latest, "latest" if latest else "none"


def _headline_kpis(runs: list[OptimisationRun]) -> dict:
    """Aggregate uplift, waste reduction and service level across runs.

    Aggregated on summed totals rather than as a mean of per-run percentages,
    so a tiny flight cannot swing the headline as much as a full one.
    """
    if not runs:
        return {
            "expected_uplift_pct": None,
            "waste_reduction_pct": None,
            "service_level_pct": None,
            "net_contribution_gbp": None,
            "baseline_net_contribution_gbp": None,
            "net_uplift_gbp": None,
            "waste_units_saved": None,
        }

    net = sum(r.expected_net_contribution or 0.0 for r in runs)
    base_net = sum(r.baseline_net_contribution or 0.0 for r in runs)
    baselines = [r.baseline_net_contribution or 0.0 for r in runs]
    # Waste is the written-off subset of unsold stock. Ambient lines return to the
    # bond and are re-used, so counting all unsold units would penalise carrying
    # slow-moving high-margin range.
    waste = sum(r.expected_waste_units or 0.0 for r in runs)
    base_waste = sum(r.baseline_waste_units or 0.0 for r in runs)

    uplift_pct = _headline_uplift_pct(net, base_net, baselines)
    waste_pct = ((base_waste - waste) / base_waste * 100.0) if base_waste > 0 else None

    service_vals = [r.service_level_achieved for r in runs if r.service_level_achieved is not None]
    service_pct = (sum(service_vals) / len(service_vals) * 100.0) if service_vals else None

    return {
        "expected_uplift_pct": uplift_pct,
        "waste_reduction_pct": waste_pct,
        "service_level_pct": service_pct,
        "net_contribution_gbp": net,
        "baseline_net_contribution_gbp": base_net,
        "net_uplift_gbp": net - base_net,
        "waste_units_saved": base_waste - waste,
    }


@router.get("/summary", response_model=dict)
def summary(session: Session = Depends(get_session)) -> dict:
    total_skus = session.scalar(select(func.count(Sku.id))) or 0
    total_routes = session.scalar(select(func.count(Route.id))) or 0
    total_flights = session.scalar(select(func.count(Flight.id))) or 0
    total_sales = session.scalar(select(func.count(Sale.id))) or 0

    routes = session.scalars(select(Route)).all()
    route_payload = []
    for r in routes:
        origin = AIRPORT_COORDS.get(r.origin_iata)
        dest = AIRPORT_COORDS.get(r.dest_iata)
        if not origin or not dest:
            continue
        route_payload.append(
            {
                "id": r.id,
                "origin_iata": r.origin_iata,
                "dest_iata": r.dest_iata,
                "origin": {"lat": origin[0], "lon": origin[1]},
                "dest": {"lat": dest[0], "lon": dest[1]},
                "distance_km": r.distance_km,
                "haul_class": r.haul_class,
            }
        )

    runs, basis = _kpi_runs(session)

    return {
        "total_skus": total_skus,
        "total_routes": total_routes,
        "total_flights": total_flights,
        "total_sales_rows": total_sales,
        "routes": route_payload,
        "kpi_basis": basis,
        "runs_counted": len(runs),
        **_headline_kpis(runs),
    }


@router.get("/activity", response_model=dict)
def activity(
    limit: int = Query(8, ge=1, le=50),
    session: Session = Depends(get_session),
) -> dict:
    """Recent planning activity and what still needs attention."""
    rows = session.execute(
        select(OptimisationRun, Flight, Route)
        .join(Flight, Flight.id == OptimisationRun.flight_id)
        .join(Route, Route.id == Flight.route_id)
        .order_by(OptimisationRun.id.desc())
        .limit(limit)
    ).all()

    recent = []
    for run, flight, route in rows:
        net = run.expected_net_contribution
        base = run.baseline_net_contribution
        has_both = net is not None and base is not None
        recent.append(
            {
                "run_id": run.id,
                "flight_id": flight.id,
                "flight_no": flight.flight_no,
                "route": f"{route.origin_iata}–{route.dest_iata}",
                "scheduled_dt": flight.scheduled_dt.isoformat(),
                "status": run.status,
                "approval_status": run.approval_status,
                "run_kind": run.run_kind,
                "scenario_label": run.scenario_label,
                "total_skus": run.total_skus,
                "total_units": run.total_units,
                "net_contribution_gbp": net,
                "baseline_net_contribution_gbp": base,
                "net_uplift_gbp": (net - base) if has_both else None,
                "uplift_pct": _uplift_pct(net, base) if has_both else None,
                "created_at": run.created_at.isoformat(),
            }
        )

    pending_approval = session.scalar(
        select(func.count(OptimisationRun.id)).where(
            OptimisationRun.status == "done",
            OptimisationRun.approval_status != "approved",
        )
    ) or 0
    approved_plans = session.scalar(
        select(func.count(OptimisationRun.id)).where(
            OptimisationRun.approval_status == "approved"
        )
    ) or 0
    failed_runs = session.scalar(
        select(func.count(OptimisationRun.id)).where(OptimisationRun.status == "failed")
    ) or 0
    flights_planned = session.scalar(
        select(func.count(func.distinct(OptimisationRun.flight_id)))
    ) or 0

    return {
        "recent_runs": recent,
        "pending_approval": pending_approval,
        "approved_plans": approved_plans,
        "failed_runs": failed_runs,
        "flights_planned": flights_planned,
    }
