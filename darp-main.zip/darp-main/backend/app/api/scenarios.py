"""Scenarios API.

A *Scenario* is a parameter overlay that re-runs the optimiser on a flight
with deltas applied to the latest CostParams + selection params. It enables
side-by-side what-ifs (e.g. fuel +30 %, service level p0.9, lighter weight
budget).

Endpoints
---------
- POST   /api/scenarios               create scenario
- GET    /api/scenarios               list
- GET    /api/scenarios/{id}          detail
- DELETE /api/scenarios/{id}
- POST   /api/scenarios/{id}/runs     execute against a flight, returns OptimisationRun id
"""

from __future__ import annotations

import threading
from datetime import datetime
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import SessionLocal, get_session
from ..models import CostParams, Flight, OptimisationRun, Scenario
from ..optim import forecast_service
from ..optim.engine import EngineProgressEvent, run_optimisation
from ..optim.selection import SelectionParams

router = APIRouter()


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class ScenarioParams(BaseModel):
    """Overlay applied on top of base params at run time.

    Everything here is a cost or capacity lever, so it changes what the plan
    *does* with a forecast, never the forecast itself. That is what lets a
    scenario reuse its base run's demand figures and stay a like-for-like
    comparison.
    """

    fuel_price_multiplier: float = Field(default=1.0, ge=0.0, description="Multiplier on fuel_price_per_kg_gbp.")
    load_factor_override: Optional[float] = Field(
        default=None, ge=0.0, le=1.2,
        description="Not supported: changing passengers would require re-forecasting demand.",
    )
    service_level_p: Optional[float] = Field(default=None, ge=0.5, le=0.99)
    volume_efficiency_eta: Optional[float] = Field(default=None, ge=0.3, le=0.95)
    retail_weight_budget_kg: Optional[float] = Field(default=None, ge=10.0, le=2000.0)
    complexity_penalty_scale: Optional[float] = Field(default=None, ge=0.0, le=5.0)


class ScenarioCreate(BaseModel):
    name: str
    description: Optional[str] = None
    params: ScenarioParams


class ScenarioOut(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    params: dict[str, Any]
    created_at: datetime

    @classmethod
    def from_model(cls, s: Scenario) -> "ScenarioOut":
        return cls(
            id=s.id,
            name=s.name,
            description=s.description,
            params=s.parameters_json or {},
            created_at=s.created_at,
        )


class ScenarioRunRequest(BaseModel):
    flight_id: int
    base_run_id: Optional[int] = Field(
        default=None,
        description="If provided, the comparison UI will use this as the baseline.",
    )


class ScenarioRunResponse(BaseModel):
    run_id: int
    scenario_id: int
    base_run_id: Optional[int]


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------


@router.post("", response_model=ScenarioOut, status_code=201)
def create_scenario(body: ScenarioCreate, session: Session = Depends(get_session)) -> ScenarioOut:
    if body.params.load_factor_override is not None:
        # It was accepted and then ignored, which quietly produced a "what-if"
        # that answered a different question than the one asked.
        raise HTTPException(422, detail={
            "reason": "load_factor_override_unsupported",
            "message": (
                "Changing the load factor changes demand, so the scenario would "
                "need a re-forecast rather than a cost overlay. Not supported yet."
            ),
        })

    s = Scenario(
        name=body.name,
        description=body.description,
        parameters_json=body.params.model_dump(exclude_none=True),
    )
    session.add(s)
    session.commit()
    session.refresh(s)
    return ScenarioOut.from_model(s)


@router.get("", response_model=list[ScenarioOut])
def list_scenarios(session: Session = Depends(get_session)) -> list[ScenarioOut]:
    rows = session.scalars(select(Scenario).order_by(Scenario.created_at.desc())).all()
    return [ScenarioOut.from_model(r) for r in rows]


@router.get("/{sid}", response_model=ScenarioOut)
def get_scenario(sid: int, session: Session = Depends(get_session)) -> ScenarioOut:
    s = session.get(Scenario, sid)
    if s is None:
        raise HTTPException(404, "scenario not found")
    return ScenarioOut.from_model(s)


@router.delete("/{sid}", status_code=204)
def delete_scenario(sid: int, session: Session = Depends(get_session)) -> None:
    s = session.get(Scenario, sid)
    if s is None:
        raise HTTPException(404, "scenario not found")
    session.delete(s)
    session.commit()


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------


def _apply_scenario(scenario: Scenario, sel_params: SelectionParams, fuel_mult: float | None = None) -> tuple[SelectionParams, float]:
    """Return (params, fuel_price_multiplier) after applying scenario overlay."""
    p = scenario.parameters_json or {}
    if "service_level_p" in p:
        sel_params.service_level_p = float(p["service_level_p"])
    if "volume_efficiency_eta" in p:
        sel_params.volume_efficiency_eta = float(p["volume_efficiency_eta"])
    if "retail_weight_budget_kg" in p:
        sel_params.retail_weight_budget_kg = float(p["retail_weight_budget_kg"])
    if "complexity_penalty_scale" in p:
        sel_params.complexity_penalty_scale = float(p["complexity_penalty_scale"])
    return sel_params, float(p.get("fuel_price_multiplier", 1.0))


@router.post("/{sid}/runs", response_model=ScenarioRunResponse)
def run_scenario(sid: int, body: ScenarioRunRequest, session: Session = Depends(get_session)) -> ScenarioRunResponse:
    scenario = session.get(Scenario, sid)
    if scenario is None:
        raise HTTPException(404, "scenario not found")
    flight = session.get(Flight, body.flight_id)
    if flight is None:
        raise HTTPException(404, "flight not found")

    # Build run shell synchronously so we can return its id.
    p = scenario.parameters_json or {}
    sel_params = SelectionParams()
    sel_params, fuel_mult = _apply_scenario(scenario, sel_params)

    label = f"scenario:{scenario.id}:{scenario.name}"
    if body.base_run_id is not None:
        label += f"|base:{body.base_run_id}"

    # A scenario only moves cost and capacity levers, so reuse the base run's
    # demand figures. Comparing against a plan built on a *different* forecast
    # would credit the scenario with changes it did not cause.
    inherited_snapshot = None
    forecast_context = None
    if body.base_run_id is not None:
        base = session.get(OptimisationRun, body.base_run_id)
        if base is None:
            raise HTTPException(404, "base run not found")
        if base.flight_id != body.flight_id:
            raise HTTPException(409, detail={
                "reason": "base_run_is_for_another_flight",
                "message": f"run {base.id} plans flight {base.flight_id}, not {body.flight_id}",
            })
        base_params = base.parameters_json or {}
        inherited_snapshot = base_params.get("forecast_snapshot") or None
        payload = base_params.get("forecasting")
        if payload:
            forecast_context = forecast_service.ForecastContext.from_dict(payload)

    if forecast_context is None:
        forecast_context = forecast_service.resolve_context(
            session,
            target_departure=flight.scheduled_dt,
            exclude_flight_ids=[flight.id],
        )

    params_json = {
        "flight_id": body.flight_id,
        "scenario_id": scenario.id,
        "scenario_name": scenario.name,
        "base_run_id": body.base_run_id,
        "fuel_price_multiplier": fuel_mult,
        "service_level_p": sel_params.service_level_p,
        "volume_efficiency_eta": sel_params.volume_efficiency_eta,
        "retail_weight_budget_kg": sel_params.retail_weight_budget_kg,
        "complexity_penalty_scale": sel_params.complexity_penalty_scale,
        "forecasting": forecast_context.to_dict(),
        "forecast_inherited": bool(inherited_snapshot),
    }
    # Capture the effective fuel price so the run-detail API can compute fuel_kg
    # / CO₂ correctly even after we restore the CostParams row.
    cp_now = session.execute(select(CostParams).order_by(CostParams.valid_from.desc())).scalars().first()
    if cp_now is not None:
        params_json["fuel_price_per_kg_gbp_used"] = float(cp_now.fuel_price_per_kg_gbp) * fuel_mult
    run = OptimisationRun(
        flight_id=body.flight_id,
        status="pending",
        parameters_json=params_json,
        scenario_label=label,
    )
    session.add(run)
    session.commit()
    session.refresh(run)
    run_id = run.id

    # The scenario's fuel price is a private input to this run, passed straight
    # to the engine. It is never written to the shared CostParams row.

    def _worker() -> None:
        from .runs import _push_event, _queue_for  # late import to avoid cycle

        _queue_for(run_id)
        s = SessionLocal()
        try:
            try:
                run_optimisation(
                    s,
                    body.flight_id,
                    params=sel_params,
                    on_progress=lambda ev: _push_event(run_id, ev),
                    run_id=run_id,
                    forecast_context=forecast_context,
                    forecast_snapshot=inherited_snapshot,
                    fuel_price_multiplier=fuel_mult,
                )
                try:
                    from ..ai.rationale import generate_rationales
                    generate_rationales(s, run_id, top_k=12)
                except Exception:  # noqa: BLE001
                    pass
                _push_event(run_id, EngineProgressEvent("done", "Run complete", 100, 0.0, extra={"run_id": run_id}))
            except Exception as exc:  # noqa: BLE001
                try:
                    r = s.get(OptimisationRun, run_id)
                    if r is not None:
                        r.status = "failed"
                        s.commit()
                except Exception:  # noqa: BLE001
                    pass
                _push_event(run_id, EngineProgressEvent("failed", f"{type(exc).__name__}: {exc}", 100, 0.0))
        finally:
            s.close()

    threading.Thread(target=_worker, name=f"scenario-run-{run_id}", daemon=True).start()
    return ScenarioRunResponse(run_id=run_id, scenario_id=scenario.id, base_run_id=body.base_run_id)
