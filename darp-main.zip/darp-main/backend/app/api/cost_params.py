"""Cost parameters endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import CostParams
from ..schemas import CostParamsOut

router = APIRouter()


class CostParamsPatch(BaseModel):
    fuel_price_per_kg_gbp: float | None = None
    pick_cost_per_unit_gbp: float | None = None
    pack_cost_per_drawer_gbp: float | None = None
    cart_assembly_cost_gbp: float | None = None
    return_handling_cost_per_unit_gbp: float | None = None
    complexity_penalty_per_new_pickline_gbp: float | None = None
    bonded_access_surcharge_gbp: float | None = None
    authorised_pick_surcharge_per_unit_gbp: float | None = None
    pickline_min_expected_margin_gbp: float | None = None
    case_break_penalty_gbp: float | None = None
    spoilage_reuse_cycle_days: float | None = None


@router.get("", response_model=list[CostParamsOut])
def list_cost_params(session: Session = Depends(get_session)) -> list[CostParamsOut]:
    rows = session.scalars(select(CostParams).order_by(CostParams.valid_from.desc())).all()
    return [CostParamsOut.model_validate(r) for r in rows]


@router.patch("/{cp_id}", response_model=CostParamsOut)
def patch_cost_params(cp_id: int, patch: CostParamsPatch, session: Session = Depends(get_session)) -> CostParamsOut:
    cp = session.get(CostParams, cp_id)
    if not cp:
        raise HTTPException(404, "CostParams not found")
    for field, value in patch.model_dump(exclude_unset=True).items():
        setattr(cp, field, value)
    session.commit()
    session.refresh(cp)
    return CostParamsOut.model_validate(cp)
