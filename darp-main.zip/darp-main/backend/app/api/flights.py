"""Flight endpoints."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from ..db import get_session
from ..models import (
    Aircraft,
    Cart,
    GalleyLayout,
    Flight,
    OptimisationRun,
    RangeDecision,
    Sku,
)
from ..optim.packing import pack_units
from ..schemas import FlightOut

router = APIRouter()


@router.get("", response_model=dict)
def list_flights(
    session: Session = Depends(get_session),
    route_id: Optional[int] = None,
    limit: int = Query(200, le=1000),
    offset: int = 0,
) -> dict:
    stmt = select(Flight)
    if route_id:
        stmt = stmt.where(Flight.route_id == route_id)
    total = session.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = session.scalars(
        stmt.order_by(Flight.scheduled_dt.desc()).offset(offset).limit(limit)
    ).all()
    return {"total": total, "items": [FlightOut.model_validate(r).model_dump(mode="json") for r in rows]}


@router.get("/{flight_id}", response_model=FlightOut)
def get_flight(flight_id: int, session: Session = Depends(get_session)) -> FlightOut:
    flight = session.get(Flight, flight_id)
    if not flight:
        raise HTTPException(404, "Flight not found")
    return FlightOut.model_validate(flight)


class AircraftSwap(BaseModel):
    aircraft_id: int


class SwapResult(BaseModel):
    flight: FlightOut
    revalidation: dict[str, Any]


def _revalidate_plan(session: Session, flight: Flight, aircraft: Aircraft) -> dict[str, Any]:
    """Re-pack the approved/latest plan against a (possibly new) aircraft's galley."""
    # Prefer the approved run; fall back to the latest done run for this flight.
    run = session.execute(
        select(OptimisationRun)
        .where(OptimisationRun.flight_id == flight.id, OptimisationRun.approval_status == "approved")
        .order_by(OptimisationRun.id.desc())
    ).scalars().first()
    if run is None:
        run = session.execute(
            select(OptimisationRun)
            .where(OptimisationRun.flight_id == flight.id, OptimisationRun.status == "done")
            .order_by(OptimisationRun.id.desc())
        ).scalars().first()
    if run is None and flight.rotation_id is not None:
        run = session.execute(
            select(OptimisationRun)
            .where(OptimisationRun.rotation_id == flight.rotation_id, OptimisationRun.status == "done")
            .order_by(OptimisationRun.id.desc())
        ).scalars().first()
    if run is None:
        return {"verdict": "no_plan", "run_id": None}

    galley = session.execute(
        select(GalleyLayout)
        .where(GalleyLayout.id == aircraft.retail_galley_layout_id)
        .options(selectinload(GalleyLayout.carts).selectinload(Cart.drawers))
    ).scalar_one()
    drawers = [d for c in galley.carts for d in c.drawers]

    decisions = session.execute(
        select(RangeDecision).where(
            RangeDecision.optimisation_run_id == run.id, RangeDecision.loaded_qty > 0
        )
    ).scalars().all()
    sku_ids = [d.sku_id for d in decisions]
    sku_map = {s.id: s for s in session.execute(select(Sku).where(Sku.id.in_(sku_ids))).scalars()} if sku_ids else {}

    units = []
    weight_kg = 0.0
    volume_cm3 = 0.0
    for d in decisions:
        sku = sku_map.get(d.sku_id)
        if sku is None:
            continue
        weight_kg += (sku.unit_weight_g / 1000.0) * d.loaded_qty
        volume_cm3 += sku.volume_cm3 * d.loaded_qty
        for _ in range(d.loaded_qty):
            units.append((sku, float(d.expected_sales)))

    pack = pack_units(drawers, units)
    unplaced_by_sku = pack.unplaced_sku_ids
    unplaced_units = sum(unplaced_by_sku.values())

    params = run.parameters_json or {}
    eta = float(params.get("volume_efficiency_eta", 0.65))
    weight_budget = float(params.get("retail_weight_budget_kg", 280.0))
    weight_cap = min(weight_budget, aircraft.max_payload_kg * 0.4)
    volume_cap = sum(
        d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in drawers
    ) * eta

    weight_ok = weight_kg <= weight_cap
    volume_ok = volume_cm3 <= volume_cap
    verdict = "still_valid" if (unplaced_units == 0 and weight_ok and volume_ok) else "capacity_violated"

    details = [
        {"sku_id": sid, "sku_code": sku_map[sid].code if sid in sku_map else str(sid),
         "sku_name": sku_map[sid].name if sid in sku_map else str(sid), "unplaced": cnt}
        for sid, cnt in sorted(unplaced_by_sku.items(), key=lambda kv: -kv[1])
    ]

    result = {
        "verdict": verdict,
        "run_id": run.id,
        "aircraft_id": aircraft.id,
        "aircraft_registration": aircraft.registration,
        "aircraft_type": aircraft.type,
        "unplaced_units": unplaced_units,
        "weight_kg": round(weight_kg, 1),
        "weight_cap_kg": round(weight_cap, 1),
        "weight_ok": weight_ok,
        "volume_used_cm3": round(volume_cm3, 1),
        "volume_cap_cm3": round(volume_cap, 1),
        "volume_ok": volume_ok,
        "drawers": len(drawers),
        "details": details[:20],
    }
    run.revalidation_json = result
    session.commit()
    return result


@router.patch("/{flight_id}/aircraft", response_model=SwapResult)
def swap_aircraft(flight_id: int, body: AircraftSwap, session: Session = Depends(get_session)) -> SwapResult:
    flight = session.get(Flight, flight_id)
    if not flight:
        raise HTTPException(404, "Flight not found")
    aircraft = session.get(Aircraft, body.aircraft_id)
    if not aircraft:
        raise HTTPException(404, "Aircraft not found")

    flight.aircraft_id = aircraft.id
    session.commit()
    session.refresh(flight)

    revalidation = _revalidate_plan(session, flight, aircraft)
    return SwapResult(flight=FlightOut.model_validate(flight), revalidation=revalidation)
