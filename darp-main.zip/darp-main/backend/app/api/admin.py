"""Admin endpoints — reset seed."""

from __future__ import annotations

from fastapi import APIRouter

router = APIRouter()


@router.post("/reset", response_model=dict)
def reset_seed() -> dict:
    # Import lazily so the seed module's heavy deps don't load at app boot.
    from ..seed.run import run_seed

    stats = run_seed(reset=True)
    return {"status": "ok", "stats": stats}
