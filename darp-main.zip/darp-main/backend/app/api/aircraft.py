"""Aircraft + galley endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from ..db import get_session
from ..models import Aircraft, Cart, GalleyLayout
from ..schemas import AircraftOut, GalleyLayoutOut

router = APIRouter()


@router.get("", response_model=list[AircraftOut])
def list_aircraft(session: Session = Depends(get_session)) -> list[AircraftOut]:
    rows = session.scalars(select(Aircraft).order_by(Aircraft.registration)).all()
    return [AircraftOut.model_validate(r) for r in rows]


@router.get("/galley/{layout_id}", response_model=GalleyLayoutOut)
def get_galley(layout_id: int, session: Session = Depends(get_session)) -> GalleyLayoutOut:
    layout = session.execute(
        select(GalleyLayout)
        .options(selectinload(GalleyLayout.carts).selectinload(Cart.drawers))
        .where(GalleyLayout.id == layout_id)
    ).scalar_one_or_none()
    if not layout:
        raise HTTPException(404, "Galley layout not found")
    return GalleyLayoutOut.model_validate(layout)
