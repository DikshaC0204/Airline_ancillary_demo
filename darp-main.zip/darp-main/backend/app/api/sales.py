"""Sales endpoints (read-only, aggregated)."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_session
from ..models import Flight, Sale, Sku

router = APIRouter()


@router.get("", response_model=dict)
def list_sales(
    session: Session = Depends(get_session),
    sku_id: Optional[int] = None,
    flight_id: Optional[int] = None,
    limit: int = Query(500, le=5000),
    offset: int = 0,
) -> dict:
    stmt = select(Sale)
    if sku_id:
        stmt = stmt.where(Sale.sku_id == sku_id)
    if flight_id:
        stmt = stmt.where(Sale.flight_id == flight_id)
    total = session.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = session.scalars(stmt.order_by(Sale.id.desc()).offset(offset).limit(limit)).all()
    items = [
        {
            "id": r.id,
            "flight_id": r.flight_id,
            "sku_id": r.sku_id,
            "units_sold": r.units_sold,
            "revenue": r.revenue,
            "unsold_units": r.unsold_units,
            "returned_units": r.returned_units,
        }
        for r in rows
    ]
    return {"total": total, "items": items}


@router.get("/aggregate-by-sku", response_model=list[dict])
def aggregate_by_sku(
    session: Session = Depends(get_session),
    route_id: Optional[int] = None,
    limit: int = Query(50, le=500),
) -> list[dict]:
    stmt = (
        select(
            Sku.id.label("sku_id"),
            Sku.name.label("name"),
            Sku.category.label("category"),
            func.sum(Sale.units_sold).label("units"),
            func.sum(Sale.revenue).label("revenue"),
        )
        .join(Sale, Sale.sku_id == Sku.id)
    )
    if route_id:
        stmt = stmt.join(Flight, Flight.id == Sale.flight_id).where(Flight.route_id == route_id)
    stmt = stmt.group_by(Sku.id).order_by(func.sum(Sale.revenue).desc()).limit(limit)
    rows = session.execute(stmt).all()
    return [
        {
            "sku_id": r.sku_id,
            "name": r.name,
            "category": r.category,
            "units": int(r.units or 0),
            "revenue": float(r.revenue or 0.0),
        }
        for r in rows
    ]
