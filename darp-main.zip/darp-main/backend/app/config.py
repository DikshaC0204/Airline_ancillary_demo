"""Application settings, loaded from environment + .env file."""

from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


REPO_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=REPO_ROOT / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Database
    arp_db_path: Path = REPO_ROOT / "data" / "arp.sqlite"

    # Trained forecasting artifacts. Local files beside the database; this is a
    # prototype, not a model registry.
    arp_model_dir: Path = REPO_ROOT / "data" / "models"
    # One training job at a time, and a fixed thread budget so a fit is
    # reproducible and cannot starve the API.
    arp_training_threads: int = 4

    # Determinism
    arp_seed: int = 42

    # Azure OpenAI (P4)
    azure_openai_endpoint: str = ""
    azure_openai_api_key: str = ""
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment: str = "gpt-4o"
    azure_openai_embedding_deployment: str = "text-embedding-3-small"
    arp_llm_call_ceiling: int = 5

    @property
    def database_url(self) -> str:
        self.arp_db_path.parent.mkdir(parents=True, exist_ok=True)
        return f"sqlite:///{self.arp_db_path.as_posix()}"

    @property
    def model_dir(self) -> Path:
        self.arp_model_dir.mkdir(parents=True, exist_ok=True)
        return self.arp_model_dir


settings = Settings()
