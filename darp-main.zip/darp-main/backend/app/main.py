"""FastAPI application entrypoint."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import (
    admin,
    ai,
    aircraft,
    cost_params,
    dashboard,
    flights,
    forecasting,
    regulatory,
    rotations,
    routes,
    runs,
    sales,
    scenarios,
    settings,
    skus,
)
from .db import Base, engine


def create_app() -> FastAPI:
    app = FastAPI(
        title="dnata ARP",
        version="0.1.0",
        description="Autonomous Range Planner — prototype backend",
    )

    # Frontend dev server runs on :3000; allow it during development.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Ensure tables exist (acceptable for prototype; Alembic added later if needed).
    Base.metadata.create_all(bind=engine)

    # A training job cannot outlive the process that ran it, so anything still
    # marked active belongs to a previous run of the server.
    try:
        from .db import session_scope
        from .optim.forecast_service import recover_interrupted_jobs

        with session_scope() as s:
            recover_interrupted_jobs(s)
    except Exception:  # noqa: BLE001 — never block startup on bookkeeping
        pass

    @app.get("/health", tags=["meta"])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    app.include_router(skus.router, prefix="/api/skus", tags=["skus"])
    app.include_router(routes.router, prefix="/api/routes", tags=["routes"])
    app.include_router(flights.router, prefix="/api/flights", tags=["flights"])
    app.include_router(aircraft.router, prefix="/api/aircraft", tags=["aircraft"])
    app.include_router(sales.router, prefix="/api/sales", tags=["sales"])
    app.include_router(cost_params.router, prefix="/api/cost-params", tags=["cost-params"])
    app.include_router(regulatory.router, prefix="/api/regulatory-rules", tags=["regulatory"])
    app.include_router(dashboard.router, prefix="/api/dashboard", tags=["dashboard"])
    app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
    app.include_router(runs.router, prefix="/api/runs", tags=["runs"])
    app.include_router(rotations.router, prefix="/api/rotations", tags=["rotations"])
    app.include_router(scenarios.router, prefix="/api/scenarios", tags=["scenarios"])
    app.include_router(settings.router, prefix="/api/settings", tags=["settings"])
    app.include_router(forecasting.router, prefix="/api/forecasting", tags=["forecasting"])
    app.include_router(ai.router, prefix="/api/ai", tags=["ai"])

    return app


app = create_app()
