"""SQLAlchemy ORM models for all entities in plan section 4."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


# ---------------------------------------------------------------------------
# Products & suppliers
# ---------------------------------------------------------------------------

class Supplier(Base):
    __tablename__ = "supplier"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    min_commitment_units_per_month: Mapped[int] = mapped_column(Integer, default=0)

    skus: Mapped[list["Sku"]] = relationship(back_populates="supplier")


class Sku(Base):
    __tablename__ = "sku"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    category: Mapped[str] = mapped_column(String(60), index=True, nullable=False)
    sub_category: Mapped[str] = mapped_column(String(60), nullable=False)
    brand: Mapped[str] = mapped_column(String(80), nullable=False)

    unit_weight_g: Mapped[float] = mapped_column(Float, nullable=False)
    length_mm: Mapped[float] = mapped_column(Float, nullable=False)
    width_mm: Mapped[float] = mapped_column(Float, nullable=False)
    height_mm: Mapped[float] = mapped_column(Float, nullable=False)
    volume_cm3: Mapped[float] = mapped_column(Float, nullable=False)

    packaging_type: Mapped[str] = mapped_column(String(40), nullable=False)
    stackable: Mapped[bool] = mapped_column(Boolean, default=True)
    max_stack_height: Mapped[int] = mapped_column(Integer, default=6)
    fragility_score: Mapped[int] = mapped_column(Integer, default=1)  # 1=robust, 5=fragile
    orientation_constraint: Mapped[str] = mapped_column(String(20), default="any")  # any|upright_only

    shelf_life_days: Mapped[int] = mapped_column(Integer, default=180)
    hazard_class: Mapped[str] = mapped_column(String(20), default="none")  # none|alcohol|tobacco|...

    # Warehouse pick zone — drives handling cost (plan WP1, brief §"Picking & Warehouse Zone Constraints").
    # ambient-fast | ambient-standard | chilled | bonded | secure-high-value
    warehouse_zone: Mapped[str] = mapped_column(String(30), default="ambient-standard")

    cost_price: Mapped[float] = mapped_column(Float, nullable=False)
    retail_price: Mapped[float] = mapped_column(Float, nullable=False)
    margin_pct: Mapped[float] = mapped_column(Float, nullable=False)

    supplier_id: Mapped[int] = mapped_column(ForeignKey("supplier.id"), nullable=False)
    supplier: Mapped[Supplier] = relationship(back_populates="skus")

    min_pack_size: Mapped[int] = mapped_column(Integer, default=1)
    case_size: Mapped[int] = mapped_column(Integer, default=12)

    bonded: Mapped[bool] = mapped_column(Boolean, default=False)
    requires_authorised_pick: Mapped[bool] = mapped_column(Boolean, default=False)

    image_url: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)


# ---------------------------------------------------------------------------
# Routes & flights
# ---------------------------------------------------------------------------

class Route(Base):
    __tablename__ = "route"

    id: Mapped[int] = mapped_column(primary_key=True)
    origin_iata: Mapped[str] = mapped_column(String(3), nullable=False)
    dest_iata: Mapped[str] = mapped_column(String(3), nullable=False)
    distance_km: Mapped[float] = mapped_column(Float, nullable=False)
    flight_duration_min: Mapped[int] = mapped_column(Integer, nullable=False)
    haul_class: Mapped[str] = mapped_column(String(20), nullable=False)  # short|medium|long

    duty_free_allowed: Mapped[bool] = mapped_column(Boolean, default=True)
    alcohol_allowed: Mapped[bool] = mapped_column(Boolean, default=True)
    tobacco_allowed: Mapped[bool] = mapped_column(Boolean, default=False)

    seasonality_profile_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    flights: Mapped[list["Flight"]] = relationship(back_populates="route")

    __table_args__ = (UniqueConstraint("origin_iata", "dest_iata", name="uq_route_pair"),)


class Rotation(Base):
    """An ordered sequence of flights that share one loaded retail range.

    Multi-leg flying: a range is loaded once at the rotation origin and carried
    across every leg; unsold stock compounds fuel cost on each onward leg
    (brief §"Unsold Inventory" / "Weight-Based Ranging Decisions").
    """

    __tablename__ = "rotation"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(60), unique=True, nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    flights: Mapped[list["Flight"]] = relationship(back_populates="rotation")


class Flight(Base):
    __tablename__ = "flight"

    id: Mapped[int] = mapped_column(primary_key=True)
    route_id: Mapped[int] = mapped_column(ForeignKey("route.id"), nullable=False, index=True)
    flight_no: Mapped[str] = mapped_column(String(10), nullable=False)
    scheduled_dt: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)

    aircraft_id: Mapped[int] = mapped_column(ForeignKey("aircraft.id"), nullable=False)
    expected_pax: Mapped[int] = mapped_column(Integer, nullable=False)
    expected_load_factor: Mapped[float] = mapped_column(Float, nullable=False)
    pax_mix_json: Mapped[dict[str, float]] = mapped_column(JSON, default=dict)
    cabin_config_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)

    # Rotation membership (nullable — most flights are standalone single legs).
    rotation_id: Mapped[Optional[int]] = mapped_column(ForeignKey("rotation.id"), nullable=True, index=True)
    leg_index: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # 1-based position in rotation

    route: Mapped[Route] = relationship(back_populates="flights")
    aircraft: Mapped["Aircraft"] = relationship(back_populates="flights")
    rotation: Mapped[Optional["Rotation"]] = relationship(back_populates="flights")


# ---------------------------------------------------------------------------
# Aircraft & galley
# ---------------------------------------------------------------------------

class GalleyLayout(Base):
    __tablename__ = "galley_layout"

    id: Mapped[int] = mapped_column(primary_key=True)
    aircraft_type: Mapped[str] = mapped_column(String(20), nullable=False)
    schematic_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    num_retail_carts: Mapped[int] = mapped_column(Integer, default=1)

    carts: Mapped[list["Cart"]] = relationship(back_populates="galley_layout", cascade="all, delete-orphan")


class Aircraft(Base):
    __tablename__ = "aircraft"

    id: Mapped[int] = mapped_column(primary_key=True)
    registration: Mapped[str] = mapped_column(String(12), unique=True, nullable=False)
    type: Mapped[str] = mapped_column(String(20), nullable=False)  # A320|A320neo
    retail_galley_layout_id: Mapped[int] = mapped_column(ForeignKey("galley_layout.id"), nullable=False)
    empty_weight_kg: Mapped[float] = mapped_column(Float, nullable=False)
    max_payload_kg: Mapped[float] = mapped_column(Float, nullable=False)
    fuel_burn_coeff_short: Mapped[float] = mapped_column(Float, nullable=False)
    fuel_burn_coeff_medium: Mapped[float] = mapped_column(Float, nullable=False)
    fuel_burn_coeff_long: Mapped[float] = mapped_column(Float, nullable=False)

    galley_layout: Mapped[GalleyLayout] = relationship()
    flights: Mapped[list[Flight]] = relationship(back_populates="aircraft")


class Cart(Base):
    __tablename__ = "cart"

    id: Mapped[int] = mapped_column(primary_key=True)
    galley_layout_id: Mapped[int] = mapped_column(ForeignKey("galley_layout.id"), nullable=False)
    position_code: Mapped[str] = mapped_column(String(20), nullable=False)
    cart_type: Mapped[str] = mapped_column(String(10), nullable=False)  # full|half

    galley_layout: Mapped[GalleyLayout] = relationship(back_populates="carts")
    drawers: Mapped[list["Drawer"]] = relationship(back_populates="cart", cascade="all, delete-orphan")


class Drawer(Base):
    __tablename__ = "drawer"

    id: Mapped[int] = mapped_column(primary_key=True)
    cart_id: Mapped[int] = mapped_column(ForeignKey("cart.id"), nullable=False)
    slot_index: Mapped[int] = mapped_column(Integer, nullable=False)
    type: Mapped[str] = mapped_column(String(20), nullable=False)  # ATLAS_full|ATLAS_half|box

    internal_l_mm: Mapped[float] = mapped_column(Float, nullable=False)
    internal_w_mm: Mapped[float] = mapped_column(Float, nullable=False)
    internal_h_mm: Mapped[float] = mapped_column(Float, nullable=False)
    max_weight_kg: Mapped[float] = mapped_column(Float, nullable=False)
    accessibility_score: Mapped[int] = mapped_column(Integer, default=3)  # 1=best, 5=worst

    cart: Mapped[Cart] = relationship(back_populates="drawers")


# ---------------------------------------------------------------------------
# Sales (synthetic history)
# ---------------------------------------------------------------------------

class Sale(Base):
    __tablename__ = "sale"

    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flight.id"), nullable=False, index=True)
    sku_id: Mapped[int] = mapped_column(ForeignKey("sku.id"), nullable=False, index=True)
    units_sold: Mapped[int] = mapped_column(Integer, nullable=False)
    revenue: Mapped[float] = mapped_column(Float, nullable=False)
    unsold_units: Mapped[int] = mapped_column(Integer, default=0)
    returned_units: Mapped[int] = mapped_column(Integer, default=0)
    sold_at_minute_of_flight: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)


# ---------------------------------------------------------------------------
# Cost, rules, commitments
# ---------------------------------------------------------------------------

class CostParams(Base):
    __tablename__ = "cost_params"

    id: Mapped[int] = mapped_column(primary_key=True)
    valid_from: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    fuel_price_per_kg_gbp: Mapped[float] = mapped_column(Float, default=0.82)
    pick_cost_per_unit_gbp: Mapped[float] = mapped_column(Float, default=0.08)
    pack_cost_per_drawer_gbp: Mapped[float] = mapped_column(Float, default=1.20)
    cart_assembly_cost_gbp: Mapped[float] = mapped_column(Float, default=4.50)
    return_handling_cost_per_unit_gbp: Mapped[float] = mapped_column(Float, default=0.15)
    complexity_penalty_per_new_pickline_gbp: Mapped[float] = mapped_column(Float, default=2.00)

    # Warehouse handling / cost-to-serve refinements (brief §"Warehouse Pick-and-Pack Cost").
    # Multiplier applied to pick_cost_per_unit by warehouse zone.
    pick_zone_multipliers_json: Mapped[dict[str, float]] = mapped_column(JSON, default=dict)
    bonded_access_surcharge_gbp: Mapped[float] = mapped_column(Float, default=1.50)  # per bonded pickline opened
    authorised_pick_surcharge_per_unit_gbp: Mapped[float] = mapped_column(Float, default=0.12)
    # Don't open a pickline whose expected margin is below this (brief §"Minimum Efficient Load Rules").
    pickline_min_expected_margin_gbp: Mapped[float] = mapped_column(Float, default=6.00)
    # Penalty for breaking a supplier case (brief §"Prefer carton/case multiples where practical").
    case_break_penalty_gbp: Mapped[float] = mapped_column(Float, default=0.40)
    # Typical days before unsold perishable stock can be re-used; drives spoilage cost.
    spoilage_reuse_cycle_days: Mapped[float] = mapped_column(Float, default=3.0)


class RegulatoryRule(Base):
    __tablename__ = "regulatory_rule"

    id: Mapped[int] = mapped_column(primary_key=True)
    route_id: Mapped[Optional[int]] = mapped_column(ForeignKey("route.id"), nullable=True)
    sku_category: Mapped[str] = mapped_column(String(60), nullable=False)
    rule_type: Mapped[str] = mapped_column(String(40), nullable=False)  # disallow|limit_qty|require_age_check
    parameters_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)


class BrandRule(Base):
    __tablename__ = "brand_rule"

    id: Mapped[int] = mapped_column(primary_key=True)
    category: Mapped[str] = mapped_column(String(60), nullable=False)
    min_skus: Mapped[int] = mapped_column(Integer, default=0)
    min_units: Mapped[int] = mapped_column(Integer, default=0)
    max_share_pct: Mapped[float] = mapped_column(Float, default=1.0)


class SupplierCommitment(Base):
    __tablename__ = "supplier_commitment"

    id: Mapped[int] = mapped_column(primary_key=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("supplier.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("sku.id"), nullable=False)
    min_units_per_flight: Mapped[int] = mapped_column(Integer, default=0)


# ---------------------------------------------------------------------------
# Optimisation outputs (populated in P1+)
# ---------------------------------------------------------------------------

class OptimisationRun(Base):
    __tablename__ = "optimisation_run"

    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[int] = mapped_column(ForeignKey("flight.id"), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|forecasting|optimising|packing|done|failed

    objective_value: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    total_weight_kg: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    total_volume_cm3: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    total_skus: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    total_units: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    expected_revenue: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    expected_net_contribution: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    # Manual-plan counterfactual, costed with the same model — see optim/baseline.py.
    baseline_expected_revenue: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    baseline_net_contribution: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    baseline_unsold_units: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    baseline_waste_units: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    baseline_total_units: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    # Units loaded but not expected to sell, from this run's own decisions.
    expected_unsold_units: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    # The written-off subset of the above; ambient stock returns to the bond.
    expected_waste_units: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    # Share of forecast demand the plan expects to satisfy (0..1).
    service_level_achieved: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    parameters_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    scenario_label: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)

    # Provenance & lineage.
    run_kind: Mapped[str] = mapped_column(String(20), default="autonomous")  # autonomous|scenario|override
    parent_run_id: Mapped[Optional[int]] = mapped_column(ForeignKey("optimisation_run.id"), nullable=True)
    rotation_id: Mapped[Optional[int]] = mapped_column(ForeignKey("rotation.id"), nullable=True, index=True)

    # Post-solve analysis (WP3).
    constraint_report_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    rotation_report_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    revalidation_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)

    # Lightweight approval workflow (WP5).
    approval_status: Mapped[str] = mapped_column(String(12), default="draft")  # draft|approved
    approved_by: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    approved_note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class RangeDecision(Base):
    __tablename__ = "range_decision"

    id: Mapped[int] = mapped_column(primary_key=True)
    optimisation_run_id: Mapped[int] = mapped_column(ForeignKey("optimisation_run.id"), nullable=False, index=True)
    sku_id: Mapped[int] = mapped_column(ForeignKey("sku.id"), nullable=False)

    decision: Mapped[str] = mapped_column(String(20), nullable=False)  # load|increase|reduce|exclude
    loaded_qty: Mapped[int] = mapped_column(Integer, default=0)
    expected_sales: Mapped[float] = mapped_column(Float, default=0.0)
    expected_margin: Mapped[float] = mapped_column(Float, default=0.0)

    fuel_cost: Mapped[float] = mapped_column(Float, default=0.0)
    pick_pack_cost: Mapped[float] = mapped_column(Float, default=0.0)
    complexity_cost: Mapped[float] = mapped_column(Float, default=0.0)
    handling_cost: Mapped[float] = mapped_column(Float, default=0.0)  # zone-multiplied pick + auth + bonded
    spoilage_cost: Mapped[float] = mapped_column(Float, default=0.0)
    net_contribution: Mapped[float] = mapped_column(Float, default=0.0)

    # Contribution density — the brief's recommended commercial metric.
    net_per_kg: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    net_per_cm3: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    # Deterministic explainability (WP3).
    reason_code: Mapped[Optional[str]] = mapped_column(String(40), nullable=True)
    reason_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    reason_detail_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    substitute_sku_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sku.id"), nullable=True)
    leg_sales_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)  # {"1": 11.0, ...}
    is_overridden: Mapped[bool] = mapped_column(Boolean, default=False)

    rationale_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)


class DrawerAssignment(Base):
    __tablename__ = "drawer_assignment"

    id: Mapped[int] = mapped_column(primary_key=True)
    optimisation_run_id: Mapped[int] = mapped_column(ForeignKey("optimisation_run.id"), nullable=False, index=True)
    drawer_id: Mapped[int] = mapped_column(ForeignKey("drawer.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("sku.id"), nullable=False)
    units: Mapped[int] = mapped_column(Integer, nullable=False)
    position_xyz_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)


class Scenario(Base):
    __tablename__ = "scenario"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    parameters_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class CrewFeedback(Base):
    __tablename__ = "crew_feedback"

    id: Mapped[int] = mapped_column(primary_key=True)
    flight_id: Mapped[Optional[int]] = mapped_column(ForeignKey("flight.id"), nullable=True)
    sku_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sku.id"), nullable=True)
    free_text: Mapped[str] = mapped_column(Text, nullable=False)
    structured_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class RunOverride(Base):
    """A planner's pin on a single SKU for an override run (WP4)."""

    __tablename__ = "run_override"

    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("optimisation_run.id"), nullable=False, index=True)
    source_run_id: Mapped[int] = mapped_column(ForeignKey("optimisation_run.id"), nullable=False)
    sku_id: Mapped[int] = mapped_column(ForeignKey("sku.id"), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False)  # force_include|force_exclude|set_qty
    qty: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    original_decision: Mapped[str] = mapped_column(String(20), default="exclude")
    original_qty: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


# ---------------------------------------------------------------------------
# Forecasting configuration (WP6)
# ---------------------------------------------------------------------------

class ApplicationSettings(Base):
    """Single-row operator settings. Defaults to the method that needs no model."""

    __tablename__ = "application_settings"

    id: Mapped[int] = mapped_column(primary_key=True, default=1)
    forecast_method: Mapped[str] = mapped_column(String(20), default="empirical")  # empirical|lightgbm
    # The trained artifact to serve. Selecting one is a separate, explicit act
    # from training it, so a fresh fit never silently takes over live planning.
    active_model_id: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    revision: Mapped[int] = mapped_column(Integer, default=0)


class ForecastTrainingJob(Base):
    """One train-and-evaluate request, with durable state so a restart is visible."""

    __tablename__ = "forecast_training_job"

    id: Mapped[int] = mapped_column(primary_key=True)
    model_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    state: Mapped[str] = mapped_column(String(20), default="queued")
    # queued|training|evaluating|succeeded|failed|interrupted
    progress_pct: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)

    requested_cutoff: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # The latest data the model was allowed to see, including tuning.
    information_cutoff: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # Content hash of the history it was fitted on; a mismatch means stale.
    data_fingerprint: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)

    report_json: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    @property
    def is_terminal(self) -> bool:
        return self.state in ("succeeded", "failed", "interrupted")
