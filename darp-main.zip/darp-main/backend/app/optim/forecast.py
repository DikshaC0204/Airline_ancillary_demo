"""Empirical demand forecaster, and the contract every forecaster must meet.

For each (route × sku × season-slot × time-of-day × dow-bucket) bin this model
takes the empirical mean and variance of units-sold-per-pax and scales them to
the target flight's expected pax, shrinking toward a category prior where a bin
is thin. It is deterministic, needs no fitted artifact, and remains the default.

Two things it deliberately does *not* do, both of which decide whether a
comparison against a learned model means anything: it reads only history that
had landed by `as_of`, so a flight cannot help predict itself; and it ignores
rows where the line was never loaded, because a zero with no stock behind it is
an availability fact rather than demand. What bias remains — upward on lines
only stocked when someone expected them to sell, downward wherever a line sold
out — is measured in `optim/forecast_evaluation.py` rather than assumed away.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from typing import Iterable, Optional, Protocol, runtime_checkable

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Flight, Sku
from .forecast_data import (
    dow_bucket as _dow_bucket,
    flight_context,
    load_training_frame,
    route_key as _route_key,
    time_of_day as _time_of_day,
)


# "Use every row there is." Callers that care about leakage pass a real cutoff,
# and the engine always does.
NO_CUTOFF = datetime.max

EMPIRICAL = "empirical"
LIGHTGBM = "lightgbm"


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

@dataclass
class ForecastResult:
    sku_id: int
    expected_units: float
    p10_units: float
    p50_units: float
    p90_units: float
    history_rows: int  # how many past sales rows informed this estimate
    # Provenance. Defaults keep older call sites and stored runs readable.
    method: str = EMPIRICAL
    cold_start: bool = False  # a prior stood in for evidence

    def to_dict(self) -> dict:
        return {
            "sku_id": self.sku_id,
            "expected_units": round(self.expected_units, 6),
            "p10_units": round(self.p10_units, 6),
            "p50_units": round(self.p50_units, 6),
            "p90_units": round(self.p90_units, 6),
            "history_rows": self.history_rows,
            "method": self.method,
            "cold_start": self.cold_start,
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "ForecastResult":
        return cls(
            sku_id=int(payload["sku_id"]),
            expected_units=float(payload["expected_units"]),
            p10_units=float(payload["p10_units"]),
            p50_units=float(payload["p50_units"]),
            p90_units=float(payload["p90_units"]),
            history_rows=int(payload.get("history_rows", 0)),
            method=payload.get("method", EMPIRICAL),
            cold_start=bool(payload.get("cold_start", False)),
        )


@runtime_checkable
class ForecastProvider(Protocol):
    """What the engine needs from a forecaster, learned or not."""

    method: str

    def train(self) -> None:
        ...

    def predict_flight(
        self,
        flight: Flight,
        skus: Iterable[Sku],
        *,
        cold_start_skus: Optional[set[int]] = None,
    ) -> list[ForecastResult]:
        ...


# ---------------------------------------------------------------------------
# Forecaster
# ---------------------------------------------------------------------------

class DemandForecaster:
    """In-memory empirical forecaster trained from eligible `sale` rows."""

    method = EMPIRICAL

    # Pseudo-observations of the category prior mixed into every bin estimate.
    SHRINKAGE_K = 5.0
    # Floor on the coefficient of variation, so a line seen twice with identical
    # sales cannot claim to be certain.
    MIN_CV = 0.25
    COLD_START_CV = 0.3

    def __init__(
        self,
        session: Session,
        *,
        as_of: Optional[datetime] = None,
        exclude_flight_ids: Iterable[int] = (),
    ) -> None:
        self.session = session
        self.as_of = as_of or NO_CUTOFF
        self.exclude_flight_ids = tuple(exclude_flight_ids)
        # bin_key -> sku_id -> (sum_per_pax, sumsq_per_pax, n)
        self._bin_stats: dict[tuple, dict[int, tuple[float, float, int]]] = {}
        # category-level prior: cat -> (mean_per_pax, var_per_pax, n)
        self._cat_prior: dict[str, tuple[float, float, int]] = {}
        self._sku_category: dict[int, str] = {}
        self._trained = False
        self.audit = None

    # ----- training -----

    def train(self) -> None:
        if self._trained:
            return
        sess = self.session

        for sku_id, category in sess.execute(select(Sku.id, Sku.category)).all():
            self._sku_category[sku_id] = category

        frame = load_training_frame(
            sess, as_of=self.as_of, exclude_flight_ids=self.exclude_flight_ids
        )
        self.audit = frame.audit

        bin_acc: dict[tuple, dict[int, list[float]]] = defaultdict(
            lambda: defaultdict(lambda: [0.0, 0.0, 0])
        )
        cat_acc: dict[str, list[float]] = defaultdict(lambda: [0.0, 0.0, 0])

        for i in range(len(frame)):
            per_pax = float(frame.units_sold[i]) / float(frame.exposure[i])
            bucket = bin_acc[frame.bin_keys[i]][int(frame.sku_ids[i])]
            bucket[0] += per_pax
            bucket[1] += per_pax * per_pax
            bucket[2] += 1

            ca = cat_acc[frame.categories[i]]
            ca[0] += per_pax
            ca[1] += per_pax * per_pax
            ca[2] += 1

        for key, sku_map in bin_acc.items():
            self._bin_stats[key] = {sid: (s, sq, n) for sid, (s, sq, n) in sku_map.items()}

        for cat, (s, sq, n) in cat_acc.items():
            if n == 0:
                self._cat_prior[cat] = (0.0, 0.0, 0)
                continue
            mean = s / n
            var = max(0.0, sq / n - mean * mean)
            self._cat_prior[cat] = (mean, var, n)

        self._trained = True

    # ----- prediction -----

    def _estimate(self, bin_key: tuple, sku_id: int, category: str) -> tuple[float, float, int, bool]:
        """Shrunk (mean_per_pax, var_per_pax, rows, unseen) for one line in one bin."""
        cat_mean, cat_var, cat_n = self._cat_prior.get(category, (0.0, 0.0, 0))
        stats = self._bin_stats.get(bin_key, {}).get(sku_id)
        if stats is None:
            # Nothing for this line in this bin, so lean on the category. If the
            # category has nothing either, say zero rather than invent demand.
            return cat_mean, max(cat_var, (cat_mean * self.COLD_START_CV) ** 2), 0, cat_n == 0

        s, sq, n = stats
        emp_mean = s / n
        emp_var = max(0.0, sq / n - emp_mean * emp_mean)
        k = self.SHRINKAGE_K
        mean_per_pax = (s + k * cat_mean) / (n + k)
        return mean_per_pax, max(emp_var, (mean_per_pax * self.MIN_CV) ** 2), n, False

    def predict_rows(self, frame) -> "np.ndarray":
        """Expected units for each row of a training frame.

        Lets the evaluation harness score this model on exactly the rows the
        learned ones see, rather than through a different code path.
        """
        import numpy as np

        out = np.zeros(len(frame), dtype=np.float64)
        for i in range(len(frame)):
            mean_per_pax, _, _, _ = self._estimate(
                frame.bin_keys[i], int(frame.sku_ids[i]), frame.categories[i]
            )
            out[i] = mean_per_pax * float(frame.exposure[i])
        return out

    def predict_flight(
        self,
        flight: Flight,
        skus: Iterable[Sku],
        *,
        cold_start_skus: Optional[set[int]] = None,
    ) -> list[ForecastResult]:
        if not self._trained:
            self.train()

        ctx = flight_context(flight)
        bin_key = ctx.bin_key
        pax = max(0, ctx.expected_pax)
        cold_start_skus = cold_start_skus or set()

        results: list[ForecastResult] = []
        for sku in skus:
            if sku.id in cold_start_skus:
                cat_mean, cat_var, cat_n = self._cat_prior.get(sku.category, (0.0, 0.0, 0))
                mean_per_pax = cat_mean
                var_per_pax = max(cat_var, (cat_mean * self.COLD_START_CV) ** 2)
                history_n, cold = 0, cat_n == 0
            else:
                mean_per_pax, var_per_pax, history_n, cold = self._estimate(
                    bin_key, sku.id, sku.category
                )

            expected = mean_per_pax * pax
            # Normal approx: sd of sum ~ sqrt(pax * var_per_pax).
            sd = math.sqrt(max(0.0, var_per_pax) * pax)
            results.append(
                ForecastResult(
                    sku_id=sku.id,
                    expected_units=expected,
                    p10_units=max(0.0, expected - 1.2816 * sd),
                    p50_units=expected,
                    p90_units=expected + 1.2816 * sd,
                    history_rows=history_n,
                    method=self.method,
                    cold_start=cold,
                )
            )
        return results
