"""Engine orchestrator — wires forecast → selection → packing.

Supports single flights and multi-leg rotations, planner pin overrides, and
deterministic post-solve explainability.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime
from typing import Callable, Optional

from sqlalchemy import inspect as sa_inspect, select
from sqlalchemy.orm import Session, selectinload

from ..models import (
    Aircraft,
    BrandRule,
    Cart,
    CostParams,
    Drawer,
    DrawerAssignment,
    Flight,
    GalleyLayout,
    OptimisationRun,
    RangeDecision,
    RegulatoryRule,
    Rotation,
    Route,
    Sku,
    SupplierCommitment,
)
from . import explain
from . import forecast_service
from .baseline import compute_baseline
from .cost_to_serve import is_perishable
from .forecast import DemandForecaster, ForecastResult
from .packing import pack_units, PackingResult
from .selection import (
    LegInput,
    PinSpec,
    SelectionInputs,
    SelectionParams,
    haul_burn_coeff,
    solve_selection,
)


@dataclass
class EngineProgressEvent:
    stage: str
    message: str
    pct: int
    elapsed_s: float
    extra: Optional[dict] = None


ProgressCb = Callable[[EngineProgressEvent], None]


def _noop(_: EngineProgressEvent) -> None:
    pass


def _repriced_fuel(cost_params: CostParams, multiplier: float) -> CostParams:
    """A detached copy of the cost row at a scenario's fuel price.

    Detached on purpose: the row is shared by every run, so repricing it in place
    charged concurrent runs the wrong fuel and compounded when scenarios overlapped.
    """
    columns = sa_inspect(cost_params).mapper.column_attrs
    values = {c.key: getattr(cost_params, c.key) for c in columns}
    values["fuel_price_per_kg_gbp"] = float(values["fuel_price_per_kg_gbp"]) * multiplier
    return CostParams(**values)


def _load_flight(session: Session, flight_id: int) -> Flight:
    return session.execute(
        select(Flight)
        .where(Flight.id == flight_id)
        .options(
            selectinload(Flight.route),
            selectinload(Flight.aircraft).selectinload(Aircraft.galley_layout)
            .selectinload(GalleyLayout.carts).selectinload(Cart.drawers),
        )
    ).scalar_one()


def run_optimisation(
    session: Session,
    flight_id: Optional[int] = None,
    *,
    rotation_id: Optional[int] = None,
    params: Optional[SelectionParams] = None,
    pins: Optional[list[PinSpec]] = None,
    run_kind: str = "autonomous",
    parent_run_id: Optional[int] = None,
    on_progress: ProgressCb = _noop,
    run_id: Optional[int] = None,
    forecast_context=None,
    forecast_snapshot: Optional[dict] = None,
    fuel_price_multiplier: float = 1.0,
) -> int:
    """Run the optimisation pipeline for a flight or rotation. Returns the run id.

    `forecast_context` fixes which forecaster is used; resolve it before queuing
    so a Settings change mid-queue cannot alter a run already asked for.
    `forecast_snapshot` replays a parent run's exact forecasts, which is what
    makes an override a comparison rather than a re-forecast.
    `fuel_price_multiplier` prices this run alone — scenarios used to write their
    fuel price into the shared cost row, which leaked into concurrent runs.
    """

    t0 = time.perf_counter()
    params = params or SelectionParams()
    pins = pins or []

    # Resolve the ordered list of leg flights.
    if rotation_id is not None:
        leg_flight_rows = session.execute(
            select(Flight).where(Flight.rotation_id == rotation_id).order_by(Flight.leg_index)
        ).scalars().all()
        if not leg_flight_rows:
            raise ValueError(f"rotation {rotation_id} has no flights")
        origin_flight_id = leg_flight_rows[0].id
    else:
        if flight_id is None:
            raise ValueError("flight_id or rotation_id required")
        origin_flight_id = flight_id

    if run_id is None:
        run = OptimisationRun(
            flight_id=origin_flight_id,
            rotation_id=rotation_id,
            run_kind=run_kind,
            parent_run_id=parent_run_id,
            status="forecasting",
            parameters_json={
                "service_level_p": params.service_level_p,
                "volume_efficiency_eta": params.volume_efficiency_eta,
                "retail_weight_budget_kg": params.retail_weight_budget_kg,
                "complexity_penalty_scale": params.complexity_penalty_scale,
            },
        )
        session.add(run)
        session.commit()
        session.refresh(run)
        run_id = run.id
    else:
        run = session.get(OptimisationRun, run_id)
        if run is None:
            raise ValueError(f"run {run_id} not found")
        run.status = "forecasting"
        session.commit()

    on_progress(EngineProgressEvent("forecasting", "Loading flight context", 5, time.perf_counter() - t0))

    origin_flight = _load_flight(session, origin_flight_id)
    aircraft = origin_flight.aircraft
    galley = aircraft.galley_layout
    drawers: list[Drawer] = [d for c in galley.carts for d in c.drawers]
    origin_route: Route = origin_flight.route

    skus: list[Sku] = list(session.execute(select(Sku)).scalars())
    cost_params: CostParams = session.execute(
        select(CostParams).order_by(CostParams.valid_from.desc())
    ).scalars().first()
    if cost_params is None:
        cost_params = CostParams(valid_from=datetime.utcnow())
        session.add(cost_params)
        session.commit()
        session.refresh(cost_params)

    regulatory_rules = list(session.execute(select(RegulatoryRule)).scalars())
    brand_rules = list(session.execute(select(BrandRule)).scalars())
    supplier_commitments = list(session.execute(select(SupplierCommitment)).scalars())

    if fuel_price_multiplier != 1.0:
        cost_params = _repriced_fuel(cost_params, fuel_price_multiplier)

    on_progress(EngineProgressEvent("forecasting", "Training demand model", 20, time.perf_counter() - t0))

    leg_flights = (
        [_load_flight(session, lf.id) for lf in leg_flight_rows]
        if rotation_id is not None else [origin_flight]
    )
    leg_ids = [lf.id for lf in leg_flights]

    if forecast_context is None:
        forecast_context = forecast_service.resolve_context(
            session,
            target_departure=origin_flight.scheduled_dt,
            exclude_flight_ids=leg_ids,
        )

    fallbacks: dict = {}
    if forecast_snapshot:
        # An override re-solves the parent's plan; re-forecasting it would move
        # the goalposts and the comparison would measure the wrong thing.
        leg_forecasts = [
            {
                int(sku_id): ForecastResult.from_dict(payload)
                for sku_id, payload in (forecast_snapshot.get(str(i + 1)) or {}).items()
            }
            for i in range(len(leg_flights))
        ]
        if any(not f for f in leg_forecasts):
            raise ValueError("inherited forecast snapshot does not cover every leg")
    else:
        forecaster, forecast_context = forecast_service.build_forecaster(session, forecast_context)
        forecaster.train()
        on_progress(EngineProgressEvent(
            "forecasting", "Predicting per-leg demand", 40, time.perf_counter() - t0
        ))
        leg_forecasts = [
            {f.sku_id: f for f in forecaster.predict_flight(lf, skus)} for lf in leg_flights
        ]
        report = getattr(forecaster, "fallbacks", None)
        if report is not None and report.total:
            fallbacks = report.to_dict()

    legs: list[LegInput] = [
        LegInput(
            flight=lf,
            route=lf.route,
            burn_coeff=haul_burn_coeff(aircraft, lf.route),
            forecasts=fc,
        )
        for lf, fc in zip(leg_flights, leg_forecasts)
    ]
    origin_forecasts = legs[0].forecasts

    run.parameters_json = {
        **(run.parameters_json or {}),
        "forecasting": {
            **forecast_context.to_dict(),
            "sku_fallbacks": fallbacks,
            "inherited_snapshot": bool(forecast_snapshot),
        },
        "forecast_snapshot": {
            str(i + 1): {str(sid): fc.to_dict() for sid, fc in leg.items()}
            for i, leg in enumerate(leg_forecasts)
        },
    }
    session.commit()

    run.status = "optimising"
    session.commit()

    on_progress(EngineProgressEvent("optimising", "Solving Stage 2 MILP", 60, time.perf_counter() - t0))

    inputs = SelectionInputs(
        flight=origin_flight,
        route=origin_route,
        aircraft=aircraft,
        galley=galley,
        drawers=drawers,
        skus=skus,
        forecasts=origin_forecasts,
        cost_params=cost_params,
        regulatory_rules=regulatory_rules,
        brand_rules=brand_rules,
        supplier_commitments=supplier_commitments,
        params=params,
        legs=legs,
        pins=pins,
    )

    # Counterfactual for the uplift/waste KPIs. Evaluated through the same inputs
    # and therefore the same cost model as the plan it is compared against.
    on_progress(EngineProgressEvent("optimising", "Costing today's manual plan", 50, time.perf_counter() - t0))
    baseline = compute_baseline(inputs)

    # Stage 2 → Stage 3 infeasibility loop. Pins persist through every cycle.
    sku_map = {s.id: s for s in skus}
    eta_curr = params.volume_efficiency_eta
    pack: "PackingResult | None" = None
    result = solve_selection(inputs)
    for cycle in range(4):
        if result.status not in ("OPTIMAL", "FEASIBLE"):
            break
        units_iter = []
        for d in result.decisions:
            if d.loaded_qty <= 0:
                continue
            sku = sku_map.get(d.sku_id)
            if sku is None:
                continue
            for _ in range(d.loaded_qty):
                units_iter.append((sku, float(d.expected_sold)))
        pack = pack_units(drawers, units_iter)
        unplaced_total = sum(pack.unplaced_sku_ids.values())
        if unplaced_total == 0 or cycle == 3:
            break
        eta_curr = max(0.4, eta_curr - 0.07)
        on_progress(EngineProgressEvent(
            "packing",
            f"{unplaced_total} units didn't fit — re-solving with η={eta_curr:.2f}",
            75, time.perf_counter() - t0,
        ))
        params.volume_efficiency_eta = eta_curr
        inputs.params = params
        result = solve_selection(inputs)

    on_progress(EngineProgressEvent("optimising", f"Solver {result.status}", 85, time.perf_counter() - t0))

    if result.status not in ("OPTIMAL", "FEASIBLE"):
        run.status = "failed"
        run.parameters_json = {**(run.parameters_json or {}), "solver_status": result.status}
        session.commit()
        on_progress(EngineProgressEvent("failed", f"Solver {result.status}", 100, time.perf_counter() - t0))
        return run_id

    # A range that will not physically fit in the drawers is not a plan. Lowering
    # η is already exhausted by the loop above, so stop rather than present a
    # loadout the warehouse cannot build.
    unplaced_total = sum(pack.unplaced_sku_ids.values()) if pack is not None else 0
    if unplaced_total > 0:
        run.status = "failed"
        run.parameters_json = {
            **(run.parameters_json or {}),
            "packing_failure": {
                "unplaced_units": unplaced_total,
                "volume_efficiency_eta": eta_curr,
                "by_sku": [
                    {
                        "sku_id": sid,
                        "sku_code": sku_map[sid].code if sid in sku_map else str(sid),
                        "unplaced": count,
                    }
                    for sid, count in sorted(
                        pack.unplaced_sku_ids.items(), key=lambda kv: -kv[1]
                    )
                ],
            },
        }
        session.commit()
        message = f"{unplaced_total} units could not be packed into the galley"
        on_progress(EngineProgressEvent("failed", message, 100, time.perf_counter() - t0))
        return run_id

    # ----- explainability -----
    analysis = explain.analyse(inputs, result)
    reason_by_sku = analysis["decisions"]

    # ----- persist decisions -----
    session.execute(
        RangeDecision.__table__.delete().where(RangeDecision.optimisation_run_id == run_id)
    )
    for d in result.decisions:
        r = reason_by_sku.get(d.sku_id, {})
        session.add(
            RangeDecision(
                optimisation_run_id=run_id,
                sku_id=d.sku_id,
                decision=d.decision,
                loaded_qty=d.loaded_qty,
                expected_sales=d.expected_sold,
                expected_margin=d.expected_margin,
                fuel_cost=d.fuel_cost,
                pick_pack_cost=d.pick_pack_cost,
                handling_cost=d.handling_cost,
                spoilage_cost=d.spoilage_cost,
                complexity_cost=d.complexity_cost,
                net_contribution=d.net_contribution,
                net_per_kg=d.net_per_kg,
                net_per_cm3=d.net_per_cm3,
                reason_code=r.get("reason_code"),
                reason_text=r.get("reason_text"),
                reason_detail_json=r.get("reason_detail") or {},
                substitute_sku_id=r.get("substitute_sku_id"),
                leg_sales_json={str(k): v for k, v in (d.leg_sales or {}).items()},
                is_overridden=d.pinned,
            )
        )

    run.status = "packing"
    session.commit()
    on_progress(EngineProgressEvent("packing", "Persisting placements", 90, time.perf_counter() - t0))

    # ----- persist drawer assignments -----
    session.execute(
        DrawerAssignment.__table__.delete().where(DrawerAssignment.optimisation_run_id == run_id)
    )
    if pack is not None:
        grouped: dict[tuple[int, int], list[dict]] = {}
        for pl in pack.placements:
            grouped.setdefault((pl.drawer_id, pl.sku_id), []).append({
                "x": pl.x_mm, "y": pl.y_mm, "z": pl.z_mm,
                "l": pl.l_mm, "w": pl.w_mm, "h": pl.h_mm,
            })
        for (drawer_id, sku_id), positions in grouped.items():
            session.add(DrawerAssignment(
                optimisation_run_id=run_id,
                drawer_id=drawer_id,
                sku_id=sku_id,
                units=len(positions),
                position_xyz_json={"positions": positions},
            ))

    # ----- rotation report -----
    rotation_report = (
        _build_rotation_report(legs, result, cost_params.fuel_price_per_kg_gbp)
        if len(legs) > 1 else None
    )

    run.status = "done"
    run.objective_value = result.objective_value_gbp
    run.total_weight_kg = result.total_weight_kg
    run.total_volume_cm3 = result.total_volume_cm3
    run.total_skus = result.total_skus
    run.total_units = result.total_loaded_units
    run.expected_revenue = result.expected_revenue
    run.expected_net_contribution = result.expected_net_contribution

    loaded_units = sum(max(0, d.loaded_qty) for d in result.decisions)
    sold_units = sum(min(float(d.expected_sold), float(max(0, d.loaded_qty))) for d in result.decisions)
    run.expected_unsold_units = max(0.0, loaded_units - sold_units)
    run.expected_waste_units = sum(
        max(0.0, d.loaded_qty - d.expected_sold)
        for d in result.decisions
        if d.sku_id in sku_map and is_perishable(sku_map[d.sku_id])
    )

    # Share of forecast demand the plan expects to actually satisfy, across every
    # leg. Comparing stock against demand instead reported 100% for a line that
    # was two units deep against demand of one, because holding stock is not the
    # same as selling it, and it ignored the later legs entirely.
    demand_units = 0.0
    for leg in leg_forecasts:
        for fc in leg.values():
            demand_units += max(0.0, float(fc.expected_units))
    run.service_level_achieved = (sold_units / demand_units) if demand_units > 0 else None

    run.baseline_expected_revenue = baseline.expected_revenue
    run.baseline_net_contribution = baseline.net_contribution
    run.baseline_unsold_units = baseline.unsold_units
    run.baseline_waste_units = baseline.waste_units
    run.baseline_total_units = baseline.total_units

    run.constraint_report_json = {"constraints": analysis["constraints"]}
    run.rotation_report_json = rotation_report
    run.parameters_json = {
        **(run.parameters_json or {}),
        "fuel_price_per_kg_gbp_used": cost_params.fuel_price_per_kg_gbp,
        "volume_efficiency_eta": eta_curr,
    }
    session.commit()

    pack_extra = {}
    if pack is not None:
        pack_extra = {
            "pack_seconds": pack.pack_seconds,
            "unplaced_units": sum(pack.unplaced_sku_ids.values()),
            "drawers_used": sum(1 for s in pack.drawer_summaries if s.units_placed > 0),
        }

    on_progress(EngineProgressEvent("done", "Finished", 100, time.perf_counter() - t0, extra={
        "volume_capacity_cm3": result.volume_capacity_cm3,
        "weight_capacity_kg": result.weight_capacity_kg,
        "solve_seconds": result.solve_seconds,
        **pack_extra,
    }))

    return run_id


def _build_rotation_report(legs: list[LegInput], result, fuel_price: float) -> dict:
    """Per-leg expected sales, carried weight (declining across legs), leg fuel cost."""
    dec = {d.sku_id: d for d in result.decisions}
    out_legs = []
    for k, leg in enumerate(legs, start=1):
        carried_in_kg = 0.0
        carried_out_kg = 0.0
        sold_units = 0.0
        leg_fuel_gbp = 0.0
        for d in dec.values():
            if d.loaded_qty <= 0:
                continue
            unit_w = d.weight_kg / d.loaded_qty
            sold_before = sum(v for kk, v in (d.leg_sales or {}).items() if int(kk) < k)
            sold_this = (d.leg_sales or {}).get(k, 0.0)
            carried_in_units = d.loaded_qty - sold_before
            carried_out_units = carried_in_units - sold_this
            carried_in_kg += carried_in_units * unit_w
            carried_out_kg += carried_out_units * unit_w
            sold_units += sold_this
            leg_fuel_gbp += carried_in_units * unit_w * leg.burn_coeff * fuel_price
        out_legs.append({
            "leg_index": k,
            "flight_id": leg.flight.id,
            "flight_no": leg.flight.flight_no,
            "origin": leg.route.origin_iata,
            "dest": leg.route.dest_iata,
            "expected_pax": leg.flight.expected_pax,
            "expected_sales_units": round(sold_units, 1),
            "carried_in_kg": round(carried_in_kg, 1),
            "carried_out_kg": round(carried_out_kg, 1),
            "fuel_cost_gbp": round(leg_fuel_gbp, 2),
        })
    return {"legs": out_legs}
