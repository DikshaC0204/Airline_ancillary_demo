"""Training data for demand forecasting: time eligibility, stock exposure, features.

Two properties here decide whether *any* forecaster built on this data can be
believed, and both are easy to get wrong:

1.  **Time eligibility.** A forecast for a flight may only use sales from flights
    that had already landed when the plan was made. Aggregating the whole `sale`
    table — which is what the original forecaster did — lets a flight help
    predict itself, and makes every backtest look better than the model is.

2.  **Stock exposure.** `sale` records what was *sold*, not what was wanted. A
    line that was never loaded sells zero units on every flight, and that zero
    says nothing about demand. A line that sold its entire load tells us demand
    was *at least* that much. Treating either as an observed demand count biases
    a model down on exactly the lines a range planner has to judge.

Both forecasters (empirical and LightGBM) and the evaluation harness read their
data through this module, so they cannot silently disagree about either point.
"""

from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Iterable, Mapping, Optional, Sequence

import numpy as np
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Flight, Route, Sale, Sku
from .season import season_slot as _season_slot


# Bump when the meaning of a feature changes; a model artifact trained under an
# older schema must not be fed vectors built under a newer one.
FEATURE_SCHEMA_VERSION = 1
# Bump when the rules below for what counts as an observation change.
LABEL_POLICY_VERSION = 1

PAX_SEGMENTS: tuple[str, ...] = ("business", "leisure", "diaspora", "other")

# Observation classes. Only STOCKED and CENSORED carry demand information.
STOCKED = "stocked"      # loaded > sold: demand was fully observed
CENSORED = "censored"    # sold == loaded > 0: demand >= loaded, upper tail unseen
UNSTOCKED = "unstocked"  # loaded == 0: the line was never offered


class DatasetIntegrityError(ValueError):
    """History that cannot be interpreted as flight/SKU inventory outcomes."""


# ---------------------------------------------------------------------------
# Binning helpers — shared with the seed generator via optim.season so history
# aggregates land in the same bin as the flight being predicted.
# ---------------------------------------------------------------------------

def time_of_day(hour: int) -> str:
    if hour < 6:
        return "early"
    if hour < 12:
        return "morning"
    if hour < 18:
        return "afternoon"
    return "evening"


def dow_bucket(dow: int) -> str:  # Monday=0
    if dow in (5, 6):
        return "weekend"
    if dow == 4:
        return "friday"
    return "weekday"


def route_key(route: Route) -> str:
    return f"{route.origin_iata}-{route.dest_iata}"


# ---------------------------------------------------------------------------
# Flight context
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FlightContext:
    """Everything about a flight that is known before it departs."""

    flight_id: Optional[int]
    route_key: str
    haul_class: str
    distance_km: float
    duration_min: int
    scheduled_dt: datetime
    expected_pax: int
    load_factor: float
    pax_mix: Mapping[str, float]

    @property
    def completion_dt(self) -> datetime:
        """When this flight's sales are known.

        Scheduled departure plus the route's nominal duration. Actual arrival and
        till-close times are not in the prototype's data, so this is the closest
        available approximation of "the sales existed by then".
        """
        return self.scheduled_dt + timedelta(minutes=int(self.duration_min or 0))

    @property
    def season_slot(self) -> str:
        return _season_slot(self.scheduled_dt.month, self.route_key)

    @property
    def bin_key(self) -> tuple[str, str, str, str]:
        return (
            self.route_key,
            self.season_slot,
            time_of_day(self.scheduled_dt.hour),
            dow_bucket(self.scheduled_dt.weekday()),
        )


def flight_context(flight: Flight, route: Optional[Route] = None) -> FlightContext:
    r = route if route is not None else flight.route
    return FlightContext(
        flight_id=flight.id,
        route_key=route_key(r),
        haul_class=r.haul_class,
        distance_km=float(r.distance_km),
        duration_min=int(r.flight_duration_min),
        scheduled_dt=flight.scheduled_dt,
        expected_pax=int(flight.expected_pax or 0),
        load_factor=float(flight.expected_load_factor or 0.0),
        pax_mix=dict(flight.pax_mix_json or {}),
    )


def load_flight_contexts(session: Session) -> dict[int, FlightContext]:
    rows = session.execute(
        select(
            Flight.id,
            Flight.scheduled_dt,
            Flight.expected_pax,
            Flight.expected_load_factor,
            Flight.pax_mix_json,
            Route.origin_iata,
            Route.dest_iata,
            Route.haul_class,
            Route.distance_km,
            Route.flight_duration_min,
        ).join(Route, Route.id == Flight.route_id)
    ).all()
    out: dict[int, FlightContext] = {}
    for fid, dt, pax, lf, mix, oi, di, haul, dist, dur in rows:
        out[fid] = FlightContext(
            flight_id=fid,
            route_key=f"{oi}-{di}",
            haul_class=haul,
            distance_km=float(dist),
            duration_min=int(dur),
            scheduled_dt=dt,
            expected_pax=int(pax or 0),
            load_factor=float(lf or 0.0),
            pax_mix=dict(mix or {}),
        )
    return out


# ---------------------------------------------------------------------------
# Feature construction
# ---------------------------------------------------------------------------

# Ordered feature names. Order is part of the artifact contract: a saved model
# indexes into these positions.
CATEGORICAL_FEATURES: tuple[str, ...] = (
    "route_key",
    "haul_class",
    "season_slot",
    "time_of_day",
    "dow_bucket",
    "sku_id",
    "category",
    "sub_category",
    "brand",
)

NUMERIC_FEATURES: tuple[str, ...] = (
    "distance_km",
    "duration_min",
    "month",
    "day_of_week",
    "hour",
    "expected_pax",
    "load_factor",
) + tuple(f"pax_{seg}" for seg in PAX_SEGMENTS)

FEATURE_NAMES: tuple[str, ...] = CATEGORICAL_FEATURES + NUMERIC_FEATURES


def feature_values(ctx: FlightContext, sku: Sku) -> tuple[list[str], list[float]]:
    """Return (categorical values, numeric values) for one (flight, SKU) pair.

    Only inputs a planner holds *before* departure. Anything derived from the
    outcome — units sold, revenue, returns, the sale minute — is deliberately
    absent: a model given those would score beautifully and forecast nothing.
    """
    mix = ctx.pax_mix or {}
    cats = [
        ctx.route_key,
        ctx.haul_class,
        ctx.season_slot,
        time_of_day(ctx.scheduled_dt.hour),
        dow_bucket(ctx.scheduled_dt.weekday()),
        str(sku.id),
        sku.category,
        sku.sub_category,
        sku.brand,
    ]
    nums = [
        ctx.distance_km,
        float(ctx.duration_min),
        float(ctx.scheduled_dt.month),
        float(ctx.scheduled_dt.weekday()),
        float(ctx.scheduled_dt.hour),
        float(ctx.expected_pax),
        ctx.load_factor,
    ] + [float(mix.get(seg, 0.0)) for seg in PAX_SEGMENTS]
    return cats, nums


@dataclass
class FeatureEncoder:
    """Deterministic categorical vocabularies, fitted on training rows only.

    Unseen categories encode to -1, which LightGBM reads as missing. Fitting the
    vocabulary on anything the model is later scored against would leak.
    """

    vocabularies: dict[str, dict[str, int]] = field(default_factory=dict)
    schema_version: int = FEATURE_SCHEMA_VERSION

    @classmethod
    def fit(cls, categorical_rows: Sequence[Sequence[str]]) -> "FeatureEncoder":
        seen: dict[str, set[str]] = {name: set() for name in CATEGORICAL_FEATURES}
        for row in categorical_rows:
            for name, value in zip(CATEGORICAL_FEATURES, row):
                seen[name].add(value)
        return cls(
            vocabularies={
                name: {value: i for i, value in enumerate(sorted(values))}
                for name, values in seen.items()
            }
        )

    def encode(self, categorical_rows: Sequence[Sequence[str]]) -> np.ndarray:
        n = len(categorical_rows)
        width = len(CATEGORICAL_FEATURES)
        out = np.full((n, width), -1.0, dtype=np.float64)
        for i, row in enumerate(categorical_rows):
            if len(row) != width:
                raise DatasetIntegrityError(
                    f"row {i} has {len(row)} categorical values, expected {width}"
                )
            for j, name in enumerate(CATEGORICAL_FEATURES):
                code = self.vocabularies.get(name, {}).get(row[j])
                if code is not None:
                    out[i, j] = float(code)
        return out

    def matrix(
        self,
        categorical_rows: Sequence[Sequence[str]],
        numeric_rows: Sequence[Sequence[float]],
    ) -> np.ndarray:
        cats = self.encode(categorical_rows)
        nums = np.asarray(numeric_rows, dtype=np.float64).reshape(len(categorical_rows), -1)
        return np.hstack([cats, nums])

    def to_dict(self) -> dict:
        return {"schema_version": self.schema_version, "vocabularies": self.vocabularies}

    @classmethod
    def from_dict(cls, payload: Mapping) -> "FeatureEncoder":
        version = int(payload.get("schema_version", 0))
        if version != FEATURE_SCHEMA_VERSION:
            raise DatasetIntegrityError(
                f"feature schema {version} does not match {FEATURE_SCHEMA_VERSION}"
            )
        return cls(
            vocabularies={k: dict(v) for k, v in (payload.get("vocabularies") or {}).items()},
            schema_version=version,
        )


CATEGORICAL_INDICES: tuple[int, ...] = tuple(range(len(CATEGORICAL_FEATURES)))


# ---------------------------------------------------------------------------
# Training frame
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class DatasetAudit:
    """What the loader kept, dropped, and why. Surfaced in the Settings page."""

    sale_rows: int = 0
    eligible_rows: int = 0
    stocked_rows: int = 0
    censored_rows: int = 0
    unstocked_rows: int = 0
    positive_sales_rows: int = 0
    zero_pax_rows_skipped: int = 0
    unknown_flight_rows: int = 0
    unknown_sku_rows: int = 0
    future_rows_excluded: int = 0
    target_rows_excluded: int = 0
    distinct_flights: int = 0
    distinct_dates: int = 0
    distinct_skus: int = 0
    total_units: int = 0
    train_start: Optional[datetime] = None
    train_end: Optional[datetime] = None

    def to_dict(self) -> dict:
        out = {
            k: (v.isoformat() if isinstance(v, datetime) else v)
            for k, v in self.__dict__.items()
        }
        return out


@dataclass
class TrainingFrame:
    """Model-ready observations, all of them time-eligible and stock-aware."""

    categorical_rows: list[list[str]]
    numeric_rows: list[list[float]]
    units_sold: np.ndarray       # observed sales
    loaded_units: np.ndarray     # what was on board; the censoring threshold
    exposure: np.ndarray         # expected passengers
    censored: np.ndarray         # bool: sold == loaded, demand only bounded below
    flight_ids: np.ndarray
    sku_ids: np.ndarray
    bin_keys: list[tuple[str, str, str, str]]  # route/season/time-of-day/day bucket
    categories: list[str]
    dates: list[datetime]        # flight calendar date, for grouped temporal folds
    completion_dts: list[datetime]  # when the row's sales became known
    as_of: datetime
    audit: DatasetAudit

    def __len__(self) -> int:
        return len(self.categorical_rows)

    @property
    def is_empty(self) -> bool:
        return len(self) == 0

    def subset(self, mask: np.ndarray) -> "TrainingFrame":
        idx = np.flatnonzero(mask)
        return TrainingFrame(
            categorical_rows=[self.categorical_rows[i] for i in idx],
            numeric_rows=[self.numeric_rows[i] for i in idx],
            units_sold=self.units_sold[idx],
            loaded_units=self.loaded_units[idx],
            exposure=self.exposure[idx],
            censored=self.censored[idx],
            flight_ids=self.flight_ids[idx],
            sku_ids=self.sku_ids[idx],
            bin_keys=[self.bin_keys[i] for i in idx],
            categories=[self.categories[i] for i in idx],
            dates=[self.dates[i] for i in idx],
            completion_dts=[self.completion_dts[i] for i in idx],
            as_of=self.as_of,
            audit=self.audit,
        )


def _validate(flight_id: int, sku_id: int, sold: int, unsold: int, returned: int) -> int:
    if sold < 0 or unsold < 0 or returned < 0:
        raise DatasetIntegrityError(
            f"negative units on flight {flight_id} sku {sku_id}: "
            f"sold={sold} unsold={unsold} returned={returned}"
        )
    if returned > unsold:
        raise DatasetIntegrityError(
            f"returned exceeds unsold on flight {flight_id} sku {sku_id}: "
            f"{returned} > {unsold}"
        )
    return sold + unsold


def load_training_frame(
    session: Session,
    *,
    as_of: datetime,
    exclude_flight_ids: Iterable[int] = (),
    flight_contexts: Optional[Mapping[int, FlightContext]] = None,
    skus: Optional[Sequence[Sku]] = None,
) -> TrainingFrame:
    """Load every observation usable for a forecast made at `as_of`.

    `as_of` is exclusive: a flight is eligible only once it has landed. Flights
    in `exclude_flight_ids` (the target, or every leg of the target rotation) are
    dropped regardless of their timing.
    """
    contexts = dict(flight_contexts) if flight_contexts is not None else load_flight_contexts(session)
    sku_list = list(skus) if skus is not None else list(session.execute(select(Sku)).scalars())
    sku_map = {s.id: s for s in sku_list}
    excluded = {int(f) for f in exclude_flight_ids}

    cat_rows: list[list[str]] = []
    num_rows: list[list[float]] = []
    sold_v: list[float] = []
    loaded_v: list[float] = []
    exposure_v: list[float] = []
    censored_v: list[bool] = []
    flight_v: list[int] = []
    sku_v: list[int] = []
    bin_v: list[tuple[str, str, str, str]] = []
    category_v: list[str] = []
    dates: list[datetime] = []
    completion_dts: list[datetime] = []

    counts = defaultdict(int)
    seen_pairs: set[tuple[int, int]] = set()
    flights_used: set[int] = set()
    skus_used: set[int] = set()
    date_set: set[datetime] = set()
    first_dt: Optional[datetime] = None
    last_dt: Optional[datetime] = None

    rows = session.execute(
        select(Sale.flight_id, Sale.sku_id, Sale.units_sold, Sale.unsold_units, Sale.returned_units)
    ).all()

    for flight_id, sku_id, sold, unsold, returned in rows:
        counts["sale_rows"] += 1
        pair = (flight_id, sku_id)
        if pair in seen_pairs:
            raise DatasetIntegrityError(
                f"duplicate sale rows for flight {flight_id} sku {sku_id}; "
                "this loader expects one inventory outcome per flight and SKU"
            )
        seen_pairs.add(pair)

        ctx = contexts.get(flight_id)
        if ctx is None:
            counts["unknown_flight_rows"] += 1
            continue
        sku = sku_map.get(sku_id)
        if sku is None:
            counts["unknown_sku_rows"] += 1
            continue
        if flight_id in excluded:
            counts["target_rows_excluded"] += 1
            continue
        if ctx.completion_dt >= as_of:
            counts["future_rows_excluded"] += 1
            continue

        loaded = _validate(flight_id, sku_id, int(sold), int(unsold or 0), int(returned or 0))
        sold = int(sold)

        counts["eligible_rows"] += 1
        if loaded <= 0:
            # Never offered, so the zero is an availability fact, not demand.
            counts["unstocked_rows"] += 1
            continue
        if ctx.expected_pax <= 0:
            # No passengers means no exposure to scale a per-passenger rate by.
            counts["zero_pax_rows_skipped"] += 1
            continue

        is_censored = sold >= loaded
        counts["censored_rows" if is_censored else "stocked_rows"] += 1
        if sold > 0:
            counts["positive_sales_rows"] += 1
            counts["total_units"] += sold

        cats, nums = feature_values(ctx, sku)
        cat_rows.append(cats)
        num_rows.append(nums)
        sold_v.append(float(sold))
        loaded_v.append(float(loaded))
        exposure_v.append(float(ctx.expected_pax))
        censored_v.append(is_censored)
        flight_v.append(flight_id)
        sku_v.append(sku_id)
        bin_v.append(ctx.bin_key)
        category_v.append(sku.category)

        day = ctx.scheduled_dt.replace(hour=0, minute=0, second=0, microsecond=0)
        dates.append(day)
        completion_dts.append(ctx.completion_dt)
        date_set.add(day)
        flights_used.add(flight_id)
        skus_used.add(sku_id)
        if first_dt is None or ctx.scheduled_dt < first_dt:
            first_dt = ctx.scheduled_dt
        if last_dt is None or ctx.scheduled_dt > last_dt:
            last_dt = ctx.scheduled_dt

    audit = DatasetAudit(
        sale_rows=counts["sale_rows"],
        eligible_rows=counts["eligible_rows"],
        stocked_rows=counts["stocked_rows"],
        censored_rows=counts["censored_rows"],
        unstocked_rows=counts["unstocked_rows"],
        positive_sales_rows=counts["positive_sales_rows"],
        zero_pax_rows_skipped=counts["zero_pax_rows_skipped"],
        unknown_flight_rows=counts["unknown_flight_rows"],
        unknown_sku_rows=counts["unknown_sku_rows"],
        future_rows_excluded=counts["future_rows_excluded"],
        target_rows_excluded=counts["target_rows_excluded"],
        distinct_flights=len(flights_used),
        distinct_dates=len(date_set),
        distinct_skus=len(skus_used),
        total_units=counts["total_units"],
        train_start=first_dt,
        train_end=last_dt,
    )

    return TrainingFrame(
        categorical_rows=cat_rows,
        numeric_rows=num_rows,
        units_sold=np.asarray(sold_v, dtype=np.float64),
        loaded_units=np.asarray(loaded_v, dtype=np.float64),
        exposure=np.asarray(exposure_v, dtype=np.float64),
        censored=np.asarray(censored_v, dtype=bool),
        flight_ids=np.asarray(flight_v, dtype=np.int64),
        sku_ids=np.asarray(sku_v, dtype=np.int64),
        bin_keys=bin_v,
        categories=category_v,
        dates=dates,
        completion_dts=completion_dts,
        as_of=as_of,
        audit=audit,
    )


# ---------------------------------------------------------------------------
# Cutoff helpers
# ---------------------------------------------------------------------------

def default_training_cutoff(session: Session) -> Optional[datetime]:
    """Start of the latest month present in history.

    Leaves the most recent month unused by training, so those flights are
    genuine out-of-time targets to demo against.
    """
    latest = session.execute(select(Flight.scheduled_dt).order_by(Flight.scheduled_dt.desc())).scalars().first()
    if latest is None:
        return None
    return latest.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def history_span(session: Session) -> tuple[Optional[datetime], Optional[datetime]]:
    first = session.execute(select(Flight.scheduled_dt).order_by(Flight.scheduled_dt.asc())).scalars().first()
    last = session.execute(select(Flight.scheduled_dt).order_by(Flight.scheduled_dt.desc())).scalars().first()
    return first, last


def rotation_flight_ids(session: Session, rotation_id: int) -> list[int]:
    return list(
        session.execute(select(Flight.id).where(Flight.rotation_id == rotation_id)).scalars()
    )


def dataset_fingerprint(session: Session) -> str:
    """Content hash of everything training reads.

    Hashing every row costs the better part of a second on the seeded database.
    It used to sit behind a cheap SQL-aggregate signature, but those aggregates
    do not see an edit that leaves counts and sums alone — renaming a SKU's brand
    changed the features a model learns while the signature, and so the cached
    hash, stayed identical and the model still looked fresh.
    """
    return _full_fingerprint(session)


def _full_fingerprint(session: Session) -> str:
    h = hashlib.sha256()
    h.update(f"schema={FEATURE_SCHEMA_VERSION};labels={LABEL_POLICY_VERSION}\n".encode())

    for row in session.execute(
        select(Sale.flight_id, Sale.sku_id, Sale.units_sold, Sale.unsold_units, Sale.returned_units)
        .order_by(Sale.flight_id, Sale.sku_id)
    ).all():
        h.update(",".join(str(v) for v in row).encode())
        h.update(b"\n")

    for row in session.execute(
        select(
            Flight.id,
            Flight.route_id,
            Flight.scheduled_dt,
            Flight.expected_pax,
            Flight.expected_load_factor,
        ).order_by(Flight.id)
    ).all():
        h.update(",".join(str(v) for v in row).encode())
        h.update(b"\n")

    for row in session.execute(
        select(Route.id, Route.origin_iata, Route.dest_iata, Route.haul_class,
               Route.distance_km, Route.flight_duration_min).order_by(Route.id)
    ).all():
        h.update(",".join(str(v) for v in row).encode())
        h.update(b"\n")

    for row in session.execute(
        select(Sku.id, Sku.category, Sku.sub_category, Sku.brand).order_by(Sku.id)
    ).all():
        h.update(",".join(str(v) for v in row).encode())
        h.update(b"\n")

    return h.hexdigest()


def json_safe(value):
    """datetime-aware JSON coercion for manifests and audit payloads."""
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    return value


def dumps(payload: Mapping) -> str:
    return json.dumps(json_safe(dict(payload)), sort_keys=True, indent=2)
