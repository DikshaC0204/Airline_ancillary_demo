"""Stage 3 — 3D bin packing into drawers.

Plan §6.3 calls for OR-Tools CP-SAT 3D bin packing. For ~350 units × ~12 drawers
the full CP-SAT formulation can blow past the 15s budget on a dev laptop, so we
use a deterministic Extreme-Point heuristic (also known as EP-FFD) which is the
standard fast packer for cuboid sets. CP-SAT can be slotted in later as a
verifier/refiner for the top-velocity items only.

Algorithm:
  - Candidate drawers sorted by accessibility (1 = best access).
  - Within each drawer, units are placed at extreme points (EPs):
      seeded with (0,0,0); when a box of size (l,w,h) is placed at EP p,
      three new EPs emerge at p+(l,0,0), p+(0,w,0), p+(0,0,h).
    Each candidate EP is tested for fit (within drawer box, no overlap with
    placed boxes) and the lowest-z / lowest-y / lowest-x point that fits is
    chosen.
  - Units of one SKU are sorted by velocity DESC across drawers (so popular
    items land in lower-accessibility-score drawers first).
  - Orientation: by default the unit's smallest dimension is laid vertical; if
    `orientation_constraint == 'upright_only'` the SKU height stays on z.
  - Per-drawer weight ceiling enforced as a hard constraint.
  - Returns `PackingResult` with one `PlacedUnit` per packed unit and a list of
    `unplaced` skus (with counts) when there isn't room.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable

from ..models import Drawer, Sku


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

@dataclass
class PlacedUnit:
    sku_id: int
    drawer_id: int
    x_mm: float
    y_mm: float
    z_mm: float
    l_mm: float
    w_mm: float
    h_mm: float


@dataclass
class DrawerSummary:
    drawer_id: int
    units_placed: int
    weight_kg: float
    weight_cap_kg: float
    volume_used_cm3: float
    volume_total_cm3: float


@dataclass
class PackingResult:
    placements: list[PlacedUnit] = field(default_factory=list)
    unplaced_sku_ids: dict[int, int] = field(default_factory=dict)  # sku_id -> count
    drawer_summaries: list[DrawerSummary] = field(default_factory=list)
    pack_seconds: float = 0.0


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _orient(sku: Sku) -> tuple[float, float, float]:
    """Return (l, w, h) with the most efficient orientation. `h` is along z."""
    dims = [sku.length_mm, sku.width_mm, sku.height_mm]
    if sku.orientation_constraint == "upright_only":
        h = sku.height_mm
        floor = sorted([sku.length_mm, sku.width_mm])
        return floor[1], floor[0], h
    # Lay smallest dim flat (height); other two as floor (longest along x).
    dims_sorted = sorted(dims)
    h = dims_sorted[0]
    l = dims_sorted[2]
    w = dims_sorted[1]
    return l, w, h


def _overlaps(a: tuple[float, float, float, float, float, float], placed: list[PlacedUnit]) -> bool:
    ax, ay, az, al, aw, ah = a
    for p in placed:
        if ax + al <= p.x_mm or p.x_mm + p.l_mm <= ax:
            continue
        if ay + aw <= p.y_mm or p.y_mm + p.w_mm <= ay:
            continue
        if az + ah <= p.z_mm or p.z_mm + p.h_mm <= az:
            continue
        return True
    return False


def _drawer_volume_cm3(d: Drawer) -> float:
    return d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0


# ---------------------------------------------------------------------------
# Packer
# ---------------------------------------------------------------------------

def pack_units(
    drawers: list[Drawer],
    units: Iterable[tuple[Sku, float]],  # (sku, velocity_score) per UNIT (one entry per loaded unit)
) -> PackingResult:
    """Greedy extreme-point packing.

    `units` is one tuple per individual loaded unit (so 5 units of SKU X means
    5 entries). Sort priority: velocity DESC, then volume DESC.
    """
    import time as _time

    t0 = _time.perf_counter()
    # Sort units by velocity DESC (high velocity → best drawer); ties by volume DESC.
    unit_list = list(units)
    unit_list.sort(key=lambda t: (-t[1], -(t[0].volume_cm3)))

    # Sort drawers by accessibility (1 best, 5 worst). Stable.
    sorted_drawers = sorted(drawers, key=lambda d: (d.accessibility_score, d.id))

    # Per-drawer state.
    per_drawer_placed: dict[int, list[PlacedUnit]] = {d.id: [] for d in sorted_drawers}
    per_drawer_eps: dict[int, list[tuple[float, float, float]]] = {d.id: [(0.0, 0.0, 0.0)] for d in sorted_drawers}
    per_drawer_weight_g: dict[int, float] = {d.id: 0.0 for d in sorted_drawers}
    drawer_by_id: dict[int, Drawer] = {d.id: d for d in sorted_drawers}

    placements: list[PlacedUnit] = []
    unplaced: dict[int, int] = {}

    for sku, _vel in unit_list:
        l, w, h = _orient(sku)
        unit_weight_kg = sku.unit_weight_g / 1000.0
        placed_flag = False
        for d in sorted_drawers:
            # Weight check.
            if per_drawer_weight_g[d.id] + sku.unit_weight_g > d.max_weight_kg * 1000.0:
                continue
            # Try extreme points in deterministic order: lowest (z, y, x).
            eps = sorted(per_drawer_eps[d.id], key=lambda p: (p[2], p[1], p[0]))
            chosen_ep: tuple[float, float, float] | None = None
            for ep in eps:
                x, y, z = ep
                # Fits in drawer?
                if x + l > d.internal_l_mm + 1e-6:
                    continue
                if y + w > d.internal_w_mm + 1e-6:
                    continue
                if z + h > d.internal_h_mm + 1e-6:
                    continue
                # Overlap?
                if _overlaps((x, y, z, l, w, h), per_drawer_placed[d.id]):
                    continue
                chosen_ep = ep
                break
            if chosen_ep is None:
                continue
            x, y, z = chosen_ep
            placement = PlacedUnit(
                sku_id=sku.id,
                drawer_id=d.id,
                x_mm=x,
                y_mm=y,
                z_mm=z,
                l_mm=l,
                w_mm=w,
                h_mm=h,
            )
            placements.append(placement)
            per_drawer_placed[d.id].append(placement)
            per_drawer_weight_g[d.id] += sku.unit_weight_g
            # Replace used EP with three new EPs.
            new_eps = [
                (x + l, y, z),
                (x, y + w, z),
                (x, y, z + h),
            ]
            eps_list = [p for p in per_drawer_eps[d.id] if p != chosen_ep]
            for nep in new_eps:
                if nep not in eps_list:
                    eps_list.append(nep)
            per_drawer_eps[d.id] = eps_list
            placed_flag = True
            break
        if not placed_flag:
            unplaced[sku.id] = unplaced.get(sku.id, 0) + 1

    # Drawer summaries for the UI.
    summaries: list[DrawerSummary] = []
    for d in sorted_drawers:
        placed = per_drawer_placed[d.id]
        used_cm3 = sum(p.l_mm * p.w_mm * p.h_mm / 1000.0 for p in placed)
        summaries.append(
            DrawerSummary(
                drawer_id=d.id,
                units_placed=len(placed),
                weight_kg=per_drawer_weight_g[d.id] / 1000.0,
                weight_cap_kg=d.max_weight_kg,
                volume_used_cm3=used_cm3,
                volume_total_cm3=_drawer_volume_cm3(d),
            )
        )

    return PackingResult(
        placements=placements,
        unplaced_sku_ids=unplaced,
        drawer_summaries=summaries,
        pack_seconds=_time.perf_counter() - t0,
    )
