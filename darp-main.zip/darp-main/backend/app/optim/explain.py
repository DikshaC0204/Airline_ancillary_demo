"""Deterministic explainability — reason codes, binding-constraint analysis,
substitutions and contribution-density metrics.

Pure post-solve analysis: takes `SelectionInputs` + `SelectionResult` and returns
plain dicts. No DB access, no LLM — so every SKU (including every rejected one)
gets a defensible "why" with numbers, satisfying the brief's requirement for a
"'why excluded' rationale for rejected SKUs". The LLM layer (ai/rationale.py)
polishes the top decisions on top of these codes; it never invents them.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from ..models import Sku
from .forecast_likelihood import expected_capped_sales
from .selection import SelectionInputs, SelectionResult, SkuDecision


# Reason-code constants.
EXCLUDED_REGULATORY = "EXCLUDED_REGULATORY"
EXCLUDED_BY_OVERRIDE = "EXCLUDED_BY_OVERRIDE"
EXCLUDED_NO_DEMAND = "EXCLUDED_NO_DEMAND"
EXCLUDED_NEGATIVE_NET = "EXCLUDED_NEGATIVE_NET"
EXCLUDED_SHELF_LIFE = "EXCLUDED_SHELF_LIFE"
EXCLUDED_LOW_RETURN_PICKLINE = "EXCLUDED_LOW_RETURN_PICKLINE"
EXCLUDED_NOT_WORTH_PICKLINE = "EXCLUDED_NOT_WORTH_PICKLINE"
EXCLUDED_DISPLACED_VOLUME = "EXCLUDED_DISPLACED_VOLUME"
EXCLUDED_DISPLACED_WEIGHT = "EXCLUDED_DISPLACED_WEIGHT"
REDUCED_TO_FIT_VOLUME = "REDUCED_TO_FIT_VOLUME"
REDUCED_TO_FIT_WEIGHT = "REDUCED_TO_FIT_WEIGHT"
REDUCED_MARGINAL_UNIT = "REDUCED_MARGINAL_UNIT"
REDUCED_CASE_ROUNDING = "REDUCED_CASE_ROUNDING"
REDUCED_SPOILAGE_RISK = "REDUCED_SPOILAGE_RISK"
LOADED_BY_OVERRIDE = "LOADED_BY_OVERRIDE"
LOADED_BRAND_RULE = "LOADED_BRAND_RULE"
LOADED_SUPPLIER_COMMITMENT = "LOADED_SUPPLIER_COMMITMENT"
LOADED_CASE_EFFICIENT = "LOADED_CASE_EFFICIENT"
LOADED_STRONG_DEMAND = "LOADED_STRONG_DEMAND"
LOADED_PARTIAL = "LOADED_PARTIAL"

# Human labels (short chip text).
REASON_LABELS = {
    EXCLUDED_REGULATORY: "regulatory ban",
    EXCLUDED_BY_OVERRIDE: "pinned out",
    EXCLUDED_NO_DEMAND: "no demand",
    EXCLUDED_NEGATIVE_NET: "loss-making",
    EXCLUDED_SHELF_LIFE: "spoilage risk",
    EXCLUDED_LOW_RETURN_PICKLINE: "low-return pickline",
    EXCLUDED_NOT_WORTH_PICKLINE: "not worth a pickline",
    EXCLUDED_DISPLACED_VOLUME: "displaced · volume",
    EXCLUDED_DISPLACED_WEIGHT: "displaced · weight",
    REDUCED_TO_FIT_VOLUME: "trimmed · volume",
    REDUCED_TO_FIT_WEIGHT: "trimmed · weight",
    REDUCED_MARGINAL_UNIT: "trimmed · marginal unit",
    REDUCED_CASE_ROUNDING: "case rounding",
    REDUCED_SPOILAGE_RISK: "spoilage risk",
    LOADED_BY_OVERRIDE: "pinned in",
    LOADED_BRAND_RULE: "brand rule",
    LOADED_SUPPLIER_COMMITMENT: "supplier minimum",
    LOADED_CASE_EFFICIENT: "case-efficient",
    LOADED_STRONG_DEMAND: "strong demand",
    LOADED_PARTIAL: "loaded",
}

BINDING = "binding"
NEAR = "near"
SLACK = "slack"


def _status(util_pct: float) -> str:
    if util_pct >= 99.5:
        return BINDING
    if util_pct >= 90.0:
        return NEAR
    return SLACK


def _expected_sold(lam: float, qty: int) -> float:
    """E[min(D, qty)] — stock only earns on what it actually sells."""
    if lam <= 0.0 or qty <= 0:
        return 0.0
    return float(expected_capped_sales(np.array([lam]), np.array([float(qty)]))[0])


def analyse(inp: SelectionInputs, result: SelectionResult) -> dict:
    """Return {constraints: [...], decisions: {sku_id: {...}}}."""
    sku_by_id = {s.id: s for s in inp.skus}
    dec_by_id = {d.sku_id: d for d in result.decisions}
    diag = result.diagnostics

    agg = result.aggregates or {}
    vol_used = agg.get("volume_used_cm3", 0.0)
    vol_cap = max(1e-9, agg.get("volume_cap_cm3", 1.0))
    wt_used = agg.get("weight_used_kg", 0.0)
    wt_cap = max(1e-9, agg.get("weight_cap_kg", 1.0))
    vol_util = 100.0 * vol_used / vol_cap
    wt_util = 100.0 * wt_used / wt_cap
    volume_binds = vol_util >= wt_util
    capacity_tight = max(vol_util, wt_util) >= 90.0
    slack_cm3 = max(0.0, vol_cap - vol_used)
    slack_kg = max(0.0, wt_cap - wt_used)

    def room_for(sku: Sku, units: int) -> bool:
        """Would `units` of this line still have fitted in what was left over?"""
        units = max(1, units)
        return (
            units * (sku.volume_cm3 or 0.0) <= slack_cm3 + 1e-9
            and units * (sku.unit_weight_g / 1000.0) <= slack_kg + 1e-9
        )

    # Loaded SKUs by category, with densities — for substitution suggestions.
    loaded_by_cat: dict[str, list[SkuDecision]] = {}
    for d in result.decisions:
        if d.loaded_qty > 0:
            sku = sku_by_id.get(d.sku_id)
            if sku is not None:
                loaded_by_cat.setdefault(sku.category, []).append(d)

    def best_substitute(sku: Sku, exclude_id: int) -> Optional[SkuDecision]:
        cands = [d for d in loaded_by_cat.get(sku.category, []) if d.sku_id != exclude_id]
        if not cands:
            return None
        key = (lambda d: (d.net_per_cm3 or 0.0)) if volume_binds else (lambda d: (d.net_per_kg or 0.0))
        return max(cands, key=key)

    # ----- per-SKU reason codes -----
    decisions_out: dict[int, dict] = {}
    for sku in inp.skus:
        d = dec_by_id.get(sku.id)
        info = diag.get(sku.id, {})
        code, detail, sub_id = _reason_for(
            sku, d, info, volume_binds, capacity_tight, best_substitute, room_for
        )
        decisions_out[sku.id] = {
            "reason_code": code,
            "reason_text": _render(code, sku, d, detail),
            "reason_detail": detail,
            "substitute_sku_id": sub_id,
        }

    # ----- binding-constraint report -----
    constraints = _constraints(inp, result, vol_used, vol_cap, wt_used, wt_cap)

    return {"constraints": constraints, "decisions": decisions_out}


def _reason_for(sku, d, info, volume_binds, capacity_tight, best_substitute, room_for):
    detail: dict = {}
    sub_id = None

    if not info.get("candidate", False):
        if info.get("regulatory"):
            return EXCLUDED_REGULATORY, detail, None
        return EXCLUDED_NO_DEMAND, detail, None

    pin_kind = info.get("pin_kind")
    loaded = info.get("loaded_qty", 0)
    cap_total = info.get("cap_total", 0)

    if info.get("pinned"):
        if pin_kind == "force_exclude" or (pin_kind == "set_qty" and loaded == 0):
            return EXCLUDED_BY_OVERRIDE, detail, None
        return LOADED_BY_OVERRIDE, detail, None

    margin_gbp_unit = info.get("margin_pence", 0) / 100.0
    handling_unit = info.get("handling_pence", 0) / 100.0
    fuel_full_unit = info.get("fuel_full_pence", 0) / 100.0
    spoil_unit = info.get("spoil_pence", 0) / 100.0
    net_unit_no_spoil = margin_gbp_unit - handling_unit - fuel_full_unit
    net_unit = net_unit_no_spoil - spoil_unit

    if loaded <= 0:
        # Excluded — diagnose why.
        if cap_total < 1:
            return EXCLUDED_NO_DEMAND, detail, None
        if net_unit < 0:
            if net_unit_no_spoil >= 0:  # only spoilage pushed it negative
                detail = {"spoilage_per_unit_gbp": round(spoil_unit, 3),
                          "shelf_life_days": sku.shelf_life_days}
                return EXCLUDED_SHELF_LIFE, detail, None
            detail = {"net_per_unit_gbp": round(net_unit, 3)}
            return EXCLUDED_NEGATIVE_NET, detail, None
        best_case = info.get("best_case_margin_gbp", 0.0)
        threshold = info.get("pickline_min_margin_gbp", 6.0)
        if best_case < threshold:
            detail = {"best_case_margin_gbp": round(best_case, 2),
                      "pickline_min_margin_gbp": threshold}
            return EXCLUDED_LOW_RETURN_PICKLINE, detail, None
        if room_for(sku, info.get("min_depth", 1)):
            # There was space for it at the depth it would have to be stocked, so
            # nothing displaced it. It simply did not earn its pickline.
            detail = {"net_per_unit_gbp": round(net_unit, 3),
                      "pickline_gbp": round(info.get("pickline_pence", 0) / 100.0, 2)}
            return EXCLUDED_NOT_WORTH_PICKLINE, detail, None
        # Net-positive but didn't make the cut — displaced on the binding constraint.
        sub = best_substitute(sku, sku.id)
        # A line that was not loaded has no realised density, so the comparison
        # uses the density it *would* have had at its forecast demand. It has to
        # be built the same way a loaded line's is — earning only on expected
        # sales, paying carriage on every unit — or a line that merely looks
        # good on paper appears to beat one that is genuinely on board.
        qty = max(1, int(cap_total))
        sold = _expected_sold(float(cap_total), qty)
        would_net = (
            margin_gbp_unit * sold
            - (handling_unit + fuel_full_unit) * qty
            - spoil_unit * max(0.0, qty - sold)
            - info.get("pickline_pence", 0) / 100.0
        )
        would_volume = (sku.volume_cm3 or 0.0) * qty
        would_weight = (sku.unit_weight_g / 1000.0) * qty
        detail = {
            "binding": "volume" if volume_binds else "weight",
            "net_per_cm3": (would_net / would_volume) if would_volume > 0 else None,
            "net_per_kg": (would_net / would_weight) if would_weight > 0 else None,
            "at_qty": qty,
        }
        if sub is not None:
            sub_id = sub.sku_id
            detail["displaced_by_sku_id"] = sub.sku_id
            detail["alternative_net_per_cm3"] = sub.net_per_cm3
            detail["alternative_net_per_kg"] = sub.net_per_kg
        return (EXCLUDED_DISPLACED_VOLUME if volume_binds else EXCLUDED_DISPLACED_WEIGHT), detail, sub_id

    if loaded < cap_total:
        # Reduced — diagnose.
        case = info.get("case_size", 0)
        if info.get("is_perishable") and not capacity_tight:
            detail = {"shelf_life_days": sku.shelf_life_days}
            return REDUCED_SPOILAGE_RISK, detail, None
        if case >= 2 and loaded % case == 0 and cap_total % case != 0 and (cap_total - loaded) < case:
            detail = {"case_size": case, "demand": cap_total}
            return REDUCED_CASE_ROUNDING, detail, None
        sub = best_substitute(sku, sku.id)
        if sub is not None:
            sub_id = sub.sku_id
        detail = {"loaded": loaded, "demand": cap_total}
        if room_for(sku, 1):
            # Another unit would have fitted; the plan stopped because the next
            # one no longer covered carrying it, not because space ran out.
            return REDUCED_MARGINAL_UNIT, detail, sub_id
        detail["binding"] = "volume" if volume_binds else "weight"
        return (REDUCED_TO_FIT_VOLUME if volume_binds else REDUCED_TO_FIT_WEIGHT), detail, sub_id

    # Loaded at/above full demand.
    case = info.get("case_size", 0)
    if net_unit < 0 <= info.get("best_case_margin_gbp", 0.0):
        # Loaded despite weak economics — must be a rule.
        return LOADED_BRAND_RULE, {"net_per_unit_gbp": round(net_unit, 3)}, None
    if case >= 2 and loaded >= case and loaded % case == 0:
        detail = {"case_size": case}
        return LOADED_CASE_EFFICIENT, detail, None
    if cap_total > 0 and loaded >= 0.9 * cap_total:
        return LOADED_STRONG_DEMAND, detail, None
    return LOADED_PARTIAL, detail, None


def _render(code: str, sku, d, detail: dict) -> str:
    n = lambda v, p=2: ("%.*f" % (p, v)) if isinstance(v, (int, float)) else "?"
    if code == EXCLUDED_REGULATORY:
        return f"Excluded — {sku.category} is not permitted on this rotation."
    if code == EXCLUDED_BY_OVERRIDE:
        return "Pinned out by the planner."
    if code == LOADED_BY_OVERRIDE:
        return f"Pinned in by the planner ({d.loaded_qty if d else 0} units)."
    if code == EXCLUDED_NO_DEMAND:
        return "Excluded — negligible forecast demand on these legs."
    if code == EXCLUDED_NEGATIVE_NET:
        return f"Excluded — loss-making: net £{n(detail.get('net_per_unit_gbp', 0), 3)}/unit after handling and fuel."
    if code == EXCLUDED_SHELF_LIFE:
        return (f"Excluded — short shelf life ({detail.get('shelf_life_days')} days) makes spoilage "
                f"(£{n(detail.get('spoilage_per_unit_gbp', 0), 2)}/unsold unit) outweigh margin.")
    if code == EXCLUDED_LOW_RETURN_PICKLINE:
        return (f"Excluded — best-case margin £{n(detail.get('best_case_margin_gbp', 0))} is below the "
                f"£{n(detail.get('pickline_min_margin_gbp', 6))} threshold to justify a warehouse pick line.")
    if code == EXCLUDED_NOT_WORTH_PICKLINE:
        return (f"Excluded — the galley had room, but £{n(detail.get('net_per_unit_gbp', 0), 3)}/unit at "
                f"forecast demand does not cover the £{n(detail.get('pickline_gbp', 0))} cost of opening "
                f"the pick line.")
    if code in (EXCLUDED_DISPLACED_VOLUME, EXCLUDED_DISPLACED_WEIGHT):
        volume = detail.get("binding", "space") == "volume"
        own = detail.get("net_per_cm3" if volume else "net_per_kg")
        unit, places = ("cm³", 4) if volume else ("kg", 2)
        measure = "volume" if volume else "weight"
        if own is None:
            return f"Displaced on {measure} — better-earning lines filled the galley first."
        # Deliberately not set against the substitute's density: that is the best
        # line already loaded in the category, not the marginal one this lost to,
        # and a loaded line's density is diluted by stock it will not sell. The
        # substitute travels separately, as an alternative rather than a verdict.
        return (f"Displaced on {measure} — £{n(own, places)}/{unit} at forecast demand was not "
                f"enough to earn drawer space once the galley filled.")
    if code in (REDUCED_TO_FIT_VOLUME, REDUCED_TO_FIT_WEIGHT):
        return (f"Trimmed to {detail.get('loaded')} of ~{detail.get('demand')} forecast units to fit "
                f"the {detail.get('binding', 'space')} budget.")
    if code == REDUCED_MARGINAL_UNIT:
        return (f"Loaded {detail.get('loaded')} of ~{detail.get('demand')} forecast units — beyond "
                f"that, another unit is more likely to fly home than sell.")
    if code == REDUCED_CASE_ROUNDING:
        return f"Rounded to a {detail.get('case_size')}-unit case multiple rather than splitting a supplier case."
    if code == REDUCED_SPOILAGE_RISK:
        return f"Held back — short shelf life ({detail.get('shelf_life_days')} days) caps safe load."
    if code == LOADED_BRAND_RULE:
        return "Loaded to satisfy a brand/category representation rule despite thin unit economics."
    if code == LOADED_SUPPLIER_COMMITMENT:
        return "Loaded to meet a supplier minimum commitment."
    if code == LOADED_CASE_EFFICIENT:
        return f"Loaded in clean {detail.get('case_size')}-unit case multiples — efficient to pick and pack."
    if code == LOADED_STRONG_DEMAND:
        return f"Loaded to forecast demand — strong, profitable seller on these legs."
    return "Loaded."


def _constraints(inp, result, vol_used, vol_cap, wt_used, wt_cap) -> list[dict]:
    out: list[dict] = []
    dec_by_id = {d.sku_id: d for d in result.decisions}
    sku_by_id = {s.id: s for s in inp.skus}

    vol_pct = 100.0 * vol_used / max(1e-9, vol_cap)
    out.append({"name": "Drawer volume", "kind": "volume", "used": round(vol_used, 1),
                "limit": round(vol_cap, 1), "utilisation_pct": round(vol_pct, 1),
                "status": _status(vol_pct), "unit": "cm³"})
    wt_pct = 100.0 * wt_used / max(1e-9, wt_cap)
    out.append({"name": "Retail weight", "kind": "weight", "used": round(wt_used, 1),
                "limit": round(wt_cap, 1), "utilisation_pct": round(wt_pct, 1),
                "status": _status(wt_pct), "unit": "kg"})

    # Brand rules.
    for rule in inp.brand_rules:
        cat_decs = [dec_by_id[s.id] for s in inp.skus
                    if s.category == rule.category and s.id in dec_by_id]
        if rule.min_skus > 0:
            used = sum(1 for d in cat_decs if d.loaded_qty > 0)
            pct = 100.0 * used / max(1, rule.min_skus) if used < rule.min_skus else (
                100.0 if used == rule.min_skus else 100.0 + (used - rule.min_skus))
            status = BINDING if used == rule.min_skus else (NEAR if used <= rule.min_skus + 1 else SLACK)
            out.append({"name": f"Brand min SKUs — {rule.category}", "kind": "brand_min_skus",
                        "used": used, "limit": rule.min_skus,
                        "utilisation_pct": round(100.0 * rule.min_skus / max(1, used), 1) if used else 100.0,
                        "status": status})
        if rule.min_units > 0:
            used = sum(d.loaded_qty for d in cat_decs)
            status = BINDING if used == rule.min_units else (NEAR if used <= rule.min_units * 1.1 else SLACK)
            out.append({"name": f"Brand min units — {rule.category}", "kind": "brand_min_units",
                        "used": used, "limit": rule.min_units,
                        "utilisation_pct": round(100.0 * rule.min_units / max(1, used), 1) if used else 100.0,
                        "status": status})

    # Supplier commitments.
    by_supplier: dict[int, int] = {}
    for c in inp.supplier_commitments:
        by_supplier[c.supplier_id] = by_supplier.get(c.supplier_id, 0) + c.min_units_per_flight
    for sup_id, min_units in by_supplier.items():
        if min_units <= 0:
            continue
        used = sum(d.loaded_qty for s in inp.skus if (sku_by_id.get(s.id) and s.supplier_id == sup_id)
                   for d in [dec_by_id.get(s.id)] if d)
        status = BINDING if used == min_units else (NEAR if used <= min_units * 1.1 else SLACK)
        out.append({"name": f"Supplier minimum #{sup_id}", "kind": "supplier_min",
                    "used": used, "limit": min_units,
                    "utilisation_pct": round(100.0 * min_units / max(1, used), 1) if used else 100.0,
                    "status": status})

    # Binding first, then near, then slack.
    order = {BINDING: 0, NEAR: 1, SLACK: 2}
    out.sort(key=lambda c: order.get(c["status"], 3))
    return out
