"""Does a learned forecaster actually beat the simple one? Measure, don't assume.

Three things make a forecast comparison here worth reading:

*   **Time-ordered folds.** Training on a random 80% of rows lets a model learn
    from flights that had not happened yet and scores it far too kindly. Splits
    are made on calendar dates, so every row of a date — and every leg of a
    rotation — sits on one side of the line.

*   **A simple challenger.** LightGBM is compared with the empirical forecaster
    *and* a regularised Poisson GLM fitted on identical data with the identical
    likelihood. If the GLM matches it, the trees are not earning their keep.

*   **Scoring what was observed.** Demand is not in the data; sales are, and only
    up to whatever was loaded. So the headline metrics compare predicted
    *capped* sales E[min(D, load)] against actual sales, plus the censored log
    score. The demand-side error is reported too, over uncensored rows only, and
    labelled with the selection bias that slice carries.

Everything here is read-only and synthetic-data-bound. A win on this data is a
prototype result, not evidence about real onboard sales.
"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Callable, Optional

import numpy as np
import scipy.sparse as sp
from scipy.optimize import minimize
from sqlalchemy.orm import Session

from . import forecast_likelihood as fl
from .forecast import EMPIRICAL, LIGHTGBM, DemandForecaster
from .forecast_data import (
    CATEGORICAL_FEATURES,
    NUMERIC_FEATURES,
    TrainingFrame,
    default_training_cutoff,
    load_training_frame,
)

GLM = "poisson_glm"

# Guard rails for "is there enough history to learn anything at all". Prototype
# safeguards against training on a handful of flights, not a claim of adequacy.
MIN_TRAINING_DAYS = 90
MIN_TRAINING_FLIGHTS = 100
MIN_TRAINING_ROWS = 500


class InsufficientData(RuntimeError):
    """Not enough eligible history to train and still hold data back."""


# ---------------------------------------------------------------------------
# Metrics
# ---------------------------------------------------------------------------

@dataclass
class MetricSet:
    rows: int = 0
    censored_nll: float = float("nan")   # primary: scores how the data was observed
    capped_mae: float = float("nan")     # |E[min(D, load)] - sold|
    capped_wape: Optional[float] = None
    capped_bias: float = float("nan")    # signed; positive means over-forecast
    demand_mae_uncensored: Optional[float] = None
    uncensored_rows: int = 0
    sellout_rows: int = 0
    mean_predicted_demand: float = float("nan")
    mean_observed_sales: float = float("nan")

    def to_dict(self) -> dict:
        return {k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in asdict(self).items()}


def evaluate_predictions(mu: np.ndarray, frame: TrainingFrame) -> MetricSet:
    """Score predicted demand `mu` against what the flight actually sold."""
    if frame.is_empty:
        return MetricSet()

    mu = np.asarray(mu, dtype=np.float64)
    sold = frame.units_sold
    loaded = frame.loaded_units
    censored = frame.censored

    capped = fl.expected_capped_sales(mu, loaded)
    errors = capped - sold
    denominator = float(np.sum(sold))

    open_rows = ~censored
    demand_mae = float(np.mean(np.abs(mu[open_rows] - sold[open_rows]))) if open_rows.any() else None

    return MetricSet(
        rows=len(frame),
        censored_nll=fl.deviance(mu, sold, loaded, censored),
        capped_mae=float(np.mean(np.abs(errors))),
        capped_wape=(float(np.sum(np.abs(errors)) / denominator) if denominator > 0 else None),
        capped_bias=float(np.mean(errors)),
        demand_mae_uncensored=demand_mae,
        uncensored_rows=int(np.count_nonzero(open_rows)),
        sellout_rows=int(np.count_nonzero(censored)),
        mean_predicted_demand=float(np.mean(mu)),
        mean_observed_sales=float(np.mean(sold)),
    )


def slice_metrics(mu: np.ndarray, frame: TrainingFrame, feature: str) -> dict[str, dict]:
    """Metrics broken out by a categorical feature, e.g. category or route."""
    if feature not in CATEGORICAL_FEATURES:
        raise ValueError(f"{feature} is not a categorical feature")
    index = CATEGORICAL_FEATURES.index(feature)
    values = np.array([row[index] for row in frame.categorical_rows])

    out: dict[str, dict] = {}
    for value in sorted(set(values.tolist())):
        mask = values == value
        out[value] = evaluate_predictions(mu[mask], frame.subset(mask)).to_dict()
    return out


def paired_delta(mu: np.ndarray, baseline_mu: np.ndarray, frame: TrainingFrame) -> dict:
    """Score difference against a baseline, with uncertainty clustered by date.

    Rows are nowhere near independent — one flight contributes a row per SKU, and
    a whole day shares weather, load and season. Treating 14,000 rows as 14,000
    observations would make a rounding error look decisive, so the standard error
    is computed across *dates*.
    """
    if frame.is_empty:
        return {"delta": None, "stderr": None, "dates": 0, "distinguishable": False}

    per_row = -fl.log_likelihood(mu, frame.units_sold, frame.loaded_units, frame.censored)
    base_row = -fl.log_likelihood(baseline_mu, frame.units_sold, frame.loaded_units, frame.censored)
    diff = np.nan_to_num(per_row - base_row, nan=0.0, posinf=0.0, neginf=0.0)

    dates = np.array([d.toordinal() for d in frame.dates])
    per_date = np.array([float(np.mean(diff[dates == d])) for d in np.unique(dates)])
    n = len(per_date)
    if n < 2:
        return {"delta": float(np.mean(per_date)), "stderr": None, "dates": n, "distinguishable": False}

    delta = float(np.mean(per_date))
    stderr = float(np.std(per_date, ddof=1) / math.sqrt(n))
    return {
        "delta": delta,
        "stderr": stderr,
        "dates": n,
        # Negative delta means lower loss, i.e. better than the baseline.
        "distinguishable": bool(stderr > 0 and abs(delta) > 1.96 * stderr),
        "improves": bool(delta < 0),
    }


# ---------------------------------------------------------------------------
# Poisson GLM reference
# ---------------------------------------------------------------------------

class PoissonGlm:
    """Regularised log-linear count model, same likelihood as the booster.

    The point of comparison: if a linear model on one-hot categories does as
    well, the extra machinery of gradient boosting is not buying anything.
    """

    method = GLM

    def __init__(self, l2: float = 1e-5, max_iter: int = 400) -> None:
        # The likelihood term below is averaged over rows, so the penalty has to
        # be small to match its scale. At l2=1 it swamps the data and every
        # category collapses onto the intercept — which would hand the booster a
        # win it had not earned.
        self.l2 = l2
        self.max_iter = max_iter
        self.vocab: dict[str, dict[str, int]] = {}
        self.offsets: dict[str, int] = {}
        self.width = 0
        self.mean_: Optional[np.ndarray] = None
        self.scale_: Optional[np.ndarray] = None
        self.beta: Optional[np.ndarray] = None
        self.converged = False

    def _build_vocab(self, frame: TrainingFrame) -> None:
        seen: dict[str, set[str]] = {name: set() for name in CATEGORICAL_FEATURES}
        for row in frame.categorical_rows:
            for name, value in zip(CATEGORICAL_FEATURES, row):
                seen[name].add(value)
        cursor = 0
        for name in CATEGORICAL_FEATURES:
            self.vocab[name] = {v: i for i, v in enumerate(sorted(seen[name]))}
            self.offsets[name] = cursor
            cursor += len(self.vocab[name])
        self.numeric_offset = cursor
        self.width = cursor + len(NUMERIC_FEATURES) + 1  # + intercept

    def _design(self, frame: TrainingFrame) -> sp.csr_matrix:
        n = len(frame)
        numeric = np.asarray(frame.numeric_rows, dtype=np.float64).reshape(n, -1)
        numeric = (numeric - self.mean_) / self.scale_

        rows, cols, vals = [], [], []
        for i, cat_row in enumerate(frame.categorical_rows):
            for name, value in zip(CATEGORICAL_FEATURES, cat_row):
                code = self.vocab[name].get(value)
                if code is None:
                    continue  # unseen level contributes nothing, like a dropped dummy
                rows.append(i)
                cols.append(self.offsets[name] + code)
                vals.append(1.0)
            for j in range(numeric.shape[1]):
                rows.append(i)
                cols.append(self.numeric_offset + j)
                vals.append(numeric[i, j])
            rows.append(i)
            cols.append(self.width - 1)
            vals.append(1.0)
        return sp.csr_matrix((vals, (rows, cols)), shape=(n, self.width))

    def fit(self, frame: TrainingFrame) -> "PoissonGlm":
        if frame.is_empty:
            raise ValueError("cannot fit on an empty training frame")
        self._build_vocab(frame)

        numeric = np.asarray(frame.numeric_rows, dtype=np.float64).reshape(len(frame), -1)
        self.mean_ = numeric.mean(axis=0)
        self.scale_ = np.where(numeric.std(axis=0) > 1e-9, numeric.std(axis=0), 1.0)

        X = self._design(frame)
        offset = np.log(np.maximum(frame.exposure, fl.MIN_RATE))
        y, loaded, censored = frame.units_sold, frame.loaded_units, frame.censored
        ones = np.ones_like(y)
        n = len(frame)

        base = max(float(np.sum(y)) / max(float(np.sum(frame.exposure)), 1e-9), 1e-6)
        beta0 = np.zeros(self.width)
        beta0[-1] = np.log(base)

        penalty_mask = np.ones(self.width)
        penalty_mask[-1] = 0.0  # never shrink the intercept

        def objective(beta: np.ndarray):
            raw = X @ beta + offset
            ll = fl.log_likelihood(np.exp(np.clip(raw, -fl.MAX_RAW_SCORE, fl.MAX_RAW_SCORE)), y, loaded, censored)
            nll = -float(np.sum(np.nan_to_num(ll, nan=0.0, neginf=-50.0))) / n
            grad_raw, _ = fl.grad_hess(raw, y, loaded, ones, censored)
            grad = (X.T @ grad_raw) / n
            reg = self.l2 * float(np.sum((beta * penalty_mask) ** 2))
            grad = grad + 2.0 * self.l2 * beta * penalty_mask
            return nll + reg, grad

        result = minimize(
            objective, beta0, jac=True, method="L-BFGS-B",
            options={"maxiter": self.max_iter, "ftol": 1e-10},
        )
        self.beta = result.x
        self.converged = bool(result.success)
        return self

    def predict_rows(self, frame: TrainingFrame) -> np.ndarray:
        if self.beta is None:
            raise RuntimeError("model is not fitted")
        if frame.is_empty:
            return np.zeros(0)
        raw = np.clip(self._design(frame) @ self.beta, -fl.MAX_RAW_SCORE, fl.MAX_RAW_SCORE)
        return frame.exposure * np.exp(raw)


# ---------------------------------------------------------------------------
# Temporal splitting
# ---------------------------------------------------------------------------

def split_date_at(frame: TrainingFrame, fraction: float) -> Optional[datetime]:
    """The date that puts `fraction` of *distinct dates* behind it."""
    dates = sorted(set(frame.dates))
    if len(dates) < 2:
        return None
    index = max(1, min(len(dates) - 1, int(round(len(dates) * fraction))))
    return dates[index]


def split_on_date(frame: TrainingFrame, boundary: datetime) -> tuple[TrainingFrame, TrainingFrame]:
    """(known before the boundary, not yet known).

    Split on when a flight's sales existed, not on when it departed. The
    empirical forecaster is refitted with `as_of=boundary`, which drops anything
    still in the air, so splitting on departure handed the learned models rows
    their rival could not see — an overnight flight departing the day before the
    boundary lands after it.
    """
    mask = np.array([dt < boundary for dt in frame.completion_dts], dtype=bool)
    return frame.subset(mask), frame.subset(~mask)


def check_sufficient(frame: TrainingFrame) -> None:
    audit = frame.audit
    if len(frame) < MIN_TRAINING_ROWS:
        raise InsufficientData(f"only {len(frame)} usable observations")
    if audit.distinct_dates < MIN_TRAINING_DAYS:
        raise InsufficientData(f"only {audit.distinct_dates} days of history")
    if audit.distinct_flights < MIN_TRAINING_FLIGHTS:
        raise InsufficientData(f"only {audit.distinct_flights} flights of history")
    if audit.positive_sales_rows <= 0:
        raise InsufficientData("no positive sales in the eligible history")


# ---------------------------------------------------------------------------
# Comparison
# ---------------------------------------------------------------------------

@dataclass
class MethodReport:
    method: str
    metrics: dict = field(default_factory=dict)
    by_category: dict = field(default_factory=dict)
    by_route: dict = field(default_factory=dict)
    vs_empirical: dict = field(default_factory=dict)
    train_seconds: float = 0.0
    predict_seconds: float = 0.0
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _timed(fn: Callable):
    start = time.perf_counter()
    value = fn()
    return value, time.perf_counter() - start


def train_and_evaluate(
    session: Session,
    *,
    cutoff: Optional[datetime] = None,
    test_fraction: float = 0.2,
    params=None,
    include_glm: bool = True,
) -> tuple[object, dict]:
    """Backtest every method, then refit LightGBM on all eligible history.

    Returns (deployment model, report). The report's scores belong to the
    *recipe* measured on held-out dates; the returned artifact is refit on
    everything up to the cutoff and is therefore not scored in-sample here.
    """
    from . import forecast_lightgbm as lgbm  # optional dependency, imported late

    cutoff = cutoff or default_training_cutoff(session)
    if cutoff is None:
        raise InsufficientData("no flights in the database")

    full = load_training_frame(session, as_of=cutoff)
    check_sufficient(full)

    boundary = split_date_at(full, 1.0 - test_fraction)
    if boundary is None:
        raise InsufficientData("history covers too few distinct dates to hold any back")
    dev, test = split_on_date(full, boundary)
    if dev.is_empty or test.is_empty:
        raise InsufficientData("temporal split left one side empty")

    # Inner split, used only to choose how many boosting rounds to keep.
    inner_boundary = split_date_at(dev, 0.8)
    inner_train, inner_valid = split_on_date(dev, inner_boundary) if inner_boundary else (dev, None)

    reports: list[MethodReport] = []

    # --- empirical, the incumbent -------------------------------------------
    def _fit_empirical():
        f = DemandForecaster(session, as_of=boundary)
        f.train()
        return f

    empirical, t_fit = _timed(_fit_empirical)
    mu_emp, t_pred = _timed(lambda: empirical.predict_rows(test))
    reports.append(MethodReport(
        method=EMPIRICAL,
        metrics=evaluate_predictions(mu_emp, test).to_dict(),
        by_category=slice_metrics(mu_emp, test, "category"),
        by_route=slice_metrics(mu_emp, test, "route_key"),
        train_seconds=round(t_fit, 3),
        predict_seconds=round(t_pred, 3),
        note="Bin averages with a category prior. Sold-out rows read as exact demand.",
    ))

    # --- Poisson GLM, the simple challenger ---------------------------------
    if include_glm:
        try:
            glm, t_fit = _timed(lambda: PoissonGlm().fit(dev))
            mu_glm, t_pred = _timed(lambda: glm.predict_rows(test))
            reports.append(MethodReport(
                method=GLM,
                metrics=evaluate_predictions(mu_glm, test).to_dict(),
                by_category=slice_metrics(mu_glm, test, "category"),
                by_route=slice_metrics(mu_glm, test, "route_key"),
                vs_empirical=paired_delta(mu_glm, mu_emp, test),
                train_seconds=round(t_fit, 3),
                predict_seconds=round(t_pred, 3),
                note="Log-linear reference on the same censored likelihood."
                     + ("" if glm.converged else " Optimiser did not fully converge."),
            ))
        except Exception as exc:  # noqa: BLE001 — a reference model must never sink the run
            reports.append(MethodReport(method=GLM, note=f"failed: {type(exc).__name__}: {exc}"))

    # --- LightGBM ------------------------------------------------------------
    params = params or lgbm.LightGbmParams()
    backtest, t_fit = _timed(lambda: lgbm.train_model(
        inner_train, valid_frame=inner_valid, params=params
    ))
    rounds = backtest.best_iteration or params.num_boost_round
    mu_lgb, t_pred = _timed(lambda: backtest.predict_rate(test.categorical_rows, test.numeric_rows) * test.exposure)
    reports.append(MethodReport(
        method=LIGHTGBM,
        metrics=evaluate_predictions(mu_lgb, test).to_dict(),
        by_category=slice_metrics(mu_lgb, test, "category"),
        by_route=slice_metrics(mu_lgb, test, "route_key"),
        vs_empirical=paired_delta(mu_lgb, mu_emp, test),
        train_seconds=round(t_fit, 3),
        predict_seconds=round(t_pred, 3),
        note=f"Pooled model, censored Poisson objective, {rounds} boosting rounds.",
    ))

    # Deployment artifact: same recipe, refit on everything before the cutoff.
    from dataclasses import replace as _replace
    final_params = _replace(params, num_boost_round=int(rounds), early_stopping_rounds=0)
    deployment, t_final = _timed(lambda: lgbm.train_model(full, params=final_params))

    best = min(
        (r for r in reports if r.metrics.get("censored_nll") is not None),
        key=lambda r: r.metrics["censored_nll"],
        default=None,
    )
    winner = best.method if best else None
    # "Best" only counts if it is outside the noise of a date-clustered estimate.
    decisive = bool(
        winner and (winner == EMPIRICAL or next(
            (r.vs_empirical.get("distinguishable", False) for r in reports if r.method == winner), False
        ))
    )

    report = {
        "cutoff": cutoff.isoformat(),
        "validation_from": boundary.isoformat(),
        "test_fraction": test_fraction,
        "rows": {"total": len(full), "train": len(dev), "test": len(test)},
        "dataset": full.audit.to_dict(),
        "methods": [r.to_dict() for r in reports],
        "best_by_censored_nll": winner,
        "best_is_distinguishable": decisive,
        "boosting_rounds": int(rounds),
        "final_fit_seconds": round(t_final, 3),
        "data_is_synthetic": True,
        "caveats": [
            "Scores come from held-out dates of one synthetic year; they do not "
            "establish accuracy on real onboard sales.",
            "Demand is never observed. Headline errors compare predicted capped "
            "sales against actual sales; the demand-side slice covers only lines "
            "that did not sell out and is biased toward lines someone chose to stock.",
            "Rows where nothing was loaded carry no demand information and are excluded.",
            "Differences are compared per calendar date, because rows from one "
            "flight or one day are not independent observations.",
        ],
    }
    return deployment, report
