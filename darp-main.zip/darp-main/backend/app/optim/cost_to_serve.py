"""Cost-to-Serve breakdown — presentation-level costing for the result UI.

NOTE: this is *not* the objective the MILP optimises. `selection.py` builds its
own integer-pence coefficients which additionally carry warehouse zone
multipliers, spoilage, low-return pickline penalties and case-break costs.
Anything that needs to be compared against a solver result must be costed by
`solve_selection`, not here, or the comparison measures the gap between two cost
models rather than the thing being tested.

Costs (per unit unless noted, GBP):
    fuel_cost          = weight_kg × haul_burn_coeff × fuel_price
    pick_cost          = qty × pick_cost_per_unit
    pack_cost          = pack_cost_per_drawer × estimated_drawers_used
    return_cost        = unsold_units × return_handling_cost
    complexity_cost    = complexity_penalty_per_new_pickline (if loaded)
Revenue:
    expected_revenue   = expected_units_sold × retail_price
    expected_cogs      = expected_units_sold × cost_price
    expected_margin    = expected_revenue - expected_cogs
Net contribution:
    net = expected_margin - fuel_cost - pick_cost - pack_cost
                          - return_cost - complexity_cost
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from ..models import CostParams, Sku

# Shelf life at or below which unsold stock is written off rather than returned
# to the bond and re-used. Only this portion is genuinely wasted: counting a
# returned pair of sunglasses as waste would punish carrying high-margin range.
PERISHABLE_SHELF_LIFE_DAYS = 7


def is_perishable(sku: Sku) -> bool:
    return (sku.shelf_life_days or 180) <= PERISHABLE_SHELF_LIFE_DAYS


@dataclass
class CostBreakdown:
    sku_id: int
    loaded_qty: int
    expected_sold: float

    expected_revenue: float
    expected_cogs: float
    expected_margin: float

    fuel_cost: float
    pick_cost: float
    pack_cost: float
    return_cost: float
    complexity_cost: float
    total_cost_to_serve: float
    net_contribution: float

    weight_kg: float
    volume_cm3: float

    def to_dict(self) -> dict:
        return asdict(self)


def cost_to_serve(
    sku: Sku,
    *,
    loaded_qty: int,
    expected_sold: float,
    cost_params: CostParams,
    haul_burn_coeff: float,
    drawers_share: float = 0.05,  # share of one drawer this SKU notionally occupies
    is_new_pickline: bool = True,
) -> CostBreakdown:
    """Compute the structured cost-to-serve breakdown for one SKU on one flight."""
    loaded_qty = max(0, int(loaded_qty))
    expected_sold = max(0.0, min(float(expected_sold), float(loaded_qty)))

    expected_revenue = expected_sold * sku.retail_price
    expected_cogs = expected_sold * sku.cost_price
    expected_margin = expected_revenue - expected_cogs

    weight_kg = (sku.unit_weight_g / 1000.0) * loaded_qty
    volume_cm3 = sku.volume_cm3 * loaded_qty

    fuel_cost = weight_kg * haul_burn_coeff * cost_params.fuel_price_per_kg_gbp
    pick_cost = loaded_qty * cost_params.pick_cost_per_unit_gbp
    pack_cost = drawers_share * cost_params.pack_cost_per_drawer_gbp
    unsold = max(0.0, loaded_qty - expected_sold)
    return_cost = unsold * cost_params.return_handling_cost_per_unit_gbp
    complexity_cost = (
        cost_params.complexity_penalty_per_new_pickline_gbp if (loaded_qty > 0 and is_new_pickline) else 0.0
    )

    total_cts = fuel_cost + pick_cost + pack_cost + return_cost + complexity_cost
    net = expected_margin - total_cts

    return CostBreakdown(
        sku_id=sku.id,
        loaded_qty=loaded_qty,
        expected_sold=expected_sold,
        expected_revenue=expected_revenue,
        expected_cogs=expected_cogs,
        expected_margin=expected_margin,
        fuel_cost=fuel_cost,
        pick_cost=pick_cost,
        pack_cost=pack_cost,
        return_cost=return_cost,
        complexity_cost=complexity_cost,
        total_cost_to_serve=total_cts,
        net_contribution=net,
        weight_kg=weight_kg,
        volume_cm3=volume_cm3,
    )
