"""Stage 2 — SKU selection & quantity MILP (OR-Tools CP-SAT).

Generalised to **rotations**: an ordered list of legs that share one loaded
range. A single flight is a 1-leg rotation, so there is one solver code path.

Decision vars (SKU i, leg k):
    x_i    ∈ ℤ≥0   loaded units (loaded once, at the rotation origin)
    y_i    ∈ {0,1} pickline opened for SKU i
    s_{k,i}∈ ℤ≥0   expected units sold on leg k  (≤ per-leg service-level cap)
Objective (maximise, GBP × 100 = pence):
    Σ_i Σ_k margin_i · s_{k,i}                       margin on sold units
    − Σ_i (handling_i + pack_i) · x_i                pick/pack/zone handling at origin
    − Σ_i Σ_k fuel_{k,i} · carried_{k,i}             carry-over fuel (compounds per leg)
    − Σ_i (return_i + spoil_i) · (x_i − Σ_k s_{k,i}) returns + spoilage on unsold
    − Σ_i (complexity_i + lowret_i + bonded_i) · y_i pickline penalties
    − λ_case · Σ_i case_break_i                      penalty for breaking supplier cases
Constraints
    volume:   Σ vol_i · x_i ≤ η · V_drawers
    weight:   Σ w_i  · x_i ≤ W_cap                   (weight at load / origin)
    regulatory: SKU dropped if any leg's route bans its category
    min econ qty:  q_min · y_i ≤ x_i ≤ x_max · y_i
    sold ≤ loaded:  Σ_k s_{k,i} ≤ x_i
    brand rules:  Σ_{i∈cat} y_i ≥ min_skus, Σ x_i ≥ min_units  (soft in override mode)
    supplier:     Σ_{i∈sup} x_i ≥ min_units_per_flight        (soft in override mode)
    case mult:    x_i = case·n_i + rem_i, penalise breaking a full case
    pins:         x_j == q / y_j == 0 / y_j == 1               (override runs)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Optional

from ortools.sat.python import cp_model

from ..models import (
    Aircraft,
    BrandRule,
    CostParams,
    Drawer,
    Flight,
    GalleyLayout,
    RegulatoryRule,
    Route,
    Sku,
    SupplierCommitment,
)
from .forecast import ForecastResult


# ---------------------------------------------------------------------------
# Inputs / outputs
# ---------------------------------------------------------------------------

@dataclass
class SelectionParams:
    volume_efficiency_eta: float = 0.65  # plan §6.2
    retail_weight_budget_kg: float = 280.0  # cap for retail loadout
    service_level_p: float = 0.7  # p70 default, 0.9 = use p90
    min_economic_qty_default: int = 2
    complexity_penalty_scale: float = 1.0
    solver_time_limit_s: float = 10.0
    seed: int = 42
    soft_constraints: bool = False  # relax brand/supplier minima (override runs)


@dataclass
class PinSpec:
    """A planner override pinning one SKU."""
    sku_id: int
    kind: str  # force_include | force_exclude | set_qty
    qty: Optional[int] = None


@dataclass
class LegInput:
    """One leg of a rotation."""
    flight: Flight
    route: Route
    burn_coeff: float
    forecasts: dict[int, ForecastResult]  # sku_id -> per-leg forecast


@dataclass
class SelectionInputs:
    flight: Flight  # rotation origin (leg 1) — metadata / backward compat
    route: Route
    aircraft: Aircraft
    galley: GalleyLayout
    drawers: list[Drawer]
    skus: list[Sku]
    forecasts: dict[int, ForecastResult]  # leg-1 forecast (single-flight compat)
    cost_params: CostParams
    regulatory_rules: list[RegulatoryRule]
    brand_rules: list[BrandRule] = field(default_factory=list)
    supplier_commitments: list[SupplierCommitment] = field(default_factory=list)
    baseline_loaded_skus: set[int] = field(default_factory=set)
    params: SelectionParams = field(default_factory=SelectionParams)
    legs: list[LegInput] = field(default_factory=list)
    pins: list[PinSpec] = field(default_factory=list)


@dataclass
class SkuDecision:
    sku_id: int
    decision: str  # load|increase|reduce|exclude
    loaded_qty: int
    expected_sold: float
    expected_revenue: float
    expected_margin: float
    fuel_cost: float
    pick_pack_cost: float
    handling_cost: float
    spoilage_cost: float
    return_cost: float
    complexity_cost: float
    case_break_cost: float
    net_contribution: float
    net_per_kg: Optional[float]
    net_per_cm3: Optional[float]
    weight_kg: float
    volume_cm3: float
    leg_sales: dict[int, float] = field(default_factory=dict)
    pinned: bool = False


@dataclass
class SelectionResult:
    status: str
    objective_value_gbp: float
    decisions: list[SkuDecision]
    total_loaded_units: int
    total_skus: int
    total_weight_kg: float
    total_volume_cm3: float
    expected_revenue: float
    expected_net_contribution: float
    volume_capacity_cm3: float
    weight_capacity_kg: float
    solve_seconds: float
    # Per-SKU diagnostics for the explainability layer (sku_id -> dict).
    diagnostics: dict[int, dict] = field(default_factory=dict)
    # Aggregate metrics used by binding-constraint analysis.
    aggregates: dict = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def haul_burn_coeff(aircraft: Aircraft, route: Route) -> float:
    if route.haul_class == "short":
        return aircraft.fuel_burn_coeff_short
    if route.haul_class == "medium":
        return aircraft.fuel_burn_coeff_medium
    return aircraft.fuel_burn_coeff_long


# Backwards-compatible private alias.
_haul_burn_coeff = haul_burn_coeff


def _disallowed_categories(routes: Iterable[Route], rules: Iterable[RegulatoryRule]) -> set[str]:
    """Categories banned on *any* leg's route (rotation must satisfy all legs)."""
    route_ids = {r.id for r in routes}
    out: set[str] = set()
    for rule in rules:
        if rule.route_id is not None and rule.route_id not in route_ids:
            continue
        if rule.rule_type == "disallow":
            out.add(rule.sku_category)
    return out


def _zone_multiplier(cp: CostParams, zone: str) -> float:
    mults = cp.pick_zone_multipliers_json or {}
    return float(mults.get(zone, 1.0))


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------

PRICE_SCALE = 100  # GBP → pence

# Sales variables are held in hundredths of a unit. Slow-moving boutique lines
# have expected sales well below 1, so integer units would round them to zero
# and the model would never stock them.
SALES_SCALE = 100


def effective_brand_minimums(rule, cat_skus, forecasts) -> tuple[int, int]:
    """Brand-rule breadth and depth, both capped at the demand that exists.

    A range agreement commits to carrying a category, and no planner reads it as
    an instruction to load more than anyone will buy. Uncapped, the seeded rules
    demand 23 open lines on a flight with 20 units of total demand, which is a
    guaranteed loss before the optimiser makes a single choice.
    """
    demand = sum(
        float(forecasts[s.id].expected_units) for s in cat_skus if s.id in forecasts
    )
    room = max(1, int(math.ceil(demand)))
    min_skus = min(rule.min_skus, room) if rule.min_skus > 0 else 0
    min_units = max(1, min(rule.min_units, room)) if rule.min_units > 0 else 0
    return min_skus, min_units


def _poisson_tail(lam: float, x_max: int) -> tuple[list[float], list[float]]:
    """Return (g, p_gt) for Poisson demand.

    g[j]    = E[min(D, j)], the units you can expect to sell if you load j.
    p_gt[j] = P(D > j), which is the marginal gain g[j+1] - g[j].

    g is concave and saturates at lam: loading a tenth unit of a line that sells
    two is not worth a tenth unit of revenue. Capping sales at a demand quantile
    instead — the previous approach — lets the plan book revenue on its own
    safety stock.
    """
    g = [0.0] * (x_max + 1)
    p_gt: list[float] = []
    if lam <= 0.0:
        return g, [0.0] * max(0, x_max)
    pmf = math.exp(-lam)  # P(D = 0)
    cdf = pmf
    for j in range(x_max):
        tail = max(0.0, 1.0 - cdf)  # P(D > j)
        p_gt.append(tail)
        g[j + 1] = g[j] + tail
        pmf = pmf * lam / (j + 1)
        cdf += pmf
    return g, p_gt


def _poisson_quantile(lam: float, p: float) -> int:
    """Smallest k with P(D <= k) >= p — the classic service-level stock level."""
    if lam <= 0.0:
        return 0
    pmf = math.exp(-lam)
    cdf = pmf
    k = 0
    while cdf < p and k < 1000:
        k += 1
        pmf = pmf * lam / k
        cdf += pmf
    return k


def _build_legs(inp: SelectionInputs) -> list[LegInput]:
    if inp.legs:
        return inp.legs
    # Single-flight compatibility: synthesise a 1-leg rotation.
    burn = haul_burn_coeff(inp.aircraft, inp.route)
    return [LegInput(flight=inp.flight, route=inp.route, burn_coeff=burn, forecasts=inp.forecasts)]


def solve_selection(inp: SelectionInputs) -> SelectionResult:
    params = inp.params
    cp = inp.cost_params
    legs = _build_legs(inp)
    leg_indices = list(range(len(legs)))
    routes = [leg.route for leg in legs]
    disallowed = _disallowed_categories(routes, inp.regulatory_rules)
    fuel_price = cp.fuel_price_per_kg_gbp

    V_total_cm3 = sum(d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in inp.drawers)
    V_cap_cm3 = V_total_cm3 * params.volume_efficiency_eta
    W_cap_kg = min(params.retail_weight_budget_kg, inp.aircraft.max_payload_kg * 0.4)

    pins_by_sku: dict[int, PinSpec] = {p.sku_id: p for p in inp.pins}

    model = cp_model.CpModel()

    x_vars: dict[int, cp_model.IntVar] = {}
    y_vars: dict[int, cp_model.IntVar] = {}
    cum_vars: dict[int, list[cp_model.IntVar]] = {}  # sku_id -> cumulative sales through leg k

    margin_pence: dict[int, int] = {}
    return_pence: dict[int, int] = {}
    spoil_pence: dict[int, int] = {}
    handling_pence: dict[int, int] = {}   # zone pick + auth surcharge, per unit
    pack_pence: dict[int, int] = {}       # volume-share pack cost, per unit
    pickline_pence: dict[int, int] = {}   # complexity + lowret + bonded, per pickline (y)
    fuel_leg_pence: dict[int, list[int]] = {}  # sku_id -> [fuel pence per carried unit, per leg]
    weight_g: dict[int, int] = {}
    volume_cm3_int: dict[int, int] = {}
    cap_per_leg: dict[int, list[int]] = {}
    cap_total: dict[int, int] = {}
    lams_per_leg: dict[int, list[float]] = {}
    min_depth: dict[int, int] = {}

    case_pen_vars: dict[int, cp_model.IntVar] = {}

    candidate_skus: list[Sku] = []
    for sku in inp.skus:
        pin = pins_by_sku.get(sku.id)
        if sku.category in disallowed:
            continue  # regulatory bans cannot be overridden, even by a pin

        # Per-leg expected demand. Sales are bounded by E[min(D, x)] below.
        caps: list[int] = []
        lams: list[float] = []
        for leg in legs:
            fc = leg.forecasts.get(sku.id)
            lam = max(0.0, float(fc.expected_units)) if fc is not None else 0.0
            lams.append(lam)
            caps.append(int(math.ceil(lam)))
        total_cap = sum(caps)

        set_qty = pin.qty if (pin and pin.kind == "set_qty" and pin.qty is not None) else None
        # Upper bound on loaded qty: past the 99.5th percentile of demand an extra
        # unit has essentially no chance of selling. A flat multiple of the mean
        # would clip the newsvendor optimum on high-margin lines.
        x_max = max(2, _poisson_quantile(sum(lams), 0.995) + sku.min_pack_size)
        if set_qty is not None:
            x_max = max(x_max, set_qty)
        if x_max < sku.min_pack_size:
            x_max = sku.min_pack_size
        if total_cap <= 0 and set_qty is None and not (pin and pin.kind == "force_include"):
            # No demand on any leg and not pinned in — still expose as candidate so it
            # can be excluded with a reason, but cap loading at min pack.
            pass

        candidate_skus.append(sku)
        cap_per_leg[sku.id] = caps
        cap_total[sku.id] = total_cap
        lams_per_leg[sku.id] = lams

        x = model.NewIntVar(0, x_max, f"x_{sku.id}")
        y = model.NewBoolVar(f"y_{sku.id}")
        x_vars[sku.id] = x
        y_vars[sku.id] = y

        # Stock is loaded once and depletes in leg order, so what the rotation
        # sells in total is min(D_1 + ... + D_K, x). Bounding each leg against the
        # full load independently sells the same unit on every leg: two units
        # against demand of one per leg scored 1.78 where the truth is 1.46.
        # Only the cumulative figures are variables — a leg's own sales are the
        # increment between two of them, and every objective term can be written
        # from the cumulative ones directly.
        cum_vars[sku.id] = []
        running_lam = 0.0
        for k in leg_indices:
            running_lam += lams[k]
            g, p_gt = _poisson_tail(running_lam, x_max)
            ub = int(round(running_lam * SALES_SCALE))
            c = model.NewIntVar(0, max(0, ub), f"c_{sku.id}_{k}")
            # g is concave, so each secant is a valid upper bound and the set of
            # them is tight at every integer load.
            for j in range(x_max):
                slope = int(round(p_gt[j] * SALES_SCALE))
                # The exact intercept is non-negative for a concave g through the
                # origin, but rounding the slope up can drive it below zero, which
                # would forbid c=0 at x=0 and make the model infeasible. Clamping
                # only relaxes the bound, so it stays valid.
                intercept = max(0, int(round(g[j] * SALES_SCALE)) - slope * j)
                model.Add(c <= slope * x + intercept)
            if cum_vars[sku.id]:
                model.Add(c >= cum_vars[sku.id][-1])  # cumulative sales cannot fall
            cum_vars[sku.id].append(c)

        # x linked to y; minimum economic quantity.
        q_min = max(params.min_economic_qty_default, sku.min_pack_size)
        # Service level now sets how deep a stocked line is filled, rather than
        # inflating the revenue booked against it.
        service_qty = _poisson_quantile(sum(lams), params.service_level_p)
        q_min = min(x_max, max(q_min, service_qty))
        min_depth[sku.id] = q_min
        if set_qty is None:
            # An explicit quantity is a deliberate instruction; a default minimum
            # should not override it (and would make the model infeasible).
            model.Add(x >= q_min).OnlyEnforceIf(y)
        model.Add(x == 0).OnlyEnforceIf(y.Not())
        model.Add(x <= x_max * y)
        # Sold across the rotation cannot exceed loaded.
        model.Add(cum_vars[sku.id][-1] <= SALES_SCALE * x)

        # ----- coefficients (pence) -----
        margin_per_unit = max(0.0, sku.retail_price - sku.cost_price)
        margin_pence[sku.id] = int(round(margin_per_unit * PRICE_SCALE))
        return_pence[sku.id] = int(round(cp.return_handling_cost_per_unit_gbp * PRICE_SCALE))

        # Spoilage: fraction of cost lost on unsold perishables.
        reuse = float(cp.spoilage_reuse_cycle_days or 3.0)
        shelf = max(1.0, float(sku.shelf_life_days or 180))
        spoil_frac = min(1.0, reuse / shelf)
        spoil_pence[sku.id] = int(round(spoil_frac * sku.cost_price * PRICE_SCALE))

        # Handling: zone-multiplied pick + authorised-pick surcharge per unit.
        pick_unit = cp.pick_cost_per_unit_gbp * _zone_multiplier(cp, sku.warehouse_zone)
        if sku.requires_authorised_pick:
            pick_unit += cp.authorised_pick_surcharge_per_unit_gbp
        handling_pence[sku.id] = int(round(pick_unit * PRICE_SCALE))
        pack_share = (sku.volume_cm3 / max(1.0, V_cap_cm3)) * cp.pack_cost_per_drawer_gbp
        pack_pence[sku.id] = int(round(pack_share * PRICE_SCALE))

        # Per-leg fuel pence for one carried unit.
        w_kg = sku.unit_weight_g / 1000.0
        fuel_leg_pence[sku.id] = [
            int(round(w_kg * leg.burn_coeff * fuel_price * PRICE_SCALE)) for leg in legs
        ]

        # Pickline penalties (per y): complexity + low-return + bonded access.
        complexity = cp.complexity_penalty_per_new_pickline_gbp * params.complexity_penalty_scale
        best_case_margin = margin_per_unit * total_cap
        lowret = max(0.0, cp.pickline_min_expected_margin_gbp - best_case_margin)
        bonded = cp.bonded_access_surcharge_gbp if sku.bonded else 0.0
        pickline_pence[sku.id] = int(round((complexity + lowret + bonded) * PRICE_SCALE))

        weight_g[sku.id] = int(round(sku.unit_weight_g))
        volume_cm3_int[sku.id] = max(1, int(round(sku.volume_cm3)))

        # ----- case-multiple preference -----
        case = int(sku.case_size or 0)
        if case >= 2 and x_max >= case:
            n_i = model.NewIntVar(0, x_max // case + 1, f"n_{sku.id}")
            rem_i = model.NewIntVar(0, case - 1, f"rem_{sku.id}")
            model.Add(x == case * n_i + rem_i)
            brk = model.NewBoolVar(f"brk_{sku.id}")  # remainder > 0
            model.Add(rem_i >= 1).OnlyEnforceIf(brk)
            model.Add(rem_i == 0).OnlyEnforceIf(brk.Not())
            big = model.NewBoolVar(f"big_{sku.id}")  # at least one full case loaded
            model.Add(x >= case).OnlyEnforceIf(big)
            model.Add(x <= case - 1).OnlyEnforceIf(big.Not())
            pen = model.NewBoolVar(f"casepen_{sku.id}")
            model.AddBoolAnd([brk, big]).OnlyEnforceIf(pen)
            model.AddBoolOr([brk.Not(), big.Not()]).OnlyEnforceIf(pen.Not())
            case_pen_vars[sku.id] = pen

        # ----- pins -----
        if pin is not None:
            if pin.kind == "force_exclude":
                model.Add(y == 0)
            elif pin.kind == "force_include":
                model.Add(y == 1)
            elif pin.kind == "set_qty" and set_qty is not None:
                model.Add(x == set_qty)
                model.Add(y == (1 if set_qty > 0 else 0))

    # ----- capacity -----
    model.Add(sum(volume_cm3_int[s.id] * x_vars[s.id] for s in candidate_skus) <= int(V_cap_cm3))
    model.Add(sum(weight_g[s.id] * x_vars[s.id] for s in candidate_skus) <= int(W_cap_kg * 1000))

    # ----- brand rules (soft in override mode) -----
    SOFT_PENALTY = int(round(cp.complexity_penalty_per_new_pickline_gbp * 10 * PRICE_SCALE))
    slack_terms: list = []
    for rule in inp.brand_rules:
        cat_skus = [s for s in candidate_skus if s.category == rule.category]
        if not cat_skus:
            continue
        min_skus, min_units = effective_brand_minimums(rule, cat_skus, inp.forecasts)
        if min_skus > 0:
            expr = sum(y_vars[s.id] for s in cat_skus)
            if params.soft_constraints:
                sl = model.NewIntVar(0, min_skus, f"slk_brsku_{rule.id}")
                model.Add(expr + sl >= min_skus)
                slack_terms.append(sl)
            else:
                model.Add(expr >= min_skus)
        if min_units > 0:
            expr = sum(x_vars[s.id] for s in cat_skus)
            if params.soft_constraints:
                sl = model.NewIntVar(0, min_units, f"slk_brunit_{rule.id}")
                model.Add(expr + sl >= min_units)
                slack_terms.append(sl)
            else:
                model.Add(expr >= min_units)

    # ----- supplier commitments -----
    by_supplier: dict[int, int] = {}
    for c in inp.supplier_commitments:
        by_supplier[c.supplier_id] = by_supplier.get(c.supplier_id, 0) + c.min_units_per_flight
    for sup_id, min_units in by_supplier.items():
        sup_skus = [s for s in candidate_skus if s.supplier_id == sup_id]
        if sup_skus and min_units > 0:
            expr = sum(x_vars[s.id] for s in sup_skus)
            if params.soft_constraints:
                sl = model.NewIntVar(0, min_units, f"slk_sup_{sup_id}")
                model.Add(expr + sl >= min_units)
                slack_terms.append(sl)
            else:
                model.Add(expr >= min_units)

    # ----- objective -----
    # Sales vars are scaled by SALES_SCALE, so every load-based term is scaled to
    # match and the objective is expressed in pence x SALES_SCALE.
    case_break_pence = int(round(cp.case_break_penalty_gbp * PRICE_SCALE))
    obj_terms = []
    for sku in candidate_skus:
        sid = sku.id
        cums = cum_vars[sid]
        sold_total = cums[-1]
        # Margin on sold.
        obj_terms.append(margin_pence[sid] * sold_total)
        # Handling + pack on loaded.
        obj_terms.append(-(handling_pence[sid] + pack_pence[sid]) * SALES_SCALE * x_vars[sid])
        # Returns + spoilage on unsold = (x - sold_total).
        unsold_coeff = return_pence[sid] + spoil_pence[sid]
        obj_terms.append(-unsold_coeff * SALES_SCALE * x_vars[sid])
        obj_terms.append(unsold_coeff * sold_total)
        # Carry-over fuel.
        fl = fuel_leg_pence[sid]
        fsum = sum(fl)
        obj_terms.append(-fsum * SALES_SCALE * x_vars[sid])
        # Selling before leg k+1 saves carrying those units on it. Summed over
        # the per-leg increments, that is exactly the next leg's fuel on each
        # cumulative total.
        for k in leg_indices[:-1]:
            if fl[k + 1]:
                obj_terms.append(fl[k + 1] * cums[k])
        # Pickline penalties.
        obj_terms.append(-pickline_pence[sid] * SALES_SCALE * y_vars[sid])
        # Case-break penalty.
        if sid in case_pen_vars:
            obj_terms.append(-case_break_pence * SALES_SCALE * case_pen_vars[sid])

    for sl in slack_terms:
        obj_terms.append(-SOFT_PENALTY * SALES_SCALE * sl)

    model.Maximize(sum(obj_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = params.solver_time_limit_s
    solver.parameters.random_seed = params.seed
    solver.parameters.num_search_workers = 4
    status = solver.Solve(model)
    status_name = solver.StatusName(status)
    solve_s = solver.WallTime()

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return SelectionResult(
            status=status_name,
            objective_value_gbp=0.0,
            decisions=[],
            total_loaded_units=0,
            total_skus=0,
            total_weight_kg=0.0,
            total_volume_cm3=0.0,
            expected_revenue=0.0,
            expected_net_contribution=0.0,
            volume_capacity_cm3=V_cap_cm3,
            weight_capacity_kg=W_cap_kg,
            solve_seconds=solve_s,
        )

    decisions: list[SkuDecision] = []
    diagnostics: dict[int, dict] = {}
    total_units = 0
    total_skus_loaded = 0
    total_weight = 0.0
    total_volume = 0.0
    total_revenue = 0.0
    total_net = 0.0

    candidate_ids = {s.id for s in candidate_skus}
    for sku in inp.skus:
        if sku.id not in candidate_ids:
            decisions.append(_empty_decision(sku.id))
            diagnostics[sku.id] = {"candidate": False, "regulatory": sku.category in disallowed}
            continue

        x_val = int(solver.Value(x_vars[sku.id]))
        # Read the load back, then value it exactly. The solver's sales variables
        # are integers in hundredths of a unit; recomputing from the load keeps
        # that scaling out of the reported money.
        leg_sold: dict[int, float] = {}
        cumulative = 0.0
        running_lam = 0.0
        for k in leg_indices:
            running_lam += lams_per_leg[sku.id][k]
            through_leg = _poisson_tail(running_lam, x_val)[0][x_val] if x_val > 0 else 0.0
            leg_sold[k + 1] = through_leg - cumulative
            cumulative = through_leg
        s_val = cumulative
        unsold = max(0.0, x_val - s_val)

        margin_gbp = margin_pence[sku.id] * s_val / PRICE_SCALE
        return_gbp = return_pence[sku.id] * unsold / PRICE_SCALE
        spoil_gbp = spoil_pence[sku.id] * unsold / PRICE_SCALE
        handling_gbp = (handling_pence[sku.id] * x_val + pack_pence[sku.id] * x_val) / PRICE_SCALE
        # Fuel: sum over legs of carried units × per-leg fuel.
        fl = fuel_leg_pence[sku.id]
        carried_fuel_pence = 0
        carried = x_val
        for k in leg_indices:
            carried_fuel_pence += fl[k] * carried
            carried -= leg_sold.get(k + 1, 0.0)
        fuel_gbp = carried_fuel_pence / PRICE_SCALE
        complexity_gbp = (pickline_pence[sku.id] / PRICE_SCALE) if x_val > 0 else 0.0
        # The objective charges for splitting a supplier case; leaving it out of
        # the reported net made the two disagree by the penalty.
        case_break_gbp = (
            case_break_pence / PRICE_SCALE
            if sku.id in case_pen_vars and solver.Value(case_pen_vars[sku.id])
            else 0.0
        )
        net_gbp = (
            margin_gbp - return_gbp - spoil_gbp - handling_gbp - fuel_gbp
            - complexity_gbp - case_break_gbp
        )

        w_kg = (sku.unit_weight_g / 1000.0) * x_val
        v_cm3 = sku.volume_cm3 * x_val
        revenue_gbp = sku.retail_price * s_val

        if x_val <= 0:
            decision = "exclude"
        elif x_val < cap_total.get(sku.id, x_val):
            decision = "reduce"
        else:
            decision = "load"

        net_per_kg = (net_gbp / w_kg) if w_kg > 0 else None
        net_per_cm3 = (net_gbp / v_cm3) if v_cm3 > 0 else None

        decisions.append(
            SkuDecision(
                sku_id=sku.id,
                decision=decision,
                loaded_qty=x_val,
                expected_sold=float(s_val),
                expected_revenue=revenue_gbp,
                expected_margin=margin_gbp,
                fuel_cost=fuel_gbp,
                pick_pack_cost=handling_gbp,
                handling_cost=handling_gbp,
                spoilage_cost=spoil_gbp,
                return_cost=return_gbp,
                complexity_cost=complexity_gbp,
                case_break_cost=case_break_gbp,
                net_contribution=net_gbp,
                net_per_kg=net_per_kg,
                net_per_cm3=net_per_cm3,
                weight_kg=w_kg,
                volume_cm3=v_cm3,
                leg_sales=leg_sold,
                pinned=sku.id in pins_by_sku,
            )
        )

        # Unit-economics diagnostics for explain.py (per-unit pence at full cap).
        diagnostics[sku.id] = {
            "candidate": True,
            "regulatory": False,
            "cap_total": cap_total.get(sku.id, 0),
            "cap_per_leg": cap_per_leg.get(sku.id, []),
            "min_depth": min_depth.get(sku.id, 0),
            "margin_pence": margin_pence[sku.id],
            "handling_pence": handling_pence[sku.id] + pack_pence[sku.id],
            "fuel_full_pence": sum(fl),
            "spoil_pence": spoil_pence[sku.id],
            "return_pence": return_pence[sku.id],
            "pickline_pence": pickline_pence[sku.id],
            "best_case_margin_gbp": margin_pence[sku.id] * cap_total.get(sku.id, 0) / PRICE_SCALE,
            "pickline_min_margin_gbp": cp.pickline_min_expected_margin_gbp,
            "case_size": int(sku.case_size or 0),
            "loaded_qty": x_val,
            "net_per_cm3": net_per_cm3,
            "net_per_kg": net_per_kg,
            "is_perishable": (float(sku.shelf_life_days or 180) <= 14),
            "pinned": sku.id in pins_by_sku,
            "pin_kind": pins_by_sku[sku.id].kind if sku.id in pins_by_sku else None,
        }

        if x_val > 0:
            total_units += x_val
            total_skus_loaded += 1
            total_weight += w_kg
            total_volume += v_cm3
            total_revenue += revenue_gbp
            total_net += net_gbp

    aggregates = {
        "volume_used_cm3": total_volume,
        "volume_cap_cm3": V_cap_cm3,
        "weight_used_kg": total_weight,
        "weight_cap_kg": W_cap_kg,
        "n_legs": len(legs),
    }

    return SelectionResult(
        status=status_name,
        objective_value_gbp=solver.ObjectiveValue() / (PRICE_SCALE * SALES_SCALE),
        decisions=decisions,
        total_loaded_units=total_units,
        total_skus=total_skus_loaded,
        total_weight_kg=total_weight,
        total_volume_cm3=total_volume,
        expected_revenue=total_revenue,
        expected_net_contribution=total_net,
        volume_capacity_cm3=V_cap_cm3,
        weight_capacity_kg=W_cap_kg,
        solve_seconds=solve_s,
        diagnostics=diagnostics,
        aggregates=aggregates,
    )


def _empty_decision(sku_id: int) -> SkuDecision:
    return SkuDecision(
        sku_id=sku_id,
        decision="exclude",
        loaded_qty=0,
        expected_sold=0.0,
        expected_revenue=0.0,
        expected_margin=0.0,
        fuel_cost=0.0,
        pick_pack_cost=0.0,
        handling_cost=0.0,
        spoilage_cost=0.0,
        return_cost=0.0,
        complexity_cost=0.0,
        case_break_cost=0.0,
        net_contribution=0.0,
        net_per_kg=None,
        net_per_cm3=None,
        weight_kg=0.0,
        volume_cm3=0.0,
    )


def validate_pins_capacity(
    drawers: list[Drawer],
    aircraft: Aircraft,
    skus: list[Sku],
    pins: list[PinSpec],
    params: SelectionParams,
) -> Optional[dict]:
    """Pre-flight check: do force_include / set_qty pins already bust capacity?

    Returns a structured error dict if infeasible up-front, else None.
    """
    V_total = sum(d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in drawers)
    V_cap = V_total * params.volume_efficiency_eta
    W_cap = min(params.retail_weight_budget_kg, aircraft.max_payload_kg * 0.4)
    sku_by_id = {s.id: s for s in skus}

    pinned_vol = 0.0
    pinned_wt = 0.0
    for pin in pins:
        sku = sku_by_id.get(pin.sku_id)
        if sku is None:
            continue
        if pin.kind == "set_qty" and pin.qty:
            qty = pin.qty
        elif pin.kind == "force_include":
            qty = max(1, sku.min_pack_size)
        else:
            continue
        pinned_vol += sku.volume_cm3 * qty
        pinned_wt += (sku.unit_weight_g / 1000.0) * qty

    if pinned_vol > V_cap:
        return {
            "reason": "pins_exceed_capacity",
            "constraint": "volume",
            "pinned_volume_cm3": round(pinned_vol, 1),
            "volume_cap_cm3": round(V_cap, 1),
        }
    if pinned_wt > W_cap:
        return {
            "reason": "pins_exceed_capacity",
            "constraint": "weight",
            "pinned_weight_kg": round(pinned_wt, 2),
            "weight_cap_kg": round(W_cap, 2),
        }
    return None
