"""Count likelihood for demand that was observed through a finite load.

A line that sold 6 of 6 did not "demand 6" — demand was *at least* 6, and the
rest walked away. Fitting an ordinary Poisson to sales therefore learns the
stocking policy as much as the demand, and learns it lowest exactly where lines
sell out. This module supplies the pieces both the LightGBM objective and the
GLM reference need to score a row by what was actually observed:

    loaded > sold   demand seen exactly      Poisson log-pmf
    sold == loaded  demand only bounded      log P(D >= loaded)

Rows that were never loaded carry no likelihood at all and are dropped upstream
in `forecast_data`. The Poisson assumption remains an assumption: it is not a
substitute for the lost-sales data the prototype does not have.
"""

from __future__ import annotations

import numpy as np
from scipy.stats import poisson

# exp(30) already dwarfs any plausible per-flight demand; clipping the raw score
# keeps a bad boosting step from producing inf and poisoning the whole fit.
MAX_RAW_SCORE = 30.0
MIN_RATE = 1e-9
MIN_HESSIAN = 1e-6


def rate_from_raw(raw_score: np.ndarray, exposure: np.ndarray) -> np.ndarray:
    """mu = exposure * exp(raw). Models a per-passenger rate, not a raw count."""
    raw = np.clip(np.asarray(raw_score, dtype=np.float64), -MAX_RAW_SCORE, MAX_RAW_SCORE)
    mu = np.asarray(exposure, dtype=np.float64) * np.exp(raw)
    return np.maximum(mu, MIN_RATE)


def log_likelihood(
    mu: np.ndarray,
    units_sold: np.ndarray,
    loaded_units: np.ndarray,
    censored: np.ndarray,
) -> np.ndarray:
    """Per-row log-likelihood under the observation model above."""
    mu = np.maximum(np.asarray(mu, dtype=np.float64), MIN_RATE)
    y = np.asarray(units_sold, dtype=np.float64)
    loaded = np.asarray(loaded_units, dtype=np.float64)
    cens = np.asarray(censored, dtype=bool)

    out = poisson.logpmf(y, mu)
    if cens.any():
        # P(D >= loaded) = P(D > loaded - 1)
        out = np.where(cens, poisson.logsf(loaded - 1.0, mu), out)
    return out


def grad_hess(
    raw_score: np.ndarray,
    units_sold: np.ndarray,
    loaded_units: np.ndarray,
    exposure: np.ndarray,
    censored: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Gradient and Hessian of the negative log-likelihood w.r.t. the raw score.

    Uncensored rows reduce to the textbook Poisson pair (mu - y, mu). Censored
    rows differentiate log P(D >= k) using d/dmu P(D >= k) = pmf(k - 1).
    """
    mu = rate_from_raw(raw_score, exposure)
    y = np.asarray(units_sold, dtype=np.float64)
    loaded = np.asarray(loaded_units, dtype=np.float64)
    cens = np.asarray(censored, dtype=bool)

    grad = mu - y
    hess = mu.copy()

    if cens.any():
        k = loaded[cens]
        m = mu[cens]
        log_s = poisson.logsf(k - 1.0, m)          # log P(D >= k)
        log_pmf_km1 = poisson.logpmf(k - 1.0, m)
        # h = pmf(k-1) / P(D >= k)
        h = np.exp(np.clip(log_pmf_km1 - log_s, -MAX_RAW_SCORE, MAX_RAW_SCORE))

        # pmf(k-2) is zero when k == 1; logpmf returns -inf there, so exp gives 0.
        with np.errstate(divide="ignore", invalid="ignore"):
            log_pmf_km2 = poisson.logpmf(k - 2.0, m)
            ratio_km2 = np.exp(np.clip(log_pmf_km2 - log_s, -MAX_RAW_SCORE, MAX_RAW_SCORE))
        ratio_km2 = np.nan_to_num(ratio_km2, nan=0.0, posinf=0.0, neginf=0.0)

        g = -m * h
        # d/dmu of (pmf(k-1)/S) = (pmf(k-2) - pmf(k-1))/S - h^2
        dh_dmu = ratio_km2 - h - h * h
        hh = -m * h - m * m * dh_dmu

        grad[cens] = g
        hess[cens] = hh

    grad = np.nan_to_num(grad, nan=0.0, posinf=0.0, neginf=0.0)
    # The censored branch is not convex everywhere; a floor keeps boosting stable
    # without changing where the gradient points.
    hess = np.maximum(np.nan_to_num(hess, nan=MIN_HESSIAN, posinf=MIN_HESSIAN, neginf=MIN_HESSIAN), MIN_HESSIAN)
    return grad, hess


def expected_capped_sales(mu: np.ndarray, cap: np.ndarray) -> np.ndarray:
    """E[min(D, cap)] — what a plan can expect to *sell* from a finite load.

    The same quantity the selection MILP approximates with Poisson secants, so
    forecast error can be scored against observed sales on equal terms.
    """
    mu = np.maximum(np.asarray(mu, dtype=np.float64), 0.0)
    cap = np.asarray(cap, dtype=np.float64)
    out = np.zeros(mu.shape, dtype=np.float64)
    if mu.size == 0:
        return out
    highest = int(np.max(cap)) if np.max(cap) > 0 else 0
    for j in range(highest):
        mask = cap > j
        if not mask.any():
            break
        out[mask] += poisson.sf(j, mu[mask])  # P(D > j)
    return out


def poisson_quantile(mu: float, p: float) -> float:
    """Smallest k with P(D <= k) >= p."""
    if mu <= 0.0:
        return 0.0
    return float(poisson.ppf(p, mu))


def deviance(
    mu: np.ndarray,
    units_sold: np.ndarray,
    loaded_units: np.ndarray,
    censored: np.ndarray,
) -> float:
    """Mean negative log-likelihood. Lower is better; comparable across models."""
    ll = log_likelihood(mu, units_sold, loaded_units, censored)
    ll = np.nan_to_num(ll, nan=0.0, posinf=0.0, neginf=-50.0)
    return float(-np.mean(ll)) if ll.size else float("nan")
