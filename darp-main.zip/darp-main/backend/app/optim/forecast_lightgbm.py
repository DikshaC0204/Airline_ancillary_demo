"""Optional LightGBM demand forecaster.

One pooled model across every route and product, not the model-per-category the
original design sketched: rare lines have too few flights to support their own
booster, and pooling lets a fragrance borrow the shape of a season from the rest
of the catalogue while `sku_id` stays available as a categorical feature.

It learns a demand *rate per passenger* through a log link, with expected pax as
an offset, and fits the censored likelihood from `forecast_likelihood` so lines
that sold out are not read as exact demand. Anything it cannot speak to — an
unknown SKU, a non-finite prediction — is handed to the empirical forecaster
under the same cutoff and reported, never silently guessed.

LightGBM is an optional dependency. Import it lazily so the backend, the seed
and the default method all run without it installed.
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional, Sequence

import numpy as np
from sqlalchemy.orm import Session

from ..models import Flight, Sku
from . import forecast_likelihood as fl
from .forecast import LIGHTGBM, DemandForecaster, ForecastResult
from .forecast_data import (
    CATEGORICAL_INDICES,
    FEATURE_NAMES,
    FEATURE_SCHEMA_VERSION,
    LABEL_POLICY_VERSION,
    FeatureEncoder,
    TrainingFrame,
    feature_values,
    flight_context,
)

MODEL_FILE = "model.txt"
META_FILE = "meta.json"
ARTIFACT_VERSION = 1


class LightGbmUnavailable(RuntimeError):
    """LightGBM is not installed, or its native library will not load."""


def lightgbm_module():
    try:
        import lightgbm  # noqa: PLC0415 — optional dependency, probed on demand
    except Exception as exc:  # noqa: BLE001 — ImportError or a native load failure
        raise LightGbmUnavailable(str(exc)) from exc
    return lightgbm


def is_available() -> bool:
    try:
        lightgbm_module()
    except LightGbmUnavailable:
        return False
    return True


def library_version() -> Optional[str]:
    try:
        return lightgbm_module().__version__
    except LightGbmUnavailable:
        return None


# ---------------------------------------------------------------------------
# Hyperparameters
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class LightGbmParams:
    """Deliberately conservative: one synthetic year is easy to overfit."""

    num_leaves: int = 31
    max_depth: int = 8
    learning_rate: float = 0.05
    min_data_in_leaf: int = 200
    feature_fraction: float = 0.9
    bagging_fraction: float = 0.9
    bagging_freq: int = 1
    lambda_l2: float = 5.0
    cat_smooth: float = 20.0
    cat_l2: float = 10.0
    num_boost_round: int = 400
    early_stopping_rounds: int = 40
    seed: int = 42
    num_threads: int = 4

    def to_lgb(self) -> dict:
        return {
            "num_leaves": self.num_leaves,
            "max_depth": self.max_depth,
            "learning_rate": self.learning_rate,
            "min_data_in_leaf": self.min_data_in_leaf,
            "feature_fraction": self.feature_fraction,
            "bagging_fraction": self.bagging_fraction,
            "bagging_freq": self.bagging_freq,
            "lambda_l2": self.lambda_l2,
            "cat_smooth": self.cat_smooth,
            "cat_l2": self.cat_l2,
            "verbose": -1,
            # Same data and parameters must give the same model on this machine.
            "deterministic": True,
            "force_col_wise": True,
            "num_threads": self.num_threads,
            "seed": self.seed,
            "bagging_seed": self.seed,
            "feature_fraction_seed": self.seed,
            "data_random_seed": self.seed,
        }


# ---------------------------------------------------------------------------
# Trained artifact
# ---------------------------------------------------------------------------

@dataclass
class TrainedModel:
    """A fitted booster plus everything needed to feed it the same way twice."""

    booster: object
    encoder: FeatureEncoder
    base_rate: float
    params: LightGbmParams
    best_iteration: int = 0
    training_rows: int = 0
    library_version: str = ""
    feature_schema_version: int = FEATURE_SCHEMA_VERSION
    label_policy_version: int = LABEL_POLICY_VERSION
    artifact_version: int = ARTIFACT_VERSION

    def known_sku_ids(self) -> set[int]:
        return {int(k) for k in self.encoder.vocabularies.get("sku_id", {})}

    def predict_rate(
        self,
        categorical_rows: Sequence[Sequence[str]],
        numeric_rows: Sequence[Sequence[float]],
    ) -> np.ndarray:
        """Demand per passenger for each row."""
        if not categorical_rows:
            return np.zeros(0, dtype=np.float64)
        matrix = self.encoder.matrix(categorical_rows, numeric_rows)
        raw = np.asarray(
            self.booster.predict(matrix, raw_score=True, num_iteration=self.best_iteration or None),
            dtype=np.float64,
        )
        raw = np.clip(raw, -fl.MAX_RAW_SCORE, fl.MAX_RAW_SCORE)
        return self.base_rate * np.exp(raw)

    # ----- persistence -----

    def save(self, directory: Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.booster.save_model(
            str(directory / MODEL_FILE), num_iteration=self.best_iteration or None
        )
        meta = {
            "artifact_version": self.artifact_version,
            "feature_schema_version": self.feature_schema_version,
            "label_policy_version": self.label_policy_version,
            "base_rate": self.base_rate,
            "best_iteration": self.best_iteration,
            "training_rows": self.training_rows,
            "library_version": self.library_version,
            "feature_names": list(FEATURE_NAMES),
            "params": asdict(self.params),
            "encoder": self.encoder.to_dict(),
        }
        (directory / META_FILE).write_text(json.dumps(meta, indent=2, sort_keys=True), encoding="utf-8")

    @classmethod
    def load(cls, directory: Path) -> "TrainedModel":
        lgb = lightgbm_module()
        directory = Path(directory)
        meta = json.loads((directory / META_FILE).read_text(encoding="utf-8"))

        if int(meta.get("artifact_version", 0)) != ARTIFACT_VERSION:
            raise LightGbmUnavailable(
                f"model artifact version {meta.get('artifact_version')} is not {ARTIFACT_VERSION}"
            )
        if list(meta.get("feature_names", [])) != list(FEATURE_NAMES):
            raise LightGbmUnavailable("model was trained on a different feature set")
        if int(meta.get("label_policy_version", 0)) != LABEL_POLICY_VERSION:
            raise LightGbmUnavailable("model was trained under a different label policy")

        booster = lgb.Booster(model_file=str(directory / MODEL_FILE))
        return cls(
            booster=booster,
            encoder=FeatureEncoder.from_dict(meta["encoder"]),
            base_rate=float(meta["base_rate"]),
            params=LightGbmParams(**meta.get("params", {})),
            best_iteration=int(meta.get("best_iteration", 0)),
            training_rows=int(meta.get("training_rows", 0)),
            library_version=str(meta.get("library_version", "")),
            feature_schema_version=int(meta["feature_schema_version"]),
            label_policy_version=int(meta["label_policy_version"]),
        )


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def _base_rate(frame: TrainingFrame) -> float:
    exposure = float(np.sum(frame.exposure))
    sold = float(np.sum(frame.units_sold))
    if exposure <= 0 or sold <= 0:
        return 1e-4
    return max(sold / exposure, 1e-6)


def _dataset(lgb, frame: TrainingFrame, encoder: FeatureEncoder, base_rate: float, reference=None):
    matrix = encoder.matrix(frame.categorical_rows, frame.numeric_rows)
    data = lgb.Dataset(
        matrix,
        label=frame.units_sold,
        # Offset: the model only has to learn departures from the average rate,
        # which also keeps the first boosting step from starting absurdly high.
        init_score=np.log(np.maximum(frame.exposure * base_rate, fl.MIN_RATE)),
        categorical_feature=list(CATEGORICAL_INDICES),
        feature_name=list(FEATURE_NAMES),
        free_raw_data=False,
        reference=reference,
        params={"verbose": -1},
    )
    # Carried so the objective and metric can see how each row was observed.
    data.loaded_units = frame.loaded_units
    data.censored = frame.censored
    return data


def _objective(preds, dataset):
    y = dataset.get_label()
    ones = np.ones_like(y)
    # preds already include init_score, so exp(preds) is the mean directly.
    return fl.grad_hess(preds, y, dataset.loaded_units, ones, dataset.censored)


def _metric(preds, dataset):
    y = dataset.get_label()
    mu = np.exp(np.clip(preds, -fl.MAX_RAW_SCORE, fl.MAX_RAW_SCORE))
    return "censored_nll", fl.deviance(mu, y, dataset.loaded_units, dataset.censored), False


def train_model(
    frame: TrainingFrame,
    *,
    valid_frame: Optional[TrainingFrame] = None,
    params: Optional[LightGbmParams] = None,
) -> TrainedModel:
    """Fit a booster on `frame`, early-stopping on `valid_frame` when given."""
    lgb = lightgbm_module()
    params = params or LightGbmParams()
    if frame.is_empty:
        raise ValueError("cannot train on an empty training frame")

    encoder = FeatureEncoder.fit(frame.categorical_rows)
    base_rate = _base_rate(frame)
    train_set = _dataset(lgb, frame, encoder, base_rate)

    valid_sets, callbacks = [], []
    if valid_frame is not None and not valid_frame.is_empty:
        valid_sets.append(_dataset(lgb, valid_frame, encoder, base_rate, reference=train_set))
        callbacks.append(lgb.early_stopping(params.early_stopping_rounds, verbose=False))

    lgb_params = params.to_lgb()
    lgb_params["objective"] = _objective

    booster = lgb.train(
        lgb_params,
        train_set,
        num_boost_round=params.num_boost_round,
        valid_sets=valid_sets or None,
        feval=_metric if valid_sets else None,
        callbacks=callbacks or None,
    )

    best = int(getattr(booster, "best_iteration", 0) or 0)
    return TrainedModel(
        booster=booster,
        encoder=encoder,
        base_rate=base_rate,
        params=params,
        best_iteration=best,
        training_rows=len(frame),
        library_version=lgb.__version__,
    )


# ---------------------------------------------------------------------------
# Provider
# ---------------------------------------------------------------------------

@dataclass
class FallbackReport:
    """How much of a prediction the model actually produced."""

    unknown_sku: int = 0
    invalid_prediction: int = 0
    requested_cold_start: int = 0

    @property
    def total(self) -> int:
        return self.unknown_sku + self.invalid_prediction + self.requested_cold_start

    def to_dict(self) -> dict:
        return asdict(self) | {"total": self.total}


class LightGbmForecaster:
    """Serves a trained model, with the empirical forecaster behind it."""

    method = LIGHTGBM

    def __init__(
        self,
        session: Session,
        model: TrainedModel,
        *,
        as_of: Optional[datetime] = None,
        exclude_flight_ids: Iterable[int] = (),
        fallback: Optional[DemandForecaster] = None,
    ) -> None:
        self.session = session
        self.model = model
        self.as_of = as_of
        self.fallback = fallback or DemandForecaster(
            session, as_of=as_of, exclude_flight_ids=exclude_flight_ids
        )
        self.fallbacks = FallbackReport()
        self._known_skus: set[int] = set()

    def train(self) -> None:
        """No fitting here — the artifact is trained from Settings, not per run."""
        self.fallback.train()
        self._known_skus = self.model.known_sku_ids()

    def predict_flight(
        self,
        flight: Flight,
        skus: Iterable[Sku],
        *,
        cold_start_skus: Optional[set[int]] = None,
    ) -> list[ForecastResult]:
        if not self._known_skus:
            self.train()

        sku_list = list(skus)
        cold_start_skus = cold_start_skus or set()
        ctx = flight_context(flight)
        pax = max(0, ctx.expected_pax)

        modelled: list[Sku] = []
        deferred: list[Sku] = []
        for sku in sku_list:
            if sku.id in cold_start_skus:
                self.fallbacks.requested_cold_start += 1
                deferred.append(sku)
            elif sku.id not in self._known_skus:
                self.fallbacks.unknown_sku += 1
                deferred.append(sku)
            else:
                modelled.append(sku)

        by_sku: dict[int, ForecastResult] = {}

        if modelled:
            cats, nums = [], []
            for sku in modelled:
                c, n = feature_values(ctx, sku)
                cats.append(c)
                nums.append(n)
            rates = self.model.predict_rate(cats, nums)
            for sku, rate in zip(modelled, rates):
                mu = float(rate) * pax
                if not math.isfinite(mu) or mu < 0.0:
                    self.fallbacks.invalid_prediction += 1
                    deferred.append(sku)
                    continue
                by_sku[sku.id] = self._result(sku.id, mu)

        if deferred:
            for res in self.fallback.predict_flight(flight, deferred):
                res.method = f"{LIGHTGBM}:{res.method}_fallback"
                by_sku[res.sku_id] = res

        return [by_sku[s.id] for s in sku_list if s.id in by_sku]

    def _result(self, sku_id: int, mu: float) -> ForecastResult:
        # Prediction quantiles of the demand count itself, not a confidence
        # interval on the fitted rate. The median is integral; the mean is not.
        return ForecastResult(
            sku_id=sku_id,
            expected_units=mu,
            p10_units=fl.poisson_quantile(mu, 0.10),
            p50_units=fl.poisson_quantile(mu, 0.50),
            p90_units=fl.poisson_quantile(mu, 0.90),
            history_rows=self.model.training_rows,
            method=self.method,
            cold_start=False,
        )
