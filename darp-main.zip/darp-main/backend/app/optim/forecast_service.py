"""Forecast method selection, model training jobs, and fallback policy.

The rules this module exists to enforce:

*   Training a model and *using* it are separate decisions. A finished fit
    becomes a candidate; someone has to choose it.
*   A model may only forecast flights that departed after everything it learned
    from. A model trained last week cannot be pointed at a flight from last year
    and called a prediction.
*   When the chosen method cannot be served — library missing, nothing trained,
    history changed underneath it — planning continues on the empirical model
    and says so. A run never silently claims a method it did not use.
"""

from __future__ import annotations

import logging
import shutil
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings as app_settings
from ..db import SessionLocal
from ..models import ApplicationSettings, ForecastTrainingJob
from .forecast import EMPIRICAL, LIGHTGBM, DemandForecaster
from .forecast_data import dataset_fingerprint, default_training_cutoff, history_span

log = logging.getLogger(__name__)

METHODS = (EMPIRICAL, LIGHTGBM)

QUEUED, TRAINING, EVALUATING = "queued", "training", "evaluating"
SUCCEEDED, FAILED, INTERRUPTED = "succeeded", "failed", "interrupted"
ACTIVE_STATES = (QUEUED, TRAINING, EVALUATING)

READY, STALE, MISSING, UNAVAILABLE = "ready", "stale", "missing", "unavailable"

# Why a run did not get the method it asked for.
FALLBACK_LIBRARY_MISSING = "lightgbm_not_installed"
FALLBACK_NO_MODEL = "no_trained_model_selected"
FALLBACK_STALE = "model_trained_on_different_data"
FALLBACK_NOT_ELIGIBLE = "model_saw_data_after_this_flight"
FALLBACK_LOAD_FAILED = "model_failed_to_load"

_training_lock = threading.Lock()
_model_cache: dict[str, object] = {}


class TrainingConflict(RuntimeError):
    """A training job is already running."""


class SettingsConflict(RuntimeError):
    """The requested method cannot be served right now."""


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

def get_settings(session: Session) -> ApplicationSettings:
    row = session.get(ApplicationSettings, 1)
    if row is None:
        row = ApplicationSettings(id=1, forecast_method=EMPIRICAL, updated_at=datetime.utcnow())
        session.add(row)
        session.commit()
        session.refresh(row)
    return row


def artifact_dir(model_id: str) -> Path:
    return Path(app_settings.model_dir) / model_id


def _succeeded_job(session: Session, model_id: str) -> Optional[ForecastTrainingJob]:
    return session.execute(
        select(ForecastTrainingJob)
        .where(ForecastTrainingJob.model_id == model_id, ForecastTrainingJob.state == SUCCEEDED)
        .order_by(ForecastTrainingJob.id.desc())
    ).scalars().first()


def candidate_model_id(session: Session, *, fingerprint: Optional[str] = None) -> Optional[str]:
    """The model a LightGBM selection would use.

    A finished job does not switch planning over by itself, but once someone
    does choose LightGBM there is no sense making them name the model they just
    trained — the newest successful one is what they mean. The same applies when
    the pinned model has gone stale: holding on to it made retraining a dead end,
    because the new model was ready and the only selectable one was not.
    """
    row = get_settings(session)
    newest = session.execute(
        select(ForecastTrainingJob)
        .where(ForecastTrainingJob.state == SUCCEEDED)
        .order_by(ForecastTrainingJob.id.desc())
    ).scalars().first()

    active = row.active_model_id
    if not active:
        return newest.model_id if newest else None
    if newest is None or newest.model_id == active:
        return active

    current = fingerprint if fingerprint is not None else dataset_fingerprint(session)
    active_job = _succeeded_job(session, active)
    active_usable = (
        active_job is not None
        and active_job.data_fingerprint == current
        and (artifact_dir(active) / "meta.json").exists()
    )
    if not active_usable and newest.data_fingerprint == current:
        return newest.model_id
    return active


def model_status(session: Session, model_id: Optional[str], *, fingerprint: Optional[str] = None) -> dict:
    """Whether a trained artifact is usable, and against which data."""
    if not model_id:
        return {"model_id": None, "state": MISSING}
    job = _succeeded_job(session, model_id)
    if job is None or not (artifact_dir(model_id) / "meta.json").exists():
        return {"model_id": model_id, "state": MISSING}

    current = fingerprint if fingerprint is not None else dataset_fingerprint(session)
    fresh = job.data_fingerprint == current
    return {
        "model_id": model_id,
        "state": READY if fresh else STALE,
        "trained_at": job.finished_at,
        "information_cutoff": job.information_cutoff,
        "data_fingerprint": job.data_fingerprint,
        "rows": (job.report_json or {}).get("rows", {}).get("total"),
    }


def available_methods(session: Session, *, fingerprint: Optional[str] = None) -> list[dict]:
    from .forecast_lightgbm import is_available, library_version

    out = [{
        "method": EMPIRICAL,
        "label": "Empirical (default)",
        "available": True,
        "state": READY,
        "detail": "Bin averages with a category prior. No training step.",
    }]

    if not is_available():
        out.append({
            "method": LIGHTGBM,
            "label": "LightGBM (experimental)",
            "available": False,
            "state": UNAVAILABLE,
            "detail": "Not installed. Install the 'forecasting' extra to enable it.",
        })
        return out

    current = get_settings(session)
    status = model_status(
        session, candidate_model_id(session, fingerprint=fingerprint), fingerprint=fingerprint
    )
    out.append({
        "method": LIGHTGBM,
        "label": "LightGBM (experimental)",
        "available": status["state"] == READY,
        "state": status["state"],
        "library_version": library_version(),
        "detail": {
            READY: "Trained and matching the current history.",
            STALE: "The history changed since this model was trained. Retrain to use it.",
            MISSING: "No trained model selected yet.",
        }.get(status["state"], ""),
        "model": status,
    })
    return out


def set_method(session: Session, method: str, *, model_id: Optional[str] = None) -> ApplicationSettings:
    if method not in METHODS:
        raise ValueError(f"unknown forecast method {method!r}")

    row = get_settings(session)
    if method == LIGHTGBM:
        candidate = model_id or candidate_model_id(session)
        status = model_status(session, candidate)
        if status["state"] != READY:
            raise SettingsConflict(
                f"cannot select LightGBM: model is {status['state']}"
            )
        row.active_model_id = candidate
    elif model_id is not None:
        row.active_model_id = model_id

    row.forecast_method = method
    row.updated_at = datetime.utcnow()
    row.revision = (row.revision or 0) + 1
    session.commit()
    session.refresh(row)
    return row


# ---------------------------------------------------------------------------
# Training jobs
# ---------------------------------------------------------------------------

def active_job(session: Session) -> Optional[ForecastTrainingJob]:
    return session.execute(
        select(ForecastTrainingJob)
        .where(ForecastTrainingJob.state.in_(ACTIVE_STATES))
        .order_by(ForecastTrainingJob.id.desc())
    ).scalars().first()


def latest_job(session: Session) -> Optional[ForecastTrainingJob]:
    return session.execute(
        select(ForecastTrainingJob).order_by(ForecastTrainingJob.id.desc())
    ).scalars().first()


def recover_interrupted_jobs(session: Session) -> int:
    """A job cannot survive a restart, so do not let one look alive forever."""
    stuck = session.execute(
        select(ForecastTrainingJob).where(ForecastTrainingJob.state.in_(ACTIVE_STATES))
    ).scalars().all()
    for job in stuck:
        job.state = INTERRUPTED
        job.message = "Interrupted by a server restart."
        job.finished_at = datetime.utcnow()
    if stuck:
        session.commit()
    return len(stuck)


def start_training(
    session: Session,
    *,
    cutoff: Optional[datetime] = None,
    spawn: bool = True,
) -> ForecastTrainingJob:
    from .forecast_lightgbm import is_available

    if not is_available():
        raise SettingsConflict("LightGBM is not installed")
    if active_job(session) is not None:
        raise TrainingConflict("a training job is already running")

    cutoff = cutoff or default_training_cutoff(session)
    if cutoff is None:
        raise SettingsConflict("there is no flight history to train on")

    job = ForecastTrainingJob(
        model_id=uuid.uuid4().hex[:16],
        state=QUEUED,
        progress_pct=0,
        message="Queued",
        requested_cutoff=cutoff,
        created_at=datetime.utcnow(),
    )
    session.add(job)
    session.commit()
    session.refresh(job)

    if spawn:
        threading.Thread(
            target=run_training_job, args=(job.id,), name=f"forecast-train-{job.id}", daemon=True
        ).start()
    return job


def run_training_job(job_id: int) -> None:
    """Fit and score a model on its own session, off the request path."""
    from . import forecast_evaluation as fe
    from .forecast_lightgbm import LightGbmParams

    if not _training_lock.acquire(blocking=False):
        with SessionLocal() as s:
            _fail(s, job_id, "another training job is already running")
        return

    session = SessionLocal()
    try:
        job = session.get(ForecastTrainingJob, job_id)
        if job is None:
            return
        job.state = TRAINING
        job.started_at = datetime.utcnow()
        job.progress_pct = 10
        job.message = "Reading eligible history"
        session.commit()

        fingerprint = dataset_fingerprint(session)

        job.state = EVALUATING
        job.progress_pct = 30
        job.message = "Training and scoring against held-out dates"
        session.commit()

        model, report = fe.train_and_evaluate(
            session,
            cutoff=job.requested_cutoff,
            params=LightGbmParams(
                seed=app_settings.arp_seed, num_threads=app_settings.arp_training_threads
            ),
        )

        job.progress_pct = 85
        job.message = "Saving model"
        session.commit()

        _publish(job.model_id, model)

        job.state = SUCCEEDED
        job.progress_pct = 100
        job.data_fingerprint = fingerprint
        job.information_cutoff = job.requested_cutoff
        job.report_json = report
        job.message = "Trained. Select it in Settings to use it for planning."
        job.finished_at = datetime.utcnow()
        session.commit()
    except Exception as exc:  # noqa: BLE001 — the job row is the error channel
        log.exception("forecast training job %s failed", job_id)
        _fail(session, job_id, f"{type(exc).__name__}: {exc}")
    finally:
        session.close()
        _training_lock.release()


def _publish(model_id: str, model) -> None:
    """Write to a staging directory, then move it into place in one step.

    A half-written model directory must never be discoverable as ready.
    """
    final = artifact_dir(model_id)
    staging = final.with_name(final.name + ".staging")
    if staging.exists():
        shutil.rmtree(staging)
    model.save(staging)
    if final.exists():
        shutil.rmtree(final)
    staging.rename(final)
    _model_cache.pop(model_id, None)


def _fail(session: Session, job_id: int, message: str) -> None:
    job = session.get(ForecastTrainingJob, job_id)
    if job is None:
        return
    job.state = FAILED
    job.error = message
    job.message = "Training failed"
    job.finished_at = datetime.utcnow()
    session.commit()


# ---------------------------------------------------------------------------
# Resolving a method for one run
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ForecastContext:
    """The forecasting decision for a run, fixed before the run starts."""

    requested_method: str
    effective_method: str
    as_of: datetime
    model_id: Optional[str] = None
    information_cutoff: Optional[datetime] = None
    fallback_reason: Optional[str] = None
    exclude_flight_ids: tuple[int, ...] = ()
    data_fingerprint: Optional[str] = None

    @property
    def did_fall_back(self) -> bool:
        return self.fallback_reason is not None

    def to_dict(self) -> dict:
        return {
            "requested_method": self.requested_method,
            "effective_method": self.effective_method,
            "as_of": self.as_of.isoformat(),
            "model_id": self.model_id,
            "information_cutoff": (
                self.information_cutoff.isoformat() if self.information_cutoff else None
            ),
            "fallback_reason": self.fallback_reason,
            "excluded_flight_ids": list(self.exclude_flight_ids),
            "data_fingerprint": self.data_fingerprint,
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "ForecastContext":
        def _dt(value):
            return datetime.fromisoformat(value) if value else None

        return cls(
            requested_method=payload.get("requested_method", EMPIRICAL),
            effective_method=payload.get("effective_method", EMPIRICAL),
            as_of=_dt(payload.get("as_of")) or datetime.utcnow(),
            model_id=payload.get("model_id"),
            information_cutoff=_dt(payload.get("information_cutoff")),
            fallback_reason=payload.get("fallback_reason"),
            exclude_flight_ids=tuple(payload.get("excluded_flight_ids") or ()),
            data_fingerprint=payload.get("data_fingerprint"),
        )


def resolve_context(
    session: Session,
    *,
    target_departure: datetime,
    requested_method: Optional[str] = None,
    exclude_flight_ids: Iterable[int] = (),
) -> ForecastContext:
    """Decide, once, what this run will forecast with."""
    requested = requested_method or get_settings(session).forecast_method
    if requested not in METHODS:
        requested = EMPIRICAL

    # Never read sales that did not exist when this flight was planned.
    as_of = min(datetime.utcnow(), target_departure)
    excluded = tuple(int(f) for f in exclude_flight_ids)

    def empirical(reason: Optional[str] = None) -> ForecastContext:
        return ForecastContext(
            requested_method=requested,
            effective_method=EMPIRICAL,
            as_of=as_of,
            fallback_reason=reason,
            exclude_flight_ids=excluded,
        )

    if requested == EMPIRICAL:
        return empirical()

    from .forecast_lightgbm import is_available

    if not is_available():
        return empirical(FALLBACK_LIBRARY_MISSING)

    current = get_settings(session)
    status = model_status(session, current.active_model_id)
    if status["state"] == MISSING:
        return empirical(FALLBACK_NO_MODEL)
    if status["state"] == STALE:
        return empirical(FALLBACK_STALE)
    cutoff = status.get("information_cutoff")
    if cutoff is not None and cutoff >= target_departure:
        # The model already knows how this flight turned out.
        return empirical(FALLBACK_NOT_ELIGIBLE)

    return ForecastContext(
        requested_method=requested,
        effective_method=LIGHTGBM,
        as_of=as_of,
        model_id=current.active_model_id,
        information_cutoff=cutoff,
        exclude_flight_ids=excluded,
        data_fingerprint=status.get("data_fingerprint"),
    )


def load_model(model_id: str):
    from .forecast_lightgbm import TrainedModel

    cached = _model_cache.get(model_id)
    if cached is not None:
        return cached
    model = TrainedModel.load(artifact_dir(model_id))
    _model_cache[model_id] = model
    return model


def build_forecaster(session: Session, context: ForecastContext):
    """Instantiate the provider this context resolved to.

    Returns (provider, context) because loading a saved model can still fail
    here, and the run has to record that it fell back.
    """
    if context.effective_method == LIGHTGBM and context.model_id:
        from .forecast_lightgbm import LightGbmForecaster

        try:
            model = load_model(context.model_id)
            return LightGbmForecaster(
                session, model,
                as_of=context.as_of,
                exclude_flight_ids=context.exclude_flight_ids,
            ), context
        except Exception as exc:  # noqa: BLE001 — degrade visibly, never crash a run
            log.warning("falling back to the empirical forecaster: %s", exc)
            context = ForecastContext(
                requested_method=context.requested_method,
                effective_method=EMPIRICAL,
                as_of=context.as_of,
                fallback_reason=FALLBACK_LOAD_FAILED,
                exclude_flight_ids=context.exclude_flight_ids,
            )

    return DemandForecaster(
        session, as_of=context.as_of, exclude_flight_ids=context.exclude_flight_ids
    ), context


def clear_caches() -> None:
    _model_cache.clear()


def dataset_overview(session: Session) -> dict:
    first, last = history_span(session)
    return {
        "history_from": first,
        "history_to": last,
        "recommended_cutoff": default_training_cutoff(session),
    }
