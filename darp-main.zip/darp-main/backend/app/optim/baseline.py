"""Manual-plan baseline — the counterfactual the optimiser is measured against.

Every headline KPI on the dashboard ("expected uplift vs today's manual plan",
"waste reduction") is a *comparison*, so it is only as defensible as the thing
being compared to. Two properties make it defensible here, and both were got
wrong before:

1.  The stocking rule is the one the synthetic sales history was generated from
    (`seed/sales_history.py`): stock every line the route allows and that can pay
    for its own pickline, at `OVERLOAD_FACTOR x` forecast demand. That is the
    classic "load it generously so we never sell out" heuristic, and it is what
    produced the `unsold_units` in the history, so it is consistent with the data
    rather than a strawman.

2.  It is *costed by the optimiser's own objective*, by pinning the manual
    quantities and letting `solve_selection` evaluate them. Scoring the baseline
    with a separate cost function silently handed it cheaper costs — no zone
    multipliers, no spoilage, no low-return penalty — and the resulting uplift
    said more about the difference between two cost models than about the
    optimiser.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

from .cost_to_serve import is_perishable
from .selection import PinSpec, SelectionInputs, effective_brand_minimums, solve_selection

# What a planner loads relative to forecast demand, and the turnover a line must
# show to be carried at all. These define the manual plan, and the sales history
# is generated from the very same rule (seed/sales_history.py) so the baseline is
# the plan that actually produced the observed data rather than an invention.
MANUAL_STOCK_BUFFER = 1.25
MIN_TURNOVER_PER_FLIGHT_GBP = 1.0

# The warehouse will not open a pickline to pick a single unit. Applies to the
# manual plan and the optimiser alike — see SelectionParams.min_economic_qty_default.
MIN_PICK_UNITS = 2

# Retained for callers that still refer to the old name.
OVERLOAD_FACTOR = MANUAL_STOCK_BUFFER


def manual_load_qty(sku, expected_units: float, *, buffer: float = MANUAL_STOCK_BUFFER) -> int:
    """Units a planner would load for one line on one flight. 0 means not carried.

    Single source of truth: the seed calls this to build the history, and the
    baseline calls it to reconstruct the plan being measured against.
    """
    if expected_units * sku.retail_price < MIN_TURNOVER_PER_FLIGHT_GBP:
        return 0
    return max(MIN_PICK_UNITS, sku.min_pack_size, int(math.ceil(expected_units * buffer)))


@dataclass
class BaselineResult:
    """A costed manual plan for one flight."""

    status: str
    total_skus: int
    total_units: int
    total_weight_kg: float
    expected_revenue: float
    net_contribution: float
    expected_sold_units: float
    unsold_units: float
    waste_units: float  # unsold stock that is written off rather than returned
    trimmed_skus: int  # lines dropped to respect the weight budget

    @property
    def waste_rate(self) -> float:
        """Unsold units as a share of units loaded."""
        if self.total_units <= 0:
            return 0.0
        return self.unsold_units / self.total_units


def rotation_demand(inp: SelectionInputs) -> dict[int, float]:
    """Forecast units per SKU across every leg the load has to cover.

    The optimiser stocks one range for the whole rotation, so a baseline built
    from the origin leg alone was provisioning a fraction of the trip and losing
    on volume it was never given — flattering the uplift rather than testing it.
    """
    legs = inp.legs or []
    if len(legs) <= 1:
        return {
            sku_id: max(0.0, float(fc.expected_units))
            for sku_id, fc in inp.forecasts.items()
        }

    totals: dict[int, float] = {}
    for leg in legs:
        for sku_id, fc in leg.forecasts.items():
            totals[sku_id] = totals.get(sku_id, 0.0) + max(0.0, float(fc.expected_units))
    return totals


def plan_manual_loads(
    inp: SelectionInputs,
    *,
    overload_factor: float = MANUAL_STOCK_BUFFER,
) -> tuple[dict[int, int], int]:
    """Decide what a human planner would load. Returns (loads, trimmed_count)."""
    params = inp.params
    disallowed = _disallowed(inp)
    demand = rotation_demand(inp)

    loads: dict[int, int] = {}
    for sku in inp.skus:
        if sku.category in disallowed:
            continue
        qty = manual_load_qty(sku, demand.get(sku.id, 0.0), buffer=overload_factor)
        if qty > 0:
            loads[sku.id] = qty

    _apply_brand_commitments(inp, loads, disallowed, demand)

    # Trim to the same physical galley the optimiser must fit, best margin density
    # first. Volume is what actually binds in a cart, so trimming on weight alone
    # leaves a "manual plan" that could never be loaded — and an uplift measured
    # against a plan that cannot fly is not an uplift.
    trimmed = 0
    by_id = {s.id: s for s in inp.skus}
    weight_budget = params.retail_weight_budget_kg
    volume_budget = sum(
        d.internal_l_mm * d.internal_w_mm * d.internal_h_mm / 1000.0 for d in inp.drawers
    ) * params.volume_efficiency_eta

    def fits(kg: float, cm3: float) -> bool:
        return (not weight_budget or kg <= weight_budget) and (
            not volume_budget or cm3 <= volume_budget
        )

    total_kg = sum((by_id[i].unit_weight_g / 1000.0) * q for i, q in loads.items())
    total_cm3 = sum(by_id[i].volume_cm3 * q for i, q in loads.items())
    if not fits(total_kg, total_cm3):
        ranked = sorted(
            loads.items(),
            key=lambda kv: _margin_per_cm3(by_id[kv[0]], kv[1], demand),
            reverse=True,
        )
        kept: dict[int, int] = {}
        run_kg = run_cm3 = 0.0
        for sku_id, qty in ranked:
            sku = by_id[sku_id]
            kg = (sku.unit_weight_g / 1000.0) * qty
            cm3 = sku.volume_cm3 * qty
            if not fits(run_kg + kg, run_cm3 + cm3):
                trimmed += 1
                continue
            kept[sku_id] = qty
            run_kg += kg
            run_cm3 += cm3
        loads = kept

    return loads, trimmed


def compute_baseline(
    inp: SelectionInputs,
    *,
    overload_factor: float = MANUAL_STOCK_BUFFER,
) -> BaselineResult:
    """Cost the manual plan using the optimiser's own objective."""
    loads, trimmed = plan_manual_loads(inp, overload_factor=overload_factor)

    # Pin every SKU so the solver evaluates this exact plan rather than improving
    # on it. Commercial rules go soft: the manual plan may breach them and be
    # charged for it, rather than rendering the evaluation infeasible.
    pins = [
        PinSpec(sku_id=sku.id, kind="set_qty", qty=loads.get(sku.id, 0))
        for sku in inp.skus
    ]
    pinned = replace(
        inp,
        pins=pins,
        params=replace(inp.params, soft_constraints=True),
    )
    res = solve_selection(pinned)

    sold = sum(d.expected_sold for d in res.decisions)
    by_id = {s.id: s for s in inp.skus}
    waste = sum(
        max(0.0, d.loaded_qty - d.expected_sold)
        for d in res.decisions
        if d.sku_id in by_id and is_perishable(by_id[d.sku_id])
    )
    return BaselineResult(
        status=res.status,
        total_skus=res.total_skus,
        total_units=res.total_loaded_units,
        total_weight_kg=res.total_weight_kg,
        expected_revenue=res.expected_revenue,
        net_contribution=res.expected_net_contribution,
        expected_sold_units=sold,
        unsold_units=max(0.0, res.total_loaded_units - sold),
        waste_units=waste,
        trimmed_skus=trimmed,
    )


def _disallowed(inp: SelectionInputs) -> set[str]:
    route_ids = {leg.route.id for leg in inp.legs} or {inp.route.id}
    out: set[str] = set()
    for rule in inp.regulatory_rules:
        if rule.route_id is not None and rule.route_id not in route_ids:
            continue
        if rule.rule_type == "disallow":
            out.add(rule.sku_category)
    return out


def _turnover(sku, demand: dict[int, float]) -> float:
    return demand.get(sku.id, 0.0) * sku.retail_price


def _apply_brand_commitments(
    inp: SelectionInputs,
    loads: dict[int, int],
    disallowed: set[str],
    demand: dict[int, float],
) -> None:
    """Top the manual plan up to the same range commitments the optimiser must meet.

    Brand minimums are contractual, so a planner honours them too. Without this
    the baseline is evaluated with those rules soft while the optimiser has them
    hard, and the baseline wins on small flights simply by skipping commitments
    the optimiser is not allowed to skip.
    """
    pax = inp.flight.expected_pax or 0

    for rule in inp.brand_rules:
        cat = [
            s for s in inp.skus
            if s.category == rule.category and s.category not in disallowed
        ]
        if not cat:
            continue
        ranked = sorted(cat, key=lambda s: _turnover(s, demand), reverse=True)
        min_skus, min_units = effective_brand_minimums(rule, cat, inp.forecasts)

        stocked = [s for s in ranked if loads.get(s.id, 0) > 0]
        for sku in ranked:
            if len(stocked) >= min_skus:
                break
            if loads.get(sku.id, 0) == 0:
                loads[sku.id] = max(MIN_PICK_UNITS, sku.min_pack_size)
                stocked.append(sku)

        total = sum(loads.get(s.id, 0) for s in cat)
        i = 0
        while total < min_units and stocked:
            loads[stocked[i % len(stocked)].id] += 1
            total += 1
            i += 1


def _margin_per_cm3(sku, qty: int, demand: dict[int, float]) -> float:
    cm3 = sku.volume_cm3 * qty
    if cm3 <= 0:
        return math.inf
    expected = min(demand.get(sku.id, 0.0), float(qty))
    return (expected * (sku.retail_price - sku.cost_price)) / cm3
