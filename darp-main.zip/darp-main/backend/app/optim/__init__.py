"""Three-stage optimisation engine: forecast → selection (MILP) → packing (3D)."""
