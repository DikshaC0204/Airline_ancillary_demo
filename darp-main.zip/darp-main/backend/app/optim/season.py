"""Shared season-slot logic.

Both the synthetic sales generator and the demand forecaster must bin flights
into the *same* season slots, otherwise the forecaster's history lookup misses
its bin and silently degrades to the category prior. This module is the single
source of truth, imported by `seed/sales_history.py` and `optim/forecast.py`.

A route is mapped to a demand *profile*; the profile decides which months are
peak / shoulder / off. New routes (mirrors and the multi-leg triangle) reuse
existing profiles so they inherit sensible seasonality.
"""

from __future__ import annotations


# route_key ("ORIG-DEST") -> profile name
ROUTE_PROFILE: dict[str, str] = {
    # Summer-leisure (Med beach): peak Jun–Aug.
    "LTN-IBZ": "leisure_summer",
    "IBZ-LTN": "leisure_summer",
    "LTN-AGP": "leisure_summer",
    "AGP-LTN": "leisure_summer",
    # Canary triangle legs — sun all year but still summer-skewed for UK O&D.
    "AGP-ACE": "leisure_summer",
    "ACE-LTN": "leisure_summer",
    "ACE-AGP": "leisure_summer",
    # Ski + diaspora: winter + late-summer peaks.
    "TIA-GVA": "ski_diaspora",
    "GVA-TIA": "ski_diaspora",
}

DEFAULT_PROFILE = "leisure_summer"


def route_profile(route_key: str) -> str:
    return ROUTE_PROFILE.get(route_key, DEFAULT_PROFILE)


def season_slot(month: int, route_key: str) -> str:
    """Return 'peak' | 'shoulder' | 'off' for a month on a route."""
    profile = route_profile(route_key)
    if profile == "ski_diaspora":
        if month in (1, 2, 7, 8, 12):
            return "peak"
        if month in (3, 9, 11):
            return "shoulder"
        return "off"
    # leisure_summer (default)
    if month in (6, 7, 8):
        return "peak"
    if month in (4, 5, 9, 10):
        return "shoulder"
    return "off"
