# dnata Brand & UI Theme Guide

This document captures the visual identity, color system, typography, spacing, and UI conventions used by the dnata SGHA Contract Analyzer. It is written so it can be dropped into any future project as an input for designing a UI that is visually consistent with the dnata brand.

---

## 1. Brand Identity

**Brand:** dnata (a global air and travel services provider; part of the Emirates Group)

**Personality / Tone**
- Professional, trustworthy, enterprise-grade
- Calm and authoritative — designed for business and operations users (contracts, ground handling, aviation)
- Clear, factual, low-noise — minimal decorative styling, generous whitespace
- Modern but conservative — avoids playful gradients, heavy shadows, or trendy effects

**Design principles**
1. **Clarity first** — content (data, contract text, status) is always more prominent than chrome.
2. **Hierarchy through color, not weight** — primary navy carries authority; blue carries interaction; green/amber/red carry status meaning.
3. **Accessible by default** — minimum WCAG AA contrast on all foreground/background pairings.
4. **Restrained motion** — short, functional transitions (≤200ms ease-out); no parallax or bouncing.

---

## 2. Color System

The palette is a navy-led corporate scheme with a bright blue interaction color, supported by semantic status colors. All colors are defined as CSS custom properties and consumed via Tailwind utility classes (e.g. `bg-primary`, `text-foreground`).

### 2.1 Primary brand colors

| Token | Hex | Usage |
|---|---|---|
| `--primary` (dnata Navy) | `#1A3A5C` | Headers, sidebar, primary text emphasis, top-level brand surfaces |
| `--secondary` (dnata Blue) | `#0072BC` | Interactive elements: links, buttons, focus rings, active states, charts |
| `--accent` (Success Green) | `#5CB85C` | Positive status, success states, "compliant" indicators |

### 2.2 Neutrals (Light mode)

| Token | Hex | Usage |
|---|---|---|
| `--background` | `#FFFFFF` | Page background |
| `--foreground` | `#333333` | Primary body text |
| `--card` / `--popover` | `#FFFFFF` | Card and overlay surfaces |
| `--muted` | `#F5F5F5` | Subtle backgrounds, table stripes, inset panels |
| `--muted-foreground` | `#666666` | Secondary / helper text |
| `--border` / `--input` | `#E0E0E0` | Dividers, input borders |
| `--ring` | `#0072BC` | Focus ring |

### 2.3 Neutrals (Dark mode)

| Token | Hex | Usage |
|---|---|---|
| `--background` | `#0F1E2E` | Page background (deep navy) |
| `--foreground` | `#E8E8E8` | Primary text |
| `--card` / `--popover` | `#162D44` | Elevated surfaces |
| `--muted` | `#1B2E42` | Inset backgrounds |
| `--muted-foreground` | `#A0A0A0` | Secondary text |
| `--border` | `rgba(255,255,255,0.1)` | Dividers |
| `--input` | `rgba(255,255,255,0.15)` | Input borders |
| `--primary` | `#0072BC` | In dark mode, the brighter blue becomes primary for contrast |
| `--secondary` | `#1A3A5C` | Navy demotes to secondary surface |

### 2.4 Semantic / status colors

| Purpose | Token | Hex |
|---|---|---|
| Success / compliant | `--accent` | `#5CB85C` |
| Warning / attention | `--chart-4` | `#F0AD4E` |
| Destructive / error / non-compliant | `--destructive` | `#DC3545` |
| Info / neutral data | `--secondary` | `#0072BC` |

### 2.5 Chart palette (in order)

1. `#0072BC` — dnata Blue (primary series)
2. `#5CB85C` — Green
3. `#1A3A5C` — Navy
4. `#F0AD4E` — Amber
5. `#D9534F` — Red

Use this order for sequential categorical data so charts feel consistent across views.

### 2.6 Sidebar (navigation chrome)

The sidebar uses navy as its surface to anchor the brand:

- Background: `#1A3A5C` (light mode) / `#0F1E2E` (dark mode)
- Foreground: `#FFFFFF` / `#E8E8E8`
- Active item: `#0072BC` background, white text

---

## 3. Typography

**Primary typeface:** [`Source Sans 3`](https://fonts.google.com/specimen/Source+Sans+3) (Google Fonts), with system fallbacks.

```css
font-family: 'Source Sans 3', system-ui, -apple-system, sans-serif;
```

**Rationale:** Source Sans 3 is open, highly legible at small sizes, and reads as professional without feeling corporate-sterile — well suited to dense contractual content and data tables.

**Suggested type scale** (Tailwind defaults work well; example app usage):

| Role | Size | Weight |
|---|---|---|
| Page title (H1) | `text-2xl` / `text-3xl` (24–30px) | 600–700 |
| Section heading (H2) | `text-xl` (20px) | 600 |
| Card title (H3) | `text-lg` (18px) | 600 |
| Body | `text-sm` / `text-base` (14–16px) | 400 |
| Helper / meta | `text-xs` (12px) | 400, `text-muted-foreground` |
| Numeric / code | `font-mono` (UI monospace stack) | 400–500 |

**Rules**
- Avoid all-caps except for short status badges or table column headers.
- Avoid italics for emphasis; use weight (600) or color (`text-primary`) instead.
- Line-height: `leading-relaxed` (1.625) for paragraph content; `leading-tight` for headings.

---

## 4. Spacing, Sizing & Radius

The app uses Tailwind's spacing scale multiplied by `--size-scale` (default `1`) so all spacing can be globally tuned.

**Spacing scale:** standard Tailwind `0`, `0.5`, `1`, `2`, `3`, `4`, `6`, `8`, `12`, `16`, `24`, … (rem-based, 1 = 0.25rem).

**Border radius**

| Token | Value | Usage |
|---|---|---|
| `--radius` | `0.625rem` (10px) | Base — cards, dialogs, drawers |
| `--radius-sm` | 6px | Inputs, badges, small buttons |
| `--radius-md` | 8px | Standard buttons, dropdowns |
| `--radius-lg` | 10px | Cards |
| `--radius-xl` | 14px | Modals, large containers |
| `--radius-full` | `9999px` | Pills, avatars, status dots |

**Shadows:** restrained. Prefer `shadow-sm` for cards and `shadow-md` for overlays/popovers. Avoid colored or heavy drop shadows.

---

## 5. Components & UI Conventions

The UI is built on [shadcn/ui](https://ui.shadcn.com/) primitives (Radix UI under the hood) styled with Tailwind. Future projects should adopt the same stack for consistency, but the conventions below are framework-agnostic.

### 5.1 Buttons
- **Primary**: `bg-primary` (navy) with white text — used for the single most important action per view.
- **Secondary / default**: `bg-secondary` (blue) with white text — used for common actions.
- **Outline**: transparent background, `border` color, `text-foreground` — secondary/cancel actions.
- **Ghost**: no border or background; used in toolbars and table rows.
- **Destructive**: `bg-destructive` (red) with white text — irreversible actions only.
- Height: 36–40px standard; 32px compact; 44px touch (mobile).
- Radius: `--radius-md`.

### 5.2 Cards
- Background `--card`, border `--border`, radius `--radius-lg`, `shadow-sm`.
- Inner padding: `p-6` for primary content, `p-4` for compact lists.
- Header uses `text-lg font-semibold`; subtitle uses `text-sm text-muted-foreground`.

### 5.3 Inputs & forms
- Background `--background`, border `--input`, radius `--radius-md`.
- Focus: 2px ring using `--ring` (`#0072BC`).
- Labels above inputs, `text-sm font-medium`. Helper text `text-xs text-muted-foreground`.
- Error state: border + helper text in `--destructive`.

### 5.4 Status badges
- Pill shape (`--radius-full`), `text-xs`, padding `px-2 py-0.5`.
- Use semantic colors at low opacity for background + full opacity for text/border:
  - Success: green text on `bg-accent/10`
  - Warning: amber text on `bg-[#F0AD4E]/10`
  - Error: red text on `bg-destructive/10`
  - Info: blue text on `bg-secondary/10`

### 5.5 Tables
- Zebra striping with `--muted` on every other row (optional).
- Header row: `text-xs font-semibold uppercase tracking-wide text-muted-foreground`.
- Border-bottom only between rows; avoid full grids.

### 5.6 Sidebar / navigation
- Navy surface (see §2.6), white text.
- Active item: full-width pill in `--secondary` blue.
- Icon + label, 14–16px icons; section labels in `text-xs` uppercase.

### 5.7 Dialogs / drawers
- Overlay: `rgba(0,0,0,0.5)`.
- Surface: `--card`, radius `--radius-xl`, `shadow-md`.
- Drawers slide from the right at 480–640px width on desktop; full-screen on mobile.

### 5.8 Iconography
- Use [Phosphor Icons](https://phosphoricons.com/) (`@phosphor-icons/react`) — line/regular weight.
- 16px in dense UI (table rows, buttons); 20px in headers; 24px+ in empty states.
- Match icon color to surrounding text color; do not introduce extra hues.

---

## 6. Motion

- **Transitions:** `transition-colors`, `transition-opacity` at `duration-150` to `duration-200`, `ease-out`.
- **Accordion / collapse:** 200ms ease-out (see `--animate-accordion-down`/`-up`).
- **Hover:** subtle (`opacity-90` or one shade darker); no scale transforms on primary content.
- Respect `prefers-reduced-motion: reduce` — disable non-essential motion.

---

## 7. Accessibility

- Maintain WCAG AA contrast: navy `#1A3A5C` on white passes AAA; blue `#0072BC` on white passes AA for normal text.
- All interactive elements must show a visible `--ring` focus state (2px outline, 2px offset).
- Color is never the *only* signal — pair status colors with an icon or text label.
- Hit targets ≥40px on touch (`coarse` pointer breakpoint).
- Dark mode is a first-class theme, toggled via `[data-appearance="dark"]` or `.dark` class on the root.

---

## 8. Imagery & Iconography Style

- Photography (when used): bright, modern aviation/logistics imagery; people in operational settings; avoid stock-cliché handshakes.
- Illustrations: flat, two-tone using navy + blue; minimal detail.
- Avoid gradients in product UI. A subtle navy→blue gradient is acceptable only for marketing hero areas.

---

## 9. Implementation Quick Reference

For a React + Tailwind + shadcn/ui project, drop these CSS variables into your root stylesheet (see this repo's `src/main.css` for the full source):

```css
:root {
  --radius: 0.625rem;
  --background: #FFFFFF;
  --foreground: #333333;
  --primary: #1A3A5C;
  --primary-foreground: #FFFFFF;
  --secondary: #0072BC;
  --secondary-foreground: #FFFFFF;
  --accent: #5CB85C;
  --accent-foreground: #FFFFFF;
  --destructive: #DC3545;
  --destructive-foreground: #FFFFFF;
  --muted: #F5F5F5;
  --muted-foreground: #666666;
  --border: #E0E0E0;
  --input: #E0E0E0;
  --ring: #0072BC;
  --chart-1: #0072BC;
  --chart-2: #5CB85C;
  --chart-3: #1A3A5C;
  --chart-4: #F0AD4E;
  --chart-5: #D9534F;
  --sidebar: #1A3A5C;
  --sidebar-foreground: #FFFFFF;
  --sidebar-primary: #0072BC;
  --sidebar-accent: #0072BC;
}

.dark {
  --background: #0F1E2E;
  --foreground: #E8E8E8;
  --card: #162D44;
  --primary: #0072BC;
  --secondary: #1A3A5C;
  --muted: #1B2E42;
  --muted-foreground: #A0A0A0;
  --border: rgba(255,255,255,0.1);
  --input: rgba(255,255,255,0.15);
  --sidebar: #0F1E2E;
}

body {
  font-family: 'Source Sans 3', system-ui, -apple-system, sans-serif;
}
```

**Recommended stack for new projects**
- React 18+ / Vite
- TypeScript
- Tailwind CSS v4
- shadcn/ui components (Radix UI primitives)
- Phosphor Icons (`@phosphor-icons/react`)
- Source Sans 3 via Google Fonts

---

## 10. Do / Don't Summary

**Do**
- Lead with navy chrome and blue interactions.
- Use generous whitespace and clear hierarchy.
- Pair color with text/icons for status.
- Keep motion short and purposeful.

**Don't**
- Introduce ad-hoc colors outside the palette.
- Use gradients, glass effects, or neon highlights in product UI.
- Use red/green as the sole indicator of state.
- Mix icon libraries — stay with Phosphor.

---

*This document is brand guidance, not a strict spec. When in doubt, optimize for clarity and content over decoration.*
