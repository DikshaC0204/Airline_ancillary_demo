# dnata ARP — Infographic Prompts

Three prompts for generating high-resolution landscape infographics.
All diagrams share the dnata brand palette: Navy `#1A3A5C`, Blue `#0072BC`, Green `#5CB85C`, Amber `#F0AD4E`, body text `#333333`, white `#FFFFFF` background.
Typography: Source Sans 3 (or a clean geometric sans-serif such as Inter/Helvetica Neue as fallback). All label text must be legible — minimum 11pt equivalent at final output size. No text may be clipped, overlapped, or rendered smaller than 11pt.

### Rules that apply to every prompt (do not render meta-instructions)

When you generate the diagram, the following must **never** appear as visible text in the image:

- **No hex codes, RGB values, or colour names** (e.g. `#1A3A5C`, "Navy", "Blue header bar") — these are styling instructions for you, not labels for the viewer. Apply the colour, do not write it.
- **No layout/meta labels** — words like "Panel 1", "Stage 1: …", "(Navy header bar)", "(left column)", "(top swimlane)", "(right margin)", "Master layout", "Soft constraints (Amber badge)" are scaffolding for the prompt. Render the visual structure they describe but never print these scaffolding words verbatim. If a section needs a heading, use the **plain title only** (e.g. "Demand Forecasting", "Hard Constraints", "Soft Constraints & Bonuses").
- **No prompt syntax** — do not render markdown bullets (`-`, `>`), backticks, or quotation marks around labels.
- **No "minimum 11pt" / "fully legible" reminders** — those are quality rules for you, not captions.

Treat anything inside parentheses describing colour, position, or layout as a directive to you, not as text content.

---

## Diagram 1 — Functional Overview (Business Audience)

**Purpose:** Help business stakeholders understand what the Autonomous Range Planner does, what data it consumes, and what value it produces — without any mention of code or algorithms.

---

**Prompt:**

> Create a high-resolution (4000 × 2500 px, 150 dpi), landscape, white-background infographic titled **"dnata Autonomous Range Planner — How It Works"**.
>
> **Brand palette:** Navy `#1A3A5C`, Blue `#0072BC`, Green `#5CB85C`, Amber `#F0AD4E`, body text `#333333`. Background `#FFFFFF`. Use Source Sans 3 or Inter as the typeface throughout. Every text label must be sharp and fully readable — do not render any text below 11pt equivalent.
>
> **Do not render any of these as visible text in the image:** hex codes, RGB values, colour names ("Navy", "Blue"), layout meta-labels ("Data Inputs lane", "left column", "bottom strip"), prompt scaffolding ("Place five icon-cards"), or markdown syntax. Use the headings **Data Inputs**, **Intelligence Engine**, **Outputs & Actions**, **Business Value** as the only lane titles. Apply colours visually; never label them.
>
> **Layout:** A clean left-to-right flow diagram divided into four horizontal lanes labelled (top to bottom): **Data Inputs**, **Intelligence Engine**, **Outputs & Actions**, **Business Value**.
>
> **Data Inputs lane (left column, Navy `#1A3A5C` header):**
> Place five icon-cards in a vertical stack:
> - Historical Sales (7 routes, 12 months, 1,458 flights, ~198,000 sale rows)
> - Flight Schedule (aircraft type, passenger count, load factor, multi-leg rotations)
> - SKU Catalogue (140 products — food, beverages, gifts, duty-free)
> - Cost Parameters (fuel price, pick cost, warehouse-zone handling, spoilage, CO₂ factor)
> - Crew Feedback (free-text observations from cabin crew)
>
> **Intelligence Engine lane (centre, Blue `#0072BC` header):**
> Show three sequential numbered stages connected by arrows:
> 1. **Demand Forecast** — "Predicts units sold per SKU per flight leg using seasonal trends, day-of-week, time-of-day, load factor and passenger mix. A trained model can be swapped in and compared against the default before anyone relies on it"
> 2. **Range Optimisation** — "Selects the best mix of SKUs to maximise net contribution — revenue less fuel, pick-and-pack, warehouse-zone handling, spoilage and complexity — across single flights or multi-leg rotations, while respecting weight, volume, regulatory and supplier constraints"
> 3. **3D Load Planning** — "Assigns every unit to a specific galley drawer, keeping best-selling lines in the most accessible drawers and respecting each drawer's weight ceiling"
> Add a fourth box below the stages labelled **AI Co-Planner** (Green `#5CB85C`) with the caption "Azure OpenAI answers planner questions, explains decisions, and narrates scenario comparisons in plain language"
>
> **Outputs & Actions lane (right column, Green `#5CB85C` header):**
> - Range Plan (which SKUs to load, in what quantities — per flight or rotation)
> - Net Contribution per kg and per cm³ (the headline commercial metric)
> - Measured Uplift vs a Costed Manual Plan (the same generous-loading rule a planner uses today, priced with the identical cost model)
> - Why-Excluded Rationale (a plain-English reason for every SKU, including rejected ones, plus a suggested alternative)
> - 3D Galley Visualisation (interactive drawer-by-drawer view)
> - Planner Overrides & Approval (pin SKUs in/out, re-optimise, sign off the plan)
> - Aircraft-Swap Revalidation (re-checks the approved plan against a new galley)
>
> **Business Value lane (bottom strip, Amber `#F0AD4E` background):**
> Three bold KPI callouts separated by vertical dividers:
> - "Higher net contribution per flight — optimises profit per kg and per cm³, not just revenue"
> - "Fewer waste write-offs from right-sized quantities and spoilage-aware loading"
> - "Faster, trusted planning — minutes not days, with a defensible reason for every decision"
>
> Add a small footnote strip beneath the value lane in `#666666`: "Figures shown in the prototype are measured on synthetic data against a like-for-like manual plan, and are indicative only."
>
> Include the dnata wordmark (text "dnata" in Navy `#1A3A5C`, bold, 36pt) in the top-left corner. Add a thin Navy horizontal rule beneath the title. Keep whitespace generous; avoid clutter.

---

## Diagram 2 — Optimisation Logic (Technical / Analytical Audience)

**Purpose:** Explain the three-stage optimisation pipeline in detail — algorithms, mathematical formulations, key constraints — for data scientists, engineers, and technically literate stakeholders.

---

**Prompt:**

> Create a high-resolution (4000 × 2500 px, 150 dpi), landscape, white-background technical infographic titled **"dnata ARP — Three-Stage Optimisation Pipeline"**.
>
> **Brand palette:** Navy `#1A3A5C`, Blue `#0072BC`, Green `#5CB85C`, Amber `#F0AD4E`, Red `#DC3545`, body text `#333333`. Background `#FFFFFF`. Use Source Sans 3 or Inter. Every label and annotation must be fully readable — minimum 11pt. No text may be clipped or overlap other elements.
>
> **Do not render any of these as visible text in the image:** hex codes, RGB values, colour names, parenthetical layout directions ("Navy header bar", "top-right corner"), or prompt scaffolding words such as "Panel 1", "Panel 2", "Panel 3", "Master layout", "Algorithm box", "Hard constraints (Red badge)", "Soft constraints / bonuses (Amber badge)". Each panel's heading should be the plain stage name only: **Stage 1 — Demand Forecasting**, **Stage 2 — Range Selection MILP**, **Stage 3 — 3D Bin Packing**. Within a panel, use the clean section labels **Algorithm**, **Optional Method**, **Features**, **Decision Variables**, **Hard Constraints**, **Soft Constraints & Bonuses**, **Service Level**, **Manual-Plan Benchmark**, **Orientation**, **Placement**, **Output**. Render the side-panel titled **Model Evaluation**. Apply colours visually; never name or hex-label them.
>
> **Master layout:** Three large vertical panels side by side, each representing one stage, connected by thick Blue `#0072BC` arrows. In the top-right corner show a small legend mapping badge colours to constraint types.
>
> **Panel 1 — Stage 1: Demand Forecasting** (Navy `#1A3A5C` header bar):
> - Algorithm box: "Empirical bin forecaster with Bayesian shrinkage (default) — bins 12 months of sale rows by (route × SKU × season-slot × time-of-day × day-of-week bucket); shrinks sparse bins toward the category prior with k = 5; outputs expected demand and p10 / p50 / p90 per (leg, SKU)"
> - Optional method box (Green): "LightGBM (experimental, off by default) — one pooled gradient-boosted model trained on a censored Poisson objective with passenger exposure as offset. Selected in Settings, never automatically"
> - Feature list (bullet points): Route (7 routes incl. mirrors + the LTN→AGP→ACE Canary triangle) · Season slot (peak / shoulder / off, shared with the seed generator) · Time-of-day bucket · Day-of-week bucket · Pax forecast · Load factor · Category prior
> - Output arrow labelled: "expected_units, p10, p50, p90 per (leg, SKU) — one forecast per rotation leg"
> - Annotation: "Only stocked observations carry demand information. A sell-out is right-censored (demand ≥ units loaded); a line nobody loaded is excluded rather than read as zero demand"
> - Annotation: "A model may only forecast a flight that departed after everything it learned from. If it cannot — library missing, nothing trained, history changed — planning continues on the empirical model and the run records that it fell back"
> - Honesty note (small grey text): "The solver consumes expected_units only; p10 / p90 are reported for the planner and do not drive the optimisation"
>
> **Model Evaluation side-panel** (small box attached to Panel 1, Amber `#F0AD4E` border):
> "Train / Evaluate compares Empirical, a regularised Poisson regression and LightGBM on held-out dates, scoring censored log-likelihood, capped-sales error and bias, with differences clustered by calendar date. Training produces a candidate; a human selects it."
>
> **Panel 2 — Stage 2: Range Selection MILP** (Blue `#0072BC` header bar):
> - Algorithm box: "CP-SAT Mixed-Integer Linear Programme (Google OR-Tools), generalised to rotations — a single flight is a one-leg rotation, so there is one solver code path"
> - Objective function displayed as styled pseudo-math: "Maximise Σᵢ marginᵢ · soldᵢ − handlingᵢ · xᵢ − Σₖ fuelₖᵢ · carriedₖᵢ − (returnᵢ + spoilageᵢ) · unsoldᵢ − (complexityᵢ + lowReturnᵢ + bondedᵢ) · yᵢ − caseBreak penalty"
> - Captions under the objective: "Expected sales saturate — a rotation loads one range at the origin and it depletes leg by leg, so it can only sell E[min(total demand, units loaded)]. Modelled as a concave piecewise bound on cumulative demand, so no unit is sold twice" · "Carry-over fuel — unsold stock carried onto each onward leg compounds fuel cost, so selling early is rewarded" · "Handling — pick cost × warehouse-zone multiplier + authorised-pick & bonded surcharges" · "Net Contribution per kg and per cm³ reported per SKU"
> - Decision variables box: "xᵢ = units loaded for SKU i (once, at the rotation origin) · yᵢ = 1 if SKU i included · cₖᵢ = expected cumulative sales through leg k, so leg sales are their increments · pins fix xⱼ / yⱼ for planner overrides"
> - Hard constraints (Red `#DC3545` badge): Volume ≤ η · galley_capacity (η = 0.65 default) · Gross weight ≤ aircraft payload allowance · Regulatory exclusions (e.g. no tobacco) · Minimum economic quantity per included SKU · Cumulative sales ≤ units loaded
> - Soft constraints / bonuses (Amber `#F0AD4E` badge): Supplier minimum commitments · Brand rules (min SKUs / units per category, each capped at the demand that actually exists) · Case-multiple preference (penalise breaking a supplier case) · Low-return pickline penalty · Complexity penalty — all relaxed to penalised slack in override mode so planner pins never deadlock
> - Service-level annotation: "Service level sets how deep a stocked line is filled — the Poisson quantile at p (default 0.70) becomes its minimum depth. It does not inflate the sales booked against it"
> - Infeasibility loop annotation: "If Stage 3 leaves units unplaced → tighten η by 7 pp and retry Stage 2 (pins preserved), up to 4 cycles. If units still will not fit, the run fails rather than reporting a loadout the warehouse cannot build"
> - Benchmark box (Green): "Every run also prices a manual plan — the same generous-loading rule that produced the sales history — through this identical objective, so the reported uplift compares two plans, not two cost models"
> - Output arrow labelled: "range_decision rows (SKU, qty, decision: load / reduce / exclude, per-leg sales, net/kg, net/cm³)"
>
> **Panel 3 — Stage 3: 3D Bin Packing** (Green `#5CB85C` header bar):
> - Algorithm box: "Extreme Point First-Fit Decreasing (EP-FFD) heuristic — deterministic, chosen over a full CP-SAT formulation because ~350 units × ~12 drawers exceeds the time budget"
> - Bin definition: "Bins = galley drawers (ATLAS Full 400×300×280 mm, ATLAS Half 400×300×140 mm) with per-drawer weight ceiling"
> - Item definition: "Items = individual SKU units as cuboids, placed at extreme points seeded from the drawer origin; the lowest feasible point wins"
> - Orientation rule: "One orientation per SKU — the smallest dimension is laid vertical, unless the SKU is marked upright-only, in which case its height stays on the vertical axis"
> - Placement rule (Blue `#0072BC` badge): "Best-selling lines are placed first into the most accessible drawers"
> - Hard rule (Red `#DC3545` badge): Per-drawer weight ceiling strictly enforced
> - Roadmap note (small grey text): "Fragility padding, locked drawers for tobacco and alcohol, bundle co-location and food / non-food separation are modelled in the catalogue but not yet enforced by the packer"
> - Output arrow labelled: "drawer_assignment rows (SKU, drawer, x, y, z, dimensions as placed)"
>
> Add the dnata wordmark (text "dnata", Navy, bold, 36pt) top-left. Thin Navy rule beneath the title.

---

## Diagram 3 — Technical Architecture

**Purpose:** Document the full system architecture — frontend, backend, data layer, AI services, and integrations — for engineers, architects, and technical evaluators.

---

**Prompt:**

> Create a high-resolution (4000 × 2500 px, 150 dpi), landscape, white-background system architecture diagram titled **"dnata Autonomous Range Planner — Technical Architecture"**.
>
> **Brand palette:** Navy `#1A3A5C`, Blue `#0072BC`, Green `#5CB85C`, Amber `#F0AD4E`, body text `#333333`. Background `#FFFFFF`. Use Source Sans 3 or Inter. Every component label, annotation, and arrow caption must be sharp and fully legible — minimum 11pt. No text may be clipped, truncated, or overlap another element. If space is tight, reduce icon size before reducing font size.
>
> **Do not render any of these as visible text in the image:** hex codes, RGB values, colour names, or prompt scaffolding such as "top swimlane", "middle swimlane", "bottom swimlane", "left margin", "right margin", "Stack label below all boxes", "Callout boxes", "Blue arrow", "Amber arrow with cloud icon". The three swimlanes are titled simply **Presentation Tier**, **Application Tier**, **Data & Services Tier**. Apply colours visually; never label them.
>
> **Layout:** Three horizontal tiers labelled on the left margin — **Presentation Tier** (top), **Application Tier** (middle), **Data & Services Tier** (bottom). Use thin rounded-rectangle swimlane borders in `#E0E0E0` to separate tiers. Arrows between tiers are directional and captioned with protocol/format.
>
> **Presentation Tier (top swimlane, Navy `#1A3A5C` label):**
> Seven component boxes arranged horizontally:
> - **Dashboard** — outcome KPI strip measured across approved plans, Leaflet route map, planning activity feed, AI insight cards
> - **Flight Detail + Range Result** — run trigger, progress SSE, range table with per-SKU reason codes, net/kg & net/cm³ columns, constraint-stress panel, forecast provenance banner, row-level overrides, approval, rotation banner + aircraft-swap revalidation
> - **3D Packing Visualiser** — React Three Fiber scene, drawer slide-out, three colour modes
> - **Optimisation** — run history with forecast method per run
> - **Scenarios** — side-by-side compare, NarrationCard (AI), scenario form
> - **Settings** — forecasting method choice, Train / Evaluate action, job progress, model comparison table and caveats
> - **AI Co-Planner Chat + Crew Feedback** — function-calling chat with tool-trace display, Markdown renderer, feedback submission form
>
> Stack label below all boxes: "React 18 + TypeScript · Vite 5 · Tailwind CSS v4 · TanStack Query v5 · React Router v6 · Phosphor Icons · Three.js / @react-three/fiber · Leaflet"
>
> **Application Tier (middle swimlane, Blue `#0072BC` label):**
> Show a FastAPI service box subdivided into four columns:
> - **API Routers** — /api/flights (+ PATCH aircraft-swap revalidation) · /api/skus · /api/routes · /api/aircraft · /api/sales · /api/runs (SSE, + override / approve) · /api/rotations · /api/scenarios · /api/settings · /api/forecasting (train / jobs / evaluations) · /api/dashboard · /api/cost-params · /api/regulatory-rules · /api/ai · /api/admin
> - **Optimisation Engine** — forecast.py (empirical bins + Bayesian shrinkage) · forecast_data.py (time-eligible training frame, censoring, fingerprint) · forecast_lightgbm.py + forecast_likelihood.py (optional pooled model, censored Poisson) · forecast_evaluation.py (date-grouped backtest vs Poisson GLM) · forecast_service.py (method selection, training jobs, fallback policy) · season.py · selection.py (CP-SAT MILP over legs + pins) · baseline.py (costed manual plan) · cost_to_serve.py · explain.py (deterministic reason codes) · packing.py (EP-FFD 3D) · engine.py (orchestrator + retry loop)
> - **AI Layer** — azure_openai.py (AzureOpenAI SDK, SQLite cache, 5-call ceiling) · rationale.py · chat.py (function calling, 4 tools: run_summary, explain_sku, list_top_skus, compare_runs) · narrate.py · crew.py
> - **Data Access** — SQLAlchemy 2.0 ORM · `Base.metadata.create_all` schema bootstrap · Pydantic v2 schemas
>
> Stack label: "Python 3.13 · FastAPI · Uvicorn · SQLAlchemy 2.0 · OR-Tools CP-SAT · NumPy / SciPy / pandas · LightGBM (optional extra) · OpenAI SDK"
>
> **Data & Services Tier (bottom swimlane, Green `#5CB85C` label):**
> Four boxes:
> - **SQLite Database** (arp.sqlite) — entities: sku, supplier, route, rotation, flight, aircraft, galley_layout, cart, drawer, sale, optimisation_run, range_decision, run_override, drawer_assignment, scenario, regulatory_rule, brand_rule, supplier_commitment, crew_feedback, cost_params, application_settings, forecast_training_job
> - **Trained Model Artifacts** (data/models/) — versioned per model id: booster file plus a manifest recording feature schema, label policy, training rows and the data fingerprint it was fitted on
> - **AOAI Response Cache** (aoai_cache.sqlite) — keyed by (prompt_hash, model); avoids redundant API calls; per-run call ceiling enforced
> - **Azure OpenAI Service** — deployment: gpt-5.4 · API version: 2025-04-01-preview · capabilities: function calling, JSON mode, long context · endpoint: Azure cloud
>
> **Arrows and protocols:**
> - Presentation → Application: "REST/JSON (Fetch API) + SSE (EventSource)" — Blue arrow
> - Presentation ↔ Application (chat): "POST /api/ai/chat — JSON turn-by-turn" — Green arrow
> - Application → SQLite: "SQLAlchemy ORM via DB-API (local file)" — Navy arrow
> - Application → Model Artifacts: "load on demand; staged write then atomic rename on publish" — dashed Green arrow
> - Application → Azure OpenAI: "HTTPS / OpenAI SDK (Azure endpoint)" — Amber arrow with cloud icon
> - Application → AOAI Cache: "cache read/write before API call" — dashed Navy arrow
>
> **Callout boxes (right margin, Amber `#F0AD4E` background):**
> - "No external auth — local-only demo deployment"
> - "All data synthetic — fixed RNG seed 42; deterministic rebuild via `make seed`"
> - "Dev proxy: Vite forwards /api → :8000; no CORS config needed in dev"
> - "Forecast method is resolved before a run is queued and stored with it, so a plan always records the model that produced it"
>
> Add the dnata wordmark (text "dnata", Navy `#1A3A5C`, bold, 36pt) top-left. Thin Navy horizontal rule beneath the title. Add a small "September 2026 — Prototype v2" caption in `#666666` bottom-right.

---

## How to use these prompts

- **Best tools:** GPT Image 1 / DALL·E 3 / Midjourney v6+ / Adobe Firefly for the rendered infographic; for an editable vector version, paste the prompt into Excalidraw AI, Whimsical AI, Eraser.io DiagramGPT, or Figma's First Draft.
- **If text comes out garbled** (a common failure mode for diffusion image models with dense text), regenerate with the instruction *"render all text via a text layer, not as part of the image; if not possible, reduce decorative elements and increase font weight to 600"*. Alternatively, generate the layout as an image and overlay the text yourself in Figma / PowerPoint.
- **Aspect ratio:** all three are 16:10 landscape (4000 × 2500 px). If the model only supports 16:9, request 3840 × 2160 instead and centre-pad on white.
- **Colour fidelity:** if the hexes drift, post-process in Figma using a Recolor plugin against the locked palette in the header of this file.
- **Iteration tip:** generate Diagram 1 first (simplest layout), confirm the model respects the palette and text rules, then move on to 2 and 3.
