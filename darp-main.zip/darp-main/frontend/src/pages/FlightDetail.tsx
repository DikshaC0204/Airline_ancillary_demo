import { useEffect, useState, useMemo } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtNum, fmtGbpDetail } from "@/lib/format";
import { Card, CardHeader, Button, Badge, Kpi } from "@/components/ui";
import { AirplaneTakeoff, Sparkle, Clock, ArrowsLeftRight, Path } from "@phosphor-icons/react";

type Flight = {
  id: number;
  route_id: number;
  flight_no: string;
  scheduled_dt: string;
  aircraft_id: number;
  expected_pax: number;
  expected_load_factor: number;
  pax_mix_json: Record<string, number>;
  rotation_id: number | null;
  leg_index: number | null;
};

type Route = { id: number; origin_iata: string; dest_iata: string; haul_class: string };
type Aircraft = { id: number; registration: string; type: string; max_payload_kg: number };
type RotationLeg = { flight_id: number; leg_index: number; origin_iata: string; dest_iata: string };
type Rotation = { id: number; code: string; description: string | null; legs: RotationLeg[] };
type Revalidation = {
  verdict: string;
  run_id: number | null;
  unplaced_units?: number;
  weight_kg?: number;
  weight_cap_kg?: number;
  weight_ok?: boolean;
  volume_used_cm3?: number;
  volume_cap_cm3?: number;
  volume_ok?: boolean;
  aircraft_registration?: string;
  details?: { sku_code: string; sku_name: string; unplaced: number }[];
};
type RunSummary = {
  id: number;
  status: string;
  created_at: string;
  objective_value: number | null;
  total_units: number | null;
  total_skus: number | null;
  total_weight_kg: number | null;
  expected_revenue: number | null;
  expected_net_contribution: number | null;
  approval_status?: string;
  approved_by?: string | null;
};

type ProgressEvent = {
  stage: string;
  message: string;
  pct: number;
  elapsed_s: number;
  extra: Record<string, unknown>;
};

export default function FlightDetailPage() {
  const { id } = useParams();
  const flightId = Number(id);
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: flight } = useQuery({
    queryKey: ["flight", flightId],
    queryFn: () => apiFetch<Flight>(`/flights/${flightId}`),
    enabled: !Number.isNaN(flightId),
  });
  const { data: routes } = useQuery({ queryKey: ["routes"], queryFn: () => apiFetch<Route[]>("/routes") });
  const { data: aircraft } = useQuery({
    queryKey: ["aircraft"],
    queryFn: () => apiFetch<Aircraft[]>("/aircraft"),
  });
  const { data: latestRun } = useQuery({
    queryKey: ["latest-run", flightId],
    queryFn: () => apiFetch<RunSummary | null>(`/runs/by-flight/${flightId}/latest`),
    enabled: !Number.isNaN(flightId),
  });
  const { data: approvedRun } = useQuery({
    queryKey: ["approved-run", flightId],
    queryFn: () => apiFetch<RunSummary | null>(`/runs/by-flight/${flightId}/approved`),
    enabled: !Number.isNaN(flightId),
  });
  const { data: rotation } = useQuery({
    queryKey: ["rotation", flight?.rotation_id],
    queryFn: () => apiFetch<Rotation>(`/rotations/${flight!.rotation_id}`),
    enabled: flight?.rotation_id != null,
  });

  const route = routes?.find((r) => r.id === flight?.route_id);
  const ac = aircraft?.find((a) => a.id === flight?.aircraft_id);

  const [reval, setReval] = useState<Revalidation | null>(null);
  const swapAircraft = async (aircraftId: number) => {
    setReval(null);
    try {
      const res = await apiFetch<{ flight: Flight; revalidation: Revalidation }>(
        `/flights/${flightId}/aircraft`,
        { method: "PATCH", body: JSON.stringify({ aircraft_id: aircraftId }) }
      );
      setReval(res.revalidation);
      qc.invalidateQueries({ queryKey: ["flight", flightId] });
    } catch (e) {
      setErrMsg(String(e));
    }
  };

  const planRotation = async () => {
    if (!flight?.rotation_id) return;
    setErrMsg(null);
    setProgress({ stage: "pending", message: "Planning whole rotation…", pct: 0, elapsed_s: 0, extra: {} });
    try {
      const run = await apiFetch<RunSummary>("/runs", {
        method: "POST",
        body: JSON.stringify({
          rotation_id: flight.rotation_id,
          service_level_p: servicePct / 100,
          volume_efficiency_eta: eta,
          retail_weight_budget_kg: weightBudget,
          complexity_penalty_scale: complexityScale,
        }),
      });
      setActiveRunId(run.id);
    } catch (e) {
      setErrMsg(String(e));
      setProgress(null);
    }
  };

  // Optimisation parameters (defaults from §6.2 / SelectionParams).
  const [servicePct, setServicePct] = useState(70);
  const [eta, setEta] = useState(0.65);
  const [complexityScale, setComplexityScale] = useState(1.0);
  const [weightBudget, setWeightBudget] = useState(280);

  const [activeRunId, setActiveRunId] = useState<number | null>(null);
  const [progress, setProgress] = useState<ProgressEvent | null>(null);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  // Open SSE stream once a run is active.
  useEffect(() => {
    if (activeRunId == null) return;
    const es = new EventSource(`/api/runs/${activeRunId}/stream`);
    es.addEventListener("progress", (e) => {
      try {
        const data = JSON.parse((e as MessageEvent).data) as ProgressEvent;
        setProgress(data);
        if (data.stage === "done") {
          es.close();
          qc.invalidateQueries({ queryKey: ["latest-run", flightId] });
          // Navigate to the result page.
          const rid = (data.extra?.run_id as number | undefined) ?? activeRunId;
          navigate(`/runs/${rid}`);
        } else if (data.stage === "failed") {
          es.close();
          setErrMsg(data.message);
        }
      } catch {
        // ignore
      }
    });
    es.onerror = () => {
      // Keep open; SSE will reconnect or close on done.
    };
    return () => es.close();
  }, [activeRunId, flightId, navigate, qc]);

  const startRun = async () => {
    setErrMsg(null);
    setProgress({ stage: "pending", message: "Starting run…", pct: 0, elapsed_s: 0, extra: {} });
    try {
      const run = await apiFetch<RunSummary>("/runs", {
        method: "POST",
        body: JSON.stringify({
          flight_id: flightId,
          service_level_p: servicePct / 100,
          volume_efficiency_eta: eta,
          retail_weight_budget_kg: weightBudget,
          complexity_penalty_scale: complexityScale,
        }),
      });
      setActiveRunId(run.id);
    } catch (e) {
      setErrMsg(String(e));
      setProgress(null);
    }
  };

  const stageBadge = (() => {
    if (!progress) return null;
    if (progress.stage === "failed") return <Badge tone="error">Failed</Badge>;
    if (progress.stage === "done") return <Badge tone="success">Done</Badge>;
    return <Badge tone="info">{progress.stage}</Badge>;
  })();

  const paxMix = useMemo(() => {
    if (!flight?.pax_mix_json) return [];
    return Object.entries(flight.pax_mix_json).sort((a, b) => b[1] - a[1]);
  }, [flight?.pax_mix_json]);

  if (!flight) {
    return <Card>Loading flight…</Card>;
  }

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title={`${flight.flight_no} · ${route ? `${route.origin_iata} → ${route.dest_iata}` : ""}`}
          subtitle={new Date(flight.scheduled_dt).toLocaleString("en-GB")}
          right={
            <Link to="/flights">
              <Button variant="ghost">← Flights</Button>
            </Link>
          }
        />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Kpi label="Pax forecast" value={fmtNum(flight.expected_pax)} hint={`${(flight.expected_load_factor * 100).toFixed(0)}% load factor`} />
          <Kpi label="Aircraft" value={ac ? ac.type : "—"} hint={ac?.registration} tone="secondary" />
          <Kpi label="Haul" value={route?.haul_class ?? "—"} tone="muted" />
          <Kpi
            label="Last run"
            value={latestRun ? `#${latestRun.id}` : "—"}
            hint={latestRun ? `${latestRun.status} · ${latestRun.total_units ?? 0} units` : "no runs yet"}
            tone="accent"
          />
        </div>
        {approvedRun && (
          <div className="mt-3">
            <Link to={`/runs/${approvedRun.id}`}>
              <Badge tone="success">✓ Approved plan #{approvedRun.id} · {approvedRun.approved_by}</Badge>
            </Link>
          </div>
        )}
      </Card>

      {/* Rotation banner */}
      {flight.rotation_id != null && rotation && (
        <Card>
          <CardHeader
            title={<span className="flex items-center gap-2"><Path /> Part of rotation {rotation.code}</span>}
            subtitle={`${rotation.description ?? ""} — this flight is leg ${flight.leg_index} of ${rotation.legs.length}. The range is planned once for the whole rotation.`}
            right={<Button variant="primary" onClick={planRotation}><Sparkle weight="fill" /> Plan whole rotation</Button>}
          />
          <div className="flex flex-wrap gap-2 text-sm">
            {rotation.legs.map((leg) => (
              <Link key={leg.flight_id} to={`/flights/${leg.flight_id}`}>
                <Badge tone={leg.flight_id === flightId ? "info" : "neutral"}>
                  leg {leg.leg_index}: {leg.origin_iata}→{leg.dest_iata}
                </Badge>
              </Link>
            ))}
          </div>
        </Card>
      )}

      {/* Aircraft swap + revalidation */}
      <Card>
        <CardHeader
          title={<span className="flex items-center gap-2"><ArrowsLeftRight /> Aircraft assignment</span>}
          subtitle="Swapping the aircraft automatically revalidates the approved plan against the new galley."
        />
        <div className="flex items-center gap-3">
          <select
            value={flight.aircraft_id}
            onChange={(e) => swapAircraft(Number(e.target.value))}
            className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
          >
            {(aircraft ?? []).map((a) => (
              <option key={a.id} value={a.id}>{a.registration} · {a.type} ({fmtNum(a.max_payload_kg)} kg)</option>
            ))}
          </select>
          {ac && <span className="text-xs text-[color:var(--color-muted-foreground)]">current: {ac.registration}</span>}
        </div>
        {reval && (
          <div className="mt-4">
            {reval.verdict === "still_valid" && <Badge tone="success">Plan still valid — all units fit the {reval.aircraft_registration} galley</Badge>}
            {reval.verdict === "no_plan" && <Badge tone="neutral">No approved plan to revalidate — generate one first</Badge>}
            {reval.verdict === "capacity_violated" && (
              <div>
                <Badge tone="error">
                  Capacity violated — {reval.unplaced_units} units no longer fit
                  {reval.weight_ok === false ? " · over weight" : ""}
                  {reval.volume_ok === false ? " · over volume" : ""}
                </Badge>
                {reval.details && reval.details.length > 0 && (
                  <ul className="mt-2 text-xs text-[color:var(--color-muted-foreground)] space-y-0.5">
                    {reval.details.slice(0, 6).map((d) => (
                      <li key={d.sku_code}>{d.sku_name} — {d.unplaced} units spill</li>
                    ))}
                  </ul>
                )}
                <div className="mt-3">
                  <Button variant="primary" onClick={startRun}><Sparkle weight="fill" /> Re-optimise for this aircraft</Button>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader title="Generate range plan" subtitle="Adjust the optimisation knobs, then run." />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <SliderRow
              label="Service level (p-target)"
              value={servicePct}
              min={50}
              max={95}
              step={5}
              unit="%"
              onChange={setServicePct}
              hint="p70 default — higher means more stock to avoid stockouts."
            />
            <SliderRow
              label="Volume efficiency η"
              value={eta * 100}
              min={40}
              max={85}
              step={5}
              unit="%"
              onChange={(v) => setEta(v / 100)}
              hint="Drawer fill rate accounting for non-cuboid waste."
            />
            <SliderRow
              label="Weight budget"
              value={weightBudget}
              min={100}
              max={500}
              step={10}
              unit=" kg"
              onChange={setWeightBudget}
              hint="Cap for retail load (separate from catering)."
            />
            <SliderRow
              label="Complexity penalty"
              value={complexityScale * 100}
              min={0}
              max={300}
              step={25}
              unit="%"
              onChange={(v) => setComplexityScale(v / 100)}
              hint="Discourage long-tail SKUs (×1.00 = baseline)."
            />
          </div>

          <div className="flex items-center gap-3 mt-6">
            <Button variant="primary" onClick={startRun} disabled={progress != null && progress.stage !== "failed" && progress.stage !== "done"}>
              <Sparkle weight="fill" /> Generate range plan
            </Button>
            {latestRun && (
              <Link to={`/runs/${latestRun.id}`}>
                <Button variant="outline">View latest result</Button>
              </Link>
            )}
            {stageBadge}
          </div>

          {progress && (
            <div className="mt-5">
              <div className="flex items-center justify-between text-xs text-[color:var(--color-muted-foreground)] mb-1">
                <span>
                  <Clock className="inline" /> {progress.message}
                </span>
                <span>{progress.elapsed_s.toFixed(1)}s</span>
              </div>
              <div className="h-2 w-full rounded-full bg-[color:var(--color-muted)] overflow-hidden">
                <div
                  className="h-full bg-[color:var(--color-secondary)] transition-all"
                  style={{ width: `${progress.pct}%` }}
                />
              </div>
            </div>
          )}

          {errMsg && (
            <div className="mt-4 text-sm text-[color:var(--color-destructive)]">{errMsg}</div>
          )}
        </Card>

        <Card>
          <CardHeader title="Flight context" />
          <div className="text-sm">
            <div className="font-medium mb-2 flex items-center gap-2">
              <AirplaneTakeoff /> Pax mix
            </div>
            <ul className="space-y-1">
              {paxMix.map(([segment, share]) => (
                <li key={segment} className="flex items-center justify-between">
                  <span className="capitalize">{segment}</span>
                  <span className="text-[color:var(--color-muted-foreground)]">{(share * 100).toFixed(0)}%</span>
                </li>
              ))}
            </ul>
            {ac && (
              <div className="mt-4 text-xs text-[color:var(--color-muted-foreground)]">
                Aircraft max payload <strong>{fmtNum(ac.max_payload_kg)} kg</strong>. Retail load capped at the slider value above.
              </div>
            )}
            {latestRun?.expected_net_contribution != null && (
              <div className="mt-4 text-xs">
                Latest run net contribution: <strong>{fmtGbpDetail(latestRun.expected_net_contribution)}</strong>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
  hint,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  hint?: string;
}) {
  return (
    <label className="flex flex-col gap-1">
      <div className="flex items-baseline justify-between">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm text-[color:var(--color-muted-foreground)] tabular-nums">
          {value.toFixed(unit === "%" ? 0 : 0)}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="accent-[color:var(--color-secondary)]"
      />
      {hint && <span className="text-xs text-[color:var(--color-muted-foreground)]">{hint}</span>}
    </label>
  );
}
