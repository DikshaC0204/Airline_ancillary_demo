import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { Card, CardHeader, Button, Badge } from "@/components/ui";
import { ChatTeardropDots, Sparkle } from "@phosphor-icons/react";

type Flight = { id: number; flight_no: string; scheduled_dt: string };

type FeedbackItem = {
  id: number;
  flight_id: number | null;
  flight_no: string | null;
  sku_id: number | null;
  sku_label: string | null;
  free_text: string;
  structured: {
    sku_code?: string;
    sku_name?: string;
    signal_type?: string;
    severity?: number;
    normalised?: string;
    crew_member?: string;
  };
};

const SIGNAL_TONE: Record<string, "success" | "info" | "warning" | "error" | "neutral"> = {
  stockout: "error",
  waste: "warning",
  quality: "warning",
  presentation: "info",
  ops: "info",
  other: "neutral",
};

const EXAMPLES = [
  "Ran out of Heineken on the LTN flight Saturday — needed double the load.",
  "Lots of leftover sandwiches at the end of the flight, threw away ~8 units.",
  "Gin & tonic was a hit but we only had 4 cans, sold out in row 3.",
];

export default function CrewFeedbackPage() {
  const [text, setText] = useState("");
  const [flightId, setFlightId] = useState<number | "">("");
  const [crewMember, setCrewMember] = useState("");

  const qc = useQueryClient();

  const { data: flights } = useQuery({
    queryKey: ["flights"],
    queryFn: () => apiFetch<{ total: number; items: Flight[] }>("/flights?limit=100"),
    select: (resp) => resp.items,
  });

  const { data: feedback, isLoading } = useQuery({
    queryKey: ["crew-feedback"],
    queryFn: () => apiFetch<FeedbackItem[]>("/ai/crew-feedback"),
  });

  const submit = useMutation({
    mutationFn: () =>
      apiFetch<{ id: number; structured: any }>("/ai/crew-feedback", {
        method: "POST",
        body: JSON.stringify({
          text: text.trim(),
          flight_id: flightId === "" ? null : Number(flightId),
          crew_member: crewMember.trim() || null,
        }),
      }),
    onSuccess: () => {
      setText("");
      qc.invalidateQueries({ queryKey: ["crew-feedback"] });
    },
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader
          title="Submit crew feedback"
          subtitle="Free-text observations from the cabin — Azure OpenAI extracts SKU, signal, severity."
          right={<Badge tone="success"><Sparkle size={12} weight="fill" className="inline mr-1" />AI-assisted</Badge>}
        />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (text.trim()) submit.mutate();
          }}
          className="flex flex-col gap-3"
        >
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={5}
            placeholder="What did you notice on the flight? Be specific — mention SKUs, quantities, what ran out or got wasted."
            className="w-full px-4 py-3 rounded-md border border-[color:var(--color-border)] bg-[color:var(--color-background)] text-sm resize-none"
          />

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-[color:var(--color-muted-foreground)] block mb-1">Flight (optional)</label>
              <select
                value={flightId}
                onChange={(e) => setFlightId(e.target.value === "" ? "" : Number(e.target.value))}
                className="w-full h-9 px-3 rounded-md border border-[color:var(--color-border)] bg-[color:var(--color-background)] text-sm"
              >
                <option value="">—</option>
                {flights?.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.flight_no} · {new Date(f.scheduled_dt).toLocaleDateString()}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-[color:var(--color-muted-foreground)] block mb-1">Crew member (optional)</label>
              <input
                value={crewMember}
                onChange={(e) => setCrewMember(e.target.value)}
                placeholder="A. Smith"
                className="w-full h-9 px-3 rounded-md border border-[color:var(--color-border)] bg-[color:var(--color-background)] text-sm"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button type="submit" variant="primary" disabled={!text.trim() || submit.isPending}>
              {submit.isPending ? "Analysing…" : "Submit"}
            </Button>
            {submit.isError && (
              <span className="text-xs" style={{ color: "var(--color-destructive)" }}>
                {(submit.error as Error).message}
              </span>
            )}
            {submit.isSuccess && (
              <span className="text-xs" style={{ color: "var(--color-accent)" }}>
                Logged.
              </span>
            )}
          </div>

          <div className="mt-1">
            <div className="text-xs text-[color:var(--color-muted-foreground)] mb-1.5">Try an example:</div>
            <div className="flex flex-wrap gap-2">
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => setText(ex)}
                  className="text-xs px-3 py-1.5 rounded-full border border-[color:var(--color-border)] bg-[color:var(--color-background)] hover:bg-[color:var(--color-secondary)]/10 text-left max-w-md"
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>
        </form>
      </Card>

      <Card>
        <CardHeader
          title="Recent feedback"
          subtitle={feedback ? `${feedback.length} entries` : "loading…"}
        />
        {isLoading && <div className="text-sm text-[color:var(--color-muted-foreground)]">Loading…</div>}
        {feedback && feedback.length === 0 && (
          <div className="text-sm text-[color:var(--color-muted-foreground)]">No feedback yet.</div>
        )}
        <div className="flex flex-col gap-3 max-h-[600px] overflow-y-auto">
          {feedback?.map((fb) => (
            <FeedbackCard key={fb.id} fb={fb} />
          ))}
        </div>
      </Card>
    </div>
  );
}

function FeedbackCard({ fb }: { fb: FeedbackItem }) {
  const sig = fb.structured?.signal_type ?? "other";
  const sev = fb.structured?.severity;
  return (
    <div className="border border-[color:var(--color-border)] rounded-md p-3 bg-[color:var(--color-muted)]">
      <div className="flex items-start gap-2 mb-2">
        <ChatTeardropDots size={16} weight="fill" className="mt-0.5" style={{ color: "var(--color-secondary)" }} />
        <div className="flex-1 text-sm">{fb.free_text}</div>
      </div>
      <div className="flex flex-wrap items-center gap-2 text-xs">
        {fb.structured?.signal_type && (
          <Badge tone={SIGNAL_TONE[sig] ?? "neutral"}>{sig}</Badge>
        )}
        {sev != null && (
          <span className="text-[color:var(--color-muted-foreground)]">
            severity {sev}/5
          </span>
        )}
        {(fb.structured?.sku_code || fb.sku_label) && (
          <span className="font-mono text-[11px]">
            → {fb.structured?.sku_code ?? fb.sku_label}
          </span>
        )}
        {fb.flight_no && (
          <span className="text-[color:var(--color-muted-foreground)]">flight {fb.flight_no}</span>
        )}
        {fb.structured?.crew_member && (
          <span className="text-[color:var(--color-muted-foreground)]">— {fb.structured.crew_member}</span>
        )}
      </div>
      {fb.structured?.normalised && fb.structured.normalised !== fb.free_text && (
        <div className="text-xs italic mt-1.5 text-[color:var(--color-muted-foreground)]">
          {fb.structured.normalised}
        </div>
      )}
    </div>
  );
}
