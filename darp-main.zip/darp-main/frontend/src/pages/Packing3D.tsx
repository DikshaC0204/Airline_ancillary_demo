import { Suspense, useState, useMemo } from "react";
import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { Card, CardHeader, Button, Badge, Kpi } from "@/components/ui";
import { fmtNum } from "@/lib/format";
import { CartScene, type PackingPayload, type ViewMode, type DrawerPacking } from "@/components/packing3d/CartScene";

type SkuRow = {
  id: number;
  unit_weight_g: number;
};

export default function PackingPage() {
  const { id } = useParams();
  const runId = Number(id);
  const [viewMode, setViewMode] = useState<ViewMode>("category");
  const [selected, setSelected] = useState<DrawerPacking | null>(null);

  const { data, isLoading, error } = useQuery({
    queryKey: ["packing", runId],
    queryFn: () => apiFetch<PackingPayload>(`/runs/${runId}/packing`),
    enabled: !Number.isNaN(runId),
  });

  // Used only for weight view shading.
  const { data: skusResp } = useQuery({
    queryKey: ["skus-weights"],
    queryFn: () => apiFetch<{ total: number; items: SkuRow[] }>("/skus?limit=1000"),
    staleTime: 5 * 60 * 1000,
  });

  const weightLookup = useMemo(() => {
    const items = skusResp?.items;
    if (!items) return undefined;
    const m: Record<number, number> = {};
    for (const s of items) m[s.id] = s.unit_weight_g;
    return m;
  }, [skusResp]);

  if (isLoading) return <Card>Loading 3D layout…</Card>;
  if (error || !data) return <Card>Packing data not available.</Card>;

  const drawerCount = data.cart_layout.reduce((s, c) => s + c.drawers.length, 0);
  const usedDrawers = data.cart_layout.reduce(
    (s, c) => s + c.drawers.filter((d) => d.placements.length > 0).length,
    0
  );

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title={`Packing — Run #${data.run_id}`}
          subtitle={`${fmtNum(data.totals.total_units_packed)} units across ${usedDrawers}/${drawerCount} drawers`}
          right={
            <div className="flex items-center gap-2">
              <Link to={`/runs/${data.run_id}`}>
                <Button variant="ghost">← Decisions</Button>
              </Link>
              <Badge tone="info">3D view</Badge>
            </div>
          }
        />

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Kpi label="Units packed" value={fmtNum(data.totals.total_units_packed)} tone="secondary" />
          <Kpi label="Total weight" value={`${data.totals.total_weight_kg.toFixed(1)} kg`} />
          <Kpi label="Drawers in use" value={`${usedDrawers} / ${drawerCount}`} />
          <Kpi label="Carts" value={fmtNum(data.cart_layout.length)} />
        </div>

        <div className="mt-4 flex items-center gap-2">
          <span className="text-xs text-[color:var(--color-muted-foreground)] uppercase tracking-wide">Colour by</span>
          <ToggleButton active={viewMode === "category"} onClick={() => setViewMode("category")}>Category</ToggleButton>
          <ToggleButton active={viewMode === "velocity"} onClick={() => setViewMode("velocity")}>Velocity</ToggleButton>
          <ToggleButton active={viewMode === "weight"} onClick={() => setViewMode("weight")}>Weight</ToggleButton>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        <Card className="overflow-hidden" padding="">
          <div style={{ height: 600 }} className="bg-[color:var(--color-muted)]">
            <Suspense fallback={<div className="p-4 text-sm">Loading scene…</div>}>
              <CartScene
                payload={data}
                viewMode={viewMode}
                unitWeightLookup={weightLookup}
                onSelectDrawer={setSelected}
              />
            </Suspense>
          </div>
          <div className="px-4 py-3 text-xs text-[color:var(--color-muted-foreground)] border-t border-[color:var(--color-border)]">
            Drag to orbit · scroll to zoom · right-click drag to pan · click a drawer to slide it out
          </div>
        </Card>

        <Card>
          <CardHeader title={selected ? `Drawer #${selected.slot_index}` : "Drawer inspector"} subtitle={selected ? selected.drawer_type : "Click a drawer in the 3D view"} />
          {selected ? (
            <div className="flex flex-col gap-3 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <Kpi label="Weight" value={`${selected.weight_kg.toFixed(2)} / ${selected.weight_cap_kg.toFixed(0)} kg`} />
                <Kpi label="Volume used" value={`${(selected.volume_used_cm3 / 1000).toFixed(1)} L`} hint={`of ${(selected.volume_total_cm3 / 1000).toFixed(1)} L`} />
              </div>
              <div className="text-xs text-[color:var(--color-muted-foreground)]">
                Internal {selected.internal_l_mm}×{selected.internal_w_mm}×{selected.internal_h_mm} mm · accessibility {selected.accessibility_score}
              </div>
              <div className="border-t border-[color:var(--color-border)] pt-3">
                <div className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)] mb-1">SKUs</div>
                <ul className="flex flex-col gap-1.5 max-h-[360px] overflow-y-auto">
                  {selected.placements.map((p) => (
                    <li key={p.sku_id} className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-medium truncate">{p.sku_name}</div>
                        <div className="text-xs text-[color:var(--color-muted-foreground)]">{p.sku_code} · {p.category}</div>
                      </div>
                      <Badge tone="info">{p.units}×</Badge>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="text-sm text-[color:var(--color-muted-foreground)]">No drawer selected.</div>
          )}
        </Card>
      </div>
    </div>
  );
}

function ToggleButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`h-8 px-3 rounded-[var(--radius-md)] text-xs font-medium border transition-colors ${
        active
          ? "bg-[color:var(--color-primary)] text-[color:var(--color-primary-foreground)] border-[color:var(--color-primary)]"
          : "bg-[color:var(--color-background)] border-[color:var(--color-input)] hover:bg-[color:var(--color-muted)]"
      }`}
    >
      {children}
    </button>
  );
}
