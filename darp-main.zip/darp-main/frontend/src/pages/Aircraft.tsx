import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtNum } from "@/lib/format";
import { Card, CardHeader, Badge } from "@/components/ui";

type Aircraft = {
  id: number;
  registration: string;
  type: string;
  retail_galley_layout_id: number;
  empty_weight_kg: number;
  max_payload_kg: number;
  fuel_burn_coeff_short: number;
  fuel_burn_coeff_medium: number;
  fuel_burn_coeff_long: number;
};

export default function AircraftPage() {
  const { data } = useQuery({
    queryKey: ["aircraft"],
    queryFn: () => apiFetch<Aircraft[]>("/aircraft"),
  });
  if (!data) return <div className="text-[color:var(--color-muted-foreground)]">Loading…</div>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {data.map((a) => (
        <Card key={a.id}>
          <CardHeader title={a.registration} subtitle={a.type} right={<Badge tone="info">{a.type}</Badge>} />
          <div className="grid grid-cols-2 gap-3 text-sm">
            <Stat label="Empty weight" value={`${fmtNum(Math.round(a.empty_weight_kg))} kg`} />
            <Stat label="Max payload" value={`${fmtNum(Math.round(a.max_payload_kg))} kg`} />
            <Stat label="Burn coeff (short)" value={a.fuel_burn_coeff_short.toFixed(3)} />
            <Stat label="Burn coeff (medium)" value={a.fuel_burn_coeff_medium.toFixed(3)} />
            <Stat label="Burn coeff (long)" value={a.fuel_burn_coeff_long.toFixed(3)} />
            <Stat label="Galley layout" value={`#${a.retail_galley_layout_id}`} />
          </div>
          <div className="mt-4 text-xs text-[color:var(--color-muted-foreground)]">
            Galley schematic with sliding drawers.
          </div>
        </Card>
      ))}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="border border-[color:var(--color-border)] rounded-[var(--radius-md)] px-3 py-2">
      <div className="text-xs text-[color:var(--color-muted-foreground)]">{label}</div>
      <div className="font-semibold">{value}</div>
    </div>
  );
}
