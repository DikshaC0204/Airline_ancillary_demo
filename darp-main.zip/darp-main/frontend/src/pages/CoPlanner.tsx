import { useState, useRef, useEffect } from "react";
import * as React from "react";
import { Card, CardHeader, Badge } from "@/components/ui";
import { useMutation } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { PaperPlaneTilt, Wrench, User, Robot, Spinner } from "@phosphor-icons/react";

type ChatMessage = { role: "user" | "assistant"; content: string; tools?: ToolTraceItem[] };
type ToolTraceItem = { tool: string; args: any; result: any };
type ChatResponse = { reply: string; tool_trace: ToolTraceItem[] };

const SUGGESTIONS = [
  "What is the top contributing SKU?",
  "Why was beer reduced?",
  "Summarise the run in 3 bullets.",
  "Which categories drive the most net contribution?",
];

export default function CoPlannerPage() {
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [contextRunId, setContextRunId] = useState<string>("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [history]);

  const send = useMutation({
    mutationFn: async (message: string) => {
      const body = {
        message,
        history: history.map((m) => ({ role: m.role, content: m.content })),
        context_run_id: contextRunId ? Number(contextRunId) : null,
      };
      return apiFetch<ChatResponse>("/ai/chat", {
        method: "POST",
        body: JSON.stringify(body),
      });
    },
    onSuccess: (resp) => {
      setHistory((h) => [
        ...h,
        { role: "assistant", content: resp.reply, tools: resp.tool_trace },
      ]);
    },
    onError: (err: any) => {
      setHistory((h) => [
        ...h,
        { role: "assistant", content: `Error: ${err?.message ?? "unknown"}` },
      ]);
    },
  });

  function submit(text: string) {
    const t = text.trim();
    if (!t || send.isPending) return;
    setHistory((h) => [...h, { role: "user", content: t }]);
    setInput("");
    send.mutate(t);
  }

  return (
    <div className="grid grid-cols-1 gap-6">
      <Card>
        <CardHeader
          title="AI Co-Planner"
          subtitle="Function-calling chat backed by Azure OpenAI. Asks the optimiser for real numbers."
          right={<Badge tone="success">Live</Badge>}
        />

        <div className="flex items-center gap-3 mb-4 text-sm">
          <label className="text-[color:var(--color-muted-foreground)]">Context run ID:</label>
          <input
            type="number"
            value={contextRunId}
            onChange={(e) => setContextRunId(e.target.value)}
            placeholder="optional"
            className="w-32 px-3 py-1.5 rounded-md border border-[color:var(--color-border)] bg-[color:var(--color-background)]"
          />
          <span className="text-xs text-[color:var(--color-muted-foreground)]">
            Tools auto-filter to this run when set.
          </span>
          {history.length > 0 && (
            <button
              onClick={() => setHistory([])}
              className="ml-auto text-xs text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-foreground)]"
            >
              Clear chat
            </button>
          )}
        </div>

        <div
          ref={scrollRef}
          className="h-[480px] overflow-y-auto border border-[color:var(--color-border)] rounded-md p-4 bg-[color:var(--color-muted)] flex flex-col gap-4"
        >
          {history.length === 0 && (
            <div className="text-center text-sm text-[color:var(--color-muted-foreground)] my-auto">
              <Robot size={36} className="mx-auto mb-2 opacity-50" />
              <div className="mb-3">Ask anything about a run, scenario, or SKU.</div>
              <div className="flex flex-col gap-2 items-center">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => submit(s)}
                    className="text-xs px-3 py-1.5 rounded-full border border-[color:var(--color-border)] bg-[color:var(--color-background)] hover:bg-[color:var(--color-secondary)]/10"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {history.map((m, i) => (
            <ChatBubble key={i} msg={m} />
          ))}

          {send.isPending && (
            <div className="flex items-center gap-2 text-sm text-[color:var(--color-muted-foreground)]">
              <Spinner size={16} className="animate-spin" /> thinking…
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit(input);
          }}
          className="mt-4 flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask the co-planner…"
            className="flex-1 px-4 py-2.5 rounded-md border border-[color:var(--color-border)] bg-[color:var(--color-background)]"
          />
          <button
            type="submit"
            disabled={send.isPending || !input.trim()}
            className="px-5 py-2.5 rounded-md bg-[color:var(--color-primary)] text-white text-sm font-medium hover:opacity-90 disabled:opacity-40 flex items-center gap-2"
          >
            <PaperPlaneTilt size={16} weight="fill" />
            Send
          </button>
        </form>
      </Card>
    </div>
  );
}

function ChatBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className="h-7 w-7 rounded-full flex items-center justify-center shrink-0"
        style={{
          background: isUser ? "var(--color-secondary)" : "var(--color-primary)",
          color: isUser
            ? "var(--color-secondary-foreground)"
            : "var(--color-primary-foreground)",
        }}
      >
        {isUser ? <User size={14} weight="bold" /> : <Robot size={14} weight="bold" />}
      </div>
      <div className={`max-w-[80%] ${isUser ? "text-right" : ""}`}>
        <div
          className={`inline-block px-3.5 py-2 rounded-lg text-sm whitespace-pre-wrap text-left ${
            isUser
              ? "bg-[color:var(--color-primary)] text-white"
              : "bg-[color:var(--color-background)] border border-[color:var(--color-border)]"
          }`}
        >
          {isUser ? msg.content : <Markdown text={msg.content} />}
        </div>
        {msg.tools && msg.tools.length > 0 && (
          <details className="mt-1.5 text-xs text-[color:var(--color-muted-foreground)]">
            <summary className="cursor-pointer flex items-center gap-1.5 hover:text-[color:var(--color-foreground)]">
              <Wrench size={12} /> {msg.tools.length} tool call{msg.tools.length > 1 ? "s" : ""}
            </summary>
            <div className="mt-1.5 flex flex-col gap-1.5 pl-4">
              {msg.tools.map((t, i) => (
                <div
                  key={i}
                  className="font-mono text-[11px] bg-[color:var(--color-muted)] px-2 py-1 rounded border border-[color:var(--color-border)]"
                >
                  <div className="font-semibold text-[color:var(--color-secondary)]">{t.tool}</div>
                  <div className="opacity-70">args: {JSON.stringify(t.args)}</div>
                </div>
              ))}
            </div>
          </details>
        )}
      </div>
    </div>
  );
}

/** Minimal inline markdown: **bold**, *italic*, `code`, and bullet/numbered lists.
 *  No dependency, safe-by-construction (no raw HTML interpretation). */
function Markdown({ text }: { text: string }) {
  const lines = text.split(/\r?\n/);
  const blocks: Array<{ type: "p" | "ul" | "ol"; items: string[] }> = [];
  for (const raw of lines) {
    const line = raw.replace(/\s+$/, "");
    const ulMatch = line.match(/^\s*[-*]\s+(.*)$/);
    const olMatch = line.match(/^\s*\d+\.\s+(.*)$/);
    if (ulMatch) {
      const last = blocks[blocks.length - 1];
      if (last && last.type === "ul") last.items.push(ulMatch[1]);
      else blocks.push({ type: "ul", items: [ulMatch[1]] });
    } else if (olMatch) {
      const last = blocks[blocks.length - 1];
      if (last && last.type === "ol") last.items.push(olMatch[1]);
      else blocks.push({ type: "ol", items: [olMatch[1]] });
    } else {
      blocks.push({ type: "p", items: [line] });
    }
  }
  return (
    <div className="flex flex-col gap-2">
      {blocks.map((b, i) => {
        if (b.type === "ul") {
          return (
            <ul key={i} className="list-disc pl-5 flex flex-col gap-0.5">
              {b.items.map((it, j) => (
                <li key={j}>{renderInline(it)}</li>
              ))}
            </ul>
          );
        }
        if (b.type === "ol") {
          return (
            <ol key={i} className="list-decimal pl-5 flex flex-col gap-0.5">
              {b.items.map((it, j) => (
                <li key={j}>{renderInline(it)}</li>
              ))}
            </ol>
          );
        }
        return <div key={i}>{renderInline(b.items[0])}</div>;
      })}
    </div>
  );
}

function renderInline(text: string): React.ReactNode {
  // Tokenise on **bold**, *italic*, `code`. Order matters: bold before italic.
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  const parts = text.split(re).filter((p) => p !== "");
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) {
      return <strong key={i}>{p.slice(2, -2)}</strong>;
    }
    if (p.startsWith("*") && p.endsWith("*") && p.length > 2) {
      return <em key={i}>{p.slice(1, -1)}</em>;
    }
    if (p.startsWith("`") && p.endsWith("`")) {
      return (
        <code key={i} className="px-1 py-0.5 rounded bg-[color:var(--color-muted)] text-[12px] font-mono">
          {p.slice(1, -1)}
        </code>
      );
    }
    return <span key={i}>{p}</span>;
  });
}
