import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtGbpDetail, fmtNum } from "@/lib/format";
import { Card, CardHeader, Badge } from "@/components/ui";

type Sku = {
  id: number;
  code: string;
  name: string;
  category: string;
  brand: string;
  unit_weight_g: number;
  volume_cm3: number;
  length_mm: number;
  width_mm: number;
  height_mm: number;
  retail_price: number;
  margin_pct: number;
  bonded: boolean;
  hazard_class: string;
};

export default function SkusPage() {
  const { data } = useQuery({
    queryKey: ["skus", "grid"],
    queryFn: () => apiFetch<{ total: number; items: Sku[] }>("/skus?limit=1000"),
  });
  if (!data) return <div className="text-[color:var(--color-muted-foreground)]">Loading…</div>;

  // Group by category.
  const byCat: Record<string, Sku[]> = {};
  for (const s of data.items) (byCat[s.category] ||= []).push(s);

  return (
    <div className="flex flex-col gap-6">
      {Object.entries(byCat).map(([cat, items]) => (
        <Card key={cat}>
          <CardHeader title={cat} subtitle={`${items.length} SKUs · ${fmtNum(items.reduce((a, b) => a + b.unit_weight_g, 0))} g total weight`} />
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
            {items.map((s) => (
              <div
                key={s.id}
                className="border border-[color:var(--color-border)] rounded-[var(--radius-md)] p-3 text-sm"
              >
                <div className="font-medium">{s.name}</div>
                <div className="text-xs text-[color:var(--color-muted-foreground)] mb-2">
                  {s.code} · {s.brand}
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span>{fmtGbpDetail(s.retail_price)}</span>
                  <span className="text-[color:var(--color-accent)]">{(s.margin_pct * 100).toFixed(0)}% margin</span>
                </div>
                <div className="text-xs text-[color:var(--color-muted-foreground)] mt-1">
                  {s.unit_weight_g} g · {Math.round(s.volume_cm3)} cm³
                </div>
                <div className="text-xs text-[color:var(--color-muted-foreground)] mt-0.5">
                  {Math.round(s.length_mm)} × {Math.round(s.width_mm)} × {Math.round(s.height_mm)} mm
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {s.bonded && <Badge tone="warning">bonded</Badge>}
                  {s.hazard_class === "alcohol" && <Badge tone="info">alcohol</Badge>}
                  {s.hazard_class === "tobacco" && <Badge tone="error">tobacco</Badge>}
                </div>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}
