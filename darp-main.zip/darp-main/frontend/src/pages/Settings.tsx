import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, Flask, Warning } from "@phosphor-icons/react";
import { apiFetch } from "@/lib/api";
import { fmtNum } from "@/lib/format";
import { Badge, Button, Card, CardHeader, EmptyState, ErrorNote, Loading } from "@/components/ui";

type MethodState = "ready" | "stale" | "missing" | "unavailable";

type MethodInfo = {
  method: string;
  label: string;
  available: boolean;
  state: MethodState;
  detail?: string;
  library_version?: string;
  model?: {
    model_id: string | null;
    state: MethodState;
    trained_at?: string | null;
    information_cutoff?: string | null;
    rows?: number | null;
  };
};

type Job = {
  id: number;
  model_id: string;
  state: string;
  progress_pct: number;
  message?: string | null;
  error?: string | null;
  requested_cutoff?: string | null;
  information_cutoff?: string | null;
  finished_at?: string | null;
  is_terminal: boolean;
};

type SettingsPayload = {
  forecast_method: string;
  active_model_id: string | null;
  revision: number;
  methods: MethodInfo[];
  dataset: {
    history_from?: string | null;
    history_to?: string | null;
    recommended_cutoff?: string | null;
  };
  latest_job: Job | null;
};

type Metrics = {
  rows: number;
  censored_nll: number | null;
  capped_mae: number | null;
  capped_wape: number | null;
  capped_bias: number | null;
  demand_mae_uncensored: number | null;
  sellout_rows: number;
};

type MethodReport = {
  method: string;
  metrics: Metrics;
  vs_empirical?: {
    delta: number | null;
    stderr: number | null;
    dates: number;
    distinguishable: boolean;
    improves?: boolean;
  };
  train_seconds: number;
  note: string;
};

type Evaluation = {
  report: {
    cutoff: string;
    validation_from: string;
    rows: { total: number; train: number; test: number };
    dataset: Record<string, any>;
    methods: MethodReport[];
    best_by_censored_nll: string | null;
    best_is_distinguishable: boolean;
    caveats: string[];
  } | null;
  job: Job | null;
};

const METHOD_LABELS: Record<string, string> = {
  empirical: "Empirical",
  poisson_glm: "Poisson regression",
  lightgbm: "LightGBM",
};

const shortDate = (v?: string | null) =>
  v ? new Date(v).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—";

const num = (v: number | null | undefined, digits = 4) =>
  v === null || v === undefined ? "—" : v.toFixed(digits);

function toneFor(state: MethodState): "success" | "warning" | "neutral" {
  if (state === "ready") return "success";
  if (state === "stale") return "warning";
  return "neutral";
}

export default function SettingsPage() {
  const qc = useQueryClient();
  const [choice, setChoice] = useState<string | null>(null);
  const [cutoff, setCutoff] = useState<string>("");

  const settings = useQuery({
    queryKey: ["settings"],
    queryFn: () => apiFetch<SettingsPayload>("/settings"),
  });

  const job = settings.data?.latest_job ?? null;
  const jobRunning = !!job && !job.is_terminal;

  // Poll only while a job is live; picks back up after a browser refresh.
  const jobQuery = useQuery({
    queryKey: ["training-job", job?.id],
    queryFn: () => apiFetch<Job>(`/forecasting/jobs/${job!.id}`),
    enabled: jobRunning,
    refetchInterval: jobRunning ? 1500 : false,
  });

  const evaluation = useQuery({
    queryKey: ["evaluation", job?.id, job?.state],
    queryFn: () => apiFetch<Evaluation>("/forecasting/evaluations/latest"),
  });

  useEffect(() => {
    if (jobQuery.data?.is_terminal) {
      qc.invalidateQueries({ queryKey: ["settings"] });
      qc.invalidateQueries({ queryKey: ["evaluation"] });
    }
  }, [jobQuery.data?.is_terminal, qc]);

  useEffect(() => {
    if (settings.data && choice === null) setChoice(settings.data.forecast_method);
    if (settings.data && !cutoff && settings.data.dataset.recommended_cutoff) {
      setCutoff(settings.data.dataset.recommended_cutoff.slice(0, 10));
    }
  }, [settings.data, choice, cutoff]);

  const train = useMutation({
    mutationFn: () =>
      apiFetch<{ job: Job }>("/forecasting/train-evaluate", {
        method: "POST",
        body: JSON.stringify({ cutoff: cutoff ? `${cutoff}T00:00:00` : null }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settings"] }),
  });

  const save = useMutation({
    mutationFn: (method: string) =>
      apiFetch<SettingsPayload>("/settings", {
        method: "PATCH",
        body: JSON.stringify({ forecast_method: method }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settings"] }),
  });

  const methods = settings.data?.methods ?? [];
  const chosenInfo = useMemo(
    () => methods.find((m) => m.method === choice),
    [methods, choice]
  );
  const dirty = !!settings.data && choice !== settings.data.forecast_method;

  if (settings.isLoading) return <Loading label="Loading settings…" />;
  if (settings.error || !settings.data)
    return <ErrorNote title="Could not load settings" error={settings.error} />;

  const lgb = methods.find((m) => m.method === "lightgbm");

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title="Demand forecasting"
          subtitle="Which model estimates demand before the optimiser decides what to load. The change applies to the next run; plans already created keep the method they were built with."
        />

        <fieldset className="flex flex-col gap-3" disabled={save.isPending}>
          <legend className="sr-only">Forecasting method</legend>
          {methods.map((m) => {
            const disabled = !m.available;
            return (
              <label
                key={m.method}
                className={[
                  "flex items-start gap-3 rounded-[var(--radius-md)] border p-4 transition-colors",
                  choice === m.method
                    ? "border-[color:var(--color-secondary)] bg-[color:var(--color-secondary)]/5"
                    : "border-[color:var(--color-border)]",
                  disabled ? "opacity-60 cursor-not-allowed" : "cursor-pointer",
                ].join(" ")}
              >
                <input
                  type="radio"
                  name="forecast-method"
                  className="mt-1"
                  value={m.method}
                  checked={choice === m.method}
                  disabled={disabled}
                  onChange={() => setChoice(m.method)}
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{m.label}</span>
                    <Badge tone={toneFor(m.state)}>{m.state}</Badge>
                    {m.library_version && (
                      <span className="text-xs text-[color:var(--color-muted-foreground)]">
                        v{m.library_version}
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-[color:var(--color-muted-foreground)] mt-1">
                    {m.detail}
                  </div>
                  {m.model?.model_id && (
                    <div className="text-xs text-[color:var(--color-muted-foreground)] mt-2 font-mono">
                      model {m.model.model_id} · trained on data to{" "}
                      {shortDate(m.model.information_cutoff)}
                      {m.model.rows ? ` · ${fmtNum(m.model.rows)} observations` : ""}
                    </div>
                  )}
                </div>
              </label>
            );
          })}
        </fieldset>

        {chosenInfo && !chosenInfo.available && (
          <div className="mt-3">
            <Badge tone="warning">
              {chosenInfo.label} cannot be selected until a model is trained and current
            </Badge>
          </div>
        )}

        <div className="flex items-center gap-3 mt-5">
          <Button
            variant="primary"
            disabled={!dirty || !chosenInfo?.available || save.isPending}
            onClick={() => choice && save.mutate(choice)}
          >
            {save.isPending ? "Saving…" : "Save"}
          </Button>
          {dirty && (
            <span className="text-sm text-[color:var(--color-muted-foreground)]">
              Unsaved change
            </span>
          )}
          {!dirty && save.isSuccess && (
            <span className="text-sm flex items-center gap-1 text-[color:var(--color-accent)]">
              <CheckCircle size={16} weight="fill" /> Saved
            </span>
          )}
        </div>
        {save.error && (
          <div className="mt-3">
            <ErrorNote title="Could not change the method" error={save.error} />
          </div>
        )}
      </Card>

      <Card>
        <CardHeader
          title="Train and evaluate"
          subtitle="Fits a LightGBM model on history up to the cutoff, then scores it against the empirical model and a simpler Poisson regression on dates none of them were trained on."
          right={
            lgb?.state === "unavailable" ? (
              <Badge tone="neutral">LightGBM not installed</Badge>
            ) : undefined
          }
        />

        <div className="flex flex-wrap items-end gap-4">
          <label className="flex flex-col gap-1">
            <span className="text-xs uppercase tracking-wide font-semibold text-[color:var(--color-muted-foreground)]">
              Training cutoff
            </span>
            <input
              type="date"
              value={cutoff}
              onChange={(e) => setCutoff(e.target.value)}
              disabled={jobRunning}
              className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-border)] bg-[color:var(--color-background)] text-sm"
            />
          </label>
          <Button
            variant="secondary"
            disabled={jobRunning || train.isPending || lgb?.state === "unavailable"}
            onClick={() => train.mutate()}
          >
            <Flask size={16} />
            {jobRunning ? "Training…" : "Train / Evaluate"}
          </Button>
          <div className="text-xs text-[color:var(--color-muted-foreground)] max-w-sm">
            History runs {shortDate(settings.data.dataset.history_from)} to{" "}
            {shortDate(settings.data.dataset.history_to)}. Flights after the cutoff stay unseen, so
            they can be planned as genuine out-of-time targets.
          </div>
        </div>

        {train.error && (
          <div className="mt-3">
            <ErrorNote title="Could not start training" error={train.error} />
          </div>
        )}

        {job && <JobStatus job={jobQuery.data ?? job} />}
      </Card>

      <ComparisonCard
        evaluation={evaluation.data}
        loading={evaluation.isLoading}
        error={evaluation.error}
      />
    </div>
  );
}

function JobStatus({ job }: { job: Job }) {
  const tone =
    job.state === "succeeded" ? "success" : job.state === "failed" || job.state === "interrupted" ? "error" : "info";
  return (
    <div className="mt-4 rounded-[var(--radius-md)] border border-[color:var(--color-border)] p-4">
      <div className="flex items-center gap-2 flex-wrap">
        <Badge tone={tone as any}>{job.state}</Badge>
        <span className="text-sm">{job.message}</span>
      </div>
      {!job.is_terminal && (
        <div className="h-1.5 mt-3 rounded-full bg-[color:var(--color-muted)] overflow-hidden">
          <div
            className="h-full bg-[color:var(--color-secondary)] transition-all"
            style={{ width: `${job.progress_pct}%` }}
          />
        </div>
      )}
      {job.error && (
        <div className="text-xs font-mono mt-2 text-[color:var(--color-destructive)] break-all">
          {job.error}
        </div>
      )}
      {job.state === "succeeded" && (
        <div className="text-xs text-[color:var(--color-muted-foreground)] mt-2">
          Trained models are not activated automatically — select LightGBM above and save to use it.
        </div>
      )}
    </div>
  );
}

function ComparisonCard({
  evaluation,
  loading,
  error,
}: {
  evaluation?: Evaluation;
  loading: boolean;
  error: unknown;
}) {
  if (loading) return <Card><Loading label="Loading comparison…" /></Card>;
  if (error)
    return (
      <Card>
        <ErrorNote title="Could not load the comparison" error={error} />
      </Card>
    );

  const report = evaluation?.report;
  if (!report) {
    return (
      <Card>
        <CardHeader title="Method comparison" />
        <EmptyState
          title="Nothing measured yet"
          body="Run Train / Evaluate to score the methods against held-out dates."
        />
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader
        title="Method comparison"
        subtitle={`Scored on ${fmtNum(report.rows.test)} observations from ${shortDate(
          report.validation_from
        )} onwards — dates no method was trained on.`}
        right={
          report.best_by_censored_nll ? (
            <Badge tone={report.best_is_distinguishable ? "success" : "warning"}>
              {report.best_is_distinguishable
                ? `${METHOD_LABELS[report.best_by_censored_nll] ?? report.best_by_censored_nll} scores best`
                : "No clear winner"}
            </Badge>
          ) : undefined
        }
      />

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
              <th className="py-2 pr-4 font-semibold">Method</th>
              <th className="py-2 pr-4 font-semibold">Log score</th>
              <th className="py-2 pr-4 font-semibold">Sales error</th>
              <th className="py-2 pr-4 font-semibold">Bias</th>
              <th className="py-2 pr-4 font-semibold">vs empirical</th>
              <th className="py-2 pr-4 font-semibold">Train</th>
            </tr>
          </thead>
          <tbody>
            {report.methods.map((m) => {
              const v = m.vs_empirical;
              return (
                <tr key={m.method} className="border-t border-[color:var(--color-border)] align-top">
                  <td className="py-3 pr-4">
                    <div className="font-medium">{METHOD_LABELS[m.method] ?? m.method}</div>
                    <div className="text-xs text-[color:var(--color-muted-foreground)] max-w-xs mt-0.5">
                      {m.note}
                    </div>
                  </td>
                  <td className="py-3 pr-4 tabular-nums">{num(m.metrics?.censored_nll, 5)}</td>
                  <td className="py-3 pr-4 tabular-nums">{num(m.metrics?.capped_mae)}</td>
                  <td className="py-3 pr-4 tabular-nums">{num(m.metrics?.capped_bias)}</td>
                  <td className="py-3 pr-4">
                    {v?.delta === null || v?.delta === undefined ? (
                      <span className="text-[color:var(--color-muted-foreground)]">baseline</span>
                    ) : (
                      <div className="flex flex-col">
                        <span className="tabular-nums">
                          {v.delta > 0 ? "+" : ""}
                          {v.delta.toFixed(5)}
                        </span>
                        <span className="text-xs text-[color:var(--color-muted-foreground)]">
                          {v.distinguishable
                            ? `${v.improves ? "better" : "worse"}, beyond noise`
                            : "within noise"}
                        </span>
                      </div>
                    )}
                  </td>
                  <td className="py-3 pr-4 tabular-nums">{m.train_seconds}s</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-5 rounded-[var(--radius-md)] border border-[color:var(--color-warning)]/30 bg-[color:var(--color-warning)]/5 p-4">
        <div className="flex items-center gap-2 text-sm font-medium text-[color:var(--color-warning)]">
          <Warning size={16} weight="fill" /> How to read this
        </div>
        <ul className="text-xs text-[color:var(--color-muted-foreground)] mt-2 list-disc pl-5 space-y-1">
          {report.caveats.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ul>
      </div>

      <div className="text-xs text-[color:var(--color-muted-foreground)] mt-4 grid grid-cols-2 gap-x-6 gap-y-1 sm:grid-cols-4">
        <div>Training rows: {fmtNum(report.rows.train)}</div>
        <div>Sold out: {fmtNum(report.dataset?.censored_rows ?? 0)}</div>
        <div>Never stocked: {fmtNum(report.dataset?.unstocked_rows ?? 0)}</div>
        <div>Flights: {fmtNum(report.dataset?.distinct_flights ?? 0)}</div>
      </div>
    </Card>
  );
}
