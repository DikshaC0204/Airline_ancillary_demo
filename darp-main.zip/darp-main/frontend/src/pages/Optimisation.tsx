import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtGbpDetail, fmtNum } from "@/lib/format";
import { Card, CardHeader, Badge } from "@/components/ui";

type RunSummary = {
  id: number;
  flight_id: number;
  created_at: string;
  status: string;
  objective_value: number | null;
  total_units: number | null;
  total_skus: number | null;
  total_weight_kg: number | null;
  expected_revenue: number | null;
  expected_net_contribution: number | null;
  parameters_json: Record<string, any>;
};

const METHOD_LABEL: Record<string, string> = {
  empirical: "Empirical",
  lightgbm: "LightGBM",
};

/** The method a run was actually built on, not the one selected today. */
function ForecastTag({ params }: { params: Record<string, any> }) {
  const fc = params?.forecasting;
  if (!fc) return <span className="text-[color:var(--color-muted-foreground)]">—</span>;
  const label = METHOD_LABEL[fc.effective_method] ?? fc.effective_method;
  if (fc.fallback_reason) {
    return (
      <span title={`Asked for ${fc.requested_method}: ${fc.fallback_reason.replace(/_/g, " ")}`}>
        <Badge tone="warning">{label} (fallback)</Badge>
      </span>
    );
  }
  return <Badge tone="neutral">{label}</Badge>;
}

const TONE: Record<string, "success" | "info" | "warning" | "error" | "neutral"> = {
  done: "success",
  failed: "error",
  pending: "neutral",
  forecasting: "info",
  optimising: "info",
  packing: "info",
};

export default function OptimisationPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["runs"],
    queryFn: () => apiFetch<RunSummary[]>("/runs?limit=50"),
    refetchInterval: 4000,
  });

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title="Optimisation runs"
          subtitle="Three-stage engine: forecast → Stage 2 MILP → 3D packing. Open a flight to start a new run."
        />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
                <th className="px-3 py-2 text-left">Run</th>
                <th className="px-3 py-2 text-left">Flight</th>
                <th className="px-3 py-2 text-left">Created</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-left">Forecast</th>
                <th className="px-3 py-2 text-right">SKUs</th>
                <th className="px-3 py-2 text-right">Units</th>
                <th className="px-3 py-2 text-right">Weight</th>
                <th className="px-3 py-2 text-right">Net contribution</th>
                <th className="px-3 py-2 text-right">Service level</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={10} className="px-3 py-6 text-center text-[color:var(--color-muted-foreground)]">
                    Loading…
                  </td>
                </tr>
              )}
              {data?.map((r) => (
                <tr key={r.id} className="border-t border-[color:var(--color-border)]">
                  <td className="px-3 py-2 font-medium">
                    <Link to={`/runs/${r.id}`} className="text-[color:var(--color-secondary)] hover:underline">
                      #{r.id}
                    </Link>
                  </td>
                  <td className="px-3 py-2">
                    <Link to={`/flights/${r.flight_id}`} className="hover:underline">
                      Flight {r.flight_id}
                    </Link>
                  </td>
                  <td className="px-3 py-2 text-[color:var(--color-muted-foreground)]">
                    {new Date(r.created_at).toLocaleString("en-GB")}
                  </td>
                  <td className="px-3 py-2">
                    <Badge tone={TONE[r.status] ?? "neutral"}>{r.status}</Badge>
                  </td>
                  <td className="px-3 py-2">
                    <ForecastTag params={r.parameters_json} />
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">{r.total_skus ?? "—"}</td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {r.total_units != null ? fmtNum(r.total_units) : "—"}
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {r.total_weight_kg != null ? `${r.total_weight_kg.toFixed(1)} kg` : "—"}
                  </td>
                  <td
                    className="px-3 py-2 text-right tabular-nums font-semibold"
                    style={{ color: "var(--color-accent)" }}
                  >
                    {r.expected_net_contribution != null ? fmtGbpDetail(r.expected_net_contribution) : "—"}
                  </td>
                  <td className="px-3 py-2 text-right text-xs text-[color:var(--color-muted-foreground)]">
                    p{Math.round((r.parameters_json?.service_level_p ?? 0.7) * 100)}
                  </td>
                </tr>
              ))}
              {data && data.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-3 py-6 text-center text-[color:var(--color-muted-foreground)]">
                    No runs yet. Open a flight to generate one.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
