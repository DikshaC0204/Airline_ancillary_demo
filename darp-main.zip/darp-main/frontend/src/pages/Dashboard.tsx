import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { useEffect, useMemo } from "react";
import { MapContainer, TileLayer, Polyline, CircleMarker, Tooltip, useMap } from "react-leaflet";
import type { LatLngBoundsExpression } from "leaflet";
import {
  ArrowRight,
  ArrowsClockwise,
  Bank,
  ChartLineUp,
  CheckCircle,
  Cube,
  Package,
  Sparkle,
  Warning,
} from "@phosphor-icons/react";
import { apiFetch } from "@/lib/api";
import { fmtGbp, fmtNum } from "@/lib/format";
import { Card, CardHeader, Kpi, Badge, EmptyState, Loading, ErrorNote } from "@/components/ui";

type Summary = {
  total_skus: number;
  total_routes: number;
  total_flights: number;
  total_sales_rows: number;
  kpi_basis: "approved" | "latest" | "none";
  runs_counted: number;
  expected_uplift_pct: number | null;
  waste_reduction_pct: number | null;
  service_level_pct: number | null;
  net_uplift_gbp: number | null;
  waste_units_saved: number | null;
  routes: {
    id: number;
    origin_iata: string;
    dest_iata: string;
    origin: { lat: number; lon: number };
    dest: { lat: number; lon: number };
    distance_km: number;
    haul_class: string;
  }[];
};

type Activity = {
  recent_runs: {
    run_id: number;
    flight_id: number;
    flight_no: string;
    route: string;
    scheduled_dt: string;
    status: string;
    approval_status: string;
    run_kind: string;
    scenario_label: string | null;
    total_skus: number | null;
    total_units: number | null;
    net_contribution_gbp: number | null;
    baseline_net_contribution_gbp: number | null;
    net_uplift_gbp: number | null;
    uplift_pct: number | null;
  }[];
  pending_approval: number;
  approved_plans: number;
  failed_runs: number;
  flights_planned: number;
};

const fmtSigned = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(1)}%`;

export default function DashboardPage() {
  const summary = useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: () => apiFetch<Summary>("/dashboard/summary"),
  });
  const activity = useQuery({
    queryKey: ["dashboard-activity"],
    queryFn: () => apiFetch<Activity>("/dashboard/activity"),
  });

  if (summary.isLoading) return <Loading label="Loading command centre…" />;
  if (summary.error || !summary.data) {
    return <ErrorNote title="Could not load the dashboard" error={summary.error} />;
  }

  const data = summary.data;

  return (
    <div className="flex flex-col gap-6">
      <KpiStrip data={data} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <RoutesMap routes={data.routes} />
        <DataSpine data={data} />
      </div>

      <ActivityFeed query={activity} />
      <AiInsightsCard />
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function KpiStrip({ data }: { data: Summary }) {
  const planned = data.kpi_basis !== "none";
  // Never show a bare dash: if nothing has been planned the tiles explain what
  // to do instead of implying the numbers are zero.
  const basisHint =
    data.kpi_basis === "approved"
      ? `across ${data.runs_counted} approved plan${data.runs_counted === 1 ? "" : "s"}`
      : data.kpi_basis === "latest"
      ? `across ${data.runs_counted} draft plan${data.runs_counted === 1 ? "" : "s"} — none approved yet`
      : "no plans yet";

  if (!planned) {
    return (
      <Card>
        <EmptyState
          icon={<ChartLineUp size={28} weight="duotone" />}
          title="No plans have been built yet"
          body="Optimise a flight and the uplift, waste and service-level figures will appear here, measured against today's manual plan."
          action={
            <Link to="/flights">
              <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--color-secondary)]">
                Choose a flight to plan <ArrowRight size={16} />
              </span>
            </Link>
          }
        />
      </Card>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi
          label="Expected uplift"
          value={
            data.expected_uplift_pct !== null
              ? fmtSigned(data.expected_uplift_pct)
              : data.net_uplift_gbp !== null
              ? fmtGbp(data.net_uplift_gbp)
              : "—"
          }
          hint={
            data.net_uplift_gbp === null
              ? "vs today's manual plan"
              : `${fmtGbp(data.net_uplift_gbp)} net vs manual plan`
          }
          tone="secondary"
        />
        <Kpi
          label="Waste reduction"
          value={data.waste_reduction_pct === null ? "—" : fmtSigned(data.waste_reduction_pct)}
          hint={
            data.waste_units_saved === null
              ? "short-life stock written off"
              : `${data.waste_units_saved.toFixed(0)} fewer units written off`
          }
          tone="accent"
        />
        <Kpi
          label="Service level"
          value={data.service_level_pct === null ? "—" : `${data.service_level_pct.toFixed(0)}%`}
          hint="share of forecast demand covered"
          tone="primary"
        />
        <Kpi
          label="Sales rows modelled"
          value={fmtNum(data.total_sales_rows)}
          hint="12-month synthetic history"
          tone="muted"
        />
      </div>
      <div className="text-xs text-[color:var(--color-muted-foreground)]">
        Outcome figures measured {basisHint}. Uplift compares net contribution against a
        costed manual plan for the same flight, using the same cost model.
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function FitBounds({ bounds }: { bounds: LatLngBoundsExpression | null }) {
  const map = useMap();
  // In an effect, not during render: the map container has no size until after
  // mount, and fitting against a zero-size box silently leaves the default zoom.
  useEffect(() => {
    if (!bounds) return;
    map.invalidateSize();
    map.fitBounds(bounds, { padding: [28, 28] });
  }, [map, bounds]);
  return null;
}

function RoutesMap({ routes }: { routes: Summary["routes"] }) {
  // Derived from the routes actually returned, so adding a route to the seed
  // does not leave the map framed on the wrong part of Europe.
  const bounds = useMemo<LatLngBoundsExpression | null>(() => {
    if (!routes.length) return null;
    const pts = routes.flatMap((r) => [
      [r.origin.lat, r.origin.lon] as [number, number],
      [r.dest.lat, r.dest.lon] as [number, number],
    ]);
    return pts as LatLngBoundsExpression;
  }, [routes]);

  return (
    <Card className="lg:col-span-2" padding="p-0">
      <div className="p-6 pb-3">
        <CardHeader
          title="Network"
          subtitle={`${routes.length} route${routes.length === 1 ? "" : "s"} modelled end to end`}
        />
      </div>
      <div className="h-[420px] px-6 pb-6">
        {routes.length === 0 ? (
          <EmptyState title="No routes with mapped airports" body="Seed the database to populate the network." />
        ) : (
          <MapContainer center={[42, 2]} zoom={4} scrollWheelZoom={false} style={{ height: "100%", width: "100%" }}>
            <FitBounds bounds={bounds} />
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {routes.map((r) => (
              <RouteOverlay key={r.id} route={r} />
            ))}
          </MapContainer>
        )}
      </div>
    </Card>
  );
}

function RouteOverlay({ route }: { route: Summary["routes"][number] }) {
  const from: [number, number] = [route.origin.lat, route.origin.lon];
  const to: [number, number] = [route.dest.lat, route.dest.lon];
  return (
    <>
      <Polyline positions={[from, to]} pathOptions={{ color: "var(--color-secondary)", weight: 2, opacity: 0.7 }} />
      {[from, to].map((p, i) => (
        <CircleMarker
          key={i}
          center={p}
          radius={5}
          pathOptions={{ color: "var(--color-primary)", fillColor: "var(--color-primary)", fillOpacity: 1 }}
        >
          <Tooltip>
            {route.origin_iata}–{route.dest_iata} · {fmtNum(route.distance_km)} km · {route.haul_class} haul
          </Tooltip>
        </CircleMarker>
      ))}
    </>
  );
}

/* -------------------------------------------------------------------------- */

const CAPABILITIES: { label: string; to: string; icon: JSX.Element }[] = [
  { label: "Demand forecast & range selection", to: "/optimisation", icon: <ChartLineUp size={16} weight="duotone" /> },
  { label: "3D cart packing", to: "/optimisation", icon: <Cube size={16} weight="duotone" /> },
  { label: "Cost-to-serve & scenarios", to: "/scenarios", icon: <Bank size={16} weight="duotone" /> },
  { label: "AI co-planner", to: "/co-planner", icon: <Sparkle size={16} weight="duotone" /> },
];

function DataSpine({ data }: { data: Summary }) {
  return (
    <Card>
      <CardHeader title="Data spine" subtitle="What the prototype has modelled" />
      <div className="space-y-3 text-sm">
        <Row label="SKUs in catalogue" value={fmtNum(data.total_skus)} />
        <Row label="Routes" value={fmtNum(data.total_routes)} />
        <Row label="Flights (12 mo)" value={fmtNum(data.total_flights)} />
        <Row label="Sales rows" value={fmtNum(data.total_sales_rows)} />
      </div>
      <div className="mt-6">
        <div className="text-xs uppercase tracking-wide font-semibold text-[color:var(--color-muted-foreground)] mb-2">
          Capabilities
        </div>
        <div className="flex flex-col gap-1">
          {CAPABILITIES.map((c) => (
            <Link
              key={c.label}
              to={c.to}
              className="flex items-center gap-2 text-sm rounded-md px-2 py-1.5 -mx-2 hover:bg-[color:var(--color-muted)] transition-colors"
            >
              <span className="text-[color:var(--color-secondary)]">{c.icon}</span>
              <span className="flex-1">{c.label}</span>
              <ArrowRight size={14} className="text-[color:var(--color-muted-foreground)]" />
            </Link>
          ))}
        </div>
      </div>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between">
      <span className="text-[color:var(--color-muted-foreground)]">{label}</span>
      <span className="font-semibold tabular-nums">{value}</span>
    </div>
  );
}

/* -------------------------------------------------------------------------- */

function ActivityFeed({ query }: { query: ReturnType<typeof useQuery<Activity>> }) {
  const { data, isLoading, error } = query;

  return (
    <Card>
      <CardHeader
        title="Planning activity"
        subtitle="Most recent optimisation runs"
        right={
          data ? (
            <div className="flex gap-2">
              {data.pending_approval > 0 && (
                <Badge tone="warning">{data.pending_approval} awaiting approval</Badge>
              )}
              {data.failed_runs > 0 && <Badge tone="error">{data.failed_runs} failed</Badge>}
              <Badge tone="success">{data.approved_plans} approved</Badge>
            </div>
          ) : undefined
        }
      />
      {isLoading ? (
        <Loading label="Loading activity…" />
      ) : error ? (
        <ErrorNote title="Could not load planning activity" error={error} />
      ) : !data || data.recent_runs.length === 0 ? (
        <EmptyState
          icon={<Package size={28} weight="duotone" />}
          title="Nothing planned yet"
          body="Pick a flight and run the optimiser to see plans appear here."
          action={
            <Link to="/flights">
              <span className="inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--color-secondary)]">
                Browse flights <ArrowRight size={16} />
              </span>
            </Link>
          }
        />
      ) : (
        <div className="flex flex-col">
          {data.recent_runs.map((r) => (
            <Link
              key={r.run_id}
              to={`/runs/${r.run_id}`}
              className="flex items-center gap-3 text-sm py-2.5 px-2 -mx-2 rounded-md hover:bg-[color:var(--color-muted)] transition-colors border-b border-[color:var(--color-border)] last:border-0"
            >
              <RunStatus status={r.status} approval={r.approval_status} />
              <div className="w-40 shrink-0">
                <div className="font-medium">{r.flight_no}</div>
                <div className="text-xs text-[color:var(--color-muted-foreground)]">{r.route}</div>
              </div>
              <div className="flex-1 text-xs text-[color:var(--color-muted-foreground)]">
                {r.scenario_label ?? (r.run_kind === "override" ? "Planner override" : "Autonomous plan")}
                {r.total_skus != null && ` · ${r.total_skus} SKUs · ${fmtNum(r.total_units ?? 0)} units`}
              </div>
              <div className="w-24 text-right tabular-nums">
                {r.net_contribution_gbp != null ? fmtGbp(r.net_contribution_gbp) : "—"}
              </div>
              <div className="w-20 text-right tabular-nums">
                <UpliftCell pct={r.uplift_pct} gbp={r.net_uplift_gbp} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </Card>
  );
}

function UpliftCell({ pct, gbp }: { pct: number | null; gbp: number | null }) {
  // A percentage against a loss-making manual plan is meaningless, so the
  // backend withholds it and the money delta is shown instead.
  const value = pct != null ? fmtSigned(pct) : gbp != null ? fmtGbp(gbp) : null;
  const positive = pct != null ? pct >= 0 : gbp != null ? gbp >= 0 : true;
  if (value === null) return <span className="text-[color:var(--color-muted-foreground)]">—</span>;
  return (
    <span style={{ color: positive ? "var(--color-accent)" : "var(--color-destructive)" }}>
      {value}
    </span>
  );
}

function RunStatus({ status, approval }: { status: string; approval: string }) {
  if (status === "failed") return <Warning size={18} weight="fill" color="var(--color-destructive)" />;
  if (status !== "done") return <ArrowsClockwise size={18} className="animate-spin" color="var(--color-secondary)" />;
  if (approval === "approved") return <CheckCircle size={18} weight="fill" color="var(--color-accent)" />;
  return <CheckCircle size={18} color="var(--color-muted-foreground)" />;
}

/* -------------------------------------------------------------------------- */

function AiInsightsCard() {
  const { data: health } = useQuery({
    queryKey: ["ai-health"],
    queryFn: () => apiFetch<{ configured: boolean }>("/ai/health"),
  });
  const { data: feedback } = useQuery({
    queryKey: ["crew-feedback"],
    queryFn: () =>
      apiFetch<
        Array<{
          id: number;
          flight_no: string | null;
          free_text: string;
          structured: { signal_type?: string; severity?: number; sku_code?: string };
        }>
      >("/ai/crew-feedback?limit=4"),
  });

  const tone: Record<string, "success" | "info" | "warning" | "error" | "neutral"> = {
    stockout: "error",
    waste: "warning",
    quality: "warning",
    presentation: "info",
    ops: "info",
    other: "neutral",
  };

  return (
    <Card>
      <CardHeader
        title="AI insights"
        subtitle="Recent crew feedback ingested by the Co-Planner"
        right={
          <div className="flex gap-2 items-center">
            <Badge tone={health?.configured ? "success" : "warning"}>
              {health?.configured ? "Azure OpenAI live" : "AI not configured"}
            </Badge>
            <Link to="/co-planner">
              <Badge tone="info">Open Co-Planner →</Badge>
            </Link>
          </div>
        }
      />
      {!feedback || feedback.length === 0 ? (
        <EmptyState
          title="No crew feedback yet"
          body="Crew comments are parsed into structured demand signals."
          action={
            <Link to="/crew" className="text-sm font-medium text-[color:var(--color-secondary)]">
              Submit some →
            </Link>
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {feedback.map((fb) => {
            const hasTag = fb.structured?.signal_type || fb.structured?.sku_code;
            return (
              <div
                key={fb.id}
                className="flex items-start gap-3 text-sm border border-[color:var(--color-border)] rounded-md px-3 py-2"
              >
                {hasTag && (
                  <div className="flex flex-col gap-1 shrink-0 w-28">
                    {fb.structured?.signal_type && (
                      <Badge tone={tone[fb.structured.signal_type] ?? "neutral"}>
                        {fb.structured.signal_type}
                      </Badge>
                    )}
                    {fb.structured?.sku_code && (
                      <span className="text-[11px] font-mono text-[color:var(--color-muted-foreground)]">
                        {fb.structured.sku_code}
                      </span>
                    )}
                  </div>
                )}
                <div className="flex-1">{fb.free_text}</div>
                {fb.flight_no && (
                  <div className="text-xs text-[color:var(--color-muted-foreground)] shrink-0">
                    {fb.flight_no}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
