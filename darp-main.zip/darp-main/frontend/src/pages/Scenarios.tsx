import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { Card, CardHeader, Button, Badge } from "@/components/ui";
import { fmtGbpDetail, fmtNum } from "@/lib/format";
import { Sparkle } from "@phosphor-icons/react";

type ScenarioParams = {
  fuel_price_multiplier?: number;
  load_factor_override?: number | null;
  service_level_p?: number | null;
  volume_efficiency_eta?: number | null;
  retail_weight_budget_kg?: number | null;
  complexity_penalty_scale?: number | null;
};

type Scenario = {
  id: number;
  name: string;
  description: string | null;
  params: ScenarioParams;
  created_at: string;
};

type RunSummary = {
  id: number;
  flight_id: number;
  status: string;
  total_weight_kg: number | null;
  total_units: number | null;
  total_skus: number | null;
  expected_revenue: number | null;
  expected_net_contribution: number | null;
  scenario_label?: string | null;
  parameters_json: Record<string, unknown>;
};

type Decision = {
  sku_id: number;
  sku_code: string;
  sku_name: string;
  category: string;
  decision: string;
  loaded_qty: number;
  expected_sales: number;
  expected_margin: number;
  fuel_cost: number;
  net_contribution: number;
  weight_kg: number;
};

type RunDetail = {
  run: RunSummary;
  decisions: Decision[];
  capacity: { weight_budget_kg: number; volume_efficiency_eta: number; service_level_p: number; max_payload_kg: number };
  sustainability: { fuel_price_per_kg_gbp: number; fuel_cost_gbp: number; fuel_kg: number; co2_kg: number };
};

type Flight = {
  id: number;
  flight_no: string;
  scheduled_dt: string;
  expected_pax: number;
};

export default function ScenariosPage() {
  const qc = useQueryClient();
  const [creating, setCreating] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);

  const { data: scenarios } = useQuery({
    queryKey: ["scenarios"],
    queryFn: () => apiFetch<Scenario[]>("/scenarios"),
  });

  const del = useMutation({
    mutationFn: (id: number) => apiFetch<void>(`/scenarios/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["scenarios"] }),
  });

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title="Scenarios"
          subtitle="Side-by-side what-ifs: fuel ±%, service level, weight budget, volume efficiency."
          right={
            <Button variant="primary" onClick={() => setCreating(true)} disabled={creating}>+ New scenario</Button>
          }
        />
        {creating && (
          <ScenarioCreateForm
            onCancel={() => setCreating(false)}
            onCreated={() => {
              setCreating(false);
              qc.invalidateQueries({ queryKey: ["scenarios"] });
            }}
          />
        )}
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr] gap-6">
        <Card>
          <CardHeader title="Saved scenarios" subtitle={`${scenarios?.length ?? 0} total`} />
          <ul className="flex flex-col gap-2">
            {scenarios?.map((s) => (
              <li key={s.id}>
                <button
                  onClick={() => setActiveId(s.id)}
                  className={[
                    "w-full text-left rounded-[var(--radius-md)] border px-3 py-2 transition-colors",
                    activeId === s.id
                      ? "border-[color:var(--color-primary)] bg-[color:var(--color-muted)]"
                      : "border-[color:var(--color-border)] hover:bg-[color:var(--color-muted)]",
                  ].join(" ")}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium">{s.name}</span>
                    <Badge tone="info">{paramSummary(s.params)}</Badge>
                  </div>
                  {s.description && (
                    <div className="text-xs text-[color:var(--color-muted-foreground)] mt-1">{s.description}</div>
                  )}
                </button>
              </li>
            ))}
            {scenarios && scenarios.length === 0 && (
              <li className="text-sm text-[color:var(--color-muted-foreground)]">No scenarios yet — create one above.</li>
            )}
          </ul>
        </Card>

        <div>
          {activeId ? (
            <ScenarioDetail
              scenarioId={activeId}
              onDelete={() => {
                if (confirm("Delete this scenario?")) {
                  del.mutate(activeId);
                  setActiveId(null);
                }
              }}
            />
          ) : (
            <Card>
              <CardHeader title="Pick a scenario" subtitle="Select one on the left to run it against a flight." />
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function paramSummary(p: ScenarioParams): string {
  const parts: string[] = [];
  if (p.fuel_price_multiplier && p.fuel_price_multiplier !== 1)
    parts.push(`fuel ×${p.fuel_price_multiplier.toFixed(2)}`);
  if (p.service_level_p) parts.push(`p${Math.round(p.service_level_p * 100)}`);
  if (p.volume_efficiency_eta) parts.push(`η${(p.volume_efficiency_eta * 100).toFixed(0)}`);
  if (p.retail_weight_budget_kg) parts.push(`${p.retail_weight_budget_kg}kg`);
  if (p.complexity_penalty_scale && p.complexity_penalty_scale !== 1)
    parts.push(`cmplx×${p.complexity_penalty_scale}`);
  return parts.length ? parts.join(" · ") : "no overlay";
}

function ScenarioCreateForm({ onCancel, onCreated }: { onCancel: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [fuelMult, setFuelMult] = useState(1.0);
  const [serviceP, setServiceP] = useState<number | "">("");
  const [eta, setEta] = useState<number | "">("");
  const [weightKg, setWeightKg] = useState<number | "">("");

  const create = useMutation({
    mutationFn: () => {
      const params: ScenarioParams = {};
      if (fuelMult !== 1.0) params.fuel_price_multiplier = fuelMult;
      if (serviceP !== "") params.service_level_p = Number(serviceP);
      if (eta !== "") params.volume_efficiency_eta = Number(eta);
      if (weightKg !== "") params.retail_weight_budget_kg = Number(weightKg);
      return apiFetch<Scenario>("/scenarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, description: description || null, params }),
      });
    },
    onSuccess: onCreated,
  });

  return (
    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3 border-t border-[color:var(--color-border)] pt-4">
      <Field label="Name">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="e.g. Fuel +30%"
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <Field label="Description">
        <input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="optional"
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <Field label="Fuel price multiplier">
        <input
          type="number" step="0.05" min="0" max="5" value={fuelMult}
          onChange={(e) => setFuelMult(parseFloat(e.target.value) || 1.0)}
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <Field label="Service level p (0.5–0.99)">
        <input
          type="number" step="0.05" min="0.5" max="0.99" value={serviceP}
          onChange={(e) => setServiceP(e.target.value === "" ? "" : parseFloat(e.target.value))}
          placeholder="leave blank to use base"
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <Field label="Volume efficiency η">
        <input
          type="number" step="0.05" min="0.3" max="0.95" value={eta}
          onChange={(e) => setEta(e.target.value === "" ? "" : parseFloat(e.target.value))}
          placeholder="leave blank"
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <Field label="Retail weight budget (kg)">
        <input
          type="number" step="10" min="50" max="2000" value={weightKg}
          onChange={(e) => setWeightKg(e.target.value === "" ? "" : parseFloat(e.target.value))}
          placeholder="leave blank"
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm w-full"
        />
      </Field>
      <div className="md:col-span-2 flex items-center gap-2">
        <Button variant="primary" onClick={() => create.mutate()} disabled={create.isPending || !name.trim()}>
          {create.isPending ? "Creating…" : "Create scenario"}
        </Button>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">{label}</span>
      {children}
    </label>
  );
}

function ScenarioDetail({ scenarioId, onDelete }: { scenarioId: number; onDelete: () => void }) {
  const [flightId, setFlightId] = useState<number | "">("");
  const [baseRunId, setBaseRunId] = useState<number | null>(null);
  const [scenarioRunId, setScenarioRunId] = useState<number | null>(null);

  const { data: scenario } = useQuery({
    queryKey: ["scenario", scenarioId],
    queryFn: () => apiFetch<Scenario>(`/scenarios/${scenarioId}`),
  });

  const { data: flights } = useQuery({
    queryKey: ["flights"],
    queryFn: () => apiFetch<{ total: number; items: Flight[] }>("/flights?limit=200"),
    select: (resp) => resp.items,
  });

  const runScenario = useMutation({
    mutationFn: async (fid: number) => {
      let base = await apiFetch<{ id: number } | null>(`/runs/by-flight/${fid}/latest`).catch(() => null);
      if (!base) {
        base = await apiFetch<{ id: number }>("/runs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ flight_id: fid }),
        });
      }
      const baselineDone = await waitForRun(base!.id);
      const sc = await apiFetch<{ run_id: number }>(`/scenarios/${scenarioId}/runs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ flight_id: fid, base_run_id: baselineDone.id }),
      });
      const scenarioDone = await waitForRun(sc.run_id);
      return { baseRunId: baselineDone.id, scenarioRunId: scenarioDone.id };
    },
    onSuccess: ({ baseRunId, scenarioRunId }) => {
      setBaseRunId(baseRunId);
      setScenarioRunId(scenarioRunId);
    },
  });

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title={scenario?.name ?? "Scenario"}
          subtitle={scenario?.description || paramSummary(scenario?.params ?? {})}
          right={<Button variant="ghost" onClick={onDelete}>Delete</Button>}
        />
        <div className="flex items-end gap-3 flex-wrap">
          <Field label="Flight">
            <select
              value={flightId}
              onChange={(e) => setFlightId(e.target.value === "" ? "" : Number(e.target.value))}
              className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm min-w-[260px]"
            >
              <option value="">Select a flight…</option>
              {flights?.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.flight_no} · {new Date(f.scheduled_dt).toLocaleDateString()} · {f.expected_pax} pax
                </option>
              ))}
            </select>
          </Field>
          <Button
            variant="primary"
            onClick={() => flightId !== "" && runScenario.mutate(Number(flightId))}
            disabled={flightId === "" || runScenario.isPending}
          >
            {runScenario.isPending ? "Running base + scenario…" : "Run & compare"}
          </Button>
        </div>
        {runScenario.isError && (
          <div className="text-sm mt-2" style={{ color: "var(--color-destructive)" }}>
            Error: {(runScenario.error as Error).message}
          </div>
        )}
      </Card>

      {baseRunId && scenarioRunId && (
        <CompareView baseRunId={baseRunId} scenarioRunId={scenarioRunId} scenarioId={scenarioId} />
      )}
    </div>
  );
}

async function waitForRun(runId: number, maxMs = 30000): Promise<RunSummary> {
  const start = Date.now();
  while (Date.now() - start < maxMs) {
    const r = await apiFetch<RunDetail>(`/runs/${runId}`);
    if (r.run.status === "done") return r.run;
    if (r.run.status === "failed") throw new Error(`Run ${runId} failed`);
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`Run ${runId} did not complete in ${maxMs}ms`);
}

function CompareView({ baseRunId, scenarioRunId, scenarioId }: { baseRunId: number; scenarioRunId: number; scenarioId: number }) {
  const { data: base } = useQuery({
    queryKey: ["run", baseRunId],
    queryFn: () => apiFetch<RunDetail>(`/runs/${baseRunId}`),
  });
  const { data: sc } = useQuery({
    queryKey: ["run", scenarioRunId],
    queryFn: () => apiFetch<RunDetail>(`/runs/${scenarioRunId}`),
  });

  if (!base || !sc) return <Card>Loading comparison…</Card>;

  const baseMap: Record<number, Decision> = {};
  base.decisions.forEach((d) => (baseMap[d.sku_id] = d));
  const scMap: Record<number, Decision> = {};
  sc.decisions.forEach((d) => (scMap[d.sku_id] = d));
  const allIds = new Set<number>([...Object.keys(baseMap).map(Number), ...Object.keys(scMap).map(Number)]);
  const rows = Array.from(allIds)
    .map((id) => {
      const b = baseMap[id];
      const s = scMap[id];
      const baseQty = b?.loaded_qty ?? 0;
      const scQty = s?.loaded_qty ?? 0;
      return {
        sku_id: id,
        sku_code: (s ?? b)!.sku_code,
        sku_name: (s ?? b)!.sku_name,
        category: (s ?? b)!.category,
        baseQty,
        scQty,
        dQty: scQty - baseQty,
      };
    })
    .filter((r) => r.dQty !== 0)
    .sort((a, b) => Math.abs(b.dQty) - Math.abs(a.dQty));

  return (
    <div className="flex flex-col gap-6">
      <NarrationCard baseRunId={baseRunId} scenarioRunId={scenarioRunId} scenarioId={scenarioId} />
      <Card>
        <CardHeader
          title="Comparison"
          subtitle={`Base run #${baseRunId} vs Scenario run #${scenarioRunId}`}
          right={
            <div className="flex gap-2">
              <Link to={`/runs/${baseRunId}`}><Button variant="ghost">Base →</Button></Link>
              <Link to={`/runs/${scenarioRunId}`}><Button variant="ghost">Scenario →</Button></Link>
            </div>
          }
        />
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <DeltaKpi label="Net contribution" base={base.run.expected_net_contribution ?? 0} scenario={sc.run.expected_net_contribution ?? 0} fmt={fmtGbpDetail} />
          <DeltaKpi label="Revenue" base={base.run.expected_revenue ?? 0} scenario={sc.run.expected_revenue ?? 0} fmt={fmtGbpDetail} />
          <DeltaKpi label="Units" base={base.run.total_units ?? 0} scenario={sc.run.total_units ?? 0} fmt={(v) => fmtNum(Math.round(v))} />
          <DeltaKpi label="Weight (kg)" base={base.run.total_weight_kg ?? 0} scenario={sc.run.total_weight_kg ?? 0} fmt={(v) => v.toFixed(1)} />
          <DeltaKpi label="CO₂ (kg)" base={base.sustainability.co2_kg} scenario={sc.sustainability.co2_kg} fmt={(v) => v.toFixed(1)} />
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <Detail label="Fuel cost" base={fmtGbpDetail(base.sustainability.fuel_cost_gbp)} scenario={fmtGbpDetail(sc.sustainability.fuel_cost_gbp)} />
          <Detail label="Fuel kg" base={base.sustainability.fuel_kg.toFixed(2)} scenario={sc.sustainability.fuel_kg.toFixed(2)} />
          <Detail label="Fuel price £/kg" base={base.sustainability.fuel_price_per_kg_gbp.toFixed(3)} scenario={sc.sustainability.fuel_price_per_kg_gbp.toFixed(3)} />
        </div>
      </Card>

      <Card>
        <CardHeader title="Range diff" subtitle={`${rows.length} SKU(s) changed loaded quantity`} />
        {rows.length === 0 ? (
          <div className="text-sm text-[color:var(--color-muted-foreground)]">
            No SKU-level changes — the scenario produced the same range. Try a more aggressive parameter overlay.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
                  <th className="px-3 py-2 text-left">SKU</th>
                  <th className="px-3 py-2 text-left">Category</th>
                  <th className="px-3 py-2 text-right">Base qty</th>
                  <th className="px-3 py-2 text-right">Scenario qty</th>
                  <th className="px-3 py-2 text-right">Δ</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.sku_id} className="border-t border-[color:var(--color-border)]">
                    <td className="px-3 py-2">
                      <div className="font-medium">{r.sku_name}</div>
                      <div className="text-xs text-[color:var(--color-muted-foreground)]">{r.sku_code}</div>
                    </td>
                    <td className="px-3 py-2 text-xs text-[color:var(--color-muted-foreground)]">{r.category}</td>
                    <td className="px-3 py-2 text-right tabular-nums">{r.baseQty}</td>
                    <td className="px-3 py-2 text-right tabular-nums">{r.scQty}</td>
                    <td className="px-3 py-2 text-right tabular-nums font-semibold" style={{ color: r.dQty > 0 ? "var(--color-accent)" : "var(--color-destructive)" }}>
                      {r.dQty > 0 ? `+${r.dQty}` : r.dQty}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}

function DeltaKpi({ label, base, scenario, fmt }: { label: string; base: number; scenario: number; fmt: (v: number) => string }) {
  const delta = scenario - base;
  const tone = delta > 0 ? "var(--color-accent)" : delta < 0 ? "var(--color-destructive)" : "var(--color-muted-foreground)";
  return (
    <div className="rounded-[var(--radius-md)] border border-[color:var(--color-border)] p-3">
      <div className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">{label}</div>
      <div className="text-lg font-semibold mt-1" style={{ color: "var(--color-primary)" }}>{fmt(scenario)}</div>
      <div className="flex items-center justify-between text-xs mt-1">
        <span className="text-[color:var(--color-muted-foreground)]">base {fmt(base)}</span>
        <span style={{ color: tone, fontWeight: 600 }}>
          {delta > 0 ? "+" : ""}{fmt(delta)}
        </span>
      </div>
    </div>
  );
}

function Detail({ label, base, scenario }: { label: string; base: string; scenario: string }) {
  return (
    <div className="rounded-[var(--radius-md)] border border-[color:var(--color-border)] px-3 py-2">
      <div className="text-[10px] uppercase tracking-wide text-[color:var(--color-muted-foreground)]">{label}</div>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs text-[color:var(--color-muted-foreground)]">base {base}</span>
        <span className="text-sm font-semibold tabular-nums" style={{ color: "var(--color-primary)" }}>{scenario}</span>
      </div>
    </div>
  );
}

function NarrationCard({ baseRunId, scenarioRunId, scenarioId }: { baseRunId: number; scenarioRunId: number; scenarioId: number }) {
  const { data, isLoading, error } = useQuery({
    queryKey: ["narrate", baseRunId, scenarioRunId, scenarioId],
    queryFn: () =>
      apiFetch<{ summary?: string; bullets?: string[] }>("/ai/narrate-scenario", {
        method: "POST",
        body: JSON.stringify({ base_run_id: baseRunId, scenario_run_id: scenarioRunId, scenario_id: scenarioId }),
      }),
    staleTime: Infinity,
    retry: false,
  });

  return (
    <Card>
      <CardHeader
        title="AI narration"
        subtitle="Three-bullet executive summary of base vs scenario"
        right={<Badge tone="info"><Sparkle size={12} weight="fill" className="inline mr-1" />Azure OpenAI</Badge>}
      />
      {isLoading && (
        <div className="text-sm text-[color:var(--color-muted-foreground)] animate-pulse">Generating narration…</div>
      )}
      {error && (
        <div className="text-sm" style={{ color: "var(--color-destructive)" }}>
          Narration unavailable: {(error as Error).message}
        </div>
      )}
      {data && data.bullets && (
        <div className="flex flex-col gap-3">
          {data.summary && (
            <div className="text-base font-medium" style={{ color: "var(--color-primary)" }}>
              {data.summary}
            </div>
          )}
          <ul className="flex flex-col gap-2">
            {data.bullets.map((b, i) => (
              <li key={i} className="flex gap-2 text-sm">
                <span style={{ color: "var(--color-secondary)" }}>•</span>
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {data && (!data.bullets || data.bullets.length === 0) && (
        <div className="text-sm text-[color:var(--color-muted-foreground)]">
          No narration returned (AI may be unconfigured).
        </div>
      )}
    </Card>
  );
}
