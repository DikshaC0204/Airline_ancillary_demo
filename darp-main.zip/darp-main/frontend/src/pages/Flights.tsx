import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtNum } from "@/lib/format";
import { Card, CardHeader, Button, Badge } from "@/components/ui";

type Flight = {
  id: number;
  flight_no: string;
  route_id: number;
  scheduled_dt: string;
  expected_pax: number;
  expected_load_factor: number;
  rotation_id: number | null;
  leg_index: number | null;
};

type Route = { id: number; origin_iata: string; dest_iata: string };

export default function FlightsPage() {
  const [routeId, setRouteId] = useState<number | "">("");
  const { data: routes } = useQuery({ queryKey: ["routes"], queryFn: () => apiFetch<Route[]>("/routes") });
  const { data, isLoading } = useQuery({
    queryKey: ["flights", routeId],
    queryFn: () => {
      const p = new URLSearchParams({ limit: "100" });
      if (routeId !== "") p.set("route_id", String(routeId));
      return apiFetch<{ total: number; items: Flight[] }>(`/flights?${p}`);
    },
  });

  const routeLabel = (rid: number) => {
    const r = routes?.find((r) => r.id === rid);
    return r ? `${r.origin_iata}→${r.dest_iata}` : `#${rid}`;
  };

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader
          title="Upcoming flights"
          subtitle="Click a flight to generate a range plan."
          right={
            <select
              value={routeId}
              onChange={(e) => setRouteId(e.target.value === "" ? "" : Number(e.target.value))}
              className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
            >
              <option value="">All routes</option>
              {routes?.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.origin_iata} → {r.dest_iata}
                </option>
              ))}
            </select>
          }
        />
        <div className="text-sm text-[color:var(--color-muted-foreground)] mb-3">
          {data ? `${fmtNum(data.total)} flights match · showing ${data.items.length}` : ""}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
                <th className="px-3 py-2 text-left">Flight</th>
                <th className="px-3 py-2 text-left">Route</th>
                <th className="px-3 py-2 text-left">Scheduled</th>
                <th className="px-3 py-2 text-right">Pax</th>
                <th className="px-3 py-2 text-right">Load</th>
                <th className="px-3 py-2 text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-[color:var(--color-muted-foreground)]">
                    Loading…
                  </td>
                </tr>
              )}
              {data?.items.map((f) => (
                <tr key={f.id} className="border-t border-[color:var(--color-border)]">
                  <td className="px-3 py-2 font-medium">{f.flight_no}</td>
                  <td className="px-3 py-2">
                    <Badge tone="info">{routeLabel(f.route_id)}</Badge>
                    {f.rotation_id != null && (
                      <span className="ml-2"><Badge tone="neutral">rotation · leg {f.leg_index}</Badge></span>
                    )}
                  </td>
                  <td className="px-3 py-2">{new Date(f.scheduled_dt).toLocaleString("en-GB")}</td>
                  <td className="px-3 py-2 text-right">{f.expected_pax}</td>
                  <td className="px-3 py-2 text-right">{(f.expected_load_factor * 100).toFixed(0)}%</td>
                  <td className="px-3 py-2 text-right">
                    <Link to={`/flights/${f.id}`}>
                      <Button variant="ghost">Open</Button>
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
