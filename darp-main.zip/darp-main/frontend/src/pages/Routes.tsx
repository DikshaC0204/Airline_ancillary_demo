import { useQuery } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtNum } from "@/lib/format";
import { Card, CardHeader, Badge } from "@/components/ui";

type Route = {
  id: number;
  origin_iata: string;
  dest_iata: string;
  distance_km: number;
  flight_duration_min: number;
  haul_class: string;
  alcohol_allowed: boolean;
  tobacco_allowed: boolean;
  seasonality_profile_json: Record<string, number>;
};

export default function RoutesPage() {
  const { data } = useQuery({ queryKey: ["routes"], queryFn: () => apiFetch<Route[]>("/routes") });
  if (!data) return <div className="text-[color:var(--color-muted-foreground)]">Loading…</div>;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {data.map((r) => (
        <Card key={r.id}>
          <CardHeader
            title={`${r.origin_iata} → ${r.dest_iata}`}
            subtitle={`${fmtNum(Math.round(r.distance_km))} km · ${r.flight_duration_min} min · ${r.haul_class}-haul`}
            right={
              <div className="flex gap-1">
                {r.alcohol_allowed && <Badge tone="info">alcohol</Badge>}
                {r.tobacco_allowed ? <Badge tone="warning">tobacco</Badge> : <Badge tone="neutral">no tobacco</Badge>}
              </div>
            }
          />
          <div className="text-xs uppercase tracking-wide font-semibold text-[color:var(--color-muted-foreground)] mb-2">
            Seasonality (demand multiplier)
          </div>
          <div className="flex items-end gap-1 h-24">
            {Array.from({ length: 12 }, (_, i) => {
              const m = String(i + 1);
              const v = r.seasonality_profile_json[m] ?? 1;
              const pct = Math.min(100, (v / 2) * 100);
              return (
                <div key={m} className="flex-1 flex flex-col items-center justify-end gap-1">
                  <div
                    className="w-full rounded-sm"
                    style={{ background: "var(--color-secondary)", height: `${pct}%` }}
                    title={`Month ${m}: ×${v.toFixed(2)}`}
                  />
                  <div className="text-[10px] text-[color:var(--color-muted-foreground)]">{m}</div>
                </div>
              );
            })}
          </div>
        </Card>
      ))}
    </div>
  );
}
