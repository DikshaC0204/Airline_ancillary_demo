import { useEffect, useMemo, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiFetch } from "@/lib/api";
import { fmtNum, fmtGbpDetail } from "@/lib/format";
import { Card, CardHeader, Button, Badge, Kpi } from "@/components/ui";
import { Sparkle, PushPin, ArrowsClockwise, CheckCircle, X } from "@phosphor-icons/react";

type RunSummary = {
  id: number;
  flight_id: number;
  created_at: string;
  status: string;
  objective_value: number | null;
  total_weight_kg: number | null;
  total_volume_cm3: number | null;
  total_skus: number | null;
  total_units: number | null;
  expected_revenue: number | null;
  expected_net_contribution: number | null;
  parameters_json: Record<string, any>;
  run_kind: string;
  parent_run_id: number | null;
  rotation_id: number | null;
  approval_status: string;
  approved_by: string | null;
  approved_note: string | null;
};

type Substitute = {
  sku_id: number;
  sku_code: string;
  sku_name: string;
  net_per_cm3: number | null;
  net_per_kg: number | null;
};

type Decision = {
  sku_id: number;
  sku_code: string;
  sku_name: string;
  category: string;
  decision: string;
  loaded_qty: number;
  expected_sales: number;
  expected_margin: number;
  fuel_cost: number;
  pick_pack_cost: number;
  handling_cost: number;
  spoilage_cost: number;
  complexity_cost: number;
  net_contribution: number;
  net_per_kg: number | null;
  net_per_cm3: number | null;
  reason_code: string | null;
  reason_text: string | null;
  reason_detail: Record<string, unknown>;
  substitute: Substitute | null;
  leg_sales: Record<string, number>;
  is_overridden: boolean;
  weight_kg: number;
  volume_cm3: number;
  retail_price: number;
  rationale_text: string | null;
};

type Constraint = {
  name: string;
  kind: string;
  used: number;
  limit: number;
  utilisation_pct: number;
  status: "binding" | "near" | "slack" | string;
  unit?: string;
};

type RotationLeg = {
  leg_index: number;
  flight_no?: string;
  origin: string;
  dest: string;
  expected_pax?: number;
  expected_sales_units: number;
  carried_in_kg: number;
  carried_out_kg: number;
  fuel_cost_gbp: number;
};

type OverrideRow = {
  sku_id: number;
  kind: string;
  qty: number | null;
  original_decision: string;
  original_qty: number;
  note: string | null;
};

type RunDetail = {
  run: RunSummary;
  decisions: Decision[];
  capacity: {
    weight_budget_kg: number;
    volume_efficiency_eta: number;
    service_level_p: number;
    max_payload_kg: number;
  };
  sustainability: {
    fuel_price_per_kg_gbp: number;
    fuel_cost_gbp: number;
    fuel_kg: number;
    co2_kg: number;
  };
  constraints: Constraint[];
  rotation: { id: number; code: string | null; description: string | null; legs: RotationLeg[] } | null;
  overrides: OverrideRow[];
};

const DECISION_TONE: Record<string, "success" | "info" | "warning" | "neutral"> = {
  load: "success",
  increase: "info",
  reduce: "warning",
  exclude: "neutral",
};

const REASON_LABEL: Record<string, string> = {
  EXCLUDED_REGULATORY: "regulatory ban",
  EXCLUDED_BY_OVERRIDE: "pinned out",
  EXCLUDED_NO_DEMAND: "no demand",
  EXCLUDED_NEGATIVE_NET: "loss-making",
  EXCLUDED_SHELF_LIFE: "spoilage risk",
  EXCLUDED_LOW_RETURN_PICKLINE: "low-return pickline",
  EXCLUDED_NOT_WORTH_PICKLINE: "not worth a pickline",
  EXCLUDED_DISPLACED_VOLUME: "displaced · volume",
  EXCLUDED_DISPLACED_WEIGHT: "displaced · weight",
  REDUCED_TO_FIT_VOLUME: "trimmed · volume",
  REDUCED_TO_FIT_WEIGHT: "trimmed · weight",
  REDUCED_MARGINAL_UNIT: "trimmed · marginal unit",
  REDUCED_CASE_ROUNDING: "case rounding",
  REDUCED_SPOILAGE_RISK: "spoilage risk",
  LOADED_BY_OVERRIDE: "pinned in",
  LOADED_BRAND_RULE: "brand rule",
  LOADED_SUPPLIER_COMMITMENT: "supplier minimum",
  LOADED_CASE_EFFICIENT: "case-efficient",
  LOADED_STRONG_DEMAND: "strong demand",
  LOADED_PARTIAL: "loaded",
};

function reasonTone(code: string | null): "success" | "info" | "warning" | "error" | "neutral" {
  if (!code) return "neutral";
  if (code === "EXCLUDED_REGULATORY" || code === "EXCLUDED_NEGATIVE_NET") return "error";
  if (code.startsWith("LOADED")) return "info";
  if (code.startsWith("REDUCED")) return "warning";
  return "neutral";
}

type SortKey = "net_contribution" | "net_per_kg" | "net_per_cm3" | "loaded_qty" | "expected_margin";

type StagedOverride = { kind: "force_include" | "force_exclude" | "set_qty"; qty?: number };

const FORECAST_LABEL: Record<string, string> = {
  empirical: "Empirical",
  lightgbm: "LightGBM",
};

const FALLBACK_TEXT: Record<string, string> = {
  lightgbm_not_installed: "LightGBM is not installed on this server.",
  no_trained_model_selected: "No trained LightGBM model was selected.",
  model_trained_on_different_data: "The selected model was trained on different history.",
  model_saw_data_after_this_flight:
    "The selected model learned from flights after this one, so using it would not be a forecast.",
  model_failed_to_load: "The selected model could not be loaded.",
};

/** A plan must say which forecast produced it, especially when it is not the one asked for. */
function ForecastProvenance({ params }: { params: Record<string, any> }) {
  const fc = params?.forecasting;
  if (!fc?.fallback_reason) return null;
  const requested = FORECAST_LABEL[fc.requested_method] ?? fc.requested_method;
  return (
    <div
      role="status"
      className="rounded-[var(--radius-md)] border border-[color:var(--color-warning)]/30 bg-[color:var(--color-warning)]/5 px-4 py-3"
    >
      <div className="text-sm font-medium text-[color:var(--color-warning)]">
        Planned with the empirical forecaster, not {requested}
      </div>
      <div className="text-xs text-[color:var(--color-muted-foreground)] mt-1">
        {FALLBACK_TEXT[fc.fallback_reason] ?? fc.fallback_reason.replace(/_/g, " ")}
      </div>
    </div>
  );
}

export default function RangeResultPage() {
  const { id } = useParams();
  const runId = Number(id);
  const navigate = useNavigate();
  const [hideExcluded, setHideExcluded] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "net_contribution", dir: "desc" });
  const [overrides, setOverrides] = useState<Map<number, StagedOverride>>(new Map());
  const [approver, setApprover] = useState("");
  const [showApprove, setShowApprove] = useState(false);
  const [reoptProgress, setReoptProgress] = useState<string | null>(null);

  const qc = useQueryClient();
  const { data, isLoading, error } = useQuery({
    queryKey: ["run", runId],
    queryFn: () => apiFetch<RunDetail>(`/runs/${runId}`),
    enabled: !Number.isNaN(runId),
  });

  // Parent run (for override delta).
  const parentId = data?.run.parent_run_id ?? null;
  const { data: parent } = useQuery({
    queryKey: ["run", parentId],
    queryFn: () => apiFetch<RunDetail>(`/runs/${parentId}`),
    enabled: parentId != null,
  });

  const regenRationales = useMutation({
    mutationFn: () =>
      apiFetch<{ run_id: number; updated: number; configured: boolean }>("/ai/rationales", {
        method: "POST",
        body: JSON.stringify({ run_id: runId, top_k: 12 }),
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["run", runId] }),
  });

  const approve = useMutation({
    mutationFn: () =>
      apiFetch<RunSummary>(`/runs/${runId}/approve`, {
        method: "POST",
        body: JSON.stringify({ approved_by: approver || "Planner" }),
      }),
    onSuccess: () => {
      setShowApprove(false);
      qc.invalidateQueries({ queryKey: ["run", runId] });
    },
  });
  const revoke = useMutation({
    mutationFn: () => apiFetch<RunSummary>(`/runs/${runId}/approve`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["run", runId] }),
  });

  const reoptimise = async () => {
    if (overrides.size === 0) return;
    setReoptProgress("Submitting overrides…");
    try {
      const body = {
        overrides: [...overrides.entries()].map(([sku_id, o]) => ({ sku_id, kind: o.kind, qty: o.qty ?? null })),
      };
      const run = await apiFetch<RunSummary>(`/runs/${runId}/override`, {
        method: "POST",
        body: JSON.stringify(body),
      });
      const es = new EventSource(`/api/runs/${run.id}/stream`);
      es.addEventListener("progress", (e) => {
        try {
          const ev = JSON.parse((e as MessageEvent).data);
          setReoptProgress(ev.message);
          if (ev.stage === "done") {
            es.close();
            setOverrides(new Map());
            setReoptProgress(null);
            navigate(`/runs/${ev.extra?.run_id ?? run.id}`);
          } else if (ev.stage === "failed") {
            es.close();
            setReoptProgress(`Failed: ${ev.message}`);
          }
        } catch {
          /* ignore */
        }
      });
    } catch (e) {
      setReoptProgress(`Error: ${String(e)}`);
    }
  };

  const parentQty = useMemo(() => {
    const m = new Map<number, number>();
    parent?.decisions.forEach((d) => m.set(d.sku_id, d.loaded_qty));
    return m;
  }, [parent]);

  const categories = useMemo(() => {
    if (!data) return [] as string[];
    return [...new Set(data.decisions.map((d) => d.category))].sort();
  }, [data]);

  const filtered = useMemo(() => {
    if (!data) return [] as Decision[];
    const rows = data.decisions.filter((d) => {
      if (hideExcluded && d.loaded_qty === 0) return false;
      if (categoryFilter && d.category !== categoryFilter) return false;
      return true;
    });
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...rows].sort((a, b) => {
      const av = (a[sort.key] as number) ?? -Infinity;
      const bv = (b[sort.key] as number) ?? -Infinity;
      return (av - bv) * dir;
    });
  }, [data, hideExcluded, categoryFilter, sort]);

  if (isLoading) return <Card>Loading run…</Card>;
  if (error || !data) return <Card>Run not found.</Card>;

  const r = data.run;
  const weightUtilPct =
    r.total_weight_kg != null && data.capacity.weight_budget_kg > 0
      ? Math.min(100, (r.total_weight_kg / data.capacity.weight_budget_kg) * 100)
      : 0;

  const netDelta =
    parent != null && r.expected_net_contribution != null && parent.run.expected_net_contribution != null
      ? r.expected_net_contribution - parent.run.expected_net_contribution
      : null;

  const toggleSort = (key: SortKey) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "desc" }));

  const stageOverride = (sku_id: number, ov: StagedOverride | null) => {
    setOverrides((prev) => {
      const next = new Map(prev);
      if (ov === null) next.delete(sku_id);
      else next.set(sku_id, ov);
      return next;
    });
  };

  return (
    <div className="flex flex-col gap-6 pb-24">
      <ForecastProvenance params={r.parameters_json} />
      <Card>
        <CardHeader
          title={`Run #${r.id} · ${r.status}`}
          subtitle={`Flight ${r.flight_id} · service level p${Math.round((r.parameters_json.service_level_p ?? 0.7) * 100)} · η ${(r.parameters_json.volume_efficiency_eta ?? 0.65).toFixed(2)} · forecast: ${
            FORECAST_LABEL[r.parameters_json?.forecasting?.effective_method] ??
            r.parameters_json?.forecasting?.effective_method ??
            "empirical"
          }`}
          right={
            <div className="flex items-center gap-2">
              <Link to={`/flights/${r.flight_id}`}>
                <Button variant="ghost">← Flight</Button>
              </Link>
              {r.status === "done" && (
                <Link to={`/runs/${r.id}/pack`}>
                  <Button variant="secondary">View 3D pack →</Button>
                </Link>
              )}
              {r.run_kind === "override" && <Badge tone="warning">Override</Badge>}
              {r.approval_status === "approved" ? (
                <Badge tone="success">✓ Approved · {r.approved_by}</Badge>
              ) : (
                r.status === "done" && <Badge tone="info">Draft</Badge>
              )}
              {r.status === "failed" && <Badge tone="error">Failed</Badge>}
            </div>
          }
        />

        {r.parent_run_id != null && (
          <div className="mb-3 text-sm text-[color:var(--color-muted-foreground)]">
            Override of{" "}
            <Link to={`/runs/${r.parent_run_id}`} className="text-[color:var(--color-secondary)] underline">
              autonomous run #{r.parent_run_id}
            </Link>
            {netDelta != null && (
              <span className="ml-2 font-medium" style={{ color: netDelta >= 0 ? "var(--color-accent)" : "var(--color-destructive)" }}>
                {netDelta >= 0 ? "+" : ""}
                {fmtGbpDetail(netDelta)} net vs autonomous plan
              </span>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          <Kpi label="Net contribution" value={fmtGbpDetail(r.expected_net_contribution ?? 0)} tone="accent" />
          <Kpi label="Expected revenue" value={fmtGbpDetail(r.expected_revenue ?? 0)} />
          <Kpi label="SKUs loaded" value={fmtNum(r.total_skus ?? 0)} hint={`${fmtNum(r.total_units ?? 0)} units`} tone="secondary" />
          <Kpi label="Weight" value={`${(r.total_weight_kg ?? 0).toFixed(1)} kg`} hint={`${weightUtilPct.toFixed(0)}% of ${data.capacity.weight_budget_kg} kg budget`} />
          <Kpi label="Volume" value={`${fmtNum(Math.round((r.total_volume_cm3 ?? 0) / 1000))} L`} hint={`η ${(data.capacity.volume_efficiency_eta * 100).toFixed(0)}%`} />
          <Kpi label="CO₂" value={`${data.sustainability.co2_kg.toFixed(1)} kg`} hint={`${data.sustainability.fuel_kg.toFixed(1)} kg fuel · ${fmtGbpDetail(data.sustainability.fuel_cost_gbp)}`} tone="muted" />
        </div>

        {/* Approval controls */}
        {r.status === "done" && (
          <div className="mt-4 flex items-center gap-3">
            {r.approval_status === "approved" ? (
              <>
                <span className="text-sm text-[color:var(--color-muted-foreground)]">
                  Approved by <strong>{r.approved_by}</strong>
                  {r.approved_note ? ` — ${r.approved_note}` : ""}
                </span>
                <Button variant="ghost" onClick={() => revoke.mutate()}>Revoke</Button>
              </>
            ) : showApprove ? (
              <>
                <input
                  autoFocus
                  placeholder="Approver name"
                  value={approver}
                  onChange={(e) => setApprover(e.target.value)}
                  className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
                />
                <Button variant="primary" onClick={() => approve.mutate()} disabled={approve.isPending}>
                  <CheckCircle weight="fill" /> Confirm approval
                </Button>
                <Button variant="ghost" onClick={() => setShowApprove(false)}>Cancel</Button>
              </>
            ) : (
              <Button variant="primary" onClick={() => setShowApprove(true)}>
                <CheckCircle weight="fill" /> Approve plan
              </Button>
            )}
          </div>
        )}
      </Card>

      {/* Rotation legs */}
      {data.rotation && data.rotation.legs.length > 0 && (
        <Card>
          <CardHeader
            title={`Rotation ${data.rotation.code ?? ""}`}
            subtitle={`${data.rotation.description ?? ""} — range loaded once, carried across all legs`}
          />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
                  <th className="px-3 py-2 text-left">Leg</th>
                  <th className="px-3 py-2 text-left">Sector</th>
                  <th className="px-3 py-2 text-right">Pax</th>
                  <th className="px-3 py-2 text-right">Expected sales</th>
                  <th className="px-3 py-2 text-right">Carried in</th>
                  <th className="px-3 py-2 text-right">Carried out</th>
                  <th className="px-3 py-2 text-right">Leg fuel £</th>
                  <th className="px-3 py-2 text-left">Carried weight</th>
                </tr>
              </thead>
              <tbody>
                {data.rotation.legs.map((leg) => {
                  const maxKg = Math.max(...data.rotation!.legs.map((l) => l.carried_in_kg), 1);
                  return (
                    <tr key={leg.leg_index} className="border-t border-[color:var(--color-border)]">
                      <td className="px-3 py-2">{leg.leg_index}</td>
                      <td className="px-3 py-2 font-medium">{leg.origin} → {leg.dest}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{leg.expected_pax ?? "—"}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{leg.expected_sales_units.toFixed(0)}</td>
                      <td className="px-3 py-2 text-right tabular-nums">{leg.carried_in_kg.toFixed(1)} kg</td>
                      <td className="px-3 py-2 text-right tabular-nums">{leg.carried_out_kg.toFixed(1)} kg</td>
                      <td className="px-3 py-2 text-right tabular-nums text-[color:var(--color-muted-foreground)]">{fmtGbpDetail(leg.fuel_cost_gbp)}</td>
                      <td className="px-3 py-2 w-40">
                        <div className="h-2 w-full rounded-full bg-[color:var(--color-muted)] overflow-hidden">
                          <div className="h-full bg-[color:var(--color-secondary)]" style={{ width: `${(leg.carried_in_kg / maxKg) * 100}%` }} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Constraint stress */}
      {data.constraints.length > 0 && (
        <Card>
          <CardHeader title="Constraint stress" subtitle="Which limits are binding the optimiser" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3">
            {data.constraints.map((c, i) => (
              <ConstraintRow key={i} c={c} />
            ))}
          </div>
        </Card>
      )}

      <Card>
        <CardHeader
          title="Range decisions"
          subtitle={`${filtered.length} rows · every SKU carries a deterministic reason`}
          right={
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => regenRationales.mutate()} disabled={regenRationales.isPending}>
                <Sparkle size={14} weight="fill" className="mr-1" />
                {regenRationales.isPending ? "Generating…" : "AI rationales"}
              </Button>
              <label className="text-xs flex items-center gap-1">
                <input type="checkbox" checked={hideExcluded} onChange={(e) => setHideExcluded(e.target.checked)} />
                Hide excluded
              </label>
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
              >
                <option value="">All categories</option>
                {categories.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          }
        />

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
                <th className="px-3 py-2 text-left">Decision</th>
                <th className="px-3 py-2 text-left">SKU / reason</th>
                <th className="px-2 py-2 text-right cursor-pointer" onClick={() => toggleSort("loaded_qty")}>Loaded</th>
                <th className="px-2 py-2 text-right">Sold (E)</th>
                <th className="px-2 py-2 text-right cursor-pointer" onClick={() => toggleSort("expected_margin")}>Margin</th>
                <th className="px-2 py-2 text-right cursor-pointer" onClick={() => toggleSort("net_per_kg")}>Net/kg{sortArrow(sort, "net_per_kg")}</th>
                <th className="px-2 py-2 text-right cursor-pointer" onClick={() => toggleSort("net_per_cm3")}>Net/cm³{sortArrow(sort, "net_per_cm3")}</th>
                <th className="px-2 py-2 text-right cursor-pointer" onClick={() => toggleSort("net_contribution")}>Net{sortArrow(sort, "net_contribution")}</th>
                <th className="px-2 py-2 text-right">Pin</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((d) => {
                const staged = overrides.get(d.sku_id);
                const prevQ = parentQty.get(d.sku_id);
                return (
                  <tr key={d.sku_id} className="border-t border-[color:var(--color-border)] align-top">
                    <td className="px-3 py-2">
                      <Badge tone={DECISION_TONE[d.decision] ?? "neutral"}>{d.decision}</Badge>
                      {d.is_overridden && <div className="mt-1"><Badge tone="warning">pinned</Badge></div>}
                    </td>
                    <td className="px-3 py-2">
                      <div className="font-medium">{d.sku_name}</div>
                      <div className="text-xs text-[color:var(--color-muted-foreground)]">{d.sku_code} · {d.category}</div>
                      {d.reason_code && (
                        <div className="mt-1" title={d.reason_text ?? ""}>
                          <Badge tone={reasonTone(d.reason_code)}>{REASON_LABEL[d.reason_code] ?? d.reason_code}</Badge>
                        </div>
                      )}
                      {d.substitute && (
                        <div className="text-xs text-[color:var(--color-secondary)] mt-1">
                          ↳ consider <strong>{d.substitute.sku_name}</strong>
                          {d.substitute.net_per_cm3 != null && ` (£${d.substitute.net_per_cm3.toFixed(4)}/cm³)`}
                        </div>
                      )}
                      {d.rationale_text && (
                        <div className="text-xs italic text-[color:var(--color-muted-foreground)] mt-1 max-w-md">{d.rationale_text}</div>
                      )}
                    </td>
                    <td className="px-2 py-2 text-right tabular-nums">
                      {fmtNum(d.loaded_qty)}
                      {prevQ != null && prevQ !== d.loaded_qty && (
                        <div className="text-xs text-[color:var(--color-muted-foreground)]">was {prevQ}</div>
                      )}
                    </td>
                    <td className="px-2 py-2 text-right tabular-nums">{d.expected_sales.toFixed(1)}</td>
                    <td className="px-2 py-2 text-right tabular-nums" title={`Handling £${d.handling_cost.toFixed(2)} · spoilage £${d.spoilage_cost.toFixed(2)} · fuel £${d.fuel_cost.toFixed(2)}`}>
                      {fmtGbpDetail(d.expected_margin)}
                    </td>
                    <td className="px-2 py-2 text-right tabular-nums text-[color:var(--color-muted-foreground)]">{d.net_per_kg != null ? `£${d.net_per_kg.toFixed(1)}` : "—"}</td>
                    <td className="px-2 py-2 text-right tabular-nums text-[color:var(--color-muted-foreground)]">{d.net_per_cm3 != null ? `£${d.net_per_cm3.toFixed(4)}` : "—"}</td>
                    <td className="px-2 py-2 text-right tabular-nums font-semibold" style={{ color: d.net_contribution >= 0 ? "var(--color-accent)" : "var(--color-destructive)" }}>
                      {fmtGbpDetail(d.net_contribution)}
                    </td>
                    <td className="px-2 py-2 text-right">
                      <PinEditor
                        staged={staged}
                        loaded={d.loaded_qty}
                        onStage={(ov) => stageOverride(d.sku_id, ov)}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Staged overrides bar */}
      {overrides.size > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-20 border-t border-[color:var(--color-border)] bg-[color:var(--color-card)] shadow-lg px-6 py-3 flex items-center justify-between">
          <div className="text-sm">
            <strong>{overrides.size}</strong> override{overrides.size > 1 ? "s" : ""} staged
            {reoptProgress && <span className="ml-3 text-[color:var(--color-muted-foreground)]">{reoptProgress}</span>}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => setOverrides(new Map())}>Clear</Button>
            <Button variant="primary" onClick={reoptimise} disabled={reoptProgress != null}>
              <ArrowsClockwise weight="fill" /> Re-optimise with overrides
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function sortArrow(sort: { key: string; dir: string }, key: string) {
  if (sort.key !== key) return "";
  return sort.dir === "desc" ? " ↓" : " ↑";
}

function PinEditor({
  staged,
  loaded,
  onStage,
}: {
  staged?: StagedOverride;
  loaded: number;
  onStage: (ov: StagedOverride | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [qty, setQty] = useState(String(loaded || 1));
  if (staged) {
    const label = staged.kind === "force_exclude" ? "out" : staged.kind === "force_include" ? "in" : `=${staged.qty}`;
    return (
      <button
        className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-[color:var(--color-warning)]/15 text-[color:var(--color-warning)]"
        onClick={() => onStage(null)}
        title="Click to clear this override"
      >
        <PushPin weight="fill" size={12} /> {label} <X size={10} />
      </button>
    );
  }
  if (!open) {
    return (
      <button className="text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-secondary)]" onClick={() => setOpen(true)} title="Pin / override">
        <PushPin size={16} />
      </button>
    );
  }
  return (
    <div className="inline-flex items-center gap-1">
      <button className="text-xs px-1.5 py-0.5 rounded bg-[color:var(--color-accent)]/15 text-[color:var(--color-accent)]" onClick={() => { onStage({ kind: "force_include" }); setOpen(false); }}>in</button>
      <button className="text-xs px-1.5 py-0.5 rounded bg-[color:var(--color-muted)] text-[color:var(--color-muted-foreground)]" onClick={() => { onStage({ kind: "force_exclude" }); setOpen(false); }}>out</button>
      <input
        type="number"
        min={0}
        value={qty}
        onChange={(e) => setQty(e.target.value)}
        className="w-14 h-7 px-1 text-xs rounded border border-[color:var(--color-input)] bg-[color:var(--color-background)]"
      />
      <button className="text-xs px-1.5 py-0.5 rounded bg-[color:var(--color-secondary)]/15 text-[color:var(--color-secondary)]" onClick={() => { onStage({ kind: "set_qty", qty: Number(qty) }); setOpen(false); }}>set</button>
      <button className="text-[color:var(--color-muted-foreground)]" onClick={() => setOpen(false)}><X size={12} /></button>
    </div>
  );
}

function ConstraintRow({ c }: { c: Constraint }) {
  const tone =
    c.status === "binding" ? "var(--color-destructive)" : c.status === "near" ? "var(--color-warning)" : "var(--color-accent)";
  const badgeTone = c.status === "binding" ? "error" : c.status === "near" ? "warning" : "success";
  const pct = Math.min(100, c.utilisation_pct);
  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="font-medium">{c.name}</span>
        <span className="flex items-center gap-2">
          <span className="text-[color:var(--color-muted-foreground)] tabular-nums">
            {fmtNum(Math.round(c.used))}/{fmtNum(Math.round(c.limit))} {c.unit ?? ""}
          </span>
          <Badge tone={badgeTone as "success" | "warning" | "error"}>{c.status}</Badge>
        </span>
      </div>
      <div className="h-2 w-full rounded-full bg-[color:var(--color-muted)] overflow-hidden">
        <div className="h-full transition-all" style={{ width: `${pct}%`, background: tone }} />
      </div>
    </div>
  );
}
