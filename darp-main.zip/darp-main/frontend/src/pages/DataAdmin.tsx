import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowsCounterClockwise, MagnifyingGlass } from "@phosphor-icons/react";
import { apiFetch } from "@/lib/api";
import { fmtGbpDetail, fmtNum } from "@/lib/format";
import { Card, CardHeader, Button, Badge } from "@/components/ui";

type Sku = {
  id: number;
  code: string;
  name: string;
  category: string;
  brand: string;
  unit_weight_g: number;
  cost_price: number;
  retail_price: number;
  margin_pct: number;
  bonded: boolean;
  hazard_class: string;
  case_size: number;
};

type Route = {
  id: number;
  origin_iata: string;
  dest_iata: string;
  distance_km: number;
  haul_class: string;
  alcohol_allowed: boolean;
  tobacco_allowed: boolean;
};

type Flight = {
  id: number;
  flight_no: string;
  route_id: number;
  scheduled_dt: string;
  expected_pax: number;
  expected_load_factor: number;
};

type Aircraft = {
  id: number;
  registration: string;
  type: string;
  max_payload_kg: number;
};

type CostParams = {
  id: number;
  fuel_price_per_kg_gbp: number;
  pick_cost_per_unit_gbp: number;
  pack_cost_per_drawer_gbp: number;
  cart_assembly_cost_gbp: number;
  return_handling_cost_per_unit_gbp: number;
  complexity_penalty_per_new_pickline_gbp: number;
};

const TABS = ["SKUs", "Routes", "Flights", "Aircraft", "Cost params", "Regulatory"] as const;
type Tab = (typeof TABS)[number];

export default function DataAdminPage() {
  const [tab, setTab] = useState<Tab>("SKUs");
  const qc = useQueryClient();

  const reset = useMutation({
    mutationFn: () => apiFetch<{ status: string; stats: any }>("/admin/reset", { method: "POST" }),
    onSuccess: () => {
      qc.invalidateQueries();
    },
  });

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <div className="flex items-center justify-between">
          <div>
            <div className="text-lg font-semibold" style={{ color: "var(--color-primary)" }}>
              Data Admin
            </div>
            <div className="text-sm text-[color:var(--color-muted-foreground)] mt-0.5">
              Browse and edit the synthetic data. All tables regenerate deterministically from a fixed seed.
            </div>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              if (confirm("Wipe and re-seed the database from the fixed seed?")) {
                reset.mutate();
              }
            }}
            disabled={reset.isPending}
          >
            <ArrowsCounterClockwise size={16} />
            {reset.isPending ? "Resetting…" : "Reset to seed"}
          </Button>
        </div>
      </Card>

      <Card padding="p-0">
        <div className="flex border-b border-[color:var(--color-border)] px-2">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={[
                "px-4 py-3 text-sm font-medium border-b-2 transition-colors -mb-px",
                tab === t
                  ? "border-[color:var(--color-secondary)] text-[color:var(--color-secondary)]"
                  : "border-transparent text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-foreground)]",
              ].join(" ")}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="p-6">
          {tab === "SKUs" && <SkusTab />}
          {tab === "Routes" && <RoutesTab />}
          {tab === "Flights" && <FlightsTab />}
          {tab === "Aircraft" && <AircraftTab />}
          {tab === "Cost params" && <CostParamsTab />}
          {tab === "Regulatory" && <RegulatoryTab />}
        </div>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// SKUs
// ---------------------------------------------------------------------------

function SkusTab() {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const { data: cats } = useQuery({
    queryKey: ["sku-categories"],
    queryFn: () => apiFetch<string[]>("/skus/categories"),
  });
  const { data, isLoading } = useQuery({
    queryKey: ["skus", q, category],
    queryFn: () => {
      const p = new URLSearchParams({ limit: "1000" });
      if (q) p.set("q", q);
      if (category) p.set("category", category);
      return apiFetch<{ total: number; items: Sku[] }>(`/skus?${p}`);
    },
  });

  return (
    <div>
      <div className="flex flex-wrap gap-3 mb-4">
        <div className="relative flex-1 min-w-[240px]">
          <MagnifyingGlass
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[color:var(--color-muted-foreground)]"
          />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search SKU, code, brand…"
            className="w-full pl-9 pr-3 h-9 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="h-9 px-3 rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)] text-sm"
        >
          <option value="">All categories</option>
          {cats?.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <div className="ml-auto text-sm text-[color:var(--color-muted-foreground)] self-center">
          {data ? `${fmtNum(data.total)} SKUs` : ""}
        </div>
      </div>
      <DataTable
        loading={isLoading}
        columns={[
          { key: "code", label: "Code", width: "w-24" },
          { key: "name", label: "Name" },
          { key: "category", label: "Category", width: "w-44" },
          { key: "brand", label: "Brand", width: "w-32" },
          {
            key: "unit_weight_g",
            label: "Weight",
            align: "right",
            render: (s: Sku) => `${s.unit_weight_g} g`,
          },
          {
            key: "retail_price",
            label: "Retail",
            align: "right",
            render: (s: Sku) => fmtGbpDetail(s.retail_price),
          },
          {
            key: "margin_pct",
            label: "Margin",
            align: "right",
            render: (s: Sku) => `${(s.margin_pct * 100).toFixed(0)}%`,
          },
          {
            key: "flags",
            label: "Flags",
            render: (s: Sku) => (
              <div className="flex gap-1">
                {s.bonded && <Badge tone="warning">bonded</Badge>}
                {s.hazard_class === "alcohol" && <Badge tone="info">alcohol</Badge>}
                {s.hazard_class === "tobacco" && <Badge tone="error">tobacco</Badge>}
              </div>
            ),
          },
        ]}
        rows={data?.items ?? []}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

function RoutesTab() {
  const { data, isLoading } = useQuery({
    queryKey: ["routes"],
    queryFn: () => apiFetch<Route[]>("/routes"),
  });
  return (
    <DataTable
      loading={isLoading}
      columns={[
        { key: "origin_iata", label: "From", width: "w-20" },
        { key: "dest_iata", label: "To", width: "w-20" },
        {
          key: "distance_km",
          label: "Distance",
          align: "right",
          render: (r: Route) => `${fmtNum(Math.round(r.distance_km))} km`,
        },
        { key: "haul_class", label: "Haul", width: "w-24" },
        {
          key: "alcohol_allowed",
          label: "Alcohol",
          render: (r: Route) => (r.alcohol_allowed ? <Badge tone="success">yes</Badge> : <Badge tone="neutral">no</Badge>),
        },
        {
          key: "tobacco_allowed",
          label: "Tobacco",
          render: (r: Route) => (r.tobacco_allowed ? <Badge tone="success">yes</Badge> : <Badge tone="error">no</Badge>),
        },
      ]}
      rows={data ?? []}
    />
  );
}

// ---------------------------------------------------------------------------
// Flights
// ---------------------------------------------------------------------------

function FlightsTab() {
  const { data, isLoading } = useQuery({
    queryKey: ["flights"],
    queryFn: () => apiFetch<{ total: number; items: Flight[] }>("/flights?limit=200"),
  });
  return (
    <>
      <div className="text-sm text-[color:var(--color-muted-foreground)] mb-3">
        {data ? `${fmtNum(data.total)} flights — showing latest 200` : ""}
      </div>
      <DataTable
        loading={isLoading}
        columns={[
          { key: "flight_no", label: "Flight", width: "w-24" },
          {
            key: "scheduled_dt",
            label: "Scheduled",
            render: (f: Flight) => new Date(f.scheduled_dt).toLocaleString("en-GB"),
          },
          { key: "route_id", label: "Route ID", align: "right", width: "w-24" },
          { key: "expected_pax", label: "Pax", align: "right", width: "w-20" },
          {
            key: "expected_load_factor",
            label: "Load",
            align: "right",
            render: (f: Flight) => `${(f.expected_load_factor * 100).toFixed(0)}%`,
          },
        ]}
        rows={data?.items ?? []}
      />
    </>
  );
}

// ---------------------------------------------------------------------------
// Aircraft
// ---------------------------------------------------------------------------

function AircraftTab() {
  const { data, isLoading } = useQuery({
    queryKey: ["aircraft"],
    queryFn: () => apiFetch<Aircraft[]>("/aircraft"),
  });
  return (
    <DataTable
      loading={isLoading}
      columns={[
        { key: "registration", label: "Registration", width: "w-32" },
        { key: "type", label: "Type", width: "w-28" },
        {
          key: "max_payload_kg",
          label: "Max payload",
          align: "right",
          render: (a: Aircraft) => `${fmtNum(Math.round(a.max_payload_kg))} kg`,
        },
      ]}
      rows={data ?? []}
    />
  );
}

// ---------------------------------------------------------------------------
// Cost params (editable)
// ---------------------------------------------------------------------------

function CostParamsTab() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["cost-params"],
    queryFn: () => apiFetch<CostParams[]>("/cost-params"),
  });
  const cp = data?.[0];
  const [draft, setDraft] = useState<Partial<CostParams> | null>(null);

  const patch = useMutation({
    mutationFn: (body: Partial<CostParams>) =>
      apiFetch<CostParams>(`/cost-params/${cp!.id}`, {
        method: "PATCH",
        body: JSON.stringify(body),
        headers: { "Content-Type": "application/json" },
      }),
    onSuccess: () => {
      setDraft(null);
      qc.invalidateQueries({ queryKey: ["cost-params"] });
    },
  });

  if (isLoading) return <div className="text-[color:var(--color-muted-foreground)]">Loading…</div>;
  if (!cp) return <div>No cost params seeded.</div>;

  const editing = draft !== null;
  const view = editing ? { ...cp, ...draft } : cp;

  const setField = (k: keyof CostParams, v: string) => {
    const num = Number.parseFloat(v);
    setDraft({ ...(draft ?? {}), [k]: Number.isFinite(num) ? num : 0 });
  };

  return (
    <div className="flex flex-col gap-4 max-w-2xl">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <EditRow label="Fuel price (£/kg)" k="fuel_price_per_kg_gbp" view={view} editing={editing} onChange={setField} />
        <EditRow label="Pick cost (£/unit)" k="pick_cost_per_unit_gbp" view={view} editing={editing} onChange={setField} />
        <EditRow label="Pack cost (£/drawer)" k="pack_cost_per_drawer_gbp" view={view} editing={editing} onChange={setField} />
        <EditRow label="Cart assembly (£/cart)" k="cart_assembly_cost_gbp" view={view} editing={editing} onChange={setField} />
        <EditRow label="Return handling (£/unit)" k="return_handling_cost_per_unit_gbp" view={view} editing={editing} onChange={setField} />
        <EditRow label="Complexity penalty (£/pickline)" k="complexity_penalty_per_new_pickline_gbp" view={view} editing={editing} onChange={setField} />
      </div>
      <div className="flex items-center gap-2">
        {!editing && (
          <Button variant="outline" onClick={() => setDraft({})}>Edit</Button>
        )}
        {editing && (
          <>
            <Button onClick={() => patch.mutate(draft!)} disabled={patch.isPending || Object.keys(draft!).length === 0}>
              {patch.isPending ? "Saving…" : "Save"}
            </Button>
            <Button variant="ghost" onClick={() => setDraft(null)} disabled={patch.isPending}>Cancel</Button>
          </>
        )}
        <span className="text-xs text-[color:var(--color-muted-foreground)] ml-auto">
          Changes apply to the next optimisation run.
        </span>
      </div>
    </div>
  );
}

function EditRow({
  label,
  k,
  view,
  editing,
  onChange,
}: {
  label: string;
  k: keyof CostParams;
  view: CostParams;
  editing: boolean;
  onChange: (k: keyof CostParams, v: string) => void;
}) {
  const value = view[k] as number;
  return (
    <div className="flex items-center justify-between border border-[color:var(--color-border)] rounded-[var(--radius-md)] px-4 py-3 gap-3">
      <span className="text-sm text-[color:var(--color-muted-foreground)]">{label}</span>
      {editing ? (
        <input
          type="number"
          step="0.01"
          value={value}
          onChange={(e) => onChange(k, e.target.value)}
          className="w-28 h-8 px-2 text-right tabular-nums text-sm rounded-[var(--radius-md)] border border-[color:var(--color-input)] bg-[color:var(--color-background)]"
        />
      ) : (
        <span className="text-sm font-semibold tabular-nums">{value.toFixed(2)}</span>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Regulatory
// ---------------------------------------------------------------------------

function RegulatoryTab() {
  const { data, isLoading } = useQuery({
    queryKey: ["regulatory"],
    queryFn: () => apiFetch<any[]>("/regulatory-rules"),
  });
  return (
    <DataTable
      loading={isLoading}
      columns={[
        { key: "id", label: "ID", width: "w-16" },
        { key: "route_id", label: "Route ID", width: "w-24" },
        { key: "sku_category", label: "Category" },
        {
          key: "rule_type",
          label: "Rule",
          render: (r: any) =>
            r.rule_type === "disallow" ? <Badge tone="error">disallow</Badge> : <Badge tone="warning">{r.rule_type}</Badge>,
        },
        {
          key: "parameters_json",
          label: "Parameters",
          render: (r: any) => (
            <span className="text-xs text-[color:var(--color-muted-foreground)]">
              {JSON.stringify(r.parameters_json)}
            </span>
          ),
        },
      ]}
      rows={data ?? []}
    />
  );
}

// ---------------------------------------------------------------------------
// Reusable table
// ---------------------------------------------------------------------------

type Column<T> = {
  key: string;
  label: string;
  width?: string;
  align?: "left" | "right";
  render?: (row: T) => any;
};

function DataTable<T>({
  columns,
  rows,
  loading,
}: {
  columns: Column<T>[];
  rows: T[];
  loading?: boolean;
}) {
  if (loading) return <div className="text-[color:var(--color-muted-foreground)]">Loading…</div>;
  return (
    <div className="overflow-x-auto -mx-2">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wide text-[color:var(--color-muted-foreground)]">
            {columns.map((c) => (
              <th
                key={c.key}
                className={`px-3 py-2 font-semibold ${c.width ?? ""} ${
                  c.align === "right" ? "text-right" : "text-left"
                }`}
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row: any, i) => (
            <tr
              key={row.id ?? i}
              className="border-t border-[color:var(--color-border)] hover:bg-[color:var(--color-muted)]/40"
            >
              {columns.map((c) => (
                <td
                  key={c.key}
                  className={`px-3 py-2 ${c.align === "right" ? "text-right" : "text-left"}`}
                >
                  {c.render ? c.render(row) : (row as any)[c.key]}
                </td>
              ))}
            </tr>
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={columns.length} className="px-3 py-6 text-center text-[color:var(--color-muted-foreground)]">
                No rows.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
