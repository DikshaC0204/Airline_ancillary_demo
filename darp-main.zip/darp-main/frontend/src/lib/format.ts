/** Currency / number formatting helpers. */

const GBP = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
  maximumFractionDigits: 0,
});

const GBP_DETAIL = new Intl.NumberFormat("en-GB", {
  style: "currency",
  currency: "GBP",
  maximumFractionDigits: 2,
});

const NUM = new Intl.NumberFormat("en-GB");

export const fmtGbp = (n: number) => GBP.format(n);
export const fmtGbpDetail = (n: number) => GBP_DETAIL.format(n);
export const fmtNum = (n: number) => NUM.format(n);
export const fmtPct = (n: number, digits = 0) => `${(n * 100).toFixed(digits)}%`;
