import { Component, ReactNode } from "react";

/** Stops one broken page from blanking the whole app mid-demo. */
export class ErrorBoundary extends Component<
  { children: ReactNode },
  { error: Error | null }
> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    const { error } = this.state;
    if (!error) return this.props.children;
    return (
      <div
        role="alert"
        className="rounded-[var(--radius-lg)] border border-[color:var(--color-destructive)]/30 bg-[color:var(--color-destructive)]/5 p-6"
      >
        <div className="text-lg font-semibold text-[color:var(--color-destructive)]">
          This page hit an error
        </div>
        <div className="text-sm text-[color:var(--color-muted-foreground)] mt-1">
          The rest of the app is still usable — pick another page from the sidebar.
        </div>
        <pre className="text-xs font-mono mt-3 whitespace-pre-wrap text-[color:var(--color-muted-foreground)]">
          {error.message}
        </pre>
        <button
          type="button"
          onClick={() => this.setState({ error: null })}
          className="mt-4 inline-flex items-center h-9 px-4 rounded-[var(--radius-md)] text-sm font-medium bg-[color:var(--color-primary)] text-[color:var(--color-primary-foreground)] hover:opacity-90"
        >
          Try again
        </button>
      </div>
    );
  }
}
