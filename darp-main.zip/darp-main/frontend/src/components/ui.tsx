import { ReactNode } from "react";

/** Brand-styled card (§5.2). */
export function Card({
  children,
  className = "",
  padding = "p-6",
}: {
  children: ReactNode;
  className?: string;
  padding?: string;
}) {
  return (
    <div
      className={`bg-[color:var(--color-card)] border border-[color:var(--color-border)] rounded-[var(--radius-lg)] shadow-sm ${padding} ${className}`}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  subtitle,
  right,
}: {
  title: ReactNode;
  subtitle?: ReactNode;
  right?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between mb-4">
      <div>
        <div className="text-lg font-semibold" style={{ color: "var(--color-primary)" }}>
          {title}
        </div>
        {subtitle && (
          <div className="text-sm text-[color:var(--color-muted-foreground)] mt-0.5">
            {subtitle}
          </div>
        )}
      </div>
      {right}
    </div>
  );
}

/** Status pill badge (§5.4). */
export function Badge({
  children,
  tone = "info",
}: {
  children: ReactNode;
  tone?: "success" | "warning" | "error" | "info" | "neutral";
}) {
  const styles: Record<string, string> = {
    success: "text-[color:var(--color-accent)] bg-[color:var(--color-accent)]/10",
    warning: "text-[color:var(--color-warning)] bg-[color:var(--color-warning)]/10",
    error: "text-[color:var(--color-destructive)] bg-[color:var(--color-destructive)]/10",
    info: "text-[color:var(--color-secondary)] bg-[color:var(--color-secondary)]/10",
    neutral: "text-[color:var(--color-muted-foreground)] bg-[color:var(--color-muted)]",
  };
  return (
    <span
      className={`inline-flex items-center text-xs px-2 py-0.5 rounded-full font-medium ${styles[tone]}`}
    >
      {children}
    </span>
  );
}

/** Brand buttons (§5.1). */
type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "destructive";

export function Button({
  children,
  onClick,
  variant = "secondary",
  type = "button",
  disabled,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: ButtonVariant;
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 h-9 px-4 rounded-[var(--radius-md)] text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed";
  const variants: Record<ButtonVariant, string> = {
    primary:
      "bg-[color:var(--color-primary)] text-[color:var(--color-primary-foreground)] hover:opacity-90",
    secondary:
      "bg-[color:var(--color-secondary)] text-[color:var(--color-secondary-foreground)] hover:opacity-90",
    outline:
      "border border-[color:var(--color-border)] text-[color:var(--color-foreground)] bg-transparent hover:bg-[color:var(--color-muted)]",
    ghost:
      "text-[color:var(--color-foreground)] bg-transparent hover:bg-[color:var(--color-muted)]",
    destructive:
      "bg-[color:var(--color-destructive)] text-[color:var(--color-destructive-foreground)] hover:opacity-90",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

/** KPI tile for dashboards. */
export function Kpi({
  label,
  value,
  hint,
  tone = "primary",
}: {
  label: string;
  value: string | number;
  hint?: string;
  tone?: "primary" | "secondary" | "accent" | "muted";
}) {
  const colorVar =
    tone === "primary"
      ? "var(--color-primary)"
      : tone === "secondary"
      ? "var(--color-secondary)"
      : tone === "accent"
      ? "var(--color-accent)"
      : "var(--color-muted-foreground)";
  return (
    <Card padding="p-5">
      <div className="text-xs uppercase tracking-wide font-semibold text-[color:var(--color-muted-foreground)]">
        {label}
      </div>
      <div className="text-3xl font-semibold mt-1" style={{ color: colorVar }}>
        {value}
      </div>
      {hint && (
        <div className="text-xs text-[color:var(--color-muted-foreground)] mt-1">{hint}</div>
      )}
    </Card>
  );
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-[color:var(--color-muted-foreground)] py-6">
      <span
        className="inline-block h-3.5 w-3.5 rounded-full border-2 border-current border-t-transparent animate-spin"
        aria-hidden
      />
      {label}
    </div>
  );
}

/** Shown instead of a bare dash, so an empty screen still says what to do next. */
export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon?: ReactNode;
  title: string;
  body?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center text-center gap-2 py-8 px-4">
      {icon && <span className="text-[color:var(--color-muted-foreground)]">{icon}</span>}
      <div className="font-medium">{title}</div>
      {body && (
        <div className="text-sm text-[color:var(--color-muted-foreground)] max-w-md">{body}</div>
      )}
      {action && <div className="mt-1">{action}</div>}
    </div>
  );
}

export function ErrorNote({ title, error }: { title: string; error?: unknown }) {
  const detail = error instanceof Error ? error.message : error ? String(error) : null;
  return (
    <div
      role="alert"
      className="rounded-[var(--radius-md)] border border-[color:var(--color-destructive)]/30 bg-[color:var(--color-destructive)]/5 px-4 py-3"
    >
      <div className="text-sm font-medium text-[color:var(--color-destructive)]">{title}</div>
      {detail && (
        <div className="text-xs text-[color:var(--color-muted-foreground)] mt-1 font-mono break-all">
          {detail}
        </div>
      )}
      <div className="text-xs text-[color:var(--color-muted-foreground)] mt-2">
        Check the backend is running on port 8000.
      </div>
    </div>
  );
}
