import { useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Text } from "@react-three/drei";
import * as THREE from "three";

// ---------------------------------------------------------------------------
// Types matching backend /api/runs/:id/packing response
// ---------------------------------------------------------------------------

export type PackedPosition = {
  x: number;
  y: number;
  z: number;
  l: number;
  w: number;
  h: number;
};

export type Placement = {
  sku_id: number;
  sku_code: string;
  sku_name: string;
  category: string;
  units: number;
  positions: PackedPosition[];
};

export type DrawerPacking = {
  drawer_id: number;
  cart_id: number;
  slot_index: number;
  drawer_type: string;
  internal_l_mm: number;
  internal_w_mm: number;
  internal_h_mm: number;
  max_weight_kg: number;
  accessibility_score: number;
  placements: Placement[];
  weight_kg: number;
  weight_cap_kg: number;
  volume_used_cm3: number;
  volume_total_cm3: number;
};

export type CartPacking = {
  id: number;
  position_code: string;
  cart_type: string;
  drawers: DrawerPacking[];
};

export type PackingPayload = {
  run_id: number;
  cart_layout: CartPacking[];
  totals: { total_units_packed: number; total_weight_kg: number };
};

export type ViewMode = "category" | "velocity" | "weight";

// Scale: 1 unit in scene = 100mm. Drawer ~400mm → 4 units.
const SCALE = 1 / 100;
// Vertical spacing between drawer slots within a cart.
const SLOT_GAP_MM = 6;
// Horizontal spacing between carts.
const CART_GAP_MM = 80;

// Brand palette for category hashing.
const CATEGORY_COLOURS = [
  "#0072BC", // dnata blue
  "#5CB85C", // green
  "#1A3A5C", // navy
  "#F5A623", // amber
  "#A14CC4", // purple
  "#E2536A", // rose
  "#26A69A", // teal
  "#FF8A65", // coral
  "#8D6E63", // brown
  "#5C6BC0", // indigo
];

function hashCategoryColour(cat: string): string {
  let h = 0;
  for (let i = 0; i < cat.length; i++) h = (h * 31 + cat.charCodeAt(i)) >>> 0;
  return CATEGORY_COLOURS[h % CATEGORY_COLOURS.length];
}

function velocityColour(units: number, max: number): string {
  // Red (cold) → green (hot)
  const t = max > 0 ? Math.min(1, units / max) : 0;
  const c = new THREE.Color().setHSL((1 - t) * 0.0 + t * 0.33, 0.7, 0.5);
  return `#${c.getHexString()}`;
}

function weightColour(unitWeightG: number, maxG: number): string {
  const t = maxG > 0 ? Math.min(1, unitWeightG / maxG) : 0;
  // Blue (light) → red (heavy)
  const c = new THREE.Color().setHSL(0.66 - 0.66 * t, 0.7, 0.5);
  return `#${c.getHexString()}`;
}

// ---------------------------------------------------------------------------
// Drawer mesh — translucent shell + units inside, slides out on click.
// ---------------------------------------------------------------------------

type DrawerProps = {
  drawer: DrawerPacking;
  cartX: number; // world x of cart centre (mm)
  cartZ: number; // world z of cart centre (mm)
  yOffsetMm: number; // cumulative y-offset within cart
  colourFor: (p: Placement, pos: PackedPosition) => string;
  onSelectDrawer: (d: DrawerPacking | null) => void;
  selected: boolean;
};

function Drawer3D({ drawer, cartX, cartZ, yOffsetMm, colourFor, onSelectDrawer, selected }: DrawerProps) {
  const groupRef = useRef<THREE.Group>(null);
  // Slide-out animation along +Z (drawer pulled outward).
  const targetSlide = selected ? drawer.internal_l_mm * 0.7 : 0;

  useFrame((_state, dt) => {
    if (!groupRef.current) return;
    const cur = groupRef.current.position.z;
    const goal = (cartZ + targetSlide) * SCALE;
    groupRef.current.position.z = cur + (goal - cur) * Math.min(1, dt * 5);
  });

  // Drawer-local origin: drawer bottom-front-left.
  // Centre the drawer on cart x/z so it slides forward (+Z).
  const baseX = cartX * SCALE;
  const baseY = yOffsetMm * SCALE;
  const baseZ = cartZ * SCALE;

  const l = drawer.internal_l_mm * SCALE;
  const w = drawer.internal_w_mm * SCALE;
  const h = drawer.internal_h_mm * SCALE;

  return (
    <group ref={groupRef} position={[baseX, baseY, baseZ]}>
      {/* Drawer shell — translucent */}
      <mesh
        position={[l / 2, h / 2, w / 2]}
        onClick={(e) => {
          e.stopPropagation();
          onSelectDrawer(selected ? null : drawer);
        }}
      >
        <boxGeometry args={[l, h, w]} />
        <meshStandardMaterial
          color={selected ? "#0072BC" : "#1A3A5C"}
          transparent
          opacity={selected ? 0.12 : 0.07}
          wireframe={false}
        />
      </mesh>
      {/* Drawer outline */}
      <lineSegments position={[l / 2, h / 2, w / 2]}>
        <edgesGeometry args={[new THREE.BoxGeometry(l, h, w)]} />
        <lineBasicMaterial color={selected ? "#0072BC" : "#1A3A5C"} linewidth={1} />
      </lineSegments>
      {/* Slot label */}
      <Text
        position={[-0.05, h / 2, w / 2]}
        rotation={[0, -Math.PI / 2, 0]}
        fontSize={0.12}
        color="#1A3A5C"
        anchorX="center"
        anchorY="middle"
      >
        {`#${drawer.slot_index}`}
      </Text>
      {/* Units */}
      {drawer.placements.flatMap((p) =>
        p.positions.map((pos, i) => {
          // backend coordinate convention: x along length, y along width, z along height.
          // Scene mapping: scene.x = pos.x (length), scene.y = pos.z (height), scene.z = pos.y (width).
          const sx = pos.x * SCALE;
          const sy = pos.z * SCALE;
          const sz = pos.y * SCALE;
          const dx = pos.l * SCALE;
          const dy = pos.h * SCALE;
          const dz = pos.w * SCALE;
          const colour = colourFor(p, pos);
          return (
            <mesh
              key={`${p.sku_id}-${i}`}
              position={[sx + dx / 2, sy + dy / 2, sz + dz / 2]}
            >
              <boxGeometry args={[dx, dy, dz]} />
              <meshStandardMaterial color={colour} roughness={0.6} metalness={0.05} />
            </mesh>
          );
        })
      )}
    </group>
  );
}

// ---------------------------------------------------------------------------
// Cart frame — stacks drawers vertically.
// ---------------------------------------------------------------------------

type CartProps = {
  cart: CartPacking;
  cartX: number;
  cartZ: number;
  colourFor: (p: Placement, pos: PackedPosition) => string;
  selectedDrawer: number | null;
  onSelectDrawer: (d: DrawerPacking | null) => void;
};

function Cart3D({ cart, cartX, cartZ, colourFor, selectedDrawer, onSelectDrawer }: CartProps) {
  // Stack drawers from slot_index 1 = top → render top-first then descending.
  const sorted = [...cart.drawers].sort((a, b) => a.slot_index - b.slot_index);
  const totalH = sorted.reduce((s, d) => s + d.internal_h_mm + SLOT_GAP_MM, 0);

  let yCursor = totalH - sorted[0].internal_h_mm; // top
  const rows = sorted.map((d) => {
    const y = yCursor;
    yCursor -= d.internal_h_mm + SLOT_GAP_MM;
    return { drawer: d, y };
  });

  return (
    <group>
      {/* Cart base plate */}
      <mesh position={[(cartX + 200) * SCALE, -0.05, (cartZ + 150) * SCALE]}>
        <boxGeometry args={[450 * SCALE, 0.05, 320 * SCALE]} />
        <meshStandardMaterial color="#1A3A5C" />
      </mesh>
      {/* Cart label */}
      <Text
        position={[(cartX + 200) * SCALE, totalH * SCALE + 0.2, (cartZ + 150) * SCALE]}
        fontSize={0.18}
        color="#1A3A5C"
        anchorX="center"
        anchorY="middle"
      >
        {`Cart ${cart.position_code} · ${cart.cart_type}`}
      </Text>
      {rows.map(({ drawer, y }) => (
        <Drawer3D
          key={drawer.drawer_id}
          drawer={drawer}
          cartX={cartX}
          cartZ={cartZ}
          yOffsetMm={y}
          colourFor={colourFor}
          onSelectDrawer={onSelectDrawer}
          selected={selectedDrawer === drawer.drawer_id}
        />
      ))}
    </group>
  );
}

// ---------------------------------------------------------------------------
// Top-level scene
// ---------------------------------------------------------------------------

export type CartSceneProps = {
  payload: PackingPayload;
  viewMode: ViewMode;
  unitWeightLookup?: Record<number, number>; // sku_id → unit_weight_g (for weight view)
  onSelectDrawer?: (d: DrawerPacking | null) => void;
};

export function CartScene({ payload, viewMode, unitWeightLookup, onSelectDrawer }: CartSceneProps) {
  const [selected, setSelected] = useState<DrawerPacking | null>(null);

  const handleSelect = (d: DrawerPacking | null) => {
    setSelected(d);
    onSelectDrawer?.(d);
  };

  // Pre-compute palette extents for velocity/weight modes.
  const maxVelocity = useMemo(() => {
    let m = 0;
    for (const c of payload.cart_layout)
      for (const d of c.drawers)
        for (const p of d.placements) if (p.units > m) m = p.units;
    return m;
  }, [payload]);

  const maxUnitWeightG = useMemo(() => {
    if (!unitWeightLookup) return 0;
    let m = 0;
    for (const id in unitWeightLookup) if (unitWeightLookup[id] > m) m = unitWeightLookup[id];
    return m;
  }, [unitWeightLookup]);

  const colourFor = (p: Placement) => {
    if (viewMode === "velocity") return velocityColour(p.units, maxVelocity);
    if (viewMode === "weight") {
      const w = unitWeightLookup?.[p.sku_id] ?? 0;
      return weightColour(w, maxUnitWeightG);
    }
    return hashCategoryColour(p.category);
  };

  // Cart layout in world coordinates (mm).
  const cartPositions = payload.cart_layout.map((c, i) => ({
    cart: c,
    cartX: i * (400 + CART_GAP_MM),
    cartZ: 0,
  }));

  return (
    <Canvas camera={{ position: [6, 6, 8], fov: 45 }} shadows>
      <color attach="background" args={["#F8F4EE"]} />
      <ambientLight intensity={0.65} />
      <directionalLight position={[5, 10, 5]} intensity={0.8} castShadow />
      <directionalLight position={[-5, 6, -3]} intensity={0.3} />
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[3, -0.1, 1.5]} receiveShadow>
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial color="#EFE7DA" />
      </mesh>
      {cartPositions.map(({ cart, cartX, cartZ }) => (
        <Cart3D
          key={cart.id}
          cart={cart}
          cartX={cartX}
          cartZ={cartZ}
          colourFor={colourFor}
          selectedDrawer={selected?.drawer_id ?? null}
          onSelectDrawer={handleSelect}
        />
      ))}
      <OrbitControls makeDefault target={[3, 1, 1]} />
    </Canvas>
  );
}
