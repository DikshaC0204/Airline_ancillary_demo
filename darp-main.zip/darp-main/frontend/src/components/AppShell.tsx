import { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  ChartLineUp,
  AirplaneTilt,
  MapTrifold,
  Package,
  Storefront,
  Sparkle,
  GitDiff,
  Database,
  ChatCircleDots,
  ChatTeardropDots,
  Gear,
  Moon,
  Sun,
} from "@phosphor-icons/react";
import { useTheme } from "@/lib/theme";

const NAV: { to: string; label: string; section: string; icon: any }[] = [
  { to: "/dashboard", label: "Dashboard", section: "Overview", icon: ChartLineUp },
  { to: "/routes", label: "Routes", section: "Operations", icon: MapTrifold },
  { to: "/flights", label: "Flights", section: "Operations", icon: AirplaneTilt },
  { to: "/skus", label: "SKU Catalogue", section: "Catalogue", icon: Package },
  { to: "/aircraft", label: "Aircraft & Galley", section: "Catalogue", icon: Storefront },
  { to: "/optimisation", label: "Optimisation", section: "Planning", icon: Sparkle },
  { to: "/scenarios", label: "Scenarios", section: "Planning", icon: GitDiff },
  { to: "/data-admin", label: "Data Admin", section: "Admin", icon: Database },
  { to: "/settings", label: "Settings", section: "Admin", icon: Gear },
  { to: "/co-planner", label: "AI Co-Planner", section: "Admin", icon: ChatCircleDots },
  { to: "/crew", label: "Crew Feedback", section: "Admin", icon: ChatTeardropDots },
];

function groupBySection() {
  const out: Record<string, typeof NAV> = {};
  for (const item of NAV) (out[item.section] ||= []).push(item);
  return out;
}

export function AppShell({ children }: { children: ReactNode }) {
  const sections = groupBySection();
  const location = useLocation();
  const { theme, toggle } = useTheme();

  return (
    <div className="flex h-screen w-screen overflow-hidden">
      {/* Sidebar — navy chrome per brand §2.6 */}
      <aside
        className="w-60 shrink-0 flex flex-col"
        style={{
          background: "var(--color-sidebar)",
          color: "var(--color-sidebar-foreground)",
        }}
      >
        <div className="mx-2 py-5 border-b border-white/10">
          <div className="flex flex-col gap-1">
            <div className="bg-white/95 rounded-md px-3 py-2 flex items-center justify-center">
              <img src="/dnata-logo.svg" alt="dnata" className="h-7 w-auto" />
            </div>
            <div className="text-[13px] opacity-70 leading-tight mt-2 text-center">
              Autonomous Range Planner
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3">
          {Object.entries(sections).map(([section, items]) => (
            <div key={section} className="mb-3">
              <div className="px-5 py-1 text-[10px] uppercase tracking-wider opacity-60 font-semibold">
                {section}
              </div>
              {items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                      [
                        "flex items-center gap-3 mx-2 my-0.5 px-3 py-2 rounded-md text-sm transition-colors",
                        isActive
                          ? "bg-[color:var(--color-sidebar-primary)] text-white font-medium"
                          : "hover:bg-white/10",
                      ].join(" ")
                    }
                  >
                    <Icon size={18} weight="regular" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="px-3 py-3 border-t border-white/10">
          <button
            onClick={toggle}
            className="w-full flex items-center justify-center gap-2 text-xs opacity-80 hover:opacity-100 py-2 rounded-md hover:bg-white/10 transition"
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto" style={{ background: "var(--color-muted)" }}>
        <header className="bg-[color:var(--color-background)] border-b border-[color:var(--color-border)] px-8 py-4">
          <PageTitle pathname={location.pathname} />
        </header>
        <div className="px-8 py-6">{children}</div>
      </main>
    </div>
  );
}

function PageTitle({ pathname }: { pathname: string }) {
  const match = NAV.find((n) => n.to === pathname);
  return (
    <div>
      <h1 className="text-2xl font-semibold" style={{ color: "var(--color-primary)" }}>
        {match?.label ?? "dnata ARP"}
      </h1>
      <div className="text-sm text-[color:var(--color-muted-foreground)] mt-0.5">
        {match?.section ?? ""}
      </div>
    </div>
  );
}
