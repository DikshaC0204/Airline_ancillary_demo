import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AppShell } from "./components/AppShell";
import { ErrorBoundary } from "./components/ErrorBoundary";
import DashboardPage from "./pages/Dashboard";
import RoutesPage from "./pages/Routes";
import FlightsPage from "./pages/Flights";
import FlightDetailPage from "./pages/FlightDetail";
import RangeResultPage from "./pages/RangeResult";
import PackingPage from "./pages/Packing3D";
import SkusPage from "./pages/Skus";
import AircraftPage from "./pages/Aircraft";
import OptimisationPage from "./pages/Optimisation";
import ScenariosPage from "./pages/Scenarios";
import DataAdminPage from "./pages/DataAdmin";
import SettingsPage from "./pages/Settings";
import CoPlannerPage from "./pages/CoPlanner";
import CrewFeedbackPage from "./pages/CrewFeedback";

export default function App() {
  const location = useLocation();
  return (
    <AppShell>
      {/* Keyed on the route so navigating away clears a crashed page. */}
      <ErrorBoundary key={location.pathname}>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/routes" element={<RoutesPage />} />
          <Route path="/flights" element={<FlightsPage />} />
          <Route path="/flights/:id" element={<FlightDetailPage />} />
          <Route path="/runs/:id" element={<RangeResultPage />} />
          <Route path="/runs/:id/pack" element={<PackingPage />} />
          <Route path="/skus" element={<SkusPage />} />
          <Route path="/aircraft" element={<AircraftPage />} />
          <Route path="/optimisation" element={<OptimisationPage />} />
          <Route path="/scenarios" element={<ScenariosPage />} />
          <Route path="/data-admin" element={<DataAdminPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/co-planner" element={<CoPlannerPage />} />
          <Route path="/crew" element={<CrewFeedbackPage />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </ErrorBoundary>
    </AppShell>
  );
}
