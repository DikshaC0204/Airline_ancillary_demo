// Generates docs/dnata-arp-business-overview.docx
// Run: node docs/build-business-overview.js

const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, LevelFormat, BorderStyle,
  WidthType, ShadingType, PageNumber, PageBreak, TableOfContents,
} = require("docx");

// ---------------------------------------------------------------------------
// Brand
// ---------------------------------------------------------------------------
const NAVY = "1A3A5C";
const BLUE = "0072BC";
const GREEN = "5CB85C";
const AMBER = "F0AD4E";
const GREY = "666666";
const LIGHT_GREY = "F5F5F5";
const BORDER_GREY = "D0D0D0";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const para = (text, opts = {}) =>
  new Paragraph({
    spacing: { before: 60, after: 120, line: 300 },
    children: [new TextRun({ text, ...opts })],
  });

const richPara = (runs, opts = {}) =>
  new Paragraph({
    spacing: { before: 60, after: 120, line: 300 },
    ...opts,
    children: runs.map((r) =>
      r instanceof TextRun ? r : new TextRun(r)
    ),
  });

const h1 = (text) =>
  new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, color: NAVY, bold: true })],
  });

const h2 = (text) =>
  new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, color: NAVY, bold: true })],
  });

const h3 = (text) =>
  new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [new TextRun({ text, color: BLUE, bold: true })],
  });

const bullet = (text, level = 0) =>
  new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { before: 40, after: 40, line: 280 },
    children: [new TextRun(text)],
  });

const richBullet = (runs, level = 0) =>
  new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: { before: 40, after: 40, line: 280 },
    children: runs.map((r) => (r instanceof TextRun ? r : new TextRun(r))),
  });

const numbered = (text) =>
  new Paragraph({
    numbering: { reference: "numbers", level: 0 },
    spacing: { before: 40, after: 40, line: 280 },
    children: [new TextRun(text)],
  });

const spacer = () =>
  new Paragraph({ spacing: { before: 60, after: 60 }, children: [new TextRun("")] });

// Callout box rendered as a single-row, single-cell table
const callout = (titleText, bodyText, accentHex = BLUE) =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 9360, type: WidthType.DXA },
            shading: { fill: LIGHT_GREY, type: ShadingType.CLEAR },
            borders: {
              top: { style: BorderStyle.SINGLE, size: 6, color: accentHex },
              bottom: { style: BorderStyle.SINGLE, size: 6, color: accentHex },
              left: { style: BorderStyle.SINGLE, size: 18, color: accentHex },
              right: { style: BorderStyle.SINGLE, size: 6, color: accentHex },
            },
            margins: { top: 160, bottom: 160, left: 220, right: 220 },
            children: [
              new Paragraph({
                spacing: { after: 80 },
                children: [
                  new TextRun({ text: titleText, bold: true, color: accentHex }),
                ],
              }),
              new Paragraph({
                spacing: { line: 280 },
                children: [new TextRun({ text: bodyText })],
              }),
            ],
          }),
        ],
      }),
    ],
  });

// Two-column key/value table
const kvTable = (rows) => {
  const colA = 2880;
  const colB = 6480;
  const cellBorders = {
    top: { style: BorderStyle.SINGLE, size: 4, color: BORDER_GREY },
    bottom: { style: BorderStyle.SINGLE, size: 4, color: BORDER_GREY },
    left: { style: BorderStyle.SINGLE, size: 4, color: BORDER_GREY },
    right: { style: BorderStyle.SINGLE, size: 4, color: BORDER_GREY },
  };
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [colA, colB],
    rows: rows.map(([k, v]) =>
      new TableRow({
        children: [
          new TableCell({
            width: { size: colA, type: WidthType.DXA },
            borders: cellBorders,
            shading: { fill: LIGHT_GREY, type: ShadingType.CLEAR },
            margins: { top: 100, bottom: 100, left: 140, right: 140 },
            children: [
              new Paragraph({
                children: [new TextRun({ text: k, bold: true, color: NAVY })],
              }),
            ],
          }),
          new TableCell({
            width: { size: colB, type: WidthType.DXA },
            borders: cellBorders,
            margins: { top: 100, bottom: 100, left: 140, right: 140 },
            children: [new Paragraph({ children: [new TextRun(v)] })],
          }),
        ],
      })
    ),
  });
};

const execSummary = (text) =>
  callout("Executive summary", text, GREEN);

// ---------------------------------------------------------------------------
// Document content
// ---------------------------------------------------------------------------
const children = [
  // Title block
  new Paragraph({
    spacing: { after: 120 },
    children: [
      new TextRun({ text: "dnata", bold: true, size: 56, color: NAVY }),
    ],
  }),
  new Paragraph({
    spacing: { after: 60 },
    children: [
      new TextRun({
        text: "Autonomous Range Planner",
        bold: true,
        size: 44,
        color: NAVY,
      }),
    ],
  }),
  new Paragraph({
    spacing: { after: 480 },
    children: [
      new TextRun({
        text: "Business overview & optimisation deep dive",
        size: 28,
        color: GREY,
      }),
    ],
  }),
  new Paragraph({
    spacing: { after: 60 },
    children: [
      new TextRun({ text: "Prototype v1 · May 2026", color: GREY }),
    ],
  }),
  new Paragraph({ children: [new PageBreak()] }),

  // ---- Section 1
  h1("1. What this application is"),
  execSummary(
    "The Autonomous Range Planner (ARP) decides which products to load on each flight, in what quantities, and exactly where to place each unit in the galley — automatically, in minutes, using the actual cost and revenue economics of every SKU. The planner becomes a reviewer rather than a builder."
  ),
  spacer(),
  para(
    "ARP replaces the spreadsheet-and-experience workflow that range planners use today with a quantitative engine. For any flight, it produces:"
  ),
  bullet("a recommended range (which SKUs, how many units each)"),
  bullet("a 3D pack of every unit into a specific galley drawer position"),
  bullet("a per-SKU cost-to-serve and contribution breakdown"),
  bullet("a side-by-side comparison against any what-if scenario (fuel ±%, load factor, aircraft swap, service-level change)"),
  bullet("a plain-English rationale for every decision, produced by an LLM"),
  spacer(),
  para(
    "The user interface is a single web application with eight pages: Dashboard, Routes, Flights, SKUs, Aircraft, Optimisation, Scenarios, Data Admin, AI Co-Planner, and Crew Feedback. A planner typically starts on the Flights list, opens a flight, clicks Generate Range Plan, reviews the result, then optionally runs a scenario or asks the Co-Planner a question in natural language."
  ),

  // ---- Section 2
  h1("2. Scope of the prototype"),
  callout(
    "All data is synthetic",
    "The application is fully functional but the underlying data is generated, not real. The catalogue contains 140 representative SKUs across 15 categories; the schedule covers two routes (London-Luton ⇄ Ibiza and Tirana ⇄ Geneva); 12 months of sales history (~50,000 transactions) is produced from a fixed-seed demand model that captures seasonality, day-of-week, time-of-day, passenger mix, load factor and stockout effects. Everything is deterministic — re-seeding the database produces the same numbers byte-for-byte. The aim is to demonstrate the planner end-to-end with realistic dynamics, before plugging into live POS, EPR and supplier feeds.",
    AMBER
  ),
  spacer(),
  para("Two routes are modelled with deliberately different characteristics so the engine has to handle real heterogeneity:"),
  spacer(),
  kvTable([
    ["LTN ⇄ IBZ", "Strong summer peak, leisure-heavy, A320 with full ATLAS galley, duty-free permitted on this UK ⇄ EU sector."],
    ["TIA ⇄ GVA", "Bi-modal seasonality (summer + winter ski), mixed leisure/business, A320neo, route-specific regulatory exclusions apply (e.g. customs duty-allowance limits, restricted-category items)."],
  ]),
  spacer(),
  para(
    "Constraints in scope: galley volume and weight, per-drawer weight ceiling, regulatory exclusions, supplier minimum commitments, brand rules (premium adjacency, own-brand share), case-multiple rounding, and a complexity penalty that discourages overly fragmented assortments."
  ),
  para(
    "Out of scope for the prototype: live integrations, multi-airline tenancy, authentication and RBAC, mobile-native crew apps, and production retraining pipelines."
  ),

  // ---- Section 3
  h1("3. The optimisation pipeline"),
  execSummary(
    "ARP runs a three-stage engine for every flight. Stage 1 forecasts demand per SKU using 12 months of history. Stage 2 picks the assortment and quantities that maximise expected contribution subject to all hard and soft constraints. Stage 3 places every unit into a specific galley drawer in 3D. If the physical pack fails, the engine automatically tightens the volume budget and re-runs the selection. Typical end-to-end run time is about one second."
  ),
  spacer(),
  para("The three stages are independent modules connected by a small orchestrator. Each stage has a precise, single responsibility, which makes it easy to swap individual algorithms (e.g. replace the forecaster with a gradient-boosted model) without rewriting the others."),

  h2("3.1 Stage 1 — Demand forecasting"),
  h3("Exec summary"),
  para(
    "For each (flight × SKU) the forecaster outputs three numbers: expected units sold, a pessimistic estimate (p10) and an optimistic estimate (p90). These feed the selection model so it can plan for upside without over-loading for the average case."
  ),
  h3("How it works"),
  para(
    "The forecaster is an empirical-quantile model with Bayesian shrinkage. For every SKU it groups the 12 months of historical sales into bins defined by route, season slot (peak / shoulder / off), time-of-day bucket and day-of-week bucket. Within each bin it computes the empirical mean and variance of units-sold-per-passenger. Bins with few observations are shrunk toward the category-level prior so noisy SKUs do not produce wild forecasts. The bin means are then scaled to the target flight's expected passenger count, which is the single largest demand driver."
  ),
  para(
    "The model is intentionally simple. The full plan specifies a LightGBM-per-category regressor; the prototype demonstrates the engine plumbing with a transparent baseline that planners can sanity-check by hand. The interface is identical, so a more sophisticated model can drop in later without touching the rest of the pipeline."
  ),
  richPara([
    { text: "Service level — ", bold: true },
    { text: "the planner can dial the conservatism of the engine with a single parameter. The default is p70: plan as if the 70th-percentile demand will materialise. Lower values favour leaner assortments; higher values protect against stockouts at the cost of more weight and more potential waste. The selection model uses a service-level-capped demand " },
    { text: "s = expected + z(p) · (p90 − expected)", italics: true },
    { text: " where z is the standard-normal quantile." },
  ]),

  h2("3.2 Stage 2 — Range selection"),
  h3("Exec summary"),
  para(
    "Stage 2 picks the assortment that maximises total expected contribution subject to all the physical, regulatory, commercial and brand constraints. It is the commercial heart of the application: this is where the engine trades off margin against weight, supplier commitments against complexity, and headline revenue against operational simplicity."
  ),
  h3("How it works"),
  para(
    "The selection problem is formulated as a Mixed-Integer Programme and solved with the CP-SAT solver from OR-Tools. CP-SAT was chosen because the problem is genuinely mixed-integer (units must be integers, SKU inclusion is binary, suppliers are binary) and CP-SAT handles all three natively, with proven optimality guarantees and sub-second performance at this scale (~140 SKUs × ~12 drawers)."
  ),
  para("The decision variables are:"),
  bullet("xᵢ — the integer number of units to load for SKU i"),
  bullet("yᵢ — 1 if SKU i is included in the range at all, 0 otherwise"),
  bullet("zⱼ — 1 if any units from supplier j are loaded"),
  spacer(),
  richPara([
    { text: "Objective: ", bold: true },
    { text: "maximise Σᵢ marginᵢ · min(xᵢ, sᵢ) − complexity_penalty(Σyᵢ), where sᵢ is the service-level-capped demand from Stage 1. The min term is the standard newsvendor truncation — loading more than demand earns no extra revenue but still costs weight and handling. The complexity penalty is a piecewise-linear cost on the count of distinct SKUs, calibrated so the engine prefers a focused range over a long tail of one-unit-each curiosities." },
  ]),
  h3("Hard constraints (must hold)"),
  bullet("Total volume ≤ η × galley capacity. The volume utilisation cap η defaults to 0.65, leaving slack for the 3D packer to find a feasible arrangement."),
  bullet("Total gross weight ≤ aircraft Maximum Zero-Fuel-Weight allowance for catering payload."),
  bullet("Regulatory exclusions per route (customs allowances, restricted-category items, destination-specific bans)."),
  bullet("Each included SKU loads at least its minimum economic quantity (no token single units)."),
  bullet("Quantities are rounded to case multiples where the supplier ships only in fixed pack sizes."),
  h3("Soft constraints and bonuses"),
  bullet("Supplier minimum commitments — if a supplier's contract requires at least X units across the period, the engine prefers ranges that meet the commitment; failing it incurs a penalty."),
  bullet("Brand rules — own-brand share targets, premium-adjacency preferences, and category coverage minimums."),
  bullet("Case-multiple soft bonus — rewards quantities that align exactly with case sizes, reducing pick-pack effort."),
  bullet("Complexity penalty — discourages assortments with more than the target SKU count."),
  spacer(),
  para(
    "Crucially, soft constraints are expressed as penalty terms in the objective rather than hard constraints. This keeps the model feasible even when goals conflict (e.g. a strict supplier commitment that would blow the weight budget) and surfaces the trade-off transparently in the output."
  ),
  h3("Why CP-SAT and not a heuristic"),
  para(
    "Heuristics (greedy, genetic, simulated annealing) can solve this size of problem quickly but offer no guarantee of optimality and no diagnostic when the problem is infeasible. CP-SAT proves optimality within seconds at this scale, produces a precise dual bound during the search (so the planner sees how close the solution is to optimal), and returns explicit infeasibility evidence when the constraints cannot be simultaneously satisfied. For a tool that planners are expected to trust over their own intuition, provable optimality matters."
  ),

  h2("3.3 Stage 3 — 3D bin packing"),
  h3("Exec summary"),
  para(
    "Once the assortment and quantities are fixed, Stage 3 decides exactly which drawer each unit goes into and where in the drawer it sits — in three dimensions. This is what turns the abstract range plan into an actionable galley loading sheet."
  ),
  h3("How it works"),
  para(
    "The packer uses an Extreme Point First-Fit Decreasing (EP-FFD) heuristic. Items (SKU units treated as cuboids) are sorted by volume in descending order. Each item is then placed in the first drawer where it fits, at the lowest extreme point that admits it, with all six valid orientations tested per placement. Drawers are the standard ATLAS containers: the Full size (400 × 300 × 280 mm) and the Half size (400 × 300 × 140 mm). Each drawer has a weight ceiling that the packer respects as a hard constraint."
  ),
  para(
    "Every SKU in the catalogue carries its own physical dimensions — length, width and height in millimetres — and a unit weight in grams. The packer reads these directly: a miniature spirit, a wrapped sandwich and a fragrance gift box are represented as differently-sized cuboids, and that is the only geometry the engine sees. The six orientations come from permuting the three dimensions."
  ),
  para(
    "Two simplifications follow from the cuboid model. First, all items are treated as rigid right-angled boxes — there is no concept of soft, crushable, or irregularly shaped packaging (e.g. a triangular Toblerone box is approximated by its bounding cuboid). Second, supplier outer cases and multi-pack wrappers are not modelled separately; each unit is packed individually rather than as part of a case. Both are deliberate prototype simplifications and easy to lift later by adding shape descriptors and pack-hierarchy fields to the SKU record."
  ),
  para(
    "EP-FFD was chosen over a full 3D MILP because the packing problem is much larger than the selection problem (hundreds of unit cuboids vs. ~140 SKU decisions) and exact 3D MILP solvers cannot reliably solve to optimality at that size within the few-second budget the UI needs. EP-FFD is a well-known heuristic with strong empirical performance and is fast enough to support interactive scenario exploration."
  ),
  h3("Soft placement rules"),
  bullet("High-velocity SKUs are biased toward the front, easily accessible drawers."),
  bullet("Fragile items are biased toward the top of drawers and given padding margins."),
  bullet("Tobacco and alcohol are placed in lockable drawers."),
  bullet("Bundle SKUs (meal-deal pairings) are co-located in the same drawer where possible."),
  bullet("Food and non-food items are kept separated."),
  h3("Infeasibility loop"),
  para(
    "If the packer cannot fit the chosen assortment into the galley (typically because the items are an awkward shape mix even though they fit the volume budget on paper), the orchestrator tightens the Stage 2 volume cap by 7 percentage points and re-runs Stage 2, then re-runs the pack. It will iterate up to three cycles before reporting a partial pack. In practice this loop is rarely invoked — Stage 2's default 0.65 utilisation cap leaves enough slack."
  ),

  h2("3.4 The cost-to-serve model"),
  execSummary(
    "Every range decision is scored on its true economic contribution, not just shelf margin. ARP attributes fuel, handling, pick-pack labour, waste risk and CO₂ to each SKU so the optimiser optimises the right number."
  ),
  spacer(),
  para("The per-SKU cost-to-serve breakdown includes:"),
  bullet("Cost of goods (supplier price net of rebates)"),
  bullet("Fuel cost attributed by weight × route distance × per-aircraft burn coefficient"),
  bullet("Pick-pack labour cost (per-unit and per-SKU components)"),
  bullet("Handling and complexity overhead"),
  bullet("Expected waste cost (probability of unsold × cost of goods, for perishables)"),
  bullet("CO₂ kilograms (jet fuel factor of 3.15 kg CO₂ per kg fuel)"),
  spacer(),
  para(
    "Net contribution per SKU = expected revenue − cost of goods − attributed operational costs. This is the number the optimiser maximises. It is why a higher-margin product can still be excluded if it is too heavy for its slot in the demand curve, and why a low-margin staple can be loaded heavily if its low weight and predictable demand make it net-positive."
  ),

  // ---- Section 4
  h1("4. Scenarios and what-if analysis"),
  execSummary(
    "Any optimisation run can be cloned as a scenario with parameter overrides — typically fuel price ±%, load factor, aircraft swap, or service-level target. The scenario is re-solved end-to-end and presented side-by-side with the baseline, with an AI-written summary of the key differences at the top."
  ),
  spacer(),
  para(
    "Scenarios are how planners explore commercial questions like \"what happens if fuel goes up 30%?\" or \"can we still meet our supplier commitments if we cut service level from p70 to p60?\" Each scenario is a first-class object with its own run record, range table, and pack — so scenarios can themselves be compared against each other or saved for later review."
  ),
  para(
    "On opening a scenario comparison, an Azure OpenAI call produces a 3-sentence narrative summary highlighting the most material differences (e.g. \"the +30% fuel scenario shifts the range toward lighter SKUs: average unit weight drops from 142 g to 118 g, four heavy gift items are excluded, and total contribution falls by 4.2% — most of the revenue protection comes from increased loading of high-velocity snacks\"). This makes scenarios immediately readable without the planner having to spot the patterns in the diff table themselves."
  ),

  // ---- Section 5
  h1("5. The AI Co-Planner"),
  execSummary(
    "A natural-language assistant powered by Azure OpenAI sits alongside the planner. It can answer questions about any run (\"why isn't the gin miniature loaded?\"), compare two runs, look up SKU history, and explain individual decisions. It is grounded in the actual database — it does not hallucinate numbers."
  ),
  spacer(),
  para(
    "The Co-Planner uses function-calling: when asked a question, the LLM decides which of four read-only tools to invoke (run summary, SKU explainer, top-SKUs lookup, run-vs-run compare), the tools execute against the live database, and the LLM composes the answer from real query results. Every tool call is shown to the user in the chat trace so the planner can audit how an answer was derived."
  ),
  para(
    "Two additional AI capabilities run automatically without the user asking:"
  ),
  bullet("Auto-rationale — after every optimisation run, the LLM writes a one-sentence \"why\" for each range decision (\"included to meet supplier commitment despite below-average margin\", \"excluded because alternative SKU in same category has 2.4× higher contribution per unit weight\")."),
  bullet("Crew feedback parsing — when cabin crew submit free-text observations (\"the Toblerone always sells out before Ibiza\"), the LLM extracts a structured signal (SKU, signal type, severity) that is surfaced on the Dashboard for the planner to action."),
  spacer(),
  para(
    "All LLM calls are cached in a local SQLite store keyed by prompt hash, and a per-run ceiling of 5 calls prevents runaway cost during scenario exploration. The cache makes repeated runs free and ensures determinism for demos."
  ),

  // ---- Section 6
  h1("6. Technology summary (for the curious)"),
  para(
    "The application is a standard two-tier web app. Nothing in the stack is exotic; everything is industry-standard and well-supported."
  ),
  spacer(),
  kvTable([
    ["User interface", "React with TypeScript, served by Vite. Tailwind CSS v4 for styling against the dnata brand tokens. Phosphor icon set. The 3D galley visualiser uses Three.js via @react-three/fiber."],
    ["Backend service", "Python 3.13 with FastAPI. Single service exposing REST endpoints and Server-Sent Events for live run progress."],
    ["Optimisation", "OR-Tools (CP-SAT) for range selection; in-house Extreme-Point First-Fit Decreasing implementation for 3D packing."],
    ["Forecasting", "In-house empirical-quantile model with Bayesian shrinkage. Designed to be swappable for LightGBM-per-category."],
    ["AI", "Azure OpenAI Service (gpt-5.4 deployment) for chat, rationale, narration, and crew feedback parsing. Function-calling for grounded tool use."],
    ["Data store", "SQLite (local file). Suitable for the prototype; portable to PostgreSQL or Azure SQL without code change because all access is via the SQLAlchemy ORM."],
    ["Deployment", "Local-only for the prototype. The architecture is ready for containerised deployment to Azure App Service or Container Apps when needed."],
  ]),
  spacer(),
  para(
    "There are no proprietary or licensed components in the optimiser. OR-Tools is open-source under a permissive licence. The forecaster and packer are in-house code. The only external service the application talks to is Azure OpenAI."
  ),

  // ---- Section 7
  h1("7. From prototype to production"),
  para(
    "The path from this prototype to a production system has three concrete steps and one organisational dependency."
  ),
  numbered("Replace synthetic data with real feeds — POS for sales history, EPR for the SKU master, supplier portals for case sizes and commitments, OPS for the flight schedule, and live fuel pricing."),
  numbered("Strengthen the forecaster — replace the empirical-quantile baseline with a per-category gradient-boosted model trained on real history, with confidence intervals surfaced in the UI."),
  numbered("Add deployment, authentication and audit — containerise the backend, deploy to Azure (Container Apps or App Service), front it with Entra ID single sign-on, and log every run for compliance."),
  spacer(),
  para(
    "The organisational dependency is governance: who owns the cost parameters, who approves regulatory rule changes, who signs off the supplier commitment matrix. These are not technical questions but they determine how much of the planner's job the engine is actually allowed to automate. The prototype is built so all of these inputs are editable in the Data Admin UI — the engine is policy-agnostic; humans set the policy."
  ),
  spacer(),
  callout(
    "What success looks like",
    "A planner can open a flight, review the recommended range, run two or three scenarios, ask the Co-Planner a clarifying question, and approve the loading sheet — all inside five minutes. The engine handles the arithmetic; the planner makes the judgement calls. That is the workflow this prototype demonstrates today on synthetic data.",
    GREEN
  ),
];

// ---------------------------------------------------------------------------
// Document
// ---------------------------------------------------------------------------
const doc = new Document({
  creator: "dnata ARP",
  title: "dnata Autonomous Range Planner — Business Overview",
  description: "Business-user overview of the dnata Autonomous Range Planner prototype.",
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } }, // 11pt
    paragraphStyles: [
      {
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 36, bold: true, font: "Arial", color: NAVY },
        paragraph: { spacing: { before: 360, after: 200 }, outlineLevel: 0 },
      },
      {
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: NAVY },
        paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 1 },
      },
      {
        id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Arial", color: BLUE },
        paragraph: { spacing: { before: 200, after: 120 }, outlineLevel: 2 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [
          {
            level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
          {
            level: 1, format: LevelFormat.BULLET, text: "-", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 1440, hanging: 360 } } },
          },
        ],
      },
      {
        reference: "numbers",
        levels: [
          {
            level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } },
          },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
        },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: "dnata Autonomous Range Planner — Business Overview",
                  size: 18, color: GREY,
                }),
              ],
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({ text: "Page ", size: 18, color: GREY }),
                new TextRun({ children: [PageNumber.CURRENT], size: 18, color: GREY }),
                new TextRun({ text: " of ", size: 18, color: GREY }),
                new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: GREY }),
              ],
            }),
          ],
        }),
      },
      children,
    },
  ],
});

const outPath = path.join(__dirname, "dnata-arp-business-overview.docx");
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync(outPath, buffer);
  console.log(`Wrote ${outPath} (${buffer.length} bytes)`);
});
