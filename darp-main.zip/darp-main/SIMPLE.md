# dnata ARP — Plain-English Explainer

Three algorithms — plus an explainer step — power the Autonomous Range Planner. Here they are in everyday language.

---

## 1. The Empirical-Quantile Forecaster — "ask the history book"

**The question it answers:** *How many units of each product will sell on this specific flight — or on each leg of a rotation?*

**The simple idea:** Look at what happened on similar flights in the past. Average it. Use that as the prediction.

**How "similar" is defined:** We group every past sale into a bucket described by five things:

- Which route (7 routes — LTN↔IBZ and TIA↔GVA turns, plus the LTN→Malaga→Lanzarote→LTN Canary triangle)
- Which season slot (peak / shoulder / off)
- Time of day (early / morning / afternoon / evening)
- Day-of-week type (weekday / Friday / weekend)
- Which SKU

So a bucket might be *"Friday evening LTN→IBZ in summer peak, Pringles Original"*. The season-slot rule lives in one shared place (`season.py`) so the forecaster and the synthetic-history generator always agree — if they drifted apart, new routes would silently lose their history.

**What we compute per bucket:** average units-sold-per-passenger, plus how much it varies. To forecast a future flight, look up its bucket and multiply by the expected passenger count. For a **rotation** we forecast each leg separately — demand on the Ibiza outbound differs from the return.

**The "Bayesian shrinkage" bit:** If a bucket only has 3 historical sales, that's not enough — the average is noisy. So we **pull (shrink) the estimate toward the category average** (e.g. "snacks sell about X per pax overall"). Lots of data → trust the bucket. Little data → trust the category.

**The "quantile" bit:** We don't just output one number. We output:
- `expected` — the average
- `p90` — a pessimistic-loading number (90% chance demand is below this)
- `p10` — an optimistic-loading number

The optimiser uses `p90` to avoid stock-outs.

**Why it's good:** Fast, fully deterministic, easy to explain. Why it's basic: it can't capture complex interactions the way a tree-based model (LightGBM) would. It's a swappable first version.

---

## 2. MILP — "the constrained shopping list"

**MILP = Mixed-Integer Linear Programme.** Think of it as a very strict shopping optimiser.

**The question it answers:** *Out of 140 possible products, which ones do we load, and how many of each, to make the most **profit** — not just revenue — without breaking any rules?*

**The "linear programme" bit:** We write down:
1. **An objective** — a number to maximise. The honest version of "profit" here is the brief's *cost-to-serve*:
   *(margin on the units we expect to sell)*
   *− (fuel cost of carrying them — and for a rotation, carrying any unsold stock onto every onward leg)*
   *− (handling: pick cost scaled by the warehouse zone, plus surcharges for authorised-pick and bonded items)*
   *− (spoilage: the slice of cost you lose if a short-shelf-life item goes unsold)*
   *− (returns handling on unsold stock)*
   *− (penalties: a complexity charge per product line, an extra charge for "low-return" lines that barely earn their keep, and a charge for breaking a supplier case)*
   The fuel term is what makes the model **sell early**: stock sold on leg 1 isn't carried — and burned for — on legs 2 and 3.
2. **Constraints** — rules nothing is allowed to break:
   - Total volume must fit in the galley drawers (with a 65% efficiency safety margin)
   - Total weight must be under the aircraft's allowance
   - Regulatory bans (e.g. no tobacco)
   - If we load a SKU at all, we must load at least its minimum economic quantity
   - You can't sell more than you loaded (summed across all legs)
   - Supplier minimum commitments and brand rules (e.g. "at least N premium drinks") — these become *soft* (a penalty rather than a hard wall) when a planner pins SKUs, so an override can never make the problem impossible

**The "mixed-integer" bit:** Some decisions are whole numbers, not fractions:
- `x_i` = how many units of SKU *i* to load (whole units, you can't load 3.7 cans). Loaded **once**, at the rotation's origin.
- `y_i` = 1 if SKU *i* is loaded at all, 0 otherwise
- `s_{k,i}` = how many units of SKU *i* we expect to sell **on leg k** (this is what spreads sales across a rotation)

A single flight is just a one-leg rotation, so there's only ever one piece of solver code. Google's **CP-SAT solver** (part of OR-Tools) handles the on/off decisions.

**Planner overrides:** a planner can *pin* a SKU — force it in, force it out, or fix its quantity — and we re-solve everything else around the pin. We check up front that the pinned items actually fit (weight and volume) before bothering the solver.

**The output:** For every SKU, a decision: **load / reduce / exclude**, the exact quantity, the per-leg sales, and its **net contribution per kg and per cm³** — the brief's headline metric for "is this product worth its space and weight?"

**Why it's good:** It finds the *provably best* answer given the rules, not just a reasonable one. It handles dozens of competing constraints simultaneously — something a human planner can't do by hand.

---

## 3. EP-FFD — "stack the suitcases in the boot"

**EP-FFD = Extreme-Point First-Fit Decreasing.** It's a packing heuristic — a fast, smart way to fit cuboid items into cuboid bins.

**The question it answers:** *Given 350 individual units chosen by the MILP, exactly where in which drawer does each one physically go?*

**The simple idea:** Pack one item at a time. Always try the biggest, highest-priority items first. Place each one into the lowest, deepest, leftmost spot where it actually fits.

**The "First-Fit Decreasing" bit:**
- **Decreasing** = sort items by importance first. We sort by sales velocity (popular items go in first, into the easiest-to-reach drawers), with volume as a tiebreaker.
- **First-Fit** = for each item, try drawers in order and drop it in the first one that has room.

**The "Extreme-Point" bit (the clever part):** Where exactly inside a drawer do you put the next box? You can't try every possible position — that's billions of options. EP keeps a small list of **candidate corners** (extreme points). Initially there's one: the bottom-back-left corner `(0,0,0)`. When you place a box of size *(l, w, h)* at a corner, three new corners are born: one along each axis where the new box ends. The packer always tries the lowest, then frontmost, then leftmost candidate corner that fits.

**Extra rules it respects:**
- **Orientation:** by default we lay each item with its smallest dimension vertical (flattest packing); fragile items marked "upright only" keep their height axis.
- **Weight ceiling:** each drawer has a hard kg limit — no exceptions.
- **Soft preferences:** high-velocity items → front drawers; tobacco/alcohol → locked drawers; fragile → top.

**The output:** For every single unit, its drawer ID and `(x, y, z)` position plus orientation. That's what the 3D visualiser renders.

**Why it's good:** It's fast (milliseconds for 350 units), deterministic, and produces realistic packings. A full mathematical optimum would be slow; EP-FFD gets you 90–95% of the way for a tiny fraction of the time.

---

## 4. The Explainer — "why every product got the decision it did"

**The question it answers:** *For each of the 140 SKUs — including the ones we rejected — why?*

**The simple idea:** Once the MILP has decided, a separate pass looks at the numbers behind each decision and assigns a **reason code** — a short, honest label drawn from the solver's own inputs and outputs. No AI guessing; the same inputs always give the same reason.

**Some of the labels it can assign:**
- *regulatory ban* — not allowed on this route
- *no demand* — the history says basically nobody buys it here
- *loss-making* — it costs more to carry and handle than its margin earns
- *spoilage risk* — short shelf life makes the expected waste outweigh the margin
- *low-return pickline* — it earns too little to justify opening a warehouse pick line for it
- *displaced (on volume / weight)* — it's profitable, but other products earn more **per cm³ / per kg**, and space ran out. Here we also name the product that beat it — a **suggested substitute**.
- *trimmed to fit*, *case rounding*, *case-efficient*, *strong demand*, *pinned in / out* — and so on.

**Two extra things it produces:**
- **Constraint stress** — which limits are actually *binding* the plan (e.g. "drawer volume 99.6% full" vs "weight only 29% used"), so a planner can see what's holding the range back.
- The brief's **net contribution per kg and per cm³** for every SKU, so "is this worth its space?" is answerable at a glance.

**The AI layer on top:** when Azure OpenAI is configured, it rewrites the top few reason codes into fluent prose — but it's only allowed to *phrase* the reason the solver already computed, never to invent a different one.

**Why it's good:** it satisfies the brief's demand for a *"why excluded" rationale for rejected SKUs* — for **every** SKU, not just a favoured dozen — and it does so deterministically, so planners can trust it.

---

## How they fit together

```
History ─► Forecaster ─► expected demand per SKU, per rotation leg
                                       │
                                       ▼
                                  MILP solver ─► which SKUs, how many, per-leg sales
                                       │
                                       ├─► Explainer ─► a reason for every SKU + binding constraints
                                       ▼
                                  EP-FFD packer ─► exact 3D placement
```

If the packer can't physically fit what the MILP chose, we tighten the volume safety margin and re-run the MILP (up to 4 times, keeping any planner pins). A planner can then **override** the result (pin SKUs and re-optimise), **approve** one plan per flight, and if the aircraft is swapped the approved plan is automatically **re-checked** against the new galley. That's the whole pipeline.
