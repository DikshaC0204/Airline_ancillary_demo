# dnata Autonomous Range Planner — Prototype Plan

**Document type:** Engineering & design plan for a working prototype
**Status:** Draft v0.1
**Scope:** Single-machine prototype, two easyJet routes (LTN→IBZ, TIA→GVA), synthetic data, Azure OpenAI enabled
**Companion docs:** Project brief (PDF), kick-off transcript, brand guidelines (to follow)

---

## 1. Vision

Build a working prototype of the **dnata Autonomous Range Planner (ARP)** that, given a flight, recommends the **most profitable, executable, physically packable range of in-flight retail SKUs** — and explains *why* every decision was made.

The prototype is intentionally **inspirational**: it shows the full vision (commercial optimisation + 3D packing + cost-to-serve + AI co-planner) on two real easyJet routes, using synthetic data that can later be swapped for live feeds without rework.

The single hardest, most differentiating piece — and the one we put the most effort into — is the **optimisation engine**.

---

## 2. Prototype Scope

### In scope
- Two routes operated by easyJet:
  - **LTN → IBZ** (London Luton → Ibiza): ~1,450 km, ~2h25, A320, leisure-heavy, summer-peaked
  - **TIA → GVA** (Tirana → Geneva): ~1,300 km, ~2h05, A320neo, mixed diaspora/business
- Full synthetic data set (SKUs, sales history, passenger mix, aircraft, fuel coefficients)
- End-to-end optimisation: SKU selection + quantities + cart/drawer packing
- Net-contribution objective (revenue – COGS – fuel – pick/pack – handling – complexity – waste)
- 3D bin-packing into ATLAS / Half-ATLAS drawers with packing rules
- Web UI for: dashboard, input-data browser, run optimisation, view recommendations, 3D pack visualiser, scenarios, AI co-planner chat
- Explainability for every SKU decision (include / reduce / increase / exclude + reason)

### Out of scope for the prototype
- Live integrations with catering / POS / inventory systems (stubbed)
- Multi-airline / fleet-wide rollout
- Production-grade auth, RBAC, audit logging
- Continuous retraining pipelines (offline retrain only)
- Mobile-native apps

### Phasing inside the prototype
Per the kick-off discussion (Alaa: *"test one route … take it from there"*), the build is staged so we can demo value at each step:

| Stage | What's working | Demo value |
|---|---|---|
| **P0 – Data spine** | Synthetic data + UI to browse it | "Look at the world we've modelled" |
| **P1 – Core optimiser** | SKU selection + quantities, basic capacity constraints, one route | "It picks a profitable range" |
| **P2 – Volumetric + packing** | 3D bin-packing into drawers, packing rules, visualiser | "It packs the cart for you" |
| **P3 – Cost-to-Serve** | Fuel, pick/pack, handling, complexity penalty, net contribution | "It thinks like a P&L" |
| **P4 – AI Co-Planner** | Chat, scenario narration, cold-start, free-text crew feedback | "Talk to the plan" |

The transcript suggests fuel modelling is "future" — we keep it in **P3** and ship P1–P2 first as the MVP demo, but the architecture supports it from day one.

---

## 3. Architecture & Tech Stack

### Tech choices and why

| Layer | Choice | Why |
|---|---|---|
| Backend | **Python 3.11 + FastAPI** | Best ecosystem for OR / ML / Azure OpenAI; FastAPI gives typed APIs cheaply |
| Optimisation | **Google OR-Tools** (CP-SAT + 3D packing) | State-of-the-art, free, handles both MILP-style selection and bin packing |
| Forecasting | **LightGBM + statsmodels** | Lightweight, accurate enough for synthetic data; explainable via SHAP |
| Database | **SQLite** (via SQLAlchemy) | Per requirement; single file, easy to ship/reset |
| AI services | **Azure OpenAI** (GPT-4-class + embeddings) | Per requirement; used for narration, cold-start, chat |
| Frontend | **Next.js 14 (App Router) + TypeScript** | Modern, fast, easy to skin with brand guidelines |
| Styling | **TailwindCSS + shadcn/ui** | Composable, themable to dnata brand once guidelines arrive |
| Charts | **Recharts** + **Tremor** | Dashboard-quality out of the box |
| 3D viz | **react-three-fiber** (Three.js) | Drawer / cart packing visualisation |
| State / data | **TanStack Query** + **Zustand** | Server cache + lightweight client state |

### Component diagram (logical)

```
┌──────────────────────────────────────────────────────────────┐
│                    Next.js Frontend (UI)                     │
│  Dashboard · Data Browser · Optimisation · Packing 3D · Chat │
└───────────────────────────┬──────────────────────────────────┘
                            │  REST / SSE
┌───────────────────────────▼──────────────────────────────────┐
│                     FastAPI Backend                          │
│  ┌────────────┐  ┌──────────────┐  ┌────────────────────┐    │
│  │   API      │→│ Optimisation │→│   Forecasting       │    │
│  │  layer     │  │   Engine     │  │   (LightGBM)        │    │
│  └─────┬──────┘  └──────┬───────┘  └──────────┬──────────┘    │
│        │                │                     │               │
│        │         ┌──────▼──────┐       ┌──────▼───────┐       │
│        │         │ 3D Packing  │       │   Cost-to-   │       │
│        │         │  (OR-Tools) │       │   Serve calc │       │
│        │         └─────────────┘       └──────────────┘       │
│        │                                                      │
│        │         ┌────────────────────────────────────┐       │
│        └────────►│   Azure OpenAI Service Wrapper     │       │
│                  │  (chat, rationale, cold-start)     │       │
│                  └────────────────────────────────────┘       │
└───────────────────────────┬──────────────────────────────────┘
                            │
                  ┌─────────▼─────────┐
                  │  SQLite database  │
                  └───────────────────┘
```

### Runtime
- Single dev laptop, two processes: `uvicorn` (API) on `:8000`, `next dev` on `:3000`
- One `docker-compose.yml` for reproducibility (optional)
- A `make seed` task regenerates the synthetic database deterministically (fixed RNG seed)

---

## 4. Data Model (SQLite)

Schemas below are the prototype shape. They're intentionally close to what a future Fabric / Synapse model would look like so migration is straightforward.

### Core entities

```sql
-- Products
sku(
  id, code, name, category, sub_category, brand,
  unit_weight_g, length_mm, width_mm, height_mm, volume_cm3,
  packaging_type, stackable, max_stack_height,
  fragility_score, orientation_constraint,    -- 'upright_only' | 'any'
  shelf_life_days, hazard_class,              -- 'alcohol' | 'tobacco' | 'none' | ...
  cost_price, retail_price, margin_pct,
  supplier_id, min_pack_size, case_size,
  bonded, requires_authorised_pick,
  image_url
)

supplier(id, name, min_commitment_units_per_month, ...)

-- Routes & flights
route(
  id, origin_iata, dest_iata, distance_km,
  flight_duration_min, haul_class,            -- 'short' | 'medium' | 'long'
  duty_free_allowed, alcohol_allowed, tobacco_allowed,
  seasonality_profile_json
)

flight(
  id, route_id, flight_no, scheduled_dt,
  aircraft_id, expected_pax, expected_load_factor,
  pax_mix_json,                               -- {business:0.1, leisure:0.85, ...}
  cabin_config_json
)

-- Aircraft & galley
aircraft(
  id, registration, type,                     -- 'A320' | 'A320neo'
  retail_galley_layout_id,
  empty_weight_kg, max_payload_kg,
  fuel_burn_coeff_short, ..._medium, ..._long
)

galley_layout(id, aircraft_type, num_retail_carts, schematic_json)

cart(id, galley_layout_id, position_code, cart_type)  -- 'full' | 'half'

drawer(
  id, cart_id, slot_index,
  type,                                       -- 'ATLAS_full' | 'ATLAS_half' | 'box'
  internal_l_mm, internal_w_mm, internal_h_mm,
  max_weight_kg, accessibility_score          -- 1=best, 5=worst (back of cart)
)

-- Historical sales (synthetic for prototype)
sale(
  id, flight_id, sku_id, units_sold, revenue,
  unsold_units, returned_units, sold_at_minute_of_flight
)

-- Costs
cost_params(
  id, valid_from, fuel_price_per_kg_gbp,
  pick_cost_per_unit_gbp, pack_cost_per_drawer_gbp,
  cart_assembly_cost_gbp, return_handling_cost_per_unit_gbp,
  complexity_penalty_per_new_pickline_gbp
)

-- Rules & constraints
regulatory_rule(id, route_id, sku_category, rule_type, parameters_json)
brand_rule(id, category, min_skus, min_units, max_share_pct)
supplier_commitment(id, supplier_id, sku_id, min_units_per_flight)

-- Optimisation runs
optimisation_run(
  id, flight_id, created_at, status, objective_value,
  total_weight_kg, total_volume_cm3, total_skus, total_units,
  expected_revenue, expected_net_contribution,
  parameters_json, scenario_label
)

range_decision(
  id, optimisation_run_id, sku_id,
  decision,                                   -- 'load' | 'increase' | 'reduce' | 'exclude'
  loaded_qty, expected_sales, expected_margin,
  fuel_cost, pick_pack_cost, complexity_cost, net_contribution,
  rationale_text                              -- LLM-generated explanation
)

drawer_assignment(
  id, optimisation_run_id, drawer_id, sku_id, units, position_xyz_json
)

scenario(id, name, description, parameters_json, created_at)
crew_feedback(id, flight_id, sku_id, free_text, structured_json, created_at)
```

### Relationships, briefly
- `flight` ↔ `aircraft` ↔ `galley_layout` ↔ `cart` ↔ `drawer`
- `optimisation_run` produces many `range_decision` and many `drawer_assignment`
- `sale` is the only large table (~50k rows for 12 months × 2 routes × ~150 SKUs)

---

## 5. Synthetic Input Data

All data is generated by a single `seed.py` with a fixed RNG seed so the database is reproducible.

### SKUs (~140 total)

| Category | Count | Example SKUs | Weight range | Notes |
|---|---|---|---|---|
| Spirits (miniatures) | 12 | Gordon's 50ml, Jack Daniel's 50ml | 50–80g | High margin, regulatory flags |
| Spirits (full size) | 8 | Whisky 1L, Vodka 70cl | 1.2–1.9kg | High margin, heavy, bonded |
| Wine | 8 | Mini Prosecco, Red 187ml | 250–350g | |
| Beer & cider | 10 | Heineken 330ml, BrewDog can | 350g | |
| Soft drinks | 14 | Coke, Diet Coke, water, juices | 200–550g | High-volume movers |
| Hot drinks | 6 | Coffee pods, tea | 5–15g | |
| Snacks (savoury) | 14 | Pringles tube, nuts, pretzels | 30–200g | |
| Snacks (sweet) | 12 | Cadbury, Mars, M&Ms | 40–250g | |
| Sandwiches & wraps | 10 | Various, refrigerated | 180–250g | Shelf life < 2 days |
| Hot meals | 6 | Pasta, breakfast box | 250–350g | |
| Fragrance & cosmetics | 14 | Mini fragrance 30ml, lipstick | 50–250g | High margin, low weight |
| Sunglasses & accessories | 8 | RayBan, scarves | 30–200g | High value, fragile |
| Gifts & travel essentials | 10 | Gift sets, travel adapters | 200–600g | Bulky |
| Tobacco | 4 | Marlboro 200s (where allowed) | 200g | Bonded, route-restricted |
| Children | 4 | Activity packs, snacks | 100g | |

Each SKU gets realistic dimensions, packaging, stackability, fragility, hazard class, supplier, margin (10–60%), case size, etc.

### Aircraft & galley

- **A320** (LTN→IBZ): 1 retail trolley × 8 ATLAS drawers + 1 half-trolley × 4 half-ATLAS drawers
- **A320neo** (TIA→GVA): same layout, slightly different burn coefficients

Drawer internal dims per the brief: Full ATLAS ~400×300×280mm; Half ATLAS ~400×300×140mm; ATLAS Box ~405×301×273mm.

### Sales history (synthetic, 12 months × 2 routes)

Generated by a model that mixes:
- Base demand per SKU per route (lognormal)
- Seasonality (summer spike for LTN→IBZ, winter ski bump for TIA→GVA via Geneva)
- Day-of-week / time-of-day effects (morning = coffee + snacks, evening = alcohol)
- Pax-mix sensitivity (leisure routes skew alcohol/snacks; business skews premium coffee, sandwiches)
- Load factor effects (sub-linear: a 90% full flight sells ~1.5× a 60% one)
- Promotion uplifts (random promo windows)
- Stockouts (capped at loaded qty)
- Noise

Output is `sale` rows realistic enough to train a forecaster and exercise the optimiser. The seed file ships baseline ranges (today's manual plan) for each route so the optimiser has a benchmark to beat.

### Passenger mix
- LTN→IBZ summer: 5% business, 90% leisure (group/family-heavy), 5% other
- LTN→IBZ winter: 15% business, 75% leisure, 10% other
- TIA→GVA: 25% business, 50% diaspora/VFR, 20% leisure, 5% other

### Cost parameters (defaults, editable in UI)
- Fuel price: £0.82/kg
- Burn coefficient: per-aircraft × per-haul matrix (see brief slide 18)
- Pick cost: £0.08/unit baseline, +£0.30/unit for bonded, +£0.50/unit for authorised-pick
- Cart assembly: £4.50 per cart
- Return handling: £0.15/unit, £1.00/unit for bonded
- Complexity penalty: £2.00 per new pick-line below an expected-revenue threshold

---

## 6. The Optimisation Engine — the heart of the prototype

This is the single most important piece. It runs in three stages and is designed so each stage can be swapped or upgraded without touching the others.

### 6.1 Stage 1 — Demand forecasting

For each `(flight, sku)` produce:
- `expected_units_sold` (mean)
- `p10`, `p90` (uncertainty band, drives safety stock)

Model: **LightGBM regressor** per category, features include:
- Route, haul class, distance, duration
- Day-of-week, month, holiday flag
- Expected pax, load factor, pax-mix vector
- Aircraft type
- Historical SKU-route mean and trend
- Cross-SKU substitution signals (top-k correlated SKUs)

Cold-start handling (new SKU or new route):
- Look up nearest neighbours in an **embedding space** of (route × category × pax-profile) using Azure OpenAI embeddings
- Borrow demand pattern from neighbours, scaled by relative volume
- Mark forecast as `cold_start=True` so the UI can flag it

### 6.2 Stage 2 — Range selection (the main MILP)

A mixed-integer programme solved with **OR-Tools CP-SAT** (handles 150 SKUs × ~12 drawers in seconds).

**Decision variables**
- `x_i ∈ ℤ₊` — units of SKU `i` loaded on the flight
- `y_i ∈ {0,1}` — whether SKU `i` is in the range at all
- `z_j ∈ {0,1}` — whether drawer `j` is used

**Objective — maximise net contribution**

```
maximise   Σᵢ ContribPerUnit(i) · min(xᵢ, p90ᵢ · Pax)
         − Σᵢ xᵢ · UnitWeight(i) · FuelBurnCost(aircraft, distance)
         − Σᵢ xᵢ · PickCost(i)
         − Σⱼ zⱼ · CartAssemblyCost
         − Σᵢ E[Returnsᵢ] · ReturnHandlingCost(i)
         − ComplexityPenalty(range)
```

where `ContribPerUnit(i) = RetailPrice(i) − CostPrice(i)` and `E[Returnsᵢ] = max(0, xᵢ − E[salesᵢ])`.

The `min(xᵢ, p90ᵢ · Pax)` is linearised by an auxiliary variable `sᵢ ≤ xᵢ` and `sᵢ ≤ p90ᵢ · Pax`, which captures "you can only sell what you load *and* what passengers want".

**Constraints**
- Total volume: `Σᵢ xᵢ · Volume(i) ≤ AvailableVolume · PackingEfficiency` (η ≈ 0.65 for mixed packaging)
- Total weight: `Σᵢ xᵢ · UnitWeight(i) ≤ MaxRetailPayload`
- Per-drawer placeholder constraints (resolved in Stage 3)
- Regulatory: `xᵢ = 0` if SKU disallowed on this route (e.g. tobacco TIA→GVA)
- Supplier minimums: `xᵢ ≥ Mᵢ · yᵢ` for committed SKUs
- Brand rules: minimum SKU count per category, max share of any one brand
- Minimum efficient load: if `yᵢ = 1` then `xᵢ ≥ MinEconomicQty(i)` to avoid 1-unit pick lines
- Case multiples: prefer (soft constraint via objective bonus) loading in case multiples

**Complexity penalty (soft, in objective)**

A piecewise penalty that grows with:
- number of distinct SKUs above a threshold (e.g. 80)
- number of SKUs below their case size
- number of SKUs across different warehouse zones (zone is a SKU attribute)
- number of bonded/authorised-pick SKUs (capacity ceiling)

This is the mechanism that prevents the "long-tail" range the brief warns about (slide 13).

### 6.3 Stage 3 — 3D bin packing into drawers

Once Stage 2 gives a target `(SKU, qty)` set, Stage 3 places units into specific drawers under physical and operational rules.

Algorithm: **constraint-programming 3D bin packing** in OR-Tools, with the following twists:

- Each unit is a cuboid with `(L, W, H)`; orientation constrained by `orientation_constraint`
- Drawers are bins with their own `(L, W, H)`
- Soft preferences (in objective):
  - High-velocity SKUs in low-`accessibility_score` drawers
  - Fragile items not under heavier items (vertical-stacking constraint)
  - Tobacco/alcohol/high-value in secured drawers
  - Bundle SKUs co-located
  - Category separation (food vs non-food)
- Hard rule: `Σ unit weights in drawer ≤ drawer.max_weight_kg`

If Stage 3 is infeasible (Stage 2 over-promised on volume due to packing inefficiency), the run feeds a **tighter `η`** back into Stage 2 and retries — up to 3 cycles before reporting a partial solution.

### 6.4 Cost-to-Serve calculator

Wrapped as a pure function `net_contribution(decision, flight) -> Breakdown`, callable from the optimiser, the UI, and the AI co-planner. Returns a structured breakdown:

```
{
  expected_revenue, cogs, gross_margin,
  fuel_cost, fuel_kg, co2_kg,
  pick_cost, pack_cost, cart_assembly_cost,
  return_handling_cost, complexity_cost,
  opportunity_cost_of_space,
  net_contribution,
  contribution_per_kg, contribution_per_cm3
}
```

This drives both the **decision rationale** displayed in the UI and the **comparison view** between scenarios.

### 6.5 Why not pure ML?

ML alone can't honour hard physical/regulatory constraints. ML alone also can't *guarantee* the cart will pack. The hybrid (forecast → optimise → pack) is both more trustworthy to commercial teams (explainable) and more correct (constraint-respecting). The ML piece is bounded to the part it's best at — predicting demand.

### 6.6 Performance target on dev laptop
- Stage 1 (forecast a flight): < 1 s (model pre-trained)
- Stage 2 (MILP, ~150 SKUs): < 10 s
- Stage 3 (3D pack, ~12 drawers): < 15 s
- Total cold run: < 30 s; warm re-run after parameter tweak: < 10 s

---

## 7. Azure OpenAI — where AI shines

Used as a **layer on top** of the deterministic optimiser, never as a replacement. Six concrete use cases:

1. **Auto-generated rationale per SKU**
   For every `range_decision`, generate a 1-sentence "why" using the structured Cost-to-Serve breakdown as input. Examples:
   > *"Increased to 18 units — high-margin (£14), low-weight (200g), and demand on summer Ibiza flights is 35% above current load."*
   > *"Excluded — bulky (1.8L) gift set displaces 6 higher-contribution SKUs and shows weak sell-through on 2h sectors."*

2. **Conversational AI Co-Planner**
   Chat panel beside any optimisation run. Backed by **function calling** — the LLM can call `recompute_with(parameters)`, `compare_scenarios(a, b)`, `explain_sku(sku_id)`, `lookup_history(sku_id, route_id)`. Lets a planner ask:
   - *"Why isn't the gin miniature in the plan?"*
   - *"What if fuel jumps 30%?"*
   - *"Make this range more premium without losing more than 5% revenue."*
   - *"Compare this to last summer's actual."*

3. **Cold-start demand synthesis**
   For a new SKU with no history, the LLM is given (a) the new SKU's attributes, (b) the 5 nearest neighbours in embedding space with their sales curves, and (c) the route. It returns a structured prior demand profile that seeds the forecaster.

4. **Free-text crew feedback → structured insights**
   Crew often note things like *"ran out of fresh sandwiches by row 12"* or *"no one wants the large perfume on Ibiza"*. The LLM parses these into structured `crew_feedback` rows (sku_id, signal_type, severity), which feed back into next planning cycle and surface as **insight cards** on the dashboard.

5. **Scenario narration**
   When a user runs a what-if, the LLM produces a 3-bullet executive summary: what changed, why net contribution moved, what to watch.

6. **Natural-language scenario builder**
   *"Show me a range optimised for a wide-body charter to Ibiza with 95% load factor and a 20% fuel-price spike"* → parsed into structured parameters → optimiser runs → results returned.

### Safety / cost
- All LLM calls are server-side; the UI never talks to Azure OpenAI directly
- Calls are cached by (prompt-hash, model) in SQLite to keep cost flat during demos
- Hard ceiling: no more than 5 LLM calls per optimisation run by default

---

## 8. UI / User Journeys

Information architecture only — visual styling will be applied once brand guidelines arrive.

### Pages

1. **Dashboard** *(landing)*
   The brief's screenshot is the north-star: top-line KPIs (service level, revenue, waste reduction, cost saving), constraint utilisation bars (weight / volume / energy / budget), best/worst routes, recommended changes, AI insight cards. Map of routes (Leaflet) with the two prototype routes lit up.

2. **Routes**
   List of routes; detail page per route shows: schedule, aircraft used, historical demand patterns, seasonality, passenger mix, regulatory flags.

3. **Flights**
   Upcoming flights table. Click into a flight → flight detail with all inputs (pax forecast, aircraft, galley layout) and a big **"Generate Range Plan"** button.

4. **SKU Catalogue**
   Card grid with filter/search. Each SKU shows dimensions, weight, margin, packaging, hazard, shelf life, supplier, an image. Editable for the prototype so demos can play "what if we added X".

5. **Aircraft & Galley**
   Pick an aircraft → see its galley layout schematically with each cart and drawer. Click a drawer → see dimensions and current default contents.

6. **Optimisation Run**
   Big button → progress states (forecasting → optimising → packing). Result view:
   - Header KPIs (revenue, net contribution, weight, volume utilisation, CO₂)
   - **Range table** with decision (load/increase/reduce/exclude), qty, weight, contribution, rationale
   - **Constraints panel** showing which constraints bind
   - **Diff vs current plan** (the synthetic baseline)
   - "Open in 3D" → packing visualiser

7. **Packing Visualiser** *(creative differentiator)*
   3D rendering (react-three-fiber) of the retail cart, with drawers that slide open. Each SKU rendered as a coloured cuboid in its placed position. Toggle views: by category, by velocity (heat colours), by weight. Click a unit → see the SKU.

8. **Scenarios**
   Side-by-side comparison panel. Define a scenario (fuel price, load factor, aircraft swap, range size cap) and compare against base. The scenario narration from Azure OpenAI sits at the top.

9. **AI Co-Planner**
   Persistent chat drawer accessible from anywhere. Conversation is bound to the currently open flight or run.

10. **Data Admin / Inputs Browser**
    Per the requirement to *"see the created input data"*. Tables for SKUs, Routes, Flights, Aircraft, Sales history, Cost parameters, Regulatory rules. All editable for demo flexibility, with a **"Reset to seed"** button.

### Key UX principles
- Every number is hover-explainable (tooltip → breakdown)
- Every decision is overridable (the brief calls this out — "override capability for commercial teams")
- Nothing is a black box: there is always a "Why?" link next to any AI- or optimiser-generated value

---

## 9. Creative Features (for inspiration & demo wow)

Things that aren't strictly required but elevate the prototype from "working" to "exciting":

- **Range DNA strip** — a single horizontal bar showing the range's category mix, weight mix, and margin mix. One glance tells you whether the range is "premium-light" or "volume-heavy".
- **Cart packing animation** — when an optimisation finishes, the 3D viz animates units flying into their drawers. Genuinely fun in demos.
- **"Beat the baseline" delta** — every run shows £ uplift vs the current manual plan, large and prominent.
- **Sustainability badge** — total CO₂ savings vs baseline; route-level CO₂-per-£.
- **Voice mode for the AI Co-Planner** — Whisper STT + TTS for hands-free demo flavour.
- **Replay timeline** — scrub through how the range would have evolved across a summer season.
- **"Crew sees" view** — render the cart as the cabin crew would see it (drawer top-down, with high-velocity items highlighted).
- **Confidence cones** — every forecast shown with a p10–p90 cone, optimiser uses p70 by default but user can slide.
- **Constraint stress meter** — shows which constraint is closest to binding; nudges planners on what to relax.
- **One-click route cloning** — "copy LTN-IBZ summer plan as a starting point for PMI" (when more routes are added).

---

## 10. Build Phases & Approximate Effort

Plan assumes one full-time senior full-stack engineer plus part-time data/ML support. Times are wall-clock for the prototype only.

| Phase | Duration | Deliverable |
|---|---|---|
| **P0** Data spine + repo + UI scaffold + seed | ~1 week | App boots, all synthetic data visible in Data Admin |
| **P1** Forecaster + Stage 2 MILP + recommendations UI | ~2 weeks | LTN→IBZ produces a profitable range vs baseline |
| **P2** Stage 3 3D packing + visualiser | ~1.5 weeks | Cart packing renders, packing rules honoured |
| **P3** Cost-to-Serve + scenarios + diff view | ~1 week | Fuel + handling + complexity baked in; what-ifs work |
| **P4** Azure OpenAI: rationale + chat + cold-start | ~1.5 weeks | Co-Planner chat, auto rationales |
| **P5** Second route (TIA→GVA), brand styling, polish | ~1 week | Both routes live, dnata brand applied, demo-ready |

Total ≈ **8 weeks** to a polished demo. P1+P2 alone (about 3.5 weeks) is already a credible MVP.

---

## 11. Suggested Project Structure

```
arp/
├─ backend/
│  ├─ app/
│  │  ├─ api/                  # FastAPI routers (flights, runs, chat, ...)
│  │  ├─ models/               # SQLAlchemy ORM
│  │  ├─ schemas/              # Pydantic
│  │  ├─ optim/
│  │  │  ├─ forecast.py        # LightGBM wrapper
│  │  │  ├─ selection.py       # Stage 2 MILP
│  │  │  ├─ packing.py         # Stage 3 3D bin packing
│  │  │  ├─ cost_to_serve.py   # Pure function
│  │  │  └─ engine.py          # Orchestrator
│  │  ├─ ai/
│  │  │  ├─ azure_openai.py    # Client + caching
│  │  │  ├─ rationale.py       # Auto rationale generation
│  │  │  ├─ chat.py            # Co-Planner with function calling
│  │  │  └─ cold_start.py
│  │  └─ seed/
│  │     ├─ skus.py            # ~140 SKUs
│  │     ├─ routes.py          # LTN-IBZ, TIA-GVA
│  │     ├─ aircraft.py
│  │     ├─ sales_history.py   # 12 months synthetic
│  │     └─ run.py             # Idempotent seed entrypoint
│  ├─ tests/
│  └─ pyproject.toml
├─ frontend/
│  ├─ app/                     # Next.js App Router pages
│  ├─ components/
│  │  ├─ packing3d/            # react-three-fiber
│  │  ├─ charts/
│  │  ├─ chat/
│  │  └─ ui/                   # shadcn primitives
│  ├─ lib/
│  └─ package.json
├─ data/
│  └─ arp.sqlite               # Generated; gitignored
├─ docs/
│  ├─ brief.pdf
│  ├─ brand-guidelines.pdf     # (to be supplied)
│  └─ this-plan.md
├─ scripts/
│  ├─ seed.sh
│  └─ reset.sh
├─ docker-compose.yml          # Optional
└─ README.md
```

---

## 12. Open Questions / Decisions to Confirm

Decisions I've made for you (override as you wish):
- **Python + FastAPI backend** (vs Node) — chosen for OR-Tools and Azure OpenAI SDK quality
- **Next.js 14** (vs SPA Vite) — for SSR-friendly demo polish; can downgrade to Vite if you prefer
- **OR-Tools CP-SAT** for both selection and packing — single solver dependency
- **LightGBM** for forecasting — small, fast, explainable
- **Synthetic data deterministic** behind a fixed seed — so demos are reproducible

Questions for you:
1. **Routes** — confirmed: LTN→IBZ, TIA→GVA. Want me to add a third (e.g. LGW→AGP) to demonstrate seasonal contrast?
2. **Aircraft** — assumed A320 (CEO) and A320neo. easyJet also flies A319/A321neo; do you want one of those instead?
3. **Currency** — assumed GBP throughout (easyJet UK base). OK to keep?
4. **Fuel modelling depth** — the transcript suggests fuel is "future" but the user message says optimisation is the absolute key. My plan **includes** fuel from P3. Is that the right call, or do you want it deferred to a v2?
5. **Azure setup** — do you have an existing Azure OpenAI deployment we'll target, or should the prototype assume a local `.env` with key + endpoint + deployment name?
6. **Brand guidelines** — will those land before P5 (brand styling)? If we get them earlier we'll apply them throughout rather than at the end.
7. **3D packing fidelity** — do you want true cuboid 3D packing (slower, slick demo) or 2D-with-layers (faster, less visually dramatic)? My default is true 3D.
8. **Demand uncertainty** — default service-level target is p70 (load enough to cover 70% of demand scenarios). Want me to expose this as a slider in the UI? (Yes, by default.)
9. **Crew feedback** — should the prototype seed some realistic free-text crew comments to demo the LLM ingestion feature? (Yes, by default.)
10. **Deployment** — local dev only, or do you also want an Azure App Service deployment script ready for sharing with stakeholders?

Once you confirm (or override) the above, the next deliverable would be the **P0 implementation**: seeded database, repo scaffold, and Data Admin pages — so you can browse the synthetic world before any optimisation logic lands.
